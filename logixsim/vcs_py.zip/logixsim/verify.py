"""Verify: what of an imported project VirtualControlStudio can and cannot execute.

Like "Verify Controller" in Studio 5000, but answering a different question:
not "is the program valid" but "which parts will the simulator really run, and
which operands look wrong".

    report = verify(controller)
    report["supported"]                 {"XIC": 42, "TON": 3, ...}      (use counts)
    report["unsupported"]               [{instruction, reason, status, count, locations}]
    report["boundary"]                  [{instruction, reason, count, locations}]
    report["routines_not_simulated"]    [{routine, type}]               (FBD, SFC)
    report["parse_errors"]              [{location, error}]
    report["operand_errors"]            [{location, instruction, error}]
    report["missing_tags"]              operands that name no tag
    report["warnings"]                  other things that differ from a controller
    report["summary"]                   programs, routines, rungs, executable_rungs, ...
"""
from __future__ import annotations

import re
from collections import Counter

from .instructions import SPECS
from .isa.catalog import lookup
from .isa.expr import tags_in
from .isa.values import literal
from .ld_interp import instructions
from .model import STRING_TYPES, Controller, TagDB

_ST_CALL = re.compile(r"(?:^|;|THEN|ELSE|DO|\n)\s*([A-Za-z_]\w*)\s*\(", re.IGNORECASE)
_ST_KEYWORDS = {"IF", "ELSIF", "WHILE", "FOR", "CASE", "REPEAT", "UNTIL", "NOT", "AND", "OR",
                "XOR", "ABS", "SQRT", "LN", "LOG", "SIN", "COS", "TAN", "ASIN", "ACOS", "ATAN",
                "TRUNC", "DEG", "RAD", "ATAN2", "MOD"}


# operands an instruction writes besides its "dest" operands (index per mnemonic)
_WRITES = {"OTE": (0,), "OTL": (0,), "OTU": (0,), "ONS": (0,), "OSR": (0, 1), "OSF": (0, 1),
           "COP": (1,), "CPS": (1,), "FLL": (1,), "BSL": (0,), "BSR": (0,), "FFL": (1,),
           "LFL": (1,), "FFU": (0,), "LFU": (0,), "SQL": (0,), "SRT": (0,), "RES": (0,)}
def _sys_simulated(cls, attr, set_=False) -> bool:
    from .isa.system import simulated
    return simulated(cls.strip(), attr.strip(), set_)


_ATOMIC_TYPES = {"BOOL", "SINT", "INT", "DINT", "LINT", "REAL", "STRING",
                 "USINT", "UINT", "UDINT", "ULINT", "LREAL"}


class _Checker:
    def __init__(self, ctrl: Controller, store=None):
        self.ctrl = ctrl
        self.store = store
        self.db = TagDB(ctrl)
        self.aois = {a.upper(): d for a, d in ctrl.aois.items()}
        self.used: Counter = Counter()
        self.unsupported: dict[str, dict] = {}
        self.boundary: dict[str, dict] = {}
        self.operand_errors: list[dict] = []
        self.missing: dict[str, None] = {}

    # ---- tag lookup ---------------------------------------------------------------
    def _scoped(self, scope, op: str) -> list[str]:
        cands = []
        if isinstance(scope, str) and scope:
            cands.append(f"Program:{scope}.{op}")
        cands.append(op)
        return cands

    def tag_type(self, scope, op: str) -> str | None:
        """Data type of an operand, '?' if it exists but cannot be typed statically,
        None if no such tag."""
        op = op.strip()
        if isinstance(scope, dict):                         # inside an AOI
            root = re.match(r"[A-Za-z_]\w*", op)
            if root and root.group().upper() in scope:
                p = scope[root.group().upper()]
                return p.data_type if root.end() == len(op) else "?"
        if "[" in op and not re.fullmatch(r"[^\[]*(\[\d+\])?(\.[^\[]*(\[\d+\])?)*", op):
            root = re.match(r"(Program:[^.]+\.)?[^.\[]+", op)
            if root:
                for cand in self._scoped(scope, root.group()):
                    if self.db.has_tag(self.db.dealias(cand)) or cand in self.db._aliases:
                        return "?"
            return None
        for cand in self._scoped(scope, op):
            try:
                return self.db.data_type(cand)
            except Exception:
                continue
        return None

    # ---- checks ------------------------------------------------------------------
    def add_unsupported(self, name, loc):
        aoi = self.aois.get(name.upper())
        entry = lookup(name)
        if aoi is not None:
            return
        reason = entry["reason"] if entry else "unknown instruction (not in the VirtualControlStudio catalog)"
        status = entry["status"] if entry else "unknown"
        u = self.unsupported.setdefault(name, {"instruction": name, "reason": reason,
                                               "status": status, "count": 0, "locations": []})
        u["count"] += 1
        if len(u["locations"]) < 25:
            u["locations"].append(loc)

    def check_instr(self, name, args, loc, scope, routines) -> bool:
        """Returns True when the instruction will be executed."""
        self.used[name] += 1
        spec = SPECS.get(name.upper())
        aoi = self.aois.get(name.upper())
        if spec is None and aoi is None:
            self.add_unsupported(name, loc)
            return False
        if spec is not None and spec.status == "boundary":
            b = self.boundary.setdefault(spec.mnemonic, {
                "instruction": spec.mnemonic, "reason": " ".join(spec.notes), "count": 0,
                "locations": []})
            b["count"] += 1
            if len(b["locations"]) < 25:
                b["locations"].append(loc)
        if aoi is not None and spec is None:
            self._check_aoi_call(aoi, args, loc, scope)
            return True
        if spec is not None and spec.mnemonic in ("GSV", "SSV") and len(args) >= 3 and \
                not _sys_simulated(args[0], args[2], spec.mnemonic == "SSV"):
            key = f"{spec.mnemonic} {args[0].strip()}.{args[2].strip()}"
            u = self.unsupported.setdefault(key, {
                "instruction": key, "status": "partial", "count": 0, "locations": [],
                "reason": "this object attribute is not simulated (or cannot be set); the "
                          "instruction raises minor fault 4/6 and leaves its operand unchanged"})
            u["count"] += 1
            if len(u["locations"]) < 25:
                u["locations"].append(loc)
            return False
        self._check_operands(spec, args, loc, scope, routines)
        return True

    def _err(self, loc, name, msg):
        self.operand_errors.append({"location": loc, "instruction": name, "error": msg})

    def _check_aoi_call(self, aoi, args, loc, scope):
        params = aoi.call_params()
        if len(args) - 1 != len(params):
            self._err(loc, aoi.name, f"expects the instance tag and {len(params)} argument(s) "
                                     f"({', '.join(p.name for p in params)}), got {len(args)}")
            return
        t = self.tag_type(scope, args[0])
        if t is None:
            self.missing[args[0]] = None
        elif t not in ("?", aoi.name):
            self._err(loc, aoi.name, f"instance tag '{args[0]}' is a {t}, not a {aoi.name}")
        for p, a in zip(params, args[1:]):
            self._operand_tag(aoi.name, a, loc, scope, p.usage == "InOut" or p.usage == "Output")
            cand, decl = self._decl_of(scope, a.strip())
            if decl is not None and getattr(decl, "constant", False):
                if p.usage == "Output":
                    self._err(loc, aoi.name, f"constant tag '{a.strip()}' cannot be passed to the "
                                             f"Output parameter {p.name}")
                elif p.usage == "InOut" and not getattr(p, "constant", False):
                    self._err(loc, aoi.name, f"constant tag '{a.strip()}' can only be passed to a "
                                             f"constant InOut parameter ({p.name} is not constant)")

    def _decl_of(self, scope, a):
        """(address, Tag) of an operand's base tag in this scope, or (None, None)."""
        if not isinstance(scope, str):
            return None, None
        for cand in self._scoped(scope, a):
            root, decl = self.db.declaration_of(cand)
            if decl is not None:
                return cand, decl
        return None, None

    def _check_constant(self, name, a, loc, scope):
        cand, decl = self._decl_of(scope, a.strip())
        if decl is not None and getattr(decl, "constant", False):
            self._err(loc, name, f"'{a.strip()}' is a constant tag; logic cannot change it")

    def _extended(self, name, a, loc, scope, written) -> str | None:
        """``Tag.@Min`` / ``Tag.@Max``: read-only, numeric, defined, not on an alias."""
        base, prop = a.split(".@", 1)
        if written:
            self._err(loc, name, f"'{a}': extended properties cannot be written by logic")
        if prop.strip().lower() not in ("min", "max"):
            self._err(loc, name, f"'{a}': only @Min and @Max can be used in logic")
            return None
        t = self.tag_type(scope, base)
        if t is None:
            self.missing[base] = None
            return None
        if t not in ("SINT", "INT", "DINT", "LINT", "REAL", "?"):
            self._err(loc, name, f"'{a}': limit properties need a SINT, INT, DINT, LINT or REAL tag")
            return t
        root = re.match(r"[A-Za-z_]\w*", base.strip())
        if root and isinstance(scope, str) and any(self.db.is_alias(c) for c in self._scoped(scope, root.group())):
            self._err(loc, name, f"'{a}': extended properties of an alias tag cannot be used in logic")
            return t
        indirect = "[" in base and not re.fullmatch(r"[^\[]*(\[[\d,\s]+\][^\[]*)*", base)
        if self.store is not None and not indirect:
            cand, decl = self._decl_of(scope, base.strip())
            try:
                v = self.store.extended(cand or base, prop.strip().lower())
            except Exception:
                v = None
            if v is None:
                self._err(loc, name, f"'{a}': the @{prop.strip().title()} extended property is not "
                                     "defined for this tag")
        return t

    def _operand_tag(self, name, a, loc, scope, must_be_tag, written=False) -> str | None:
        a = a.strip()
        if not a or a == "?" or a[:2].upper() == "S:":
            return None
        if ".@" in a:
            return self._extended(name, a, loc, scope, written)
        if literal(a) is not None or (a.startswith("'") and a.endswith("'")):
            if must_be_tag:
                self._err(loc, name, f"'{a}' must be a tag, not a constant")
            return None
        t = self.tag_type(scope, a)
        if t is None:
            self.missing[a] = None
        return t

    def _check_operands(self, spec, args, loc, scope, routines):
        n = len(args)
        lo, hi = spec.min_args(), spec.max_args()
        if n < lo or (hi is not None and n > hi):
            want = f"{lo}" if lo == hi else f"{lo}..{hi if hi is not None else 'n'}"
            self._err(loc, spec.mnemonic, f"needs {want} operand(s), has {n}")
            return
        for i, a in enumerate(args):
            if not spec.operands:
                break
            od = spec.operands[min(i, len(spec.operands) - 1)]
            if od.kind == "routine":
                if a.strip() not in routines:
                    self._err(loc, spec.mnemonic, f"no routine '{a.strip()}' in this program")
                continue
            if od.kind in ("label", "imm"):
                continue
            if od.kind in ("expr", "elem"):
                for t in tags_in(a):
                    if t[:2].upper() != "S:" and self.tag_type(scope, t) is None:
                        self.missing[t] = None
                continue
            written = od.kind == "dest" or i in _WRITES.get(spec.mnemonic, ()) or (
                od.kind == "tag" and od.types and not set(od.types) & _ATOMIC_TYPES)
            t = self._operand_tag(spec.mnemonic, a, loc, scope, od.kind in ("tag", "dest"), written)
            if written and ".@" not in a:
                self._check_constant(spec.mnemonic, a, loc, scope)
            if t and t != "?" and od.types and t not in od.types and not (
                    t in STRING_TYPES and "STRING" in od.types):
                self._err(loc, spec.mnemonic,
                          f"operand {od.name} '{a}' is {t}; expected {'/'.join(od.types)}")


def verify(ctrl: Controller, store=None) -> dict:
    """``store`` (a TagStore) lets Verify check extended properties (@Min/@Max)."""
    ck = _Checker(ctrl, store)
    not_simulated, parse_errors, warnings = [], [], []
    rungs = executable = 0

    def check_rll(routine, where, scope, routines):
        nonlocal rungs, executable
        labels = set()
        jumps = []
        for n, text in enumerate(routine.rungs):
            rungs += 1
            loc = f"{where} rung {n}"
            try:
                items = instructions(text)
            except Exception as exc:
                parse_errors.append({"location": loc, "error": str(exc)})
                continue
            ok = True
            for i, (name, args) in enumerate(items):
                if name.upper() == "LBL" and args:
                    labels.add(args[0].strip().upper())
                    if i != 0:
                        warnings.append(f"{loc}: LBL is not the first instruction of its rung")
                if name.upper() == "JMP" and args:
                    jumps.append((args[0].strip(), loc))
                ok &= ck.check_instr(name, args, loc, scope, routines)
            executable += ok
        for label, loc in jumps:
            if label.upper() not in labels:
                ck._err(loc, "JMP", f"no LBL({label}) in this routine")
        if routine.pending_edits:
            warnings.append(f"{where}: {len(routine.pending_edits)} rung(s) with pending online "
                            "edits; VirtualControlStudio executes every rung as exported")

    def check_st(routine, where, scope):
        for name in _st_calls(routine.text):
            spec = SPECS.get(name.upper())
            if spec is None and name.upper() not in ck.aois:
                ck.used[name] += 1
                ck.add_unsupported(name, f"{where} (ST)")
            else:
                ck.used[name] += 1
        try:
            from .st_interp import _Parser, tokenize
            _Parser(tokenize(routine.text)).block()
        except Exception as exc:
            parse_errors.append({"location": where, "error": str(exc)})

    for pname, prog in ctrl.programs.items():
        for rname, routine in prog.routines.items():
            where = f"{pname}/{rname}"
            if routine.rtype in ("FBD", "SFC"):
                not_simulated.append({"routine": where, "type": routine.rtype})
            elif routine.rtype == "ST":
                check_st(routine, where, pname)
            else:
                check_rll(routine, where, pname, prog.routines)

    for aname, aoi in ctrl.aois.items():
        scope = {p.name.upper(): p for p in aoi.parameters + aoi.local_tags}
        for rname, routine in aoi.routines.items():
            where = f"AOI {aname}/{rname}"
            if routine.rtype in ("FBD", "SFC"):
                not_simulated.append({"routine": where, "type": routine.rtype})
            elif routine.rtype == "ST":
                check_st(routine, where, scope)
            else:
                check_rll(routine, where, scope, aoi.routines)
        if aoi.execute_postscan:
            warnings.append(f"AOI {aname}: Postscan routine is not used (SFC is not simulated)")

    valid_access = ("Read/Write", "Read Only", "None")
    for scope_name, tags in [("controller", ctrl.tags)] + [(p.name, p.tags) for p in ctrl.programs.values()]:
        for tg in tags:
            ea = getattr(tg, "external_access", "Read/Write")
            if ea not in valid_access:
                where = tg.name if scope_name == "controller" else f"Program:{scope_name}.{tg.name}"
                warnings.append(f"Tag {where}: External Access '{ea}' is not Read/Write, Read Only "
                                "or None; Read/Write is used")
    for t in ctrl.tasks:
        if t.get("type") == "EVENT":
            warnings.append(f"Event task {t['name']} is not executed by VirtualControlStudio")
    warnings.extend(_logic_warnings(ctrl))
    scheduled = {p for t in ctrl.tasks for p in t.get("programs", [])}
    if ctrl.tasks:
        for pname in ctrl.programs:
            if pname not in scheduled:
                warnings.append(f"Program {pname} is unscheduled and does not run")

    return {
        "controller": ctrl.name,
        "supported": dict(sorted(_merge_upper(ck.used).items())),
        "unsupported": sorted(ck.unsupported.values(), key=lambda u: -u["count"]),
        "boundary": sorted(ck.boundary.values(), key=lambda u: u["instruction"]),
        "routines_not_simulated": not_simulated,
        "parse_errors": parse_errors,
        "operand_errors": ck.operand_errors[:200],
        "missing_tags": list(ck.missing),
        "warnings": warnings,
        "summary": {
            "programs": len(ctrl.programs),
            "routines": sum(len(p.routines) for p in ctrl.programs.values()),
            "rungs": rungs,
            "executable_rungs": executable,
            "tags": len(ck.db.names()),
            "data_types": len(ctrl.data_types),
            "modules": len(ctrl.modules),
            "aois": len(ctrl.aois),
        },
        "known_instructions": sorted({s.mnemonic for s in SPECS.values()}),
    }


# instructions whose bit is "destructive": writing it from two places makes one of them win
_DESTRUCTIVE = {"OTE": 0, "ONS": 0, "OSR": 0, "OSF": 0}
_JSR_ST = re.compile(r"\bJSR\s*\(\s*([A-Za-z_]\w*)", re.IGNORECASE)


def _logic_warnings(ctrl: Controller) -> list[str]:
    """Studio-style verification warnings (Tools > Options > Verification):
    duplicate destructive bits, shorted branches (a branch level with nothing on it)
    and routines that nothing calls."""
    from .ld_interp import parsed
    out: list[str] = []
    seen: dict[str, str] = {}
    called: set[tuple[str, str]] = set()

    def key(pname, prog, tag):
        root = re.split(r"[.\[]", tag, 1)[0].upper()
        local = any(t.name.upper() == root for t in prog.tags)
        return (f"Program:{pname}." if local else "") + tag.replace(" ", "").upper()

    def walk(series, visit):
        for item in series:
            if item[0] == "branch":
                visit(item)
                for leg in item[1]:
                    walk(leg, visit)
            else:
                visit(item)

    for pname, prog in ctrl.programs.items():
        for rname, routine in prog.routines.items():
            if routine.rtype == "ST":
                for m in _JSR_ST.finditer(routine.text or ""):
                    called.add((pname, m.group(1).upper()))
                continue
            if routine.rtype != "RLL":
                continue
            for n, text in enumerate(routine.rungs):
                loc = f"{pname}/{rname} rung {n}"
                try:
                    tree = parsed(text)
                except Exception:
                    continue
                shorted = []

                def visit(item, loc=loc, shorted=shorted):
                    if item[0] == "branch":
                        if any(len(leg) == 0 for leg in item[1]):
                            shorted.append(1)
                        return
                    name, args = str(item[1]).upper(), item[2]
                    if name == "JSR" and args:
                        called.add((pname, args[0].strip().upper()))
                    k = _DESTRUCTIVE.get(name)
                    if k is not None and len(args) > k and args[k].strip() not in ("", "?"):
                        tag = args[k].strip()
                        kk = key(pname, prog, tag)
                        if kk in seen:
                            out.append(f"{loc}: duplicate destructive bit: {name} {tag} is also "
                                       f"written at {seen[kk]}")
                        else:
                            seen[kk] = loc
                walk(tree, visit)
                if shorted:
                    out.append(f"{loc}: shorted branch: a branch level has no instructions")
    for pname, prog in ctrl.programs.items():
        for rname in prog.routines:
            if rname.upper() == (prog.main or "").upper():
                continue
            if (pname, rname.upper()) not in called:
                out.append(f"Routine {pname}/{rname} is never called (no JSR) and does not run")
    return out


def _merge_upper(used: Counter) -> dict:
    out: Counter = Counter()
    for k, v in used.items():
        spec = SPECS.get(k.upper())
        if spec is not None:
            out[spec.mnemonic] += v
    return out


def _st_calls(text: str) -> list[str]:
    text = re.sub(r"//[^\n]*|\(\*.*?\*\)|/\*.*?\*/", " ", text, flags=re.S)
    text = re.sub(r"'(?:\$.|[^'$])*'|\"(?:\$.|[^\"$])*\"", "''", text)
    return [m for m in _ST_CALL.findall(text) if m.upper() not in _ST_KEYWORDS]


def format_report(r: dict) -> str:
    s = r["summary"]
    lines = [f"Verify {r['controller']}: {s['programs']} programs, {s['routines']} routines, "
             f"{s['rungs']} rungs ({s['executable_rungs']} fully executable), "
             f"{s['tags']} tags, {s['modules']} I/O modules, {s['aois']} AOIs"]
    lines.append("Supported instructions used: " +
                 (", ".join(f"{k}x{v}" for k, v in r["supported"].items()) or "none"))
    for u in r["unsupported"]:
        lines.append(f"NOT EXECUTED  {u['instruction']} x{u['count']}: {u['reason']} "
                     f"-- {', '.join(u['locations'][:5])}")
    for b in r.get("boundary", []):
        lines.append(f"BOUNDARY      {b['instruction']} x{b['count']}: accepted, no effect in "
                     f"simulation -- {', '.join(b['locations'][:5])}")
    for x in r["routines_not_simulated"]:
        lines.append(f"NOT SIMULATED {x['type']} routine {x['routine']}")
    for e in r["parse_errors"]:
        lines.append(f"PARSE ERROR   {e['location']}: {e['error']}")
    for e in r.get("operand_errors", [])[:50]:
        lines.append(f"OPERAND       {e['location']} {e['instruction']}: {e['error']}")
    if r["missing_tags"]:
        lines.append("MISSING TAGS  " + ", ".join(r["missing_tags"][:30]))
    for w in r.get("warnings", [])[:30]:
        lines.append(f"WARNING       {w}")
    if not (r["unsupported"] or r["routines_not_simulated"] or r["parse_errors"]
            or r["missing_tags"] or r.get("operand_errors")):
        lines.append("Everything in this project can be executed by VirtualControlStudio.")
    return "\n".join(lines)
