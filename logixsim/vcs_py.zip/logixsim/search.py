"""Find / Replace in logic for the Studio (Search > Find, Find All, Replace All).

Ladder rungs are searched per instruction: mnemonics, operands and rung comments
("Find Within"). Structured Text is searched as text, line by line. Replace All
goes through the normal edit service (validated, applied at a scan boundary,
one undo step per routine)."""
from __future__ import annotations

import re

from .editing import EditError, apply_rung_batch, apply_st_edit
from .validation import RungSyntaxError, flatten, parse_rung_strict


def _pattern(q: str, whole: bool, case: bool, operand_only: bool = False, wild: bool = False) -> re.Pattern:
    if wild:                                 # wildcards: * any text, ? one character, # one digit
        body = "".join(r"[\w.\[\]:]*" if c == "*" else r"[\w.\[\]:]" if c == "?" else r"\d" if c == "#"
                       else re.escape(c) for c in q)
    else:
        body = re.escape(q)
    if whole:
        body = r"(?<![\w])" + body + r"(?![\w])"
    if operand_only:
        body += r"(?!\s*\()"                 # not a mnemonic / function name
    return re.compile(body, 0 if case else re.I)


def _routines(engine, scope: str, program: str, routine: str):
    c = engine.controller
    for pname, prog in c.programs.items():
        if scope in ("routine", "program") and pname != program:
            continue
        for rname, rt in prog.routines.items():
            if scope == "routine" and rname != routine:
                continue
            yield pname, rname, rt
    if scope == "all" or program.startswith("AOI:"):
        for aname, aoi in c.aois.items():
            p = "AOI:" + aname
            if scope in ("routine", "program") and p != program:
                continue
            for rname, rt in aoi.routines.items():
                if scope == "routine" and rname != routine:
                    continue
                yield p, rname, rt


def _st_comment_spans(text: str) -> list[tuple[int, int]]:
    """Character ranges of the comments in Structured Text ((* *), /* */, //)."""
    spans, i, n = [], 0, len(text)
    while i < n:
        c2 = text[i:i + 2]
        if c2 in ("(*", "/*"):
            end = text.find("*)" if c2 == "(*" else "*/", i + 2)
            end = n if end < 0 else end + 2
            spans.append((i, end)); i = end; continue
        if c2 == "//":
            end = text.find("\n", i)
            end = n if end < 0 else end
            spans.append((i, end)); i = end; continue
        if text[i] == "'":
            end = text.find("'", i + 1)
            i = n if end < 0 else end + 1; continue
        i += 1
    return spans


def search_logic(engine, q: str, scope="all", program="", routine="", within=None,
                 whole=False, case=False, limit=2000, wild=False) -> list[dict]:
    if not q:
        return []
    within = within or {"operands", "mnemonics", "comments"}
    pat = _pattern(q, whole, case, wild=wild)
    # Structured Text: "stcomments" / "stcode" limit the search to comments or statements
    st_only = None
    if "stcomments" in within and "stcode" not in within:
        st_only = "comments"
    elif "stcode" in within and "stcomments" not in within:
        st_only = "code"
    hits = []
    for pname, rname, rt in _routines(engine, scope, program, routine):
        if rt.rtype == "RLL":
            for n, text in enumerate(rt.rungs):
                try:
                    items = flatten(parse_rung_strict(text))
                except RungSyntaxError:
                    items = []
                for k, (_, name, args, _pos) in enumerate(items):
                    if "mnemonics" in within and (pat.fullmatch(name) if whole else pat.search(name)):
                        hits.append({"program": pname, "routine": rname, "rung": n, "index": k,
                                     "kind": "mnemonic", "text": text})
                    if "operands" in within:
                        for j, a in enumerate(args):
                            if pat.search(a or ""):
                                hits.append({"program": pname, "routine": rname, "rung": n, "index": k,
                                             "operand": j, "kind": "operand", "match": a, "text": text})
                com = rt.comments.get(n, "")
                if "comments" in within and com and pat.search(com):
                    hits.append({"program": pname, "routine": rname, "rung": n, "kind": "comment",
                                 "text": com})
                if len(hits) >= limit:
                    return hits
        elif rt.rtype == "ST" and rt.text:
            spans = _st_comment_spans(rt.text) if st_only else []
            in_c = lambda off: any(a <= off < b for a, b in spans)
            off0 = 0
            for ln, line in enumerate(rt.text.split("\n"), 1):
                for m in pat.finditer(line):
                    if st_only and in_c(off0 + m.start()) != (st_only == "comments"):
                        continue
                    hits.append({"program": pname, "routine": rname, "line": ln, "col": m.start() + 1,
                                 "kind": "text", "text": line.strip()})
                    break
                off0 += len(line) + 1
                if len(hits) >= limit:
                    return hits
    return hits


def replace_logic(engine, q: str, new: str, scope="all", program="", routine="", within=None,
                  whole=False, case=False) -> dict:
    """Replace in every routine of the scope. Each routine is one edit (all its rungs
    validated together); a routine whose result does not verify is left unchanged and
    reported."""
    if not q:
        raise EditError("enter the text to find")
    within = within or {"operands", "comments"}
    op_pat = _pattern(q, whole, case, operand_only="mnemonics" not in within)
    any_pat = _pattern(q, whole, case)
    done, failed, count = [], [], 0
    for pname, rname, rt in list(_routines(engine, scope, program, routine)):
        if pname.startswith("AOI:"):
            continue                          # AOI logic is read-only online
        try:
            if rt.rtype == "RLL":
                ops = []
                for n, text in enumerate(rt.rungs):
                    nt, c1 = op_pat.subn(lambda m: new, text) if ("operands" in within or "mnemonics" in within) else (text, 0)
                    com = rt.comments.get(n, "")
                    nc, c2 = any_pat.subn(lambda m: new, com) if ("comments" in within and com) else (com, 0)
                    if c1 or c2:
                        ops.append({"op": "replace", "index": n, "text": nt, "comment": nc, "_n": c1 + c2})
                if ops:
                    apply_rung_batch(engine, pname, rname, ops)
                    count += sum(o["_n"] for o in ops)
                    done.append({"program": pname, "routine": rname, "rungs": [o["index"] for o in ops]})
            elif rt.rtype == "ST" and rt.text:
                nt, c = any_pat.subn(lambda m: new, rt.text)
                if c:
                    apply_st_edit(engine, pname, rname, nt)
                    count += c
                    done.append({"program": pname, "routine": rname, "lines": c})
        except EditError as exc:
            failed.append({"program": pname, "routine": rname, "error": str(exc),
                           "issues": [i.get("message") for i in exc.issues][:5]})
    return {"ok": not failed, "replaced": count, "routines": done, "failed": failed}
