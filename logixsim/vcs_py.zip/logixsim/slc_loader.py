"""Load an RSLogix 500 ASCII *instruction report* into a runnable program.

The report lists rungs as mnemonics between SOR (start of rung) and EOR (end of
rung), with BST / NXB / BND marking parallel branches:

    Processor Name: SLC_DEMO

    LAD 2 - MAIN
    SOR XIC I:1/0 BST XIC B3:0/0 NXB XIC I:1/1 BND XIO I:1/2 OTE B3:0/0 EOR
    SOR XIC B3:0/0 TON T4:0 1.0 50 0 EOR
    SOR XIC T4:0/DN OTE O:2/0 EOR

This is translated into the bracketed rung text the ladder interpreter already
runs (BST->'[', NXB->',', BND->']'), and timer/counter presets are seeded into
the data table. Fit the token rules to a real export when one is available; the
exact dialect is version-specific.
"""
from __future__ import annotations

import re

from .engine import Engine
from .instructions import REGISTRY
from .model import Controller, Program, Routine
from .slc_model import SLCDataTable

_STRUCTURAL = {"SOR", "EOR", "BST", "NXB", "BND"}
_MNEMONIC = re.compile(r"[A-Z]{2,4}[0-9]?$")
_KNOWN = set(REGISTRY.keys())


def _is_mnemonic(tok: str) -> bool:
    return bool(_MNEMONIC.match(tok)) and tok not in _STRUCTURAL


def _norm_jsr(operand: str) -> str:
    """JSR operand (U:3, 3, LAD3) -> routine name LAD3."""
    m = re.search(r"(\d+)", operand)
    return f"LAD{m.group(1)}" if m else operand


class SLCReport:
    def __init__(self):
        self.name = "SLC_Controller"
        self.rungs_by_file: dict[str, list[str]] = {}
        self.presets: dict[str, int] = {}


def parse_report(text: str) -> SLCReport:
    rep = SLCReport()
    toks = _tokenize(text, rep)
    current = "LAD2"
    i = 0
    while i < len(toks):
        t = toks[i]
        if t == "LAD":
            current = f"LAD{toks[i + 1]}"
            rep.rungs_by_file.setdefault(current, [])
            i += 2
            continue
        if t == "SOR":
            j = i + 1
            rung_toks = []
            while j < len(toks) and toks[j] != "EOR":
                rung_toks.append(toks[j])
                j += 1
            rep.rungs_by_file.setdefault(current, []).append(
                _translate(rung_toks, rep))
            i = j + 1
            continue
        i += 1
    return rep


def _tokenize(text: str, rep: SLCReport) -> list[str]:
    toks = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        low = line.lower()
        if low.startswith("processor name"):
            rep.name = line.split(":", 1)[1].strip() or rep.name
            continue
        toks.extend(line.replace("-", " ").split())
    return toks


def _translate(toks: list[str], rep: SLCReport) -> str:
    out = ""
    i = 0
    while i < len(toks):
        t = toks[i]
        if t == "BST":
            out += "["
            i += 1
        elif t == "NXB":
            out += ","
            i += 1
        elif t == "BND":
            out += "]"
            i += 1
        elif _is_mnemonic(t):
            name = t.upper()
            args = []
            i += 1
            while i < len(toks) and not _is_mnemonic(toks[i]) \
                    and toks[i] not in _STRUCTURAL:
                args.append(toks[i])
                i += 1
            out += _emit(name, args, rep)
        else:
            i += 1  # stray operand with no instruction; skip
    return out


def _emit(name: str, args: list[str], rep: SLCReport) -> str:
    if name in ("TON", "TOF", "RTO") and args:
        addr = args[0]
        nums = [a for a in args[1:] if _isnum(a)]
        if len(nums) >= 2:                       # base, preset, [accum]
            rep.presets[f"{addr}.PRE"] = int(float(nums[1]))
        return f"{name}({addr},?,?)"
    if name in ("CTU", "CTD") and args:
        addr = args[0]
        nums = [a for a in args[1:] if _isnum(a)]
        if nums:                                 # preset, [accum]
            rep.presets[f"{addr}.PRE"] = int(float(nums[0]))
        return f"{name}({addr},?,?)"
    if name == "JSR" and args:
        return f"JSR({_norm_jsr(args[0])})"
    return f"{name}({','.join(args)})"


def _isnum(tok: str) -> bool:
    try:
        float(tok)
        return True
    except ValueError:
        return False


def build(text: str):
    """Return (Controller, SLCDataTable) ready to hand to Engine."""
    rep = parse_report(text)
    ctrl = Controller(name=rep.name)
    prog = Program("MAIN")
    files = sorted(rep.rungs_by_file, key=lambda f: int(f[3:]))
    for fname in files:
        prog.routines[fname] = Routine(fname, "RLL", rungs=rep.rungs_by_file[fname])
    prog.main = files[0] if files else ""
    ctrl.programs["MAIN"] = prog
    ctrl.task_order = ["MAIN"]

    dt = SLCDataTable()
    for addr, val in rep.presets.items():
        dt.set(addr, val)
    return ctrl, dt


def load_report_to_engine(text: str) -> Engine:
    ctrl, dt = build(text)
    return Engine(ctrl, db=dt)


def load_file_to_engine(path: str) -> Engine:
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        return load_report_to_engine(fh.read())
