"""OPC UA server connector (asyncua).

Address space::

    Objects / <Project> / Tags / Start              (Boolean variable)
                                 Level              (Float, EngineeringUnits, EURange)
                                 Arr                (Int32[] variable)
                                     [0] [1] ...    (element variables)
                                 M1                 (object for a structure)
                                     Run  Speed  Faults ...
                                 Line               (object for an array of structures)
                                     [0] -> Run ...

Every node's NodeId is the tag address as a string in namespace ``urn:logixsim``,
e.g. ``ns=2;s=Line[1].Speed`` — clients can address tags directly by name.

Client writes go through ``TagStore.write(source="opcua")``: forced and
read-only tags are refused (BadUserAccessDenied / BadNotWritable), values
outside min..max get BadOutOfRange, wrong values BadTypeMismatch. asyncua
reports a refused write as a service fault for that Write request.
Store changes reach the nodes through the EventBus, so subscribed clients get
data-change notifications. Tags defined, deleted or renamed at runtime add or
remove their nodes.

Security: anonymous by default; ``users={"name": "password"}`` enables login
(``allow_anonymous=False`` to require it); ``security=["none","basic256sha256"]``
also offers an encrypted endpoint with a self-signed certificate in ``pki_dir``.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import logging
import os
import re
import threading
from datetime import datetime, timezone
from typing import Any

from asyncua import Server, ua
from asyncua.crypto.permission_rules import User, UserRole
from asyncua.server.user_managers import UserManager

from ..model import STRING_TYPES
from ..tagstore import TagStoreError, root_of
from .base import BIND_FIELD, Connector, bind_address, register
from .errors import explain, local_ips, port_free

log = logging.getLogger(__name__)

NAMESPACE = "urn:logixsim"
VARIANT = {"BOOL": ua.VariantType.Boolean, "SINT": ua.VariantType.SByte,
           "INT": ua.VariantType.Int16, "DINT": ua.VariantType.Int32,
           "LINT": ua.VariantType.Int64, "REAL": ua.VariantType.Float,
           "STRING": ua.VariantType.String}
ERRORS = {"forced": ua.StatusCodes.BadUserAccessDenied,
          "readonly": ua.StatusCodes.BadNotWritable,
          "range": ua.StatusCodes.BadOutOfRange,
          "value": ua.StatusCodes.BadTypeMismatch,
          "type": ua.StatusCodes.BadTypeMismatch,
          "unknown": ua.StatusCodes.BadNodeIdUnknown}
_ELEM = re.compile(r"^(.*)\[(\d+)\]$")


PBKDF2_ITERATIONS = 200_000


def hash_password(password: str, iterations: int = PBKDF2_ITERATIONS) -> str:
    """Salted PBKDF2-SHA256 hash for the project file: pbkdf2:sha256:<n>:<salt>:<hash>."""
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"pbkdf2:sha256:{iterations}:{salt.hex()}:{dk.hex()}"


def verify_password(stored: str, password: str | None) -> bool:
    if password is None or stored is None:
        return False
    if isinstance(password, bytes):
        password = password.decode("utf-8", "replace")
    if stored.startswith("pbkdf2:sha256:"):
        try:
            _, _, n, salt, digest = stored.split(":")
            dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), int(n))
            return hmac.compare_digest(dk.hex(), digest)
        except (ValueError, TypeError):
            return False
    return hmac.compare_digest(stored.encode("utf-8"), password.encode("utf-8"))   # legacy plain


class _Users(UserManager):
    def __init__(self, users: dict[str, str], allow_anonymous: bool):
        self.users, self.allow_anonymous = users, allow_anonymous
        plain = [u for u, p in users.items() if not str(p).startswith("pbkdf2:")]
        if plain:
            log.warning("OPC UA users %s have plain-text passwords in the project file; "
                        "store hashes from 'python -m logixsim hash-password'", ", ".join(plain))

    def get_user(self, iserver, username=None, password=None, certificate=None):
        if username is None:
            return User(role=UserRole.User) if self.allow_anonymous else None
        if username in self.users and verify_password(self.users[username], password):
            return User(role=UserRole.User, name=username)
        return None


@register("opcua")
class OpcUaConnector(Connector):
    name = kind = "opcua"
    title = "OPC UA server"
    role = "server"
    summary = "Ignition, Kepware, UaExpert, SCADA and other OPC UA clients"
    schema = [
        dict(BIND_FIELD),
        {"name": "port", "type": "int", "label": "Port", "default": 4840, "min": 1, "max": 65535,
         "group": "Network"},
        {"name": "path", "type": "str", "label": "Path", "default": "/logixsim/", "group": "Network",
         "advanced": True, "help": "Part of the endpoint URL after the port."},
        {"name": "allow_anonymous", "type": "bool", "label": "Allow anonymous login", "default": True,
         "group": "Security"},
        {"name": "users", "type": "dict", "label": "Users", "default": {}, "group": "Security",
         "help": "User name and password pairs. Passwords are stored hashed."},
        {"name": "security", "type": "list", "label": "Security policies",
         "default": ["none", "basic256sha256"], "group": "Security", "advanced": True,
         "help": "none and/or basic256sha256 (encrypted, with a self-signed certificate)."},
    ]

    def __init__(self, emu, host: str = "127.0.0.1", port: int = 4840, path: str = "/logixsim/",
                 users: dict[str, str] | None = None, allow_anonymous: bool = True,
                 security: list[str] | None = None, pki_dir: str | None = None,
                 element_nodes: bool = True, allow_plain_login: bool = False,
                 max_element_nodes: int = 1000, bind: str | None = None, **settings):
        super().__init__(emu, **settings)
        if bind:
            host = bind_address(bind)
        self.bind = bind or ("local" if host in ("127.0.0.1", "localhost") else host)
        self.host, self.port, self.path = host, int(port), "/" + path.strip("/") + "/"
        self.users = dict(users or {})
        self.allow_anonymous = bool(allow_anonymous)
        self.security = [s.lower() for s in (security or ["none"])]
        if self.users and not allow_plain_login and "basic256sha256" not in self.security:
            # a certificate lets clients encrypt the password even on the None endpoint
            self.security.append("basic256sha256")
        self.pki_dir = pki_dir or os.path.join(os.getcwd(), ".logixsim-pki")
        self.element_nodes = element_nodes
        self.max_element_nodes = int(max_element_nodes)   # bigger arrays: array node only
        self.endpoint = f"opc.tcp://{host}:{self.port}{self.path}"
        self.server: Server | None = None
        self.idx = 2
        self._nodes: dict[str, Any] = {}        # address -> node (variables and objects)
        self._vtype: dict[str, ua.VariantType] = {}
        self._arrays: set[str] = set()           # atomic array variables
        self._own: set[int] = set()              # DataValues we wrote ourselves
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._ready = threading.Event()
        self._error: BaseException | None = None
        self._stopper: asyncio.Event | None = None
        self._sub = None
        self._running = False

    # ---- public --------------------------------------------------------------------
    def start(self) -> None:
        self._nodes.clear()
        self._vtype.clear()
        self._arrays.clear()
        self._ready.clear()
        self._error = None
        self._thread = threading.Thread(target=self._thread_main, name="opcua", daemon=True)
        self._thread.start()
        if not self._ready.wait(30):
            raise RuntimeError("OPC UA server did not start within 30 s")
        if self._error is not None:
            raise RuntimeError(f"OPC UA server failed to start on {self.endpoint}: {self._error}")

    def stop(self) -> None:
        if self._sub is not None:
            self.emu.bus.unsubscribe(self._sub)
            self._sub = None
        self.emu.bus.off_event(self._on_event)
        if self._loop and self._stopper:
            self._loop.call_soon_threadsafe(self._stopper.set)
        if self._thread:
            self._thread.join(timeout=10)
            self._thread = None

    def status(self) -> dict:
        return {"name": self.name, "running": self._running, "endpoint": self.endpoints()[0],
                "nodes": len(self._nodes), "security": self.security,
                "login": "required" if not self.allow_anonymous else
                         ("optional" if self.users else "anonymous")}

    def endpoints(self) -> list[str]:
        hosts = local_ips() if self.host == "0.0.0.0" else [self.host]
        return [f"opc.tcp://{h}:{self.port}{self.path}" for h in hosts]

    def other_side(self) -> dict:
        eps = self.endpoints()
        users = ", ".join(self.users) or "(none)"
        return {"values": {"Endpoint URL": eps[0], "Security": " / ".join(self.security),
                           "Login": ("anonymous or user" if self.allow_anonymous and self.users else
                                     "anonymous" if self.allow_anonymous else "user required"),
                           "Users": users, "Tags under": f"Objects > {self.emu.name} > Tags"},
                "steps": ["Ignition: Gateway > OPC Connections > Servers > create a new OPC UA "
                          "connection (menu names to verify on your gateway). Endpoint URL as shown.",
                          "Security None, or Basic256Sha256 with a user. If Ignition asks, trust the "
                          "server certificate 'VirtualControlStudio'.",
                          "In the Designer OPC browser open the new connection > Objects > the "
                          "project > Tags and drag tags into your tag provider.",
                          "Node IDs equal the tag address: ns=2;s=Motor_Run."],
                "examples": {}}

    @classmethod
    def test(cls, emu, params: dict, running=None) -> list[dict]:
        host = bind_address(params.get("bind", "local"))
        port = int(params.get("port", 4840))
        if running is None or not running._running:
            ok, err = port_free(host, port)
            return [{"ok": ok, "label": f"Port {port} is free" if ok else err["message"],
                     "hint": "" if ok else err["hint"]}]
        checks = [{"ok": True, "label": f"Server running, {len(running._nodes)} nodes", "hint": ""}]
        target = "127.0.0.1" if host == "0.0.0.0" else host
        url = f"opc.tcp://{target}:{port}{running.path}"
        if not running.allow_anonymous:
            checks.append({"ok": None, "label": "Login required: the test client cannot log in",
                           "hint": "Test from the client with a user name."})
            return checks

        async def probe():
            from asyncua import Client
            c = Client(url, timeout=4)
            await c.connect()
            try:
                objs = await c.nodes.objects.get_children()
                return len(objs)
            finally:
                await c.disconnect()
        try:
            asyncio.run(probe())
            checks.append({"ok": True, "label": "A test client connected and browsed Objects",
                           "hint": ""})
        except Exception as exc:
            e = explain(exc, port=port, host=target, kind="opcua")
            checks.append({"ok": False, "label": e["message"], "hint": e["hint"]})
        return checks

    def has_node(self, addr: str) -> bool:
        return addr in self._nodes

    # ---- server thread ------------------------------------------------------------------
    def _thread_main(self) -> None:
        loop = asyncio.new_event_loop()
        self._loop = loop
        try:
            loop.run_until_complete(self._main())
        except BaseException as exc:            # start-up failure
            self._error = self._error or exc
        finally:
            self._running = False
            self._ready.set()
            loop.close()

    async def _main(self) -> None:
        self._stopper = asyncio.Event()
        um = _Users(self.users, self.allow_anonymous)
        srv = Server(user_manager=um)
        await srv.init()
        srv.set_endpoint(self.endpoint)
        srv.set_server_name(f"VirtualControlStudio - {self.emu.name}")
        await srv.set_application_uri("urn:logixsim:server")
        tokens = []
        if self.allow_anonymous:
            tokens.append(ua.AnonymousIdentityToken)
        if self.users:
            tokens.append(ua.UserNameIdentityToken)
        srv.set_identity_tokens(tokens or [ua.AnonymousIdentityToken])
        await self._setup_security(srv)
        self._per_node_write_status(srv)
        self.server = srv
        self.idx = await srv.register_namespace(NAMESPACE)
        proj = await srv.nodes.objects.add_folder(ua.NodeId("__project__", self.idx), self._qn(self.emu.name))
        self._tags_folder = await proj.add_folder(ua.NodeId("__tags__", self.idx), self._qn("Tags"))

        # subscribe before building so no change is missed (duplicates are harmless)
        self._sub = self.emu.bus.subscribe(["*"], self._on_changes)
        self.emu.bus.on_event(self._on_event)
        for d in self.emu.store.definitions():
            await self._add_tag(d["name"])

        try:
            await srv.start()
        except BaseException as exc:
            self._error = exc
            self.emu.bus.unsubscribe(self._sub)
            self._sub = None
            raise
        self._running = True
        self._ready.set()
        try:
            await self._stopper.wait()
        finally:
            self._running = False
            await srv.stop()

    @staticmethod
    def _per_node_write_status(srv: Server) -> None:
        """asyncua turns a refused value (setter exception) into a fault for the
        whole Write request, even though earlier nodes were already written.
        Write node by node and report each node's own status instead."""
        svc = srv.iserver.attribute_service
        original = svc.write

        async def write(params, user=None, **kw):
            results = []
            for wv in params.NodesToWrite:
                one = ua.WriteParameters()
                one.NodesToWrite = [wv]
                try:
                    results += await (original(one, user=user, **kw) if user is not None
                                      else original(one, **kw))
                except ua.UaStatusCodeError as exc:
                    results.append(ua.StatusCode(exc.code))
            return results
        svc.write = write

    async def _setup_security(self, srv: Server) -> None:
        policies = []
        if "none" in self.security:
            policies.append(ua.SecurityPolicyType.NoSecurity)
        if "basic256sha256" in self.security:
            from cryptography.x509.oid import ExtendedKeyUsageOID
            from pathlib import Path
            from asyncua.crypto.cert_gen import setup_self_signed_certificate
            os.makedirs(self.pki_dir, mode=0o700, exist_ok=True)
            cert = Path(self.pki_dir) / "server_cert.der"
            key = Path(self.pki_dir) / "server_key.pem"
            await setup_self_signed_certificate(
                key, cert, "urn:logixsim:server", self.host if self.host != "0.0.0.0" else "localhost",
                [ExtendedKeyUsageOID.SERVER_AUTH, ExtendedKeyUsageOID.CLIENT_AUTH],
                {"countryName": "US", "organizationName": "VirtualControlStudio", "commonName": "VirtualControlStudio"})
            if os.name == "posix":
                os.chmod(key, 0o600)
            await srv.load_certificate(str(cert))
            await srv.load_private_key(str(key))
            policies += [ua.SecurityPolicyType.Basic256Sha256_SignAndEncrypt,
                         ua.SecurityPolicyType.Basic256Sha256_Sign]
        srv.set_security_policy(policies or [ua.SecurityPolicyType.NoSecurity])

    # ---- address space ---------------------------------------------------------------------
    def _qn(self, name: str) -> ua.QualifiedName:
        return ua.QualifiedName(name, self.idx)

    def _nid(self, addr: str) -> ua.NodeId:
        return ua.NodeId(addr, self.idx)

    async def _add_tag(self, name: str) -> None:
        st = self.emu.store
        try:
            value = st.read(name)
            meta = st.meta(name)
        except TagStoreError:
            return
        if getattr(st, "access", None) and st.access(name) == "none":
            return                                      # External Access None: not exposed
        await self._build(self._tags_folder, name, name, value, meta)

    async def _build(self, parent, addr: str, browse: str, value, meta) -> None:
        if isinstance(value, dict):
            obj = await parent.add_object(self._nid(addr), self._qn(browse))
            self._nodes[addr] = obj
            for k, v in value.items():
                await self._build(obj, f"{addr}.{k}", k, v, meta)
            return
        if isinstance(value, list) and value and isinstance(value[0], (dict, list)):
            obj = await parent.add_object(self._nid(addr), self._qn(browse))
            self._nodes[addr] = obj
            for i, v in enumerate(value):
                ea = self._elem(addr, i)
                await self._build(obj, ea, ea[len(addr):], v, meta)
            return
        dtype = self._dtype(addr, value)
        vt = VARIANT[dtype]
        var = await parent.add_variable(self._nid(addr), self._qn(browse), ua.Variant(value, vt))
        self._nodes[addr] = var
        self._vtype[addr] = vt
        if meta.access == "rw":
            await var.set_writable()
        if meta.description and browse == addr:
            await var.write_attribute(ua.AttributeIds.Description,
                                      ua.DataValue(ua.Variant(ua.LocalizedText(meta.description))))
        if browse == addr and (meta.units or meta.min is not None or meta.max is not None):
            await self._eu(var, meta)
        self.server.set_attribute_value_setter(var.nodeid, self._setter)
        if isinstance(value, list):
            self._arrays.add(addr)
            if self.element_nodes and len(value) <= self.max_element_nodes:
                for i, v in enumerate(value):
                    ea = self._elem(addr, i)
                    ev = await var.add_variable(self._nid(ea), self._qn(ea[len(addr):]),
                                                ua.Variant(v, vt))
                    self._nodes[ea] = ev
                    self._vtype[ea] = vt
                    if meta.access == "rw":
                        await ev.set_writable()
                    self.server.set_attribute_value_setter(ev.nodeid, self._setter)

    def _elem(self, addr: str, i: int) -> str:
        db = getattr(self.emu.store, "db", None)
        return db.elem_address(addr, i) if hasattr(db, "elem_address") else f"{addr}[{i}]"

    def _dtype(self, addr: str, value) -> str:
        if isinstance(value, str):
            return "STRING"
        try:
            t = self.emu.store.data_type(addr)
        except TagStoreError:
            t = "REAL" if isinstance(value, float) else "DINT"
        return "STRING" if t in STRING_TYPES else (t if t in VARIANT else "DINT")

    async def _eu(self, var, meta) -> None:
        if meta.units:
            eu = ua.EUInformation(NamespaceUri="http://www.opcfoundation.org/UA/units/un/cefact",
                                  UnitId=-1, DisplayName=ua.LocalizedText(meta.units),
                                  Description=ua.LocalizedText(meta.units))
            await var.add_property(0, "EngineeringUnits", ua.Variant(eu, ua.VariantType.ExtensionObject))
        if meta.min is not None or meta.max is not None:
            rng = ua.Range(Low=float(meta.min if meta.min is not None else -1e38),
                           High=float(meta.max if meta.max is not None else 1e38))
            await var.add_property(0, "EURange", ua.Variant(rng, ua.VariantType.ExtensionObject))

    async def _remove_tag(self, name: str) -> None:
        node = self._nodes.get(name)
        for a in [a for a in self._nodes if root_of(a) == name]:
            self._nodes.pop(a, None)
            self._vtype.pop(a, None)
            self._arrays.discard(a)
        if node is not None:
            await self.server.delete_nodes([node], recursive=True)

    # ---- client writes ------------------------------------------------------------------
    def _setter(self, node, attr, dv) -> None:
        if id(dv) in self._own:                  # our own update from the store
            self._own.discard(id(dv))
            node.attributes[attr].value = dv
            return
        addr = node.nodeid.Identifier
        value = dv.Value.Value if dv.Value is not None else None
        try:
            self.emu.store.write(addr, value, source="opcua")
        except TagStoreError as exc:
            raise ua.UaStatusCodeError(ERRORS.get(exc.code, ua.StatusCodes.BadInternalError))
        node.attributes[attr].value = dv

    # ---- store -> nodes ------------------------------------------------------------------------
    def _on_changes(self, batch: dict, seq: int) -> None:
        loop = self._loop
        if loop is not None and not loop.is_closed():
            asyncio.run_coroutine_threadsafe(self._apply(batch), loop)

    def _on_event(self, kind: str, data: dict) -> None:
        if kind != "tags" or self._loop is None or self._loop.is_closed():
            return
        asyncio.run_coroutine_threadsafe(self._structure(data), self._loop)

    async def _structure(self, data: dict) -> None:
        try:
            action = data.get("action")
            if action == "define":
                await self._add_tag(data["name"])
            elif action == "delete":
                await self._remove_tag(data["name"])
            elif action == "rename":
                await self._remove_tag(data["old"])
                await self._add_tag(data["name"])
        except Exception:
            log.exception("OPC UA: could not update the address space for %s", data)

    async def _set(self, addr: str, value) -> None:
        node, vt = self._nodes.get(addr), self._vtype.get(addr)
        if node is None or vt is None:
            return
        dv = ua.DataValue(ua.Variant(value, vt), SourceTimestamp=datetime.now(timezone.utc))
        self._own.add(id(dv))
        try:
            await self.server.write_attribute_value(node.nodeid, dv)
        except Exception:
            log.debug("OPC UA: could not update %s", addr, exc_info=True)
        finally:
            self._own.discard(id(dv))

    async def _apply(self, batch: dict) -> None:
        arrays = set()
        for addr, v in batch.items():
            await self._set(addr, v)
            m = _ELEM.match(addr)
            if m and m.group(1) in self._arrays:
                arrays.add(m.group(1))
        for a in arrays:
            try:
                await self._set(a, self.emu.store.read(a))
            except TagStoreError:
                pass
