"""Modbus TCP client connector: VirtualControlStudio polls a Modbus TCP device
(remote I/O, an IO-Link master, a temperature transmitter, a drive, a meter, a
gateway to Modbus RTU devices, ...) and copies its values into tags.

Points (the connection's ``mapping``): one row per value::

    {"tag": "Oven_Temp", "address": "30001", "type": "INT",
     "scale": 0.1, "offset": 0, "dir": "in"}

``address`` uses the usual Modbus numbering:

=================  ==============================  ==========================
address            table                           function codes
=================  ==============================  ==========================
1 - 9999           coil (read/write bit)            1 read, 5 write
10001 - 19999      discrete input (read bit)        2
30001 - 39999      input register (read word)       4
40001 - 49999      holding register (read/write)    3 read, 6 / 16 write
=================  ==============================  ==========================

Six-digit addresses (``400001``) reach offsets up to 65535. ``40001.3`` is bit 3
of a register (BOOL). A prefix with a 0-based offset is also accepted:
``hr0``, ``ir0``, ``co0``, ``di0``.

Types: BOOL, INT, UINT, DINT, UDINT, REAL, LINT. 32- and 64-bit values use
``word_order``. Incoming: tag = raw * scale + offset; outgoing raw = (tag - offset)
/ scale.

Safety: writing to the device is **off** until ``allow_writes`` is turned on;
rows with direction out/both are read-only until then. Discrete inputs and input
registers can never be written.

Polling reads neighbouring points in one request (up to 125 registers / 2000
bits). A point the device refuses (exception 02, illegal address) is marked bad
and retried every 30 s; the other points keep working. The connection is kept up
with reconnects after 1, 2, 5, 10, then every 30 s.
"""
from __future__ import annotations

import asyncio
import re
import socket
import struct
import time

from .base import Connector, ParamError, register
from .errors import explain
from .runner import LoopThread

BACKOFF = (1, 2, 5, 10, 30)
MAX_POINTS = 2000
BAD_RETRY_S = 30
GAP = 8                                   # read across gaps up to this many registers

TABLES = ("coil", "discrete", "input", "holding")
READ_FC = {"coil": 1, "discrete": 2, "input": 4, "holding": 3}
BASE5 = {0: "coil", 1: "discrete", 3: "input", 4: "holding"}
PREFIX = {"co": "coil", "c": "coil", "di": "discrete", "ir": "input", "hr": "holding"}
MODICON = {"coil": 1, "discrete": 10001, "input": 30001, "holding": 40001}
WORDS = {"BOOL": 1, "INT": 1, "UINT": 1, "DINT": 2, "UDINT": 2, "REAL": 2, "LINT": 4}
TAG_TYPE = {"BOOL": "BOOL", "INT": "INT", "UINT": "DINT", "DINT": "DINT", "UDINT": "LINT",
            "REAL": "REAL", "LINT": "LINT"}
EXCEPTIONS = {1: "illegal function", 2: "illegal data address", 3: "illegal data value",
              4: "device failure", 5: "acknowledge", 6: "device busy",
              10: "gateway path unavailable", 11: "gateway target did not respond"}


class NoAnswer(Exception):
    """The device accepted the TCP connection but did not answer a request in time."""


class BadAnswer(Exception):
    """The device sent an answer that is not valid Modbus."""


class ModbusException(Exception):
    def __init__(self, fc: int, code: int):
        self.fc, self.code = fc, code
        super().__init__(f"exception {code:02d} ({EXCEPTIONS.get(code, 'unknown')})")


# ---- addresses --------------------------------------------------------------------------------
def parse_address(text) -> tuple[str, int, int | None]:
    """'40001' -> ('holding', 0, None); '40010.3' -> ('holding', 9, 3); 'hr5' -> ('holding', 5, None)."""
    s = str(text if text is not None else "").strip().lower().replace(" ", "")
    m = re.fullmatch(r"([a-z]+)?(\d+)(?:\.(\d+))?", s)
    if not m:
        raise ValueError(f"{text!r} is not a Modbus address (examples: 40001, 30005, 1, 10001, 40001.3)")
    pre, num, bit = m.group(1), m.group(2), m.group(3)
    bit = int(bit) if bit is not None else None
    if bit is not None and not 0 <= bit <= 15:
        raise ValueError(f"bit {bit} in {text!r}: use 0 to 15")
    if pre:
        if pre not in PREFIX:
            raise ValueError(f"unknown prefix {pre!r} in {text!r} (use hr, ir, co or di)")
        table, off = PREFIX[pre], int(num)
    else:
        n = int(num)
        if len(num) == 6:
            first, off = int(num[0]), int(num[1:]) - 1
        elif n <= 9999:
            first, off = 0, n - 1
        else:
            first, off = n // 10000, n % 10000 - 1
        if first not in BASE5 or off < 0:
            raise ValueError(f"{text!r} is not a Modbus address (1-9999 coils, 10001 discrete inputs, "
                             "30001 input registers, 40001 holding registers)")
        table = BASE5[first]
    if not 0 <= off <= 65535:
        raise ValueError(f"{text!r}: offset {off} is out of range")
    if bit is not None and table in ("coil", "discrete"):
        raise ValueError(f"{text!r}: a bit number only applies to registers")
    return table, off, bit


def format_address(table: str, off: int, bit: int | None = None) -> str:
    n = MODICON[table] + off
    s = str(n) if off <= 9998 else f"{MODICON[table] // 10000}{off + 1:05d}" if table != "coil" \
        else f"{off + 1:06d}"
    return s + (f".{bit}" if bit is not None else "")


def point(m: dict) -> dict:
    """Validate one mapping row; returns the normalized row."""
    if not isinstance(m, dict) or not str(m.get("tag") or "").strip():
        raise ParamError("mapping", "each point needs a tag")
    tag = str(m["tag"]).strip()
    try:
        if m.get("address") not in (None, ""):
            table, off, bit = parse_address(m["address"])
        else:
            table, off = str(m.get("table") or ""), int(m.get("addr"))
            bit = None if m.get("bit") in (None, "") else int(m["bit"])
            if table not in TABLES:
                raise ValueError(f"table must be one of {', '.join(TABLES)}")
    except (ValueError, TypeError) as exc:
        raise ParamError("mapping", f"{tag}: {exc}") from None
    typ = str(m.get("type") or ("BOOL" if table in ("coil", "discrete") or bit is not None
                                else "INT")).upper()
    if typ not in WORDS:
        raise ParamError("mapping", f"{tag}: type must be one of {', '.join(WORDS)}")
    if table in ("coil", "discrete") and typ != "BOOL":
        raise ParamError("mapping", f"{tag}: coils and discrete inputs are BOOL")
    if bit is not None and typ != "BOOL":
        raise ParamError("mapping", f"{tag}: a register bit ({format_address(table, off, bit)}) is BOOL")
    if table in ("input", "holding") and typ == "BOOL" and bit is None:
        bit = 0
    if off + (WORDS[typ] if table in ("input", "holding") else 1) - 1 > 65535:
        raise ParamError("mapping", f"{tag}: the value runs past address 65535")
    d = str(m.get("dir") or "in")
    if d not in ("in", "out", "both"):
        raise ParamError("mapping", f"{tag}: direction must be in, out or both")
    if d != "in" and table in ("discrete", "input"):
        raise ParamError("mapping", f"{tag}: {format_address(table, off, bit)} is read-only on the "
                                    "device (discrete input / input register); use direction 'in'")
    try:
        scale = float(m.get("scale") if m.get("scale") not in (None, "") else 1.0)
        offset = float(m.get("offset") if m.get("offset") not in (None, "") else 0.0)
    except (TypeError, ValueError):
        raise ParamError("mapping", f"{tag}: scale and offset must be numbers") from None
    if scale == 0:
        raise ParamError("mapping", f"{tag}: scale cannot be 0")
    return {"tag": tag, "address": format_address(table, off, bit), "table": table, "addr": off,
            "bit": bit, "type": typ, "scale": scale, "offset": offset, "dir": d}


def points(rows) -> list[dict]:
    rows = list(rows or [])
    if len(rows) > MAX_POINTS:
        raise ParamError("mapping", f"at most {MAX_POINTS} points per connection")
    return [point(r) for r in rows]


def blocks(pts: list[dict]) -> list[tuple[str, int, int, list[dict]]]:
    """Group points into read requests: (table, start, count, points)."""
    out = []
    for table in TABLES:
        mine = sorted((p for p in pts if p["table"] == table), key=lambda p: p["addr"])
        limit = 2000 if table in ("coil", "discrete") else 125
        cur = None
        for p in mine:
            n = 1 if table in ("coil", "discrete") or p["type"] == "BOOL" else WORDS[p["type"]]
            end = p["addr"] + n
            if cur and p["addr"] - cur[2] <= GAP and max(end, cur[2]) - cur[1] <= limit:
                cur[2] = max(cur[2], end)
                cur[3].append(p)
            else:
                cur = [table, p["addr"], end, [p]]
                out.append(cur)
    return [(t, s, e - s, ps) for t, s, e, ps in out]


# ---- the connector ----------------------------------------------------------------------------
@register("modbus_client")
class ModbusClientConnector(Connector):
    name = kind = "modbus_client"
    title = "Modbus TCP client"
    role = "client"
    summary = "VirtualControlStudio polls a Modbus TCP device: I/O, sensors, IO-Link masters, drives, meters"
    schema = [
        {"name": "host", "type": "str", "label": "Device IP address", "default": "", "required": True,
         "group": "Network", "help": "IP address or name of the device (or of the Modbus gateway)."},
        {"name": "port", "type": "int", "label": "Port", "default": 502, "min": 1, "max": 65535,
         "group": "Network"},
        {"name": "unit_id", "type": "int", "label": "Unit ID", "default": 1, "min": 0, "max": 255,
         "group": "Network", "help": "Usually 1 (some devices use 0 or 255). Behind a gateway it "
                                     "selects the serial device."},
        {"name": "poll_ms", "type": "int", "label": "Poll every (ms)", "default": 500, "min": 50,
         "max": 60000, "group": "Protocol"},
        {"name": "timeout_s", "type": "float", "label": "Answer timeout (s)", "default": 2, "min": 0.2,
         "max": 30, "group": "Protocol", "advanced": True},
        {"name": "word_order", "type": "str", "label": "32-bit word order", "default": "high_first",
         "group": "Protocol", "choices": [["high_first", "High word first (most devices)"],
                                          ["low_first", "Low word first (word swap)"]],
         "help": "If REAL/DINT values look wrong (huge or tiny numbers), try the other order."},
        {"name": "allow_writes", "type": "bool", "label": "Allow writing to the device",
         "default": False, "group": "Safety",
         "help": "Off: points with direction out/both are only read. Turn on only when writing to "
                 "this device cannot move anything unexpectedly."},
        {"name": "create_tags", "type": "bool", "label": "Create missing tags", "default": True,
         "group": "Tags", "advanced": True,
         "help": "Points whose tag does not exist get a controller tag of a matching type."},
    ]

    def __init__(self, emu, host="", port=502, unit_id=1, poll_ms=500, timeout_s=2,
                 word_order="high_first", allow_writes=False, create_tags=True, mapping=None,
                 **settings):
        super().__init__(emu, **settings)
        if not str(host or "").strip():
            raise ParamError("host", "enter the device's IP address")
        self.host, self.port, self.unit = str(host).strip(), int(port), int(unit_id)
        self.poll = max(0.05, int(poll_ms) / 1000)
        self.timeout = float(timeout_s)
        self.word_order = word_order
        self.allow_writes = bool(allow_writes)
        self.create_tags = bool(create_tags)
        self.points = points(mapping)
        self.state = "off"
        self.attempt = 0
        self.next_retry = None
        self.last_error = None
        self.since = None
        self.bad: dict[str, dict] = {}          # tag -> {"message", "since", "retry_at"}
        self.counters = {"polls": 0, "requests": 0, "writes": 0, "errors": 0, "refused": 0,
                         "poll_ms": 0}
        self._last_raw: dict[str, object] = {}  # tag -> last raw value read from the device
        self._runner = LoopThread("modbus-client")
        self._sub = None
        self._tid = 0
        self._io = None
        self._pending: list[dict] = []
        self._kick: asyncio.Event | None = None
        self._src = f"conn:{self.settings.get('_name') or self.kind}"
        self._writes_off_noted = False

    # ---- lifecycle --------------------------------------------------------------------
    def start(self) -> None:
        if self.create_tags:
            self._create_missing_tags()
        async def main(ready):
            self._kick = asyncio.Event()
            ready()
            await self._keep_connected()
        self.state = "connecting"
        outs = [p["tag"] for p in self.points if p["dir"] != "in"]
        if outs:
            self._sub = self.emu.bus.subscribe(outs, self._on_changes)
            self.emu.bus.start()
        self._runner.start(main)

    def stop(self) -> None:
        if self._sub is not None:
            self.emu.bus.unsubscribe(self._sub)
            self._sub = None
        self._runner.stop()
        self.state = "off"

    @property
    def running(self) -> bool:
        return self._runner.alive

    def status(self) -> dict:
        st = {"name": self.name, "running": self.running, "state": self.state, "since": self.since,
              "endpoint": f"{self.host}:{self.port} unit {self.unit}", "points": len(self.points),
              "bad": [{"tag": t, **{k: v for k, v in b.items() if k != "retry_at"}}
                      for t, b in self.bad.items()],
              "writes_enabled": self.allow_writes, **self.counters}
        if self.state == "reconnecting":
            st["attempt"] = self.attempt
            st["next_in"] = max(0, round((self.next_retry or 0) - time.time(), 1))
        if self.last_error:
            st["error"] = self.last_error
        return st

    def _create_missing_tags(self) -> None:
        st = self.emu.store
        flat = st.flat()
        for p in self.points:
            if p["tag"] in flat or "." in p["tag"] or "[" in p["tag"]:
                continue
            typ = TAG_TYPE[p["type"]]
            if typ != "BOOL" and (p["scale"] != 1 or p["offset"]) :
                typ = "REAL"
            try:
                st.define(p["tag"], typ)
                flat[p["tag"]] = None
                self.log("info", f"created tag {p['tag']} ({typ})")
            except Exception as exc:
                self.log("warn", f"could not create tag {p['tag']}: {exc}")

    # ---- connection loop -------------------------------------------------------------------
    async def _keep_connected(self):
        stopping = self._runner.stopping
        while not stopping.is_set():
            try:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(self.host, self.port), self.timeout + 3)
                self._io = (reader, writer)
                try:
                    await self._poll_once()
                    outs = [p["tag"] for p in self.points if p["dir"] == "out"]
                    if outs:                     # the device gets the tags' current values
                        flat = self.emu.store.flat()
                        self._pending.append({t: flat[t] for t in outs if t in flat})
                    self.state, self.attempt, self.last_error = "connected", 0, None
                    self.since = time.time()
                    self.log("info", f"connected to {self.host}:{self.port} (unit {self.unit}), "
                                     f"{len(self.points)} points")
                    self.emu.bus.emit("connection", {"kind": self.kind})
                    while not stopping.is_set():
                        t0 = time.perf_counter()
                        await self._flush_writes()
                        await self._poll_once()
                        took = time.perf_counter() - t0
                        self.counters["poll_ms"] = round(took * 1000, 1)
                        await self._wait_work(stopping, max(0.0, self.poll - took))
                finally:
                    self._io = None
                    writer.close()
                if stopping.is_set():
                    break
            except Exception as exc:
                if stopping.is_set():
                    break
                e = _explain(exc, self.host, self.port, self.unit)
                was = self.state == "connected"
                self.last_error = e
                self.counters["errors"] += 1
                delay = BACKOFF[min(self.attempt, len(BACKOFF) - 1)]
                self.attempt += 1
                self.state, self.next_retry = "reconnecting", time.time() + delay
                self.log("warn" if was else "error", f"{e['message']} Retry {self.attempt} in {delay} s.")
                self.emu.bus.emit("connection", {"kind": self.kind})
                try:
                    await asyncio.wait_for(stopping.wait(), delay)
                except asyncio.TimeoutError:
                    pass
        self.state = "off"

    async def _wait_work(self, stopping, delay):
        """Sleep until the next poll; wake early for a stop or a pending write."""
        tasks = [asyncio.create_task(self._kick.wait()), asyncio.create_task(stopping.wait())]
        try:
            await asyncio.wait(tasks, timeout=delay, return_when=asyncio.FIRST_COMPLETED)
        finally:
            for t in tasks:
                t.cancel()

    async def request(self, pdu: bytes) -> bytes:
        reader, writer = self._io
        self._tid = (self._tid + 1) & 0xFFFF
        tid = self._tid
        writer.write(struct.pack(">HHHB", tid, 0, len(pdu) + 1, self.unit) + pdu)
        await writer.drain()
        self.counters["requests"] += 1
        try:
            while True:
                head = await asyncio.wait_for(reader.readexactly(7), self.timeout)
                rtid, _pid, length, _uid = struct.unpack(">HHHB", head)
                if not 2 <= length <= 260:
                    raise BadAnswer(f"invalid length {length} in the answer")
                body = await asyncio.wait_for(reader.readexactly(length - 1), self.timeout)
                if rtid == tid:
                    break                                     # a late answer to an old request: skip
        except asyncio.TimeoutError:
            raise NoAnswer(f"no answer in {self.timeout:g} s") from None
        if body[0] & 0x80:
            raise ModbusException(body[0] & 0x7F, body[1] if len(body) > 1 else 0)
        return body

    # ---- reading ----------------------------------------------------------------------------
    async def _poll_once(self):
        now = time.time()
        good = [p for p in self.points if p["tag"] not in self.bad]
        retry = [p for p in self.points if p["tag"] in self.bad and self.bad[p["tag"]]["retry_at"] <= now]
        values = {}
        for table, start, count, pts in blocks(good):
            try:
                data = await self._read(table, start, count)
                for p in pts:
                    values[p["tag"]] = (p, data)
            except ModbusException:
                for p in pts:                                   # find the bad one(s)
                    await self._read_single(p, values)
        for p in retry:
            await self._read_single(p, values)
        self.counters["polls"] += 1
        self._apply(values)

    async def _read_single(self, p, values):
        n = 1 if p["table"] in ("coil", "discrete") or p["type"] == "BOOL" else WORDS[p["type"]]
        try:
            data = await self._read(p["table"], p["addr"], n)
            values[p["tag"]] = (p, data)
            if self.bad.pop(p["tag"], None) is not None:
                self.log("info", f"{p['tag']} ({p['address']}) reads again")
                self.emu.bus.emit("connection", {"kind": self.kind})
        except ModbusException as exc:
            if p["tag"] not in self.bad:
                msg = f"{p['address']}: the device answered {exc}"
                hint = _exc_hint(exc.code, self.unit) or ("Check the address; some manuals count "
                                                          "from 0, others from 1.")
                self.log("warn", f"{p['tag']} — {msg}. {hint} Retrying every 30 s.")
                self.bad[p["tag"]] = {"message": msg, "since": time.time()}
                self.emu.bus.emit("connection", {"kind": self.kind})
            self.bad[p["tag"]]["retry_at"] = time.time() + BAD_RETRY_S

    async def _read(self, table, start, count) -> dict:
        fc = READ_FC[table]
        body = await self.request(struct.pack(">BHH", fc, start, count))
        out = {}
        need = (count + 7) // 8 if table in ("coil", "discrete") else 2 * count
        if body[0] != fc or len(body) < 2 or body[1] < need or len(body) < 2 + need:
            raise BadAnswer(f"short or wrong answer to function {fc} ({len(body)} bytes)")
        if table in ("coil", "discrete"):
            data = body[2:]
            for i in range(count):
                out[start + i] = bool(data[i // 8] >> (i % 8) & 1)
        else:
            regs = struct.unpack(f">{body[1] // 2}H", body[2:2 + body[1]])
            for i, r in enumerate(regs[:count]):
                out[start + i] = r
        return out

    def decode(self, p, data: dict):
        if p["table"] in ("coil", "discrete"):
            return data[p["addr"]]
        if p["type"] == "BOOL":
            return bool(data[p["addr"]] >> (p["bit"] or 0) & 1)
        words = [data[p["addr"] + i] for i in range(WORDS[p["type"]])]
        if self.word_order != "high_first":
            words = words[::-1]
        raw = b"".join(w.to_bytes(2, "big") for w in words)
        t = p["type"]
        if t == "REAL":
            return struct.unpack(">f", raw)[0]
        return int.from_bytes(raw, "big", signed=t in ("INT", "DINT", "LINT"))

    def encode(self, p, raw) -> list[int]:
        t = p["type"]
        if t == "REAL":
            b = struct.pack(">f", float(raw))
        else:
            n = WORDS[t] * 2
            v = int(round(float(raw)))
            lo, hi = (-(1 << (8 * n - 1)), (1 << (8 * n - 1)) - 1) if t in ("INT", "DINT", "LINT") \
                else (0, (1 << (8 * n)) - 1)
            if not lo <= v <= hi:
                raise ValueError(f"{v} does not fit in {t} ({lo} to {hi})")
            b = v.to_bytes(n, "big", signed=t in ("INT", "DINT", "LINT"))
        words = [int.from_bytes(b[i:i + 2], "big") for i in range(0, len(b), 2)]
        return words if self.word_order == "high_first" else words[::-1]

    def _apply(self, values: dict) -> None:
        from ..tagstore import TagStoreError
        changed = False
        for tag, (p, data) in values.items():
            try:
                raw = self.decode(p, data)
            except KeyError:
                continue
            if self._last_raw.get(tag, object()) == raw:
                continue                         # device value unchanged: the tag keeps its value
            self._last_raw[tag] = raw
            if p["dir"] == "out":
                continue                         # read only to know what the device has
            v = raw if isinstance(raw, bool) or (p["scale"] == 1 and not p["offset"]) \
                else raw * p["scale"] + p["offset"]
            try:
                self.emu.store.write(tag, v, source=self._src)
            except TagStoreError as exc:
                self.counters["refused"] += 1
                self.log("warn", f"value for {tag} from {p['address']} refused: {exc}")
            changed = True
        return changed

    # ---- writing ------------------------------------------------------------------------------
    def _on_changes(self, batch: dict, seq: int) -> None:
        if self._kick is not None:
            self._runner.call(self._enqueue, dict(batch))

    def _enqueue(self, batch: dict) -> None:
        self._pending.append(batch)
        self._kick.set()

    async def _flush_writes(self):
        self._kick.clear()
        while self._pending:
            batch = self._pending.pop(0)
            for p in self.points:
                if p["dir"] == "in" or p["tag"] not in batch:
                    continue
                v = batch[p["tag"]]
                raw = v if p["type"] == "BOOL" else (
                    v if p["scale"] == 1 and not p["offset"] else (float(v) - p["offset"]) / p["scale"])
                if p["type"] == "BOOL":
                    raw = bool(raw)
                elif p["type"] != "REAL":
                    raw = int(round(float(raw)))
                if self._last_raw.get(p["tag"], object()) == raw:
                    continue                     # the device already has it (our own read)
                if not self.allow_writes:
                    if not self._writes_off_noted:
                        self.log("warn", f"{p['tag']} changed but writing to the device is off "
                                         "(Settings > Safety > Allow writing to the device)")
                        self._writes_off_noted = True
                    continue
                try:
                    await self._write(p, raw)
                    self._last_raw[p["tag"]] = raw
                    self.counters["writes"] += 1
                except ModbusException as exc:
                    self.counters["refused"] += 1
                    self.log("warn", f"write {p['tag']} -> {p['address']}: the device answered {exc}")
                except ValueError as exc:
                    self.counters["refused"] += 1
                    self.log("warn", f"write {p['tag']} -> {p['address']}: {exc}")

    async def _write(self, p, raw):
        if p["table"] == "coil":
            await self.request(struct.pack(">BHH", 5, p["addr"], 0xFF00 if raw else 0))
        elif p["type"] == "BOOL":                                       # bit in a holding register
            cur = (await self._read("holding", p["addr"], 1))[p["addr"]]
            bit = 1 << (p["bit"] or 0)
            new = (cur | bit) if raw else (cur & ~bit & 0xFFFF)
            await self.request(struct.pack(">BHH", 6, p["addr"], new))
        else:
            words = self.encode(p, raw)
            if len(words) == 1:
                await self.request(struct.pack(">BHH", 6, p["addr"], words[0]))
            else:
                await self.request(struct.pack(f">BHHB{len(words)}H", 16, p["addr"], len(words),
                                               2 * len(words), *words))

    # ---- Connections page -----------------------------------------------------------------------
    def other_side(self) -> dict:
        return {"values": {"Device": f"{self.host}:{self.port}", "Unit ID": str(self.unit),
                           "Writing": "allowed" if self.allow_writes else "off (read only)"},
                "steps": [
                    "On the device: turn on its Modbus TCP server (some devices call it 'Modbus "
                    "slave') and note its IP address. Use the device manual's register list.",
                    "Add one point per value on the Tags tab: the tag name, the Modbus address "
                    "(40001 = first holding register, 30001 = first input register, 1 = first "
                    "coil, 10001 = first discrete input), the data type, and scale/offset if the "
                    "device sends e.g. tenths of a degree.",
                    "Some manuals give 0-based offsets (register 0 = 40001). If every value is "
                    "off by one point, or the device answers 'illegal data address', shift the "
                    "addresses by one.",
                    "This PC must reach the device: same network, no firewall blocking port "
                    f"{self.port}. Only one or two Modbus clients are allowed on some devices — "
                    "close other polling tools.",
                    "Writing to a real device is off until you turn on 'Allow writing to the "
                    "device'. Never write to equipment that can move without checking first."],
                "examples": {}}

    @classmethod
    def test(cls, emu, params: dict, running=None, mapping=None) -> list[dict]:
        host, port = str(params.get("host") or "").strip(), int(params.get("port", 502))
        unit = int(params.get("unit_id", 1))
        if not host:
            return [_check(False, "Enter the device's IP address")]
        checks = []
        try:
            ip = socket.gethostbyname(host)
            checks.append(_check(True, f"{host} is {ip}" if ip != host else f"Address {ip}"))
        except OSError as exc:
            e = explain(exc, host=host, port=port)
            return checks + [_check(False, e["message"], e["hint"])]
        try:
            pts = points(mapping if mapping is not None else
                         (running.points if running is not None else []))
        except ParamError as exc:
            pts = []
            checks.append(_check(False, str(exc)))
        try:
            got = asyncio.run(_probe(ip, port, unit, float(params.get("timeout_s", 2)),
                                     params.get("word_order", "high_first"), pts[:8]))
            checks.append(_check(True, f"{ip}:{port} accepts connections"))
            for label, ok, hint in got:
                checks.append(_check(ok, label, hint))
        except Exception as exc:
            e = _explain(exc, ip, port, unit)
            checks.append(_check(False, e["message"], e["hint"]))
            return checks
        if not pts:
            checks.append(_check(None, "No points yet — add them on the Tags tab"))
        if not params.get("allow_writes"):
            checks.append(_check(None, "Writing to the device is off (read only)",
                                 "Turn on 'Allow writing to the device' only when it is safe."))
        if running is not None:
            st = running.status()
            checks.append(_check(st["state"] == "connected", f"The connection is {st['state']}",
                                 (st.get("error") or {}).get("hint", "")))
        return checks


async def _probe(ip, port, unit, timeout, word_order, pts):
    """Connect and read a few points (or holding register 40001)."""
    c = ModbusClientConnector.__new__(ModbusClientConnector)
    c.unit, c.timeout, c.word_order, c._tid = unit, timeout, word_order, 0
    c.counters = {"requests": 0}
    c._io = await asyncio.wait_for(asyncio.open_connection(ip, port), timeout + 3)
    out = []
    try:
        targets = pts or [point({"tag": "test", "address": "40001"})]
        for p in targets:
            n = 1 if p["table"] in ("coil", "discrete") or p["type"] == "BOOL" else WORDS[p["type"]]
            try:
                data = await c._read(p["table"], p["addr"], n)
                v = c.decode(p, data)
                if not isinstance(v, bool) and (p["scale"] != 1 or p["offset"]):
                    v = round(v * p["scale"] + p["offset"], 6)
                who = p["tag"] if pts else "Holding register 40001"
                out.append((f"{who} ({p['address']}) = {v}" if pts else
                            f"The device answered: {who} = {v}", True, ""))
            except ModbusException as exc:
                if exc.code in (2, 3):
                    out.append((f"{p['tag'] if pts else '40001'} ({p['address']}): {exc}",
                                False if pts else None,
                                "Check the address; some manuals count from 0, others from 1."
                                if pts else "The device answered, so the connection works; "
                                            "40001 is just not one of its registers."))
                else:
                    out.append((f"{p['address']}: {exc}", False, _exc_hint(exc.code, unit)))
    finally:
        c._io[1].close()
    return out


def _exc_hint(code, unit):
    if code in (10, 11):
        return (f"The gateway could not reach serial device {unit}. Check the unit ID and the "
                "serial wiring/baud rate behind the gateway.")
    if code == 1:
        return "The device does not support this function (e.g. it has no coils)."
    return ""


def _explain(exc, host, port, unit) -> dict:
    if isinstance(exc, ModbusException):
        return {"code": "modbus", "message": f"The device answered {exc}.",
                "hint": _exc_hint(exc.code, unit), "detail": str(exc)}
    if isinstance(exc, BadAnswer):
        return {"code": "bad_answer", "message": f"{host}:{port} sent an answer that is not valid Modbus ({exc}).",
                "hint": "Is this really a Modbus TCP port? Check the port number in the device manual.",
                "detail": str(exc)}
    if isinstance(exc, NoAnswer):
        return {"code": "timeout", "message": f"{host}:{port} accepted the connection but did not answer.",
                "hint": f"Check the unit ID ({unit}); some devices only answer 1, 0 or 255. "
                        "Another Modbus client may also be holding the device.", "detail": str(exc)}
    if isinstance(exc, asyncio.IncompleteReadError):
        return {"code": "closed", "message": f"{host}:{port} closed the connection.",
                "hint": "The device may allow only one or two clients, or rejects this unit ID.",
                "detail": str(exc)}
    return explain(exc, port=port, host=host, kind="modbus_client")


def _check(ok, label, hint=""):
    return {"ok": ok, "label": label, "hint": hint}
