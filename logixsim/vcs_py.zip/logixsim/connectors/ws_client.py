"""WebSocket client connector: VirtualControlStudio connects OUT to a simulator
(or a Node-RED ``websocket-listener``) and exchanges tag values with it.

Message formats
* ``flat-json`` (default): JSON objects ``{"key": value, ...}`` both ways. Keys may
  be dotted paths (``agv1.pos``) into nested objects.
* ``vcs``: the other side speaks the VirtualControlStudio protocol (for example
  another VirtualControlStudio): we send hello + subscribe, apply its
  ``snapshot``/``changes`` to our tags, and send our changes as ``write``.

Mapping rows: ``{"tag": "AGV1_Pos", "key": "agv1.pos", "dir": "in"|"out"|"both",
"scale": 1.0, "offset": 0.0}``. Incoming: tag = value * scale + offset; outgoing:
value = (tag - offset) / scale. Besides the mapping, ``send_tags`` (patterns) are
sent under their own names, and incoming keys matching ``receive_tags`` are
written to tags of the same name.

The connection is kept up: reconnect after 1, 2, 5, 10, then every 30 s, with a
heartbeat ping; the status says "reconnecting (attempt n, next in s)".
"""
from __future__ import annotations

import asyncio
import json
import socket
import time
from urllib.parse import urlparse

from .base import Connector, ParamError, register
from .errors import explain
from .runner import LoopThread

BACKOFF = (1, 2, 5, 10, 30)


@register("ws_client")
class WsClientConnector(Connector):
    name = kind = "ws_client"
    title = "WebSocket client"
    role = "client"
    summary = "VirtualControlStudio connects to a simulator or a Node-RED WebSocket listener"
    schema = [
        {"name": "url", "type": "str", "label": "Server URL", "default": "", "required": True,
         "group": "Network", "help": "For example ws://192.168.1.50:9000/sim or ws://nodered:1880/ws/vcs"},
        {"name": "format", "type": "str", "label": "Message format", "default": "flat-json",
         "group": "Protocol",
         "choices": [["flat-json", 'Flat JSON {"key": value}'],
                     ["vcs", "VirtualControlStudio protocol"]]},
        {"name": "heartbeat_s", "type": "float", "label": "Heartbeat (s)", "default": 10, "min": 0,
         "max": 600, "group": "Protocol", "advanced": True,
         "help": "Ping interval; the connection is restarted when no answer comes. 0 = off."},
        {"name": "send_tags", "type": "list", "label": "Also send tags", "default": [],
         "group": "Tags", "help": "Tag patterns sent under their own names (besides the mapping)."},
        {"name": "receive_tags", "type": "list", "label": "Also accept tags", "default": [],
         "group": "Tags", "help": "Incoming keys matching these patterns write the tag of that name."},
        {"name": "deadband", "type": "float", "label": "REAL deadband", "default": 0, "min": 0,
         "group": "Tags", "advanced": True},
    ]

    def __init__(self, emu, url="", format="flat-json", heartbeat_s=10, send_tags=None,
                 receive_tags=None, deadband=0, mapping=None, **settings):
        super().__init__(emu, **settings)
        u = urlparse(url or "")
        if u.scheme not in ("ws", "wss") or not u.hostname:
            raise ParamError("url", f"{url!r} is not a WebSocket URL (ws://host:port/path)")
        self.url, self.format = url, format
        self.heartbeat = float(heartbeat_s or 0)
        self.send_tags, self.receive_tags = list(send_tags or []), list(receive_tags or [])
        self.deadband = float(deadband or 0)
        self.mapping = [_row(m) for m in (mapping or [])]
        self.state = "off"
        self.attempt = 0
        self.next_retry = None
        self.last_error = None
        self.since = None
        self.counters = {"msgs_in": 0, "msgs_out": 0, "refused": 0}
        self._runner = LoopThread("ws-client")
        self._sub = None
        self._out: asyncio.Queue | None = None

    # ---- lifecycle --------------------------------------------------------------------
    def start(self) -> None:
        async def main(ready):
            self._out = asyncio.Queue()
            ready()
            await self._keep_connected()
        self.state = "connecting"
        pats = self._out_patterns()
        if pats:                       # before the first connect, so it sees current values
            self._sub = self.emu.bus.subscribe(pats, self._on_changes, deadband=self.deadband)
            self.emu.bus.start()
        self._runner.start(main)

    def stop(self) -> None:
        if self._sub is not None:
            self.emu.bus.unsubscribe(self._sub)
            self._sub = None
        self._runner.stop()
        self.state = "off"

    @property
    def running(self) -> bool:
        return self._runner.alive

    def status(self) -> dict:
        st = {"name": self.name, "running": self.running, "endpoint": self.url,
              "state": self.state, "since": self.since, **self.counters}
        if self.state == "reconnecting":
            st["attempt"] = self.attempt
            st["next_in"] = max(0, round((self.next_retry or 0) - time.time(), 1))
        if self.last_error:
            st["error"] = self.last_error
        return st

    # ---- the connection loop ----------------------------------------------------------
    async def _keep_connected(self):
        from websockets.asyncio.client import connect
        stopping = self._runner.stopping
        while not stopping.is_set():
            try:
                async with connect(self.url, proxy=None, open_timeout=5,
                                   ping_interval=self.heartbeat or None,
                                   ping_timeout=self.heartbeat or None,
                                   max_size=1024 * 1024) as ws:
                    self.state, self.attempt, self.last_error = "connected", 0, None
                    self.since = time.time()
                    self.log("info", f"connected to {self.url}")
                    self.emu.bus.emit("connection", {"kind": self.kind})
                    await self._on_open(ws)
                    await self._pump(ws, stopping)
                if stopping.is_set():
                    break
                raise ConnectionError("the server closed the connection")
            except Exception as exc:
                if stopping.is_set():
                    break
                u = urlparse(self.url)
                e = explain(exc, port=u.port, host=u.hostname, kind=self.kind)
                was_connected = self.state == "connected"
                self.last_error = e
                delay = BACKOFF[min(self.attempt, len(BACKOFF) - 1)]
                self.attempt += 1
                self.state, self.next_retry = "reconnecting", time.time() + delay
                self.log("warn" if was_connected else "error",
                         f"{e['message']} Retry {self.attempt} in {delay} s.")
                self.emu.bus.emit("connection", {"kind": self.kind})
                try:
                    await asyncio.wait_for(stopping.wait(), delay)
                except asyncio.TimeoutError:
                    pass
        self.state = "off"

    async def _pump(self, ws, stopping):
        async def sender():
            while True:
                msg = await self._out.get()
                await ws.send(json.dumps(msg, default=str))
                self.counters["msgs_out"] += 1

        async def receiver():
            async for text in ws:
                self.counters["msgs_in"] += 1
                self._on_message(text)
        tasks = [asyncio.create_task(sender()), asyncio.create_task(receiver()),
                 asyncio.create_task(stopping.wait())]
        done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()
        for t in done:
            if t.exception() and not stopping.is_set():
                raise t.exception()

    async def _on_open(self, ws):
        while not self._out.empty():                 # stale messages from before
            self._out.get_nowait()
        if self.format == "vcs":
            keys = [m["key"] for m in self.mapping if m["dir"] in ("in", "both")] + self.receive_tags
            await ws.send(json.dumps({"op": "hello", "client": "VirtualControlStudio"}))
            if keys:
                await ws.send(json.dumps({"op": "subscribe", "tags": keys}))
        current = {a: v for a, v in self.emu.store.flat().items() if self._sub and self._sub.matches(a)}
        if current:
            self._send(current)

    # ---- tag values -> the other side ------------------------------------------------
    def _out_patterns(self) -> list[str]:
        return [m["tag"] for m in self.mapping if m["dir"] in ("out", "both")] + self.send_tags

    def _on_changes(self, batch: dict, seq: int) -> None:
        self._runner.call(self._send, batch)

    def _send(self, batch: dict) -> None:
        if self._out is None or self.state != "connected":
            return
        from ..events import compile_pattern
        out = {}
        send_all = [compile_pattern(p) for p in self.send_tags]
        for addr, v in batch.items():
            for m in self.mapping:
                if m["dir"] in ("out", "both") and (addr == m["tag"]):
                    out[m["key"]] = _to_remote(v, m)
            if any(p(addr) for p in send_all):
                out[addr] = v
        if not out:
            return
        if self.format == "vcs":
            self._out.put_nowait({"op": "write", "values": out})
        else:
            self._out.put_nowait(_nest(out))

    # ---- the other side -> tag values -------------------------------------------------
    def _on_message(self, text: str) -> None:
        try:
            msg = json.loads(text)
        except ValueError:
            self.log("warn", f"ignored a message that is not JSON: {text[:80]!r}")
            return
        if not isinstance(msg, dict):
            return
        if self.format == "vcs":
            if msg.get("op") in ("snapshot", "changes", "values"):
                values = msg.get("values") or {}
            elif msg.get("op") == "error":
                self.log("warn", f"the server reported: {msg.get('error')}")
                return
            else:
                return
        else:
            values = _flatten(msg)
        self._apply(values)

    def _apply(self, values: dict) -> None:
        from ..events import compile_pattern
        from ..tagstore import TagStoreError
        direct = [compile_pattern(p) for p in self.receive_tags]
        src = f"conn:{self.settings.get('_name') or self.kind}"
        for key, v in values.items():
            targets = [(m["tag"], _to_tag(v, m)) for m in self.mapping
                       if m["dir"] in ("in", "both") and m["key"] == key]
            if not targets and any(p(key) for p in direct):
                targets = [(key, v)]
            for tag, value in targets:
                try:
                    self.emu.store.write(tag, value, source=src)
                except TagStoreError as exc:
                    self.counters["refused"] += 1
                    self.log("warn", f"value for {tag} (from '{key}') refused: {exc}")

    # ---- Connections page ---------------------------------------------------------------
    def other_side(self) -> dict:
        steps = ["The other program must run a WebSocket server at the URL above.",
                 'Format flat JSON: it receives objects like {"agv1": {"go": true}} and sends '
                 'objects in the same shape; each key in the mapping is a dotted path.'
                 if self.format == "flat-json" else
                 "Format VirtualControlStudio protocol: the other side answers hello/subscribe "
                 "and accepts write messages (for example another VirtualControlStudio).",
                 "Node-RED as the server: add a 'websocket in' node with a 'Listen on' path "
                 "(e.g. /ws/vcs) and set this URL to ws://<node-red-ip>:1880/ws/vcs."]
        return {"values": {"URL": self.url}, "steps": steps, "examples": {}}

    @classmethod
    def test(cls, emu, params: dict, running=None) -> list[dict]:
        url = params.get("url") or ""
        u = urlparse(url)
        if u.scheme not in ("ws", "wss") or not u.hostname:
            return [_check(False, f"{url!r} is not a WebSocket URL", "Use ws://host:port/path")]
        port = u.port or (443 if u.scheme == "wss" else 80)
        checks = []
        try:
            ip = socket.gethostbyname(u.hostname)
            checks.append(_check(True, f"{u.hostname} is {ip}" if ip != u.hostname else f"Address {ip}"))
        except OSError as exc:
            e = explain(exc, host=u.hostname, port=port)
            return checks + [_check(False, e["message"], e["hint"])]
        try:
            with socket.create_connection((ip, port), timeout=3):
                pass
            checks.append(_check(True, f"{ip}:{port} accepts connections"))
        except OSError as exc:
            e = explain(exc, host=u.hostname, port=port)
            return checks + [_check(False, e["message"], e["hint"])]
        try:
            asyncio.run(_handshake(url))
            checks.append(_check(True, "WebSocket handshake succeeded"))
        except Exception as exc:
            e = explain(exc, host=u.hostname, port=port)
            checks.append(_check(False, e["message"], e["hint"]))
        if running is not None:
            st = running.status()
            checks.append(_check(st["state"] == "connected",
                                 f"The connection is {st['state']}",
                                 (st.get("error") or {}).get("hint", "")))
        return checks


async def _handshake(url):
    from websockets.asyncio.client import connect
    async with connect(url, proxy=None, open_timeout=3):
        pass


def _row(m: dict) -> dict:
    if not isinstance(m, dict) or not m.get("tag") or not m.get("key"):
        raise ParamError("mapping", "each mapping row needs a tag and a key")
    d = str(m.get("dir") or "both")
    if d not in ("in", "out", "both"):
        raise ParamError("mapping", f"direction must be in, out or both (got {d!r})")
    scale = float(m.get("scale") if m.get("scale") not in (None, "") else 1.0)
    if scale == 0:
        raise ParamError("mapping", f"scale for {m['tag']} cannot be 0")
    return {"tag": str(m["tag"]).strip(), "key": str(m["key"]).strip(), "dir": d, "scale": scale,
            "offset": float(m.get("offset") if m.get("offset") not in (None, "") else 0.0)}


def _to_tag(v, m):
    if isinstance(v, (int, float)) and not isinstance(v, bool) and (m["scale"] != 1 or m["offset"]):
        return v * m["scale"] + m["offset"]
    return v


def _to_remote(v, m):
    if isinstance(v, (int, float)) and not isinstance(v, bool) and (m["scale"] != 1 or m["offset"]):
        return (v - m["offset"]) / m["scale"]
    return v


def _flatten(obj, prefix="") -> dict:
    out = {}
    for k, v in obj.items():
        key = f"{prefix}{k}"
        out[key] = v
        if isinstance(v, dict):
            out.update(_flatten(v, key + "."))
    return out


def _nest(flat: dict) -> dict:
    out: dict = {}
    for key, v in flat.items():
        parts = key.split(".") if "[" not in key else [key]
        d = out
        for p in parts[:-1]:
            d = d.setdefault(p, {}) if isinstance(d.get(p, {}), dict) else d
        d[parts[-1]] = v
    return out


def _check(ok, label, hint=""):
    return {"ok": ok, "label": label, "hint": hint}
