"""WebSocket server connector: the VirtualControlStudio JSON protocol (the same
messages as /api/v1/ws, see api.py) on its own port.

Why a separate port: Node-RED or a simulator on another PC can reach this
endpoint while the engineering UI and its edit API stay on 127.0.0.1.

Per connection: who can connect (this PC / the network), an optional access
token (``?token=..`` in the URL or ``Authorization: Bearer ..``), read-only or
read-write, which tags are visible and which may be written, and whether
run/stop/force/define are allowed. ``?subscribe=*`` (or a comma list of
patterns) in the URL subscribes at connect time, so a client that cannot send a
first message (Node-RED's websocket-client after a reconnect) still gets a
snapshot and every change.
"""
from __future__ import annotations

import asyncio
import hmac
import json
import time
from urllib.parse import parse_qs, urlparse

from .base import BIND_FIELD, Connector, bind_address, register
from .errors import explain, local_ips, port_free
from .runner import LoopThread

MAX_MESSAGE = 1024 * 1024
MAX_CLIENTS = 64


@register("ws_server")
class WsServerConnector(Connector):
    name = kind = "ws_server"
    title = "WebSocket server"
    role = "server"
    summary = "Node-RED, simulators and scripts connect to VirtualControlStudio"
    schema = [
        dict(BIND_FIELD),
        {"name": "port", "type": "int", "label": "Port", "default": 8810, "min": 1, "max": 65535,
         "group": "Network", "help": "The port clients connect to (not the UI port 8800)."},
        {"name": "path", "type": "str", "label": "Path", "default": "/api/v1/ws", "group": "Network",
         "advanced": True, "help": "URL path. '/' is also accepted."},
        {"name": "access", "type": "str", "label": "Access", "default": "rw", "group": "Access",
         "choices": [["rw", "Read and write"], ["ro", "Read only"]]},
        {"name": "read_tags", "type": "list", "label": "Tags shared", "default": ["*"],
         "group": "Access", "help": "Tag patterns clients can see. * = all; AGV* = names starting AGV."},
        {"name": "write_tags", "type": "list", "label": "Tags it may write", "default": ["*"],
         "group": "Access", "help": "Writes to other tags are refused and shown in Activity."},
        {"name": "control", "type": "bool", "label": "Allow run / stop / force / define",
         "default": False, "group": "Access", "advanced": True},
        {"name": "token", "type": "str", "label": "Access token", "default": "", "group": "Security",
         "advanced": True, "secret": True,
         "help": "Optional. Clients add ?token=<value> to the URL. Recommended when other computers "
                 "can connect."},
    ]

    def __init__(self, emu, bind="local", port=8810, path="/api/v1/ws", access="rw",
                 read_tags=None, write_tags=None, control=False, token="", host=None, **settings):
        super().__init__(emu, **settings)
        if host and bind == "local":                 # legacy 'host' setting
            bind = "local" if host in ("127.0.0.1", "localhost") else host
        self.bind, self.host = bind, bind_address(bind)
        self.port, self.path = int(port), "/" + (path or "").strip("/")
        self.policy = {"access": access, "read": list(read_tags or ["*"]),
                       "write": list(write_tags or ["*"]), "control": bool(control)}
        self.token = token or ""
        self.clients: dict[int, dict] = {}
        self.counters = {"msgs_in": 0, "msgs_out": 0, "refused": 0}
        self._runner = LoopThread("ws-server")
        self._server = None
        self._ids = 0

    # ---- lifecycle --------------------------------------------------------------------
    def start(self) -> None:
        from websockets.asyncio.server import serve

        async def main(ready):
            async with serve(self._session, self.host, self.port, max_size=MAX_MESSAGE,
                             process_request=self._check_request, ping_interval=20,
                             ping_timeout=20, server_header="VirtualControlStudio") as server:
                self._server = server
                ready()
                await self._runner.stopping.wait()
            self._server = None
        self._runner.start(main)
        self.log("info", f"listening on {self.host}:{self.port}{self.path}")

    def stop(self) -> None:
        self._runner.stop()
        self.clients.clear()

    @property
    def running(self) -> bool:
        return self._runner.alive and self._server is not None

    def status(self) -> dict:
        n = len(self.clients)
        return {"name": self.name, "running": self.running, "endpoint": self.urls()[0],
                "urls": self.urls(), "clients": [dict(c) for c in self.clients.values()],
                "client_count": n, **self.counters}

    def urls(self) -> list[str]:
        hosts = local_ips() if self.host == "0.0.0.0" else [self.host]
        return [f"ws://{h}:{self.port}{self.path}" for h in hosts]

    # ---- connections ------------------------------------------------------------------
    def _check_request(self, connection, request):
        url = urlparse(request.path)
        if url.path.rstrip("/") not in (self.path.rstrip("/"), ""):
            return connection.respond(404, f"no WebSocket endpoint at {url.path}\n")
        if len(self.clients) >= MAX_CLIENTS:
            self.log("warn", f"client {_peer(connection)} refused: {MAX_CLIENTS} clients already")
            return connection.respond(503, "too many clients\n")
        if self.token:
            q = parse_qs(url.query)
            given = (q.get("token") or [""])[0]
            auth = request.headers.get("Authorization", "")
            if auth.lower().startswith("bearer "):
                given = given or auth[7:].strip()
            if not hmac.compare_digest(given.encode(), self.token.encode()):
                self.log("warn", f"client {_peer(connection)} refused: wrong or missing access token")
                return connection.respond(403, "wrong or missing access token\n")
        return None

    async def _session(self, ws):
        from ..api import handle_with_policy
        loop = asyncio.get_running_loop()
        out: asyncio.Queue = asyncio.Queue()
        self._ids += 1
        cid = self._ids
        peer = _peer(ws)
        info = {"id": cid, "address": peer, "client": "anon", "since": time.time(),
                "msgs_in": 0, "msgs_out": 0}
        self.clients[cid] = info
        conn = {"client": "anon", "subs": {}, "refused": 0,
                "on_refused": lambda text: self.log("warn", f"{peer}: {text}")}

        def push(msg):
            loop.call_soon_threadsafe(out.put_nowait, msg)

        def on_event(kind, data):
            if kind != "connection":             # internal (Connections page) events
                push({"op": "event", "kind": kind, "data": data})

        self.emu.bus.on_event(on_event)
        self.log("info", f"client {peer} connected")
        self.emu.bus.emit("connection", {"kind": self.kind})

        async def sender():
            while True:
                msg = await out.get()
                await ws.send(json.dumps(msg, default=str))
                info["msgs_out"] += 1
                self.counters["msgs_out"] += 1

        task = asyncio.create_task(sender())
        try:
            q = parse_qs(urlparse(ws.request.path).query)
            if q.get("subscribe"):
                pats = [p for p in ",".join(q["subscribe"]).split(",") if p.strip()]
                for r in handle_with_policy(self.emu, conn, {"op": "subscribe", "tags": pats},
                                            push, self.policy):
                    out.put_nowait(r)
            async for text in ws:
                info["msgs_in"] += 1
                self.counters["msgs_in"] += 1
                try:
                    msg = json.loads(text)
                    if not isinstance(msg, dict):
                        raise ValueError("message must be a JSON object")
                except ValueError as exc:
                    out.put_nowait({"op": "error", "error": f"bad message: {exc}"})
                    continue
                before = conn["refused"]
                for reply in handle_with_policy(self.emu, conn, msg, push, self.policy):
                    if msg.get("id") is not None and "id" not in reply:
                        reply["id"] = msg["id"]
                    out.put_nowait(reply)
                self.counters["refused"] += conn["refused"] - before
                if msg.get("op") == "hello":
                    info["client"] = conn["client"]
                    self.log("info", f"{peer} is '{conn['client']}'")
        except Exception as exc:                     # connection closed or broken
            if type(exc).__name__ not in ("ConnectionClosedOK", "ConnectionClosedError",
                                          "ConnectionClosed"):
                self.log("warn", f"{peer}: {exc}")
        finally:
            for sub in conn["subs"].values():
                self.emu.bus.unsubscribe(sub)
            self.emu.bus.off_event(on_event)
            task.cancel()
            self.clients.pop(cid, None)
            self.log("info", f"client {peer} disconnected")
            self.emu.bus.emit("connection", {"kind": self.kind})

    # ---- Connections page ---------------------------------------------------------------
    def other_side(self) -> dict:
        urls = self.urls()
        sub_url = urls[0] + ("&" if "?" in urls[0] else "?") + "subscribe=*"
        if self.token:
            sub_url += f"&token={self.token}"
        return {
            "values": {"URL": urls[0], "URL with auto-subscribe": sub_url,
                       **({"Other addresses": ", ".join(urls[1:])} if len(urls) > 1 else {})},
            "steps": [
                "Node-RED: Menu > Import, paste the flow from 'Download Node-RED flow', Deploy. "
                "No extra palette packages are needed.",
                "Any program: connect a WebSocket to the URL. Send "
                '{"op":"hello","client":"my-sim"} then {"op":"subscribe","tags":["*"]}; '
                'write with {"op":"write","values":{"Start_PB":true}}.',
                "Or use the auto-subscribe URL: values arrive without sending anything.",
            ] + (["Other computers must use this PC's address (not 127.0.0.1). If they cannot "
                  "connect, allow Python through Windows Firewall for Private networks."]
                 if self.host == "0.0.0.0" else
                 ["Only programs on this PC can connect. Choose 'Other computers on the network' "
                  "for Node-RED on another PC."]),
            "examples": {
                "subscribe": '{"op":"subscribe","tags":["*"]}',
                "write": '{"op":"write","values":{"Start_PB":true}}',
                "python": "import asyncio, json, websockets\n"
                          "async def main():\n"
                          f"    async with websockets.connect('{sub_url}') as ws:\n"
                          "        async for msg in ws:\n"
                          "            print(json.loads(msg))\n"
                          "asyncio.run(main())",
            },
        }

    @classmethod
    def test(cls, emu, params: dict, running=None) -> list[dict]:
        host, port = bind_address(params.get("bind", "local")), int(params.get("port", 8810))
        checks = []
        if running is None or not running.running:
            ok, err = port_free(host, port)
            checks.append(_check(ok, f"Port {port} is free" if ok else err["message"],
                                 "" if ok else err["hint"]))
            if not ok:
                return checks
            checks.append(_check(None, "Not running — turn the connection on to accept clients"))
            return checks
        checks.append(_check(True, f"Listening on {', '.join(running.urls())}"))
        target = "127.0.0.1" if host == "0.0.0.0" else host
        q = f"?token={running.token}" if running.token else ""
        t0 = time.perf_counter()
        try:
            got = asyncio.run(_probe(f"ws://{target}:{port}{running.path}{q}"))
            checks.append(_check(got.get("op") == "welcome",
                                 f"A test client connected and was answered ({time.perf_counter() - t0:.2f} s)"))
        except Exception as exc:
            e = explain(exc, port=port, host=target)
            checks.append(_check(False, e["message"], e["hint"]))
        if host != "127.0.0.1" and not running.token:
            checks.append(_check(None, "Other computers can connect without an access token",
                                 "Set an access token (Settings, advanced) and limit 'Tags it may "
                                 "write' when the network is shared."))
        if host == "0.0.0.0":
            checks.append(_check(None, "Not tested from the other PC yet",
                                 "If it cannot connect, allow Python through Windows Firewall "
                                 "for Private networks."))
        return checks


async def _probe(url: str) -> dict:
    from websockets.asyncio.client import connect
    async with connect(url, proxy=None, open_timeout=3) as ws:
        await ws.send(json.dumps({"op": "hello", "client": "vcs-test", "id": 1}))
        while True:
            m = json.loads(await asyncio.wait_for(ws.recv(), 3))
            if m.get("id") == 1 or m.get("op") == "welcome":
                return m


def _peer(conn) -> str:
    try:
        a = conn.remote_address
        return f"{a[0]}:{a[1]}"
    except Exception:
        return "?"


def _check(ok, label, hint=""):
    return {"ok": ok, "label": label, "hint": hint}
