"""Connector interface and registry.

A connector links the emulator's tags to the outside world (a server other
programs connect to, or a client that connects out). Version 2 of the interface
adds what the Connections page needs; every addition has a default, so older
connectors keep working:

* ``kind`` / ``title`` / ``role`` ("server" | "client") / ``summary``
* ``schema``: the parameters, as a list of field dicts::

      {"name": "port", "type": "int", "label": "Port", "default": 8810, "min": 1,
       "max": 65535, "group": "Network", "help": "...", "advanced": False,
       "choices": [[value, label], ...]}

  The UI builds its forms from this; ``validate_params`` checks values with it.
* ``test(emu, params) -> list[check]``: checks without disturbing a running
  connection; each check is ``{"ok": bool | None, "label": str, "hint": str}``.
* ``other_side()``: what to enter on the other system (copyable values, steps).
* ``log(level, message)``: activity log, provided by the ConnectionManager.
"""
from __future__ import annotations

import ipaddress
from typing import Callable

REGISTRY: dict[str, Callable] = {}


class Connector:
    """Base class. ``emu`` is the Emulator; ``settings`` come from the project file."""
    name = "connector"
    kind = "connector"
    title = "Connector"
    role = "server"
    summary = ""
    schema: list[dict] = []

    def __init__(self, emu, **settings):
        self.emu = emu
        self.settings = settings
        self._log = None                    # set by the ConnectionManager

    def start(self) -> None:          # pragma: no cover - interface
        raise NotImplementedError

    def stop(self) -> None:           # pragma: no cover - interface
        raise NotImplementedError

    def status(self) -> dict:
        return {"name": self.name, "running": False}

    # ---- v2 -----------------------------------------------------------------------------
    def log(self, level: str, message: str) -> None:
        if self._log:
            self._log(level, message)

    def other_side(self) -> dict:
        return {"steps": [], "values": {}}

    @classmethod
    def test(cls, emu, params: dict, running=None) -> list[dict]:
        """Checks for the Connections page. ``running`` is the live connector of this
        connection, if it is on; tests must not disturb it."""
        return []

    @classmethod
    def defaults(cls) -> dict:
        return {f["name"]: f.get("default") for f in cls.schema if "default" in f}


# ---- parameter checking (shared by every connector) -----------------------------------------
class ParamError(ValueError):
    def __init__(self, field: str, message: str):
        super().__init__(message)
        self.field = field


def validate_params(schema: list[dict], params: dict) -> dict:
    """Return cleaned params: defaults filled in, types converted, ranges checked."""
    out = {}
    params = dict(params or {})
    known = {f["name"] for f in schema}
    for f in schema:
        name, typ = f["name"], f.get("type", "str")
        v = params.get(name, f.get("default"))
        label = f.get("label", name)
        if v is None or v == "":
            if f.get("required"):
                raise ParamError(name, f"{label} is required")
            out[name] = f.get("default") if v is None else v
            continue
        try:
            if typ == "int":
                if isinstance(v, bool) or (isinstance(v, float) and not v.is_integer()):
                    raise ValueError
                v = int(str(v).strip())
            elif typ == "float":
                v = float(v)
            elif typ == "bool":
                v = v if isinstance(v, bool) else str(v).strip().lower() in ("1", "true", "yes", "on")
            elif typ == "list":
                if isinstance(v, str):
                    v = [x.strip() for x in v.replace("\n", ",").split(",") if x.strip()]
                elif not isinstance(v, list):
                    raise ValueError
            elif typ == "dict":
                if not isinstance(v, dict):
                    raise ValueError
            else:
                v = str(v).strip()
        except (TypeError, ValueError):
            raise ParamError(name, f"{label}: {v!r} is not a valid {typ}") from None
        if typ in ("int", "float"):
            if "min" in f and v < f["min"]:
                raise ParamError(name, f"{label} must be at least {f['min']}")
            if "max" in f and v > f["max"]:
                raise ParamError(name, f"{label} must be at most {f['max']}")
        if f.get("choices") and v not in [c[0] if isinstance(c, (list, tuple)) else c
                                          for c in f["choices"]]:
            raise ParamError(name, f"{label}: {v!r} is not one of the choices")
        out[name] = v
    for k, v in params.items():               # keep unknown keys (forward compatibility)
        if k not in known:
            out[k] = v
    return out


def bind_address(bind: str) -> str:
    """'local' -> 127.0.0.1, 'lan' -> 0.0.0.0 (all network cards), else an IP."""
    b = (bind or "local").strip()
    if b == "local":
        return "127.0.0.1"
    if b in ("lan", "all", "0.0.0.0"):
        return "0.0.0.0"
    try:
        ipaddress.ip_address(b)
    except ValueError:
        raise ParamError("bind", f"{b!r} is not 'local', 'lan' or an IP address") from None
    return b


BIND_FIELD = {"name": "bind", "type": "str", "label": "Who can connect", "default": "local",
              "group": "Network",
              "choices": [["local", "This PC only"], ["lan", "Other computers on the network"]],
              "help": "Other computers: only this connection's port is opened to the network; "
                      "the engineering UI stays local."}


def register(name: str):
    def deco(factory):
        REGISTRY[name] = factory
        return factory
    return deco


def create(name: str, emu, settings: dict):
    """Build a connector from project settings ({"enabled": false} -> None)."""
    _load_builtins()
    settings = dict(settings or {})
    if not settings.pop("enabled", True):
        return None
    if name not in REGISTRY:
        raise ValueError(f"unknown connector {name!r} (known: {', '.join(sorted(REGISTRY))})")
    return REGISTRY[name](emu, **settings)


def _load_builtins() -> None:
    """Import the bundled connectors so they register themselves."""
    from . import cip, modbus_client, modbus_tcp, opcua, ws_client, ws_server  # noqa: F401
