"""Run one connector's asyncio code in its own thread and event loop, so a slow
or failing connection never blocks the scan engine, the web UI or the others."""
from __future__ import annotations

import asyncio
import threading
from typing import Awaitable, Callable


class LoopThread:
    """``start(main)`` runs ``await main(ready)`` in a new thread; ``main`` calls
    ``ready()`` once it is up (or raises). ``stop()`` sets ``self.stopping``
    (an asyncio.Event inside the loop) and joins the thread."""

    def __init__(self, name: str):
        self.name = name
        self.loop: asyncio.AbstractEventLoop | None = None
        self.stopping: asyncio.Event | None = None
        self._thread: threading.Thread | None = None
        self._ready = threading.Event()
        self.error: BaseException | None = None

    def start(self, main: Callable[[Callable[[], None]], Awaitable[None]], timeout: float = 15.0):
        self._ready.clear()
        self.error = None

        def run():
            loop = asyncio.new_event_loop()
            self.loop = loop
            asyncio.set_event_loop(loop)
            try:
                self.stopping = asyncio.Event()
                loop.run_until_complete(main(self._ready.set))
            except BaseException as exc:          # start-up or runtime failure
                self.error = exc
            finally:
                self._ready.set()
                try:
                    loop.run_until_complete(loop.shutdown_asyncgens())
                except Exception:
                    pass
                loop.close()
                self.loop = None

        self._thread = threading.Thread(target=run, name=self.name, daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout):
            raise RuntimeError(f"{self.name} did not start within {timeout:.0f} s")
        if self.error is not None:
            raise self.error

    def call(self, fn, *args) -> None:
        """Run fn(*args) on the loop (thread-safe, fire and forget)."""
        loop = self.loop
        if loop is not None and not loop.is_closed():
            try:
                loop.call_soon_threadsafe(fn, *args)
            except RuntimeError:
                pass

    def stop(self, timeout: float = 10.0) -> None:
        if self.stopping is not None:
            self.call(self.stopping.set)
        if self._thread is not None:
            self._thread.join(timeout)
            self._thread = None

    @property
    def alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()
