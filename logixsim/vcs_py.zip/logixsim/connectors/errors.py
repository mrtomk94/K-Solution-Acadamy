"""Turn network exceptions into plain-language messages with a hint on what to do.

``explain(exc, port=.., host=.., kind=..)`` -> {"code", "message", "hint", "detail"}
"""
from __future__ import annotations

import errno
import socket

_IN_USE = {errno.EADDRINUSE, 10048, 98}
_NOT_HERE = {errno.EADDRNOTAVAIL, 10049, 99}
_DENIED = {errno.EACCES, 10013, 13}
_REFUSED = {errno.ECONNREFUSED, 10061, 111}
_TIMEOUT = {errno.ETIMEDOUT, 10060, 110}
_UNREACH = {errno.EHOSTUNREACH, errno.ENETUNREACH, 10065, 10051, 113, 101}


def _errno(exc):
    for e in (exc, getattr(exc, "__cause__", None), getattr(exc, "__context__", None)):
        if e is None:
            continue
        n = getattr(e, "winerror", None) or getattr(e, "errno", None)
        if n:
            return n
        for a in getattr(e, "args", ()):
            if isinstance(a, OSError) and (a.errno or getattr(a, "winerror", None)):
                return getattr(a, "winerror", None) or a.errno
    text = str(exc)
    for code in (10048, 10049, 10013, 10061, 10060):
        if f"{code}" in text:
            return code
    if "address already in use" in text.lower():
        return errno.EADDRINUSE
    return None


def explain(exc: BaseException, port=None, host=None, kind: str = "", local_ips=()) -> dict:
    n = _errno(exc)
    text = str(exc) or type(exc).__name__
    where = f"{host}:{port}" if host and port else (str(port) if port else (host or ""))
    if n in _IN_USE:
        hint = ("Stop the other program, or choose another port.")
        if kind == "cip" or port == 44818:
            hint = ("This is usually RSLinx Classic or FactoryTalk Linx. Stop that service "
                    "(Windows Services), or run VirtualControlStudio on another PC, or use "
                    "Modbus TCP for this connection.")
        elif port == 502:
            hint = "Another Modbus server is running. Stop it or choose another port (e.g. 5020)."
        return _r("port_in_use", f"Port {port} is already used by another program on this PC.",
                  hint, text)
    if n in _DENIED:
        return _r("permission", f"This system does not allow port {port} for normal programs.",
                  "Choose a port above 1024, or run VirtualControlStudio as administrator.", text)
    if n in _NOT_HERE:
        ips = ", ".join(local_ips) if local_ips else "127.0.0.1"
        return _r("not_this_pc", f"{host} is not an address of this PC.",
                  f"Pick one of: {ips}, or 'Other computers on the network'.", text)
    if n in _REFUSED or isinstance(exc, ConnectionRefusedError):
        return _r("refused", f"Nothing is listening at {where}.",
                  "Start the other program, and check the IP address and port.", text)
    if n in _TIMEOUT or isinstance(exc, (TimeoutError, socket.timeout)):
        return _r("timeout", f"No answer from {where or 'the other side'} in time.",
                  "Check the IP address, the cable / network, and Windows Firewall on that PC.",
                  text)
    if n in _UNREACH:
        return _r("unreachable", f"{host or 'The address'} cannot be reached from this PC.",
                  "Check the IP address and that both PCs are on the same network.", text)
    if isinstance(exc, socket.gaierror):
        return _r("dns", f"The name '{host}' cannot be found.", "Use the IP address instead.", text)
    status = getattr(exc, "status_code", None) or getattr(getattr(exc, "response", None),
                                                           "status_code", None)
    if status in (401, 403):
        return _r("refused_auth", f"{where} answered but refused the connection ({status}).",
                  "Check the access token or user name.", text)
    if status == 404:
        return _r("bad_path", f"{where} answered, but that path does not exist (404).",
                  "Check the path part of the URL (for example /ws/vcs).", text)
    low = text.lower()
    if "certificate" in low or ("security" in low and kind == "opcua"):
        return _r("certificate", "The OPC UA client does not trust this server's certificate yet.",
                  "In the client (e.g. the Ignition gateway) trust the certificate named "
                  "VirtualControlStudio, then test again.", text)
    return _r("error", text, "", text)


def _r(code, message, hint, detail):
    return {"code": code, "message": message, "hint": hint, "detail": detail}


def local_ips() -> list[str]:
    """This PC's IPv4 addresses (best effort, no network traffic)."""
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    try:                                       # the address used for the default route
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("10.255.255.255", 1))     # UDP connect: no packet is sent
            ips.add(s.getsockname()[0])
        finally:
            s.close()
    except OSError:
        pass
    out = sorted(ip for ip in ips if not ip.startswith("127."))
    return out + ["127.0.0.1"]


def port_free(host: str, port: int) -> tuple[bool, dict | None]:
    """Can we listen on host:port right now?"""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):          # Windows: detect real conflicts
            s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        s.bind((host, int(port)))
        return True, None
    except OSError as exc:
        return False, explain(exc, port=port, host=host)
    finally:
        s.close()
