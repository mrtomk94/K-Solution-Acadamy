"""Modbus TCP server connector: tags as coils and registers, for HMIs (C-more,
...), gateways and test tools that speak Modbus.

Register map (generated, then kept stable in the connection's ``map`` setting, so
adding tags never moves existing addresses):

=========================  =====================  ===========================
tag type                   writable tag            read-only tag
=========================  =====================  ===========================
BOOL                       coil (0xxxx)            discrete input (1xxxx)
SINT / INT                 1 holding register      1 input register (3xxxx)
DINT / REAL                2 holding registers     2 input registers
LINT                       4 holding registers     4 input registers
STRING, structures         (members are mapped one by one; STRING is skipped)
=========================  =====================  ===========================

REAL is IEEE-754 single precision. Multi-register values use ``word_order``
"high_first" (the high word in the lower address, the common default) or
"low_first". Function codes 1, 2, 3, 4, 5, 6, 15 and 16. Any unit id is
answered. Unmapped addresses inside the table read as 0; reading past the end
gives exception 02 (illegal data address).
"""
from __future__ import annotations

import asyncio
import csv
import io
import struct

from .base import BIND_FIELD, Connector, bind_address, register
from .errors import explain, local_ips, port_free
from .runner import LoopThread

WORDS = {"BOOL": 0, "SINT": 1, "INT": 1, "DINT": 2, "REAL": 2, "LINT": 4,
         "USINT": 1, "UINT": 1, "UDINT": 2, "ULINT": 4}
MAX_ENTRIES = 20000
TABLES = ("coil", "discrete", "holding", "input")
_OFFSET = {"coil": 1, "discrete": 10001, "input": 30001, "holding": 40001}


MAX_CLIENTS = 32
IDLE_TIMEOUT_S = 300          # a silent client is dropped after 5 minutes


@register("modbus_tcp")
class ModbusTcpConnector(Connector):
    name = kind = "modbus_tcp"
    title = "Modbus TCP server"
    role = "server"
    summary = "HMIs (C-more), gateways and test tools read and write tags as Modbus"
    schema = [
        dict(BIND_FIELD),
        {"name": "port", "type": "int", "label": "Port", "default": 502, "min": 1, "max": 65535,
         "group": "Network", "help": "502 is the Modbus standard. On Linux use 5020 or run as root."},
        {"name": "word_order", "type": "str", "label": "32-bit word order", "default": "high_first",
         "group": "Protocol", "choices": [["high_first", "High word first (most HMIs)"],
                                          ["low_first", "Low word first"]]},
        {"name": "tags", "type": "list", "label": "Tags mapped", "default": ["*"], "group": "Tags",
         "help": "Tag patterns to put in the register map."},
    ]

    def __init__(self, emu, bind="local", port=502, word_order="high_first", tags=None,
                 map=None, host=None, **settings):
        super().__init__(emu, **settings)
        if host and bind == "local":
            bind = "local" if host in ("127.0.0.1", "localhost") else host
        self.bind, self.host, self.port = bind, bind_address(bind), int(port)
        self.word_order = word_order
        self.patterns = list(tags or ["*"])
        self.map: list[dict] = [dict(e) for e in (map or [])]
        self.clients = 0
        self.counters = {"msgs_in": 0, "msgs_out": 0, "refused": 0}
        self._runner = LoopThread("modbus-tcp")
        self._server = None
        self._index: dict = {}

    # ---- register map -------------------------------------------------------------------
    def build_map(self) -> list[dict]:
        """Keep existing entries (stable addresses), add new tags at the end of each table,
        drop entries whose tag is gone."""
        from ..events import compile_pattern
        st = self.emu.store
        pats = [compile_pattern(p) for p in self.patterns]
        flat = st.flat()
        leaves = [a for a in flat if any(p(a) for p in pats) and not isinstance(flat[a], str)]
        keep = [e for e in self.map if e["tag"] in flat]
        have = {e["tag"] for e in keep}
        nxt = {t: 0 for t in TABLES}
        for e in keep:
            nxt[e["table"]] = max(nxt[e["table"]], e["addr"] + max(1, e["words"]))
        for a in leaves:
            if a in have or len(keep) >= MAX_ENTRIES:
                continue
            try:
                dtype = st.data_type(a)
            except Exception:
                continue
            if dtype not in WORDS:
                continue
            acc = st.access(a) if hasattr(st, "access") else st.meta(a).access
            if acc == "none":
                continue                                # External Access None: not mapped
            ro = acc == "ro"
            if dtype == "BOOL":
                table, words = ("discrete" if ro else "coil"), 0
            else:
                table, words = ("input" if ro else "holding"), WORDS[dtype]
            keep.append({"tag": a, "table": table, "addr": nxt[table], "type": dtype, "words": words})
            nxt[table] += max(1, words)
        self.map = keep
        self._reindex()
        return self.map

    def _reindex(self):
        self._index = {t: {} for t in TABLES}
        self._size = {t: 0 for t in TABLES}
        for e in self.map:
            n = max(1, e["words"])
            for k in range(n):
                self._index[e["table"]][e["addr"] + k] = (e, k)
            self._size[e["table"]] = max(self._size[e["table"]], e["addr"] + n)

    def map_csv(self) -> str:
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Tag", "Table", "Modbus address", "Offset (0-based)", "Data type",
                    "Registers", "Access"])
        for e in sorted(self.map, key=lambda e: (TABLES.index(e["table"]), e["addr"])):
            w.writerow([e["tag"], e["table"], _OFFSET[e["table"]] + e["addr"], e["addr"], e["type"],
                        max(1, e["words"]) if e["words"] else 1,
                        "read" if e["table"] in ("discrete", "input") else "read/write"])
        return buf.getvalue()

    # ---- value <-> registers -------------------------------------------------------------
    def _encode(self, e, value) -> list[int]:
        t = e["type"]
        if t == "REAL":
            raw = struct.pack(">f", float(value or 0.0))
        else:
            n = e["words"] * 2
            v = int(value or 0) & ((1 << (8 * n)) - 1)
            raw = v.to_bytes(n, "big")
        words = [int.from_bytes(raw[i:i + 2], "big") for i in range(0, len(raw), 2)]
        return words if self.word_order == "high_first" else words[::-1]

    def _decode(self, e, words: list[int]):
        if self.word_order != "high_first":
            words = words[::-1]
        raw = b"".join(w.to_bytes(2, "big") for w in words)
        t = e["type"]
        if t == "REAL":
            return struct.unpack(">f", raw)[0]
        v = int.from_bytes(raw, "big")
        if t in ("SINT", "INT", "DINT", "LINT"):
            bits = 8 * len(raw)
            if t == "SINT":
                v &= 0xFF
                bits = 8
            if v >= 1 << (bits - 1):
                v -= 1 << bits
        return v

    # ---- protocol ---------------------------------------------------------------------------
    def handle_pdu(self, pdu: bytes) -> bytes:
        """One Modbus PDU in, the response PDU out (also used by the tests)."""
        if not pdu:
            return b""
        fc = pdu[0]
        try:
            if fc in (1, 2):
                start, count = struct.unpack(">HH", pdu[1:5])
                if not 1 <= count <= 2000:
                    return _exc(fc, 3)
                table = "coil" if fc == 1 else "discrete"
                self._range(table, start, count)
                flat = self.emu.store.flat()
                bits = []
                for a in range(start, start + count):
                    hit = self._index[table].get(a)
                    bits.append(bool(flat.get(hit[0]["tag"])) if hit else False)
                data = bytearray((count + 7) // 8)
                for i, b in enumerate(bits):
                    if b:
                        data[i // 8] |= 1 << (i % 8)
                return bytes([fc, len(data)]) + bytes(data)
            if fc in (3, 4):
                start, count = struct.unpack(">HH", pdu[1:5])
                if not 1 <= count <= 125:
                    return _exc(fc, 3)
                table = "holding" if fc == 3 else "input"
                self._range(table, start, count)
                flat = self.emu.store.flat()
                out = []
                cache = {}
                for a in range(start, start + count):
                    hit = self._index[table].get(a)
                    if not hit:
                        out.append(0)
                        continue
                    e, k = hit
                    if e["tag"] not in cache:
                        cache[e["tag"]] = self._encode(e, flat.get(e["tag"]))
                    out.append(cache[e["tag"]][k])
                return bytes([fc, 2 * count]) + struct.pack(f">{count}H", *out)
            if fc == 5:
                addr, val = struct.unpack(">HH", pdu[1:5])
                if val not in (0x0000, 0xFF00):
                    return _exc(fc, 3)
                self._write_bits(addr, [val == 0xFF00])
                return pdu[:5]
            if fc == 15:
                start, count, nbytes = struct.unpack(">HHB", pdu[1:6])
                data = pdu[6:6 + nbytes]
                if not 1 <= count <= 1968 or len(data) < (count + 7) // 8:
                    return _exc(fc, 3)
                self._write_bits(start, [bool(data[i // 8] >> (i % 8) & 1) for i in range(count)])
                return pdu[:5]
            if fc == 6:
                addr, val = struct.unpack(">HH", pdu[1:5])
                self._write_words(addr, [val])
                return pdu[:5]
            if fc == 16:
                start, count, nbytes = struct.unpack(">HHB", pdu[1:6])
                if not 1 <= count <= 123 or nbytes != 2 * count or len(pdu) < 6 + nbytes:
                    return _exc(fc, 3)
                self._write_words(start, list(struct.unpack(f">{count}H", pdu[6:6 + nbytes])))
                return pdu[:5]
            return _exc(fc, 1)
        except _ModbusError as e:
            return _exc(fc, e.code)
        except struct.error:
            return _exc(fc, 3)

    def _range(self, table, start, count):
        if start + count > self._size[table]:
            raise _ModbusError(2)

    def _write_bits(self, start, bits):
        self._range("coil", start, len(bits))
        for i, b in enumerate(bits):
            hit = self._index["coil"].get(start + i)
            if hit:
                self._store(hit[0]["tag"], b)

    def _write_words(self, start, words):
        self._range("holding", start, len(words))
        flat = self.emu.store.flat()
        pending = {}
        for i, w in enumerate(words):
            hit = self._index["holding"].get(start + i)
            if not hit:
                continue
            e, k = hit
            if e["tag"] not in pending:
                pending[e["tag"]] = (e, self._encode(e, flat.get(e["tag"])))
            pending[e["tag"]][1][k] = w
        for tag, (e, ws) in pending.items():
            self._store(tag, self._decode(e, ws))

    def _store(self, tag, value):
        from ..tagstore import TagStoreError
        try:
            self.emu.store.write(tag, value, source="conn:modbus")
        except TagStoreError as exc:
            self.counters["refused"] += 1
            self.log("warn", f"write to {tag} refused: {exc}")
            raise _ModbusError(4) from None

    # ---- server -----------------------------------------------------------------------------
    def start(self) -> None:
        self.build_map()

        async def main(ready):
            server = await asyncio.start_server(self._client, self.host, self.port)
            self._server = server
            ready()
            async with server:
                await self._runner.stopping.wait()
            self._server = None
        try:
            self._runner.start(main)
        except OSError as exc:
            e = explain(exc, port=self.port, host=self.host, kind=self.kind)
            raise RuntimeError(f"{e['message']} {e['hint']}") from exc
        self.log("info", f"listening on {self.host}:{self.port} ({len(self.map)} tags mapped)")

    async def _client(self, reader, writer):
        peer = writer.get_extra_info("peername")
        if self.clients >= MAX_CLIENTS:              # refuse floods; HMIs use one or two
            self.log("warn", f"client {peer[0]}:{peer[1]} refused: {MAX_CLIENTS} clients already")
            writer.close()
            return
        self.clients += 1
        self.log("info", f"client {peer[0]}:{peer[1]} connected")
        self.emu.bus.emit("connection", {"kind": self.kind})
        try:
            while True:
                head = await asyncio.wait_for(reader.readexactly(7), IDLE_TIMEOUT_S)
                tid, pid, length, uid = struct.unpack(">HHHB", head)
                if length < 2 or length > 260:
                    break
                pdu = await reader.readexactly(length - 1)
                self.counters["msgs_in"] += 1
                resp = self.handle_pdu(pdu) if pid == 0 else b""
                if resp:
                    writer.write(struct.pack(">HHHB", tid, 0, len(resp) + 1, uid) + resp)
                    await writer.drain()
                    self.counters["msgs_out"] += 1
        except (asyncio.IncompleteReadError, ConnectionError, asyncio.TimeoutError):
            pass
        finally:
            self.clients -= 1
            writer.close()
            self.log("info", f"client {peer[0]}:{peer[1]} disconnected")
            self.emu.bus.emit("connection", {"kind": self.kind})

    def stop(self) -> None:
        self._runner.stop()

    @property
    def running(self) -> bool:
        return self._runner.alive and self._server is not None

    def status(self) -> dict:
        hosts = local_ips() if self.host == "0.0.0.0" else [self.host]
        return {"name": self.name, "running": self.running,
                "endpoint": f"{hosts[0]}:{self.port}", "client_count": self.clients,
                "mapped": len(self.map), **self.counters}

    def persist(self) -> dict:
        """Settings to save back into the project (the stable map)."""
        return {"map": self.map}

    def other_side(self) -> dict:
        hosts = local_ips() if self.host == "0.0.0.0" else [self.host]
        return {"values": {"IP address": hosts[0], "Port": str(self.port), "Unit ID": "1 (any)",
                           "32-bit word order": "high word first" if self.word_order == "high_first"
                           else "low word first"},
                "steps": ["In the HMI / client, add a Modbus TCP device with this IP address and port.",
                          "Download the register map (CSV) to see which address holds which tag.",
                          "C-more: protocol 'Modbus TCP/IP'; BOOL tags are coils 0xxxx (read-only: "
                          "1xxxx), numbers are holding registers 4xxxx (read-only: 3xxxx); DINT and "
                          "REAL use two registers."],
                "examples": {}}

    @classmethod
    def test(cls, emu, params: dict, running=None) -> list[dict]:
        host, port = bind_address(params.get("bind", "local")), int(params.get("port", 502))
        if running is None or not running.running:
            ok, err = port_free(host, port)
            return [_check(ok, f"Port {port} is free" if ok else err["message"],
                           "" if ok else err["hint"])]
        checks = [_check(True, f"Listening on {host}:{port}, {len(running.map)} tags mapped")]
        import socket
        target = "127.0.0.1" if host == "0.0.0.0" else host
        try:
            with socket.create_connection((target, port), timeout=3) as s:
                s.settimeout(3)
                s.sendall(struct.pack(">HHHBBHH", 1, 0, 6, 1, 3, 0, 1))
                resp = s.recv(260)
            checks.append(_check(len(resp) >= 9, "A test client read holding register 40001"))
        except OSError as exc:
            e = explain(exc, port=port, host=target)
            checks.append(_check(False, e["message"], e["hint"]))
        return checks


class _ModbusError(Exception):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


def _exc(fc, code) -> bytes:
    return bytes([fc | 0x80, code])


def _check(ok, label, hint=""):
    return {"ok": ok, "label": label, "hint": hint}
