"""EtherNet/IP (CIP) connector: the emulator answers as a Logix controller in a slot.

Works with pycomm3 LogixDriver, Node-RED (node-red-contrib-cip-ethernet-ip), HMIs
with an Allen-Bradley "Tag Based" driver (C-more, to be verified on the panel) and
other Logix clients. Writes go through the TagStore (forces and read-only tags are
refused with a CIP privilege violation).
"""
from __future__ import annotations

from ..chassis import Chassis
from ..cip_server import CIPServer
from .base import BIND_FIELD, Connector, bind_address, register
from .errors import explain, local_ips, port_free


@register("cip")
class CipConnector(Connector):
    name = kind = "cip"
    title = "EtherNet/IP server"
    role = "server"
    summary = "Allen-Bradley Logix clients: C-more 'Tag Based', pycomm3, Ignition (to verify)"
    schema = [
        dict(BIND_FIELD),
        {"name": "port", "type": "int", "label": "Port", "default": 44818, "min": 1, "max": 65535,
         "group": "Network", "advanced": True,
         "help": "EtherNet/IP uses 44818; most HMIs cannot use another port."},
        {"name": "slot", "type": "int", "label": "Slot", "default": 0, "min": 0, "max": 16,
         "group": "Protocol", "help": "The controller slot clients use in their path (usually 0)."},
    ]

    def __init__(self, emu, bind="local", port: int = 44818, slot: int = 0, host=None, **settings):
        super().__init__(emu, **settings)
        if host and bind == "local":
            bind = "local" if host in ("127.0.0.1", "localhost") else host
        self.bind = bind
        self.host, self.port, self.slot = bind_address(bind), int(port), int(slot)
        self.server: CIPServer | None = None

    def start(self) -> None:
        self.server = CIPServer(Chassis.single(self.emu.engine, slot=self.slot),
                                host=self.host, port=self.port)
        try:
            self.port = self.server.start()
        except OSError as exc:
            self.server = None
            e = explain(exc, port=self.port, host=self.host, kind="cip")
            raise RuntimeError(f"{e['message']} {e['hint']}") from exc
        self.log("info", f"listening on {self.host}:{self.port}, slot {self.slot}")

    def stop(self) -> None:
        if self.server:
            self.server.stop()
            self.server = None

    def status(self) -> dict:
        hosts = local_ips() if self.host == "0.0.0.0" else [self.host]
        return {"name": self.name, "running": self.server is not None,
                "endpoint": f"{hosts[0]}:{self.port} slot {self.slot}",
                "connections": len(self.server.connections) if self.server else 0,
                "client_count": len(self.server.connections) if self.server else 0}

    def other_side(self) -> dict:
        hosts = local_ips() if self.host == "0.0.0.0" else [self.host]
        return {"values": {"PLC IP address": hosts[0], "Slot": str(self.slot),
                           "pycomm3 path": f"{hosts[0]}/{self.slot}"},
                "steps": ["C-more Programming Software > Panel Manager: protocol "
                          "'Allen-Bradley EtherNet/IP' Tag Based (ControlLogix / CompactLogix), "
                          "IP address and slot as shown. Tag names are the controller tags.",
                          "Import the tag list into C-more with 'Tag list CSV' (or the exported L5X). "
                          "Field names in C-more are to be verified on your version.",
                          "Ignition: an Allen-Bradley Logix driver connection may work (experimental); "
                          "OPC UA is the recommended way for Ignition.",
                          "Python: pycomm3.LogixDriver('<IP>/<slot>')."],
                "examples": {}}

    @classmethod
    def test(cls, emu, params: dict, running=None) -> list[dict]:
        host, port = bind_address(params.get("bind", "local")), int(params.get("port", 44818))
        if running is None or running.server is None:
            ok, err = port_free(host, port)
            if not ok:
                e = explain(OSError(98, "in use"), port=port, host=host, kind="cip") \
                    if err["code"] == "port_in_use" else err
                return [_check(False, e["message"], e["hint"])]
            return [_check(True, f"Port {port} is free")]
        checks = [_check(True, f"Listening on {host}:{port}, slot {running.slot}")]
        import socket
        import struct
        target = "127.0.0.1" if host == "0.0.0.0" else host
        try:                                     # List Identity (encapsulation command 0x63)
            with socket.create_connection((target, port), timeout=3) as s:
                s.settimeout(3)
                s.sendall(struct.pack("<HHII8sI", 0x63, 0, 0, 0, b"\0" * 8, 0))
                resp = s.recv(600)
            ok = len(resp) >= 24 and struct.unpack("<H", resp[:2])[0] == 0x63
            checks.append(_check(ok, "A test client got the controller identity (List Identity)"))
        except OSError as exc:
            e = explain(exc, port=port, host=target)
            checks.append(_check(False, e["message"], e["hint"]))
        return checks


def _check(ok, label, hint=""):
    return {"ok": ok, "label": label, "hint": hint}
