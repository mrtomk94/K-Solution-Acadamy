"""Connectors: pluggable links between the emulator's tags and the outside world.

A connector implements ``start()``, ``stop()`` and ``status() -> dict`` and is
created from the project file's ``connectors`` section through the registry::

    {"connectors": {"opcua": {"enabled": true, "port": 4840}}}
"""
from .base import REGISTRY, Connector, create, register  # noqa: F401
