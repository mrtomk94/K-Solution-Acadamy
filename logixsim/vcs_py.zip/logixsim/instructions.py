"""Instruction library shared by the ST and Ladder interpreters.

The implementations live in :mod:`logixsim.isa` (one module per instruction
family, each with metadata). This module keeps the original import surface:
``REGISTRY``, ``ExecContext``, ``op`` and ``UnsupportedInstruction``.

Calling conventions:

* condition instructions (XIC, EQU, ...): ``fn(ctx, args) -> bool``
* action instructions (OTE, TON, MOV, ...): ``fn(ctx, args, rung=True) -> bool``
  (rung-condition-out)
"""
from __future__ import annotations

from .isa import (REGISTRY, SPECS, ExecContext, InstructionError, MajorFault,  # noqa: F401
                  UnsupportedInstruction, op)
