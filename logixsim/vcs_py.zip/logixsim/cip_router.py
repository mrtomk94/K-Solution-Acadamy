"""Per-controller CIP message router — what a 1756-L8x answers once a request
has been routed to its slot (unconnected or over a Class 3 connection).

Services:
  0x4C Read Tag            0x4D Write Tag          0x4E Read-Modify-Write
  0x52 Read Tag Fragmented 0x53 Write Tag Fragmented
  0x0A Multiple Service Packet (Message Router, class 0x02)
  0x01 Get Attributes All  on Identity (0x01) and Program Name (0x64)
  0x55 Get Instance Attribute List on Symbol (0x6B), controller or
       ``Program:<name>`` scope, paged with status 0x06.

Tag listing covers atomic tags and atomic (non-BOOL) arrays. Struct/UDT tags
need the Template object (0x6C) and arrive in Phase 3; their atomic members
remain readable by symbolic path.
"""
from __future__ import annotations

import logging
import re
import struct
import threading
import time
from dataclasses import dataclass

from .engine import BitMask
from .tagstore import TagStoreError, root_of
from .model import coerce

log = logging.getLogger(__name__)

TYPE_CODE = {"BOOL": 0xC1, "SINT": 0xC2, "INT": 0xC3,
             "DINT": 0xC4, "LINT": 0xC5, "REAL": 0xCA,
             "USINT": 0xC6, "UINT": 0xC7, "UDINT": 0xC8, "ULINT": 0xC9, "LREAL": 0xCB}
PACK = {"BOOL": "<B", "SINT": "<b", "INT": "<h", "DINT": "<i", "LINT": "<q", "REAL": "<f",
        "USINT": "<B", "UINT": "<H", "UDINT": "<I", "ULINT": "<Q", "LREAL": "<d"}
SIZE = {t: struct.calcsize(f) for t, f in PACK.items()}
INT_BITS = {"SINT": 8, "INT": 16, "DINT": 32, "LINT": 64, "USINT": 8, "UINT": 16, "UDINT": 32, "ULINT": 64}

# general status codes
OK, PATH_SEG_ERR, PATH_UNKNOWN, PARTIAL = 0x00, 0x04, 0x05, 0x06
NOT_SUPPORTED, ATTR_NOT_SUPPORTED, NOT_ENOUGH_DATA = 0x08, 0x14, 0x13
EMBEDDED_ERR, GENERAL = 0x1E, 0xFF
PRIVILEGE, INVALID_VALUE = 0x0F, 0x09
EXT_BEYOND_END, EXT_TYPE_MISMATCH = 0x2105, 0x2107

CLS_IDENTITY, CLS_ROUTER, CLS_PROGRAM_NAME, CLS_SYMBOL = 0x01, 0x02, 0x64, 0x6B
SVC_GET_ALL, SVC_MULTI, SVC_GET_INST_LIST = 0x01, 0x0A, 0x55
SVC_READ, SVC_WRITE, SVC_RMW, SVC_READ_FRAG, SVC_WRITE_FRAG = 0x4C, 0x4D, 0x4E, 0x52, 0x53
TAG_SERVICES = {SVC_READ, SVC_WRITE, SVC_RMW, SVC_READ_FRAG, SVC_WRITE_FRAG}

BASE_TAG_BIT = 1 << 26
PROGRAM_SYMBOL_TYPE = 0x1068
_REPLY_OVERHEAD = 8      # reply header (4) + sequence count (2) + margin


class CIPError(Exception):
    def __init__(self, status: int, ext: int | None = None):
        super().__init__(f"CIP status 0x{status:02X}")
        self.status, self.ext = status, ext


def reply(service: int, status: int = OK, data: bytes = b"", ext: int | None = None) -> bytes:
    ext_bytes = struct.pack("<H", ext) if ext is not None else b""
    return struct.pack("<BBBB", service | 0x80, 0, status, len(ext_bytes) // 2) + ext_bytes + data


# ---- EPATH decoding --------------------------------------------------------
_LOGICAL = {0x20: "class", 0x24: "instance", 0x28: "elem", 0x30: "attr"}


def decode_path(data: bytes) -> list[tuple[str, object]]:
    """Decode a padded EPATH into [('sym', name) | ('class'|'instance'|'elem'|'attr', n)]."""
    segs: list[tuple[str, object]] = []
    i = 0
    while i < len(data):
        seg = data[i]
        if seg == 0x91:                                   # ANSI extended symbolic
            ln = data[i + 1]
            name = data[i + 2:i + 2 + ln]
            if len(name) != ln:
                raise CIPError(PATH_SEG_ERR)
            segs.append(("sym", name.decode("ascii")))
            i += 2 + ln + (ln & 1)
            continue
        kind = _LOGICAL.get(seg & 0xFC)
        if kind is None:
            raise CIPError(PATH_SEG_ERR)
        fmt = seg & 0x03
        if fmt == 0:
            if i + 1 >= len(data):
                raise CIPError(PATH_SEG_ERR)
            val, i = data[i + 1], i + 2
        elif fmt == 1:
            val, i = struct.unpack_from("<H", data, i + 2)[0], i + 4
        elif fmt == 2:
            val, i = struct.unpack_from("<I", data, i + 2)[0], i + 6
        else:
            raise CIPError(PATH_SEG_ERR)
        segs.append((kind, val))
    return segs


def _join_address(segs) -> str:
    addr = ""
    prev = None
    for kind, val in segs:
        if kind == "sym":
            addr += ("." + val) if addr else val
        elif kind == "elem":
            if prev == "elem":                      # consecutive element segments: Grid[1,2]
                addr = addr[:-1] + f",{val}]"
            else:
                addr += f"[{val}]"
        else:
            raise CIPError(PATH_SEG_ERR)
        prev = kind
    if not addr:
        raise CIPError(PATH_SEG_ERR)
    return addr


def _decode(dtype: str, data: bytes, count: int) -> list:
    size = SIZE[dtype]
    if len(data) < size * count:
        raise CIPError(NOT_ENOUGH_DATA)
    vals = [struct.unpack_from(PACK[dtype], data, i * size)[0] for i in range(count)]
    return [bool(v) for v in vals] if dtype == "BOOL" else vals


@dataclass
class _Target:
    """An atomic scalar, or ``count`` elements of an array starting at ``start``."""
    dtype: str
    addr: str
    seq: list | None        # live array list (None for a scalar)
    base: str | None        # array address without the subscript
    start: int
    count: int
    value: object = None    # scalar value at resolve time
    elem: object = None     # (base, flat index) -> element address (multi-dimensional aware)

    def element(self, i: int) -> str:
        if self.seq is None:
            return self.addr
        if self.elem is not None:
            return self.elem(self.base, self.start + i)
        return f"{self.base}[{self.start + i}]"

    def encode(self, first: int, n: int) -> bytes:
        """Encode n elements beginning ``first`` elements into this target."""
        if self.seq is None:
            vals = [self.value]
        else:
            lo = self.start + first
            vals = self.seq[lo:lo + n]
        if self.dtype == "BOOL":
            return bytes(1 if v else 0 for v in vals)
        if self.dtype == "REAL":
            vals = [float(v) for v in vals]
        else:
            vals = [int(v) for v in vals]
        return struct.pack(f"<{len(vals)}{PACK[self.dtype][1]}", *vals)


class MessageRouter:
    def __init__(self, engine, identity, name: str | None = None):
        self.engine = engine
        self.db = engine.db
        self.store = engine.store
        self._inst_ids: dict[str, int] = {}
        if hasattr(self.store, "on_structure"):
            self.store.on_structure(self._invalidate)
        self.identity = identity
        self.name = name or engine.controller.name
        self._symbols = None            # lazily built symbol table
        self._frag: dict[str, bytearray] = {}
        self._lock = threading.Lock()

    # ---- entry point ------------------------------------------------------
    def handle(self, req: bytes, conn_size: int = 504) -> bytes:
        if len(req) < 2:
            return reply(req[0] if req else 0, PATH_SEG_ERR)
        service = req[0]
        plen = req[1] * 2
        path, data = req[2:2 + plen], req[2 + plen:]
        try:
            segs = decode_path(path)
            return self._dispatch(service, segs, data, conn_size)
        except CIPError as err:
            return reply(service, err.status, ext=err.ext)
        except (struct.error, IndexError):  # request shorter than the service needs
            return reply(service, NOT_ENOUGH_DATA)
        except Exception as exc:            # a bug: report it, never drop the socket
            log.exception("CIP service 0x%02X failed", service)
            self.engine.fault(f"CIP service 0x{service:02X}: {exc!r}", dedup=True)
            return reply(service, GENERAL)

    def _dispatch(self, service, segs, data, conn_size) -> bytes:
        if not segs:
            raise CIPError(PATH_SEG_ERR)
        kind, val = segs[0]
        if kind == "class":
            inst = segs[1][1] if len(segs) > 1 and segs[1][0] == "instance" else None
            if val == CLS_IDENTITY and service == SVC_GET_ALL and inst == 1:
                return reply(service, data=self._identity_bytes())
            if val == CLS_PROGRAM_NAME and service == SVC_GET_ALL:
                name = self.name.encode("ascii", "replace")
                return reply(service, data=struct.pack("<H", len(name)) + name)
            if val == CLS_ROUTER and service == SVC_MULTI:
                return self._multi(data, conn_size)
            if val == CLS_SYMBOL and service == SVC_GET_INST_LIST:
                return self._list(service, None, inst or 0, data, conn_size)
            if val == CLS_SYMBOL and inst is not None and service in TAG_SERVICES:
                base = self._name_for_instance(inst)
                addr = _join_address([("sym", base)] + segs[2:])
                return self._tag_service(service, addr, data, conn_size)
            if val in (CLS_IDENTITY, CLS_PROGRAM_NAME, CLS_ROUTER, CLS_SYMBOL):
                raise CIPError(NOT_SUPPORTED)
            raise CIPError(PATH_UNKNOWN)
        if (kind == "sym" and str(val).startswith("Program:") and len(segs) >= 2
                and segs[1] == ("class", CLS_SYMBOL) and service == SVC_GET_INST_LIST):
            inst = segs[2][1] if len(segs) > 2 and segs[2][0] == "instance" else 0
            return self._list(service, val[len("Program:"):], inst, data, conn_size)
        if service in TAG_SERVICES:
            return self._tag_service(service, _join_address(segs), data, conn_size)
        raise CIPError(NOT_SUPPORTED)

    # ---- identity ---------------------------------------------------------
    def _identity_bytes(self) -> bytes:
        status = b"\x60\x30" if self.engine.running else b"\x70\x30"   # REMOTE RUN / PROG
        return self.identity.encode(status)

    # ---- tag access helpers --------------------------------------------------
    def _target(self, addr: str, count: int) -> "_Target":
        """Resolve addr + element count to an atomic scalar or an array slice.
        A tag with External Access None is invisible to clients (path unknown)."""
        access = getattr(self.store, "access", None)
        if access is not None:
            try:
                if access(addr) == "none":
                    raise CIPError(PATH_UNKNOWN)
            except CIPError:
                raise
            except Exception:
                pass
        try:
            value = self.db.get(addr)
            dtype = self.db.data_type(addr)
        except Exception:
            raise CIPError(PATH_UNKNOWN)
        seq, base, start = None, None, 0
        if isinstance(value, list):                       # whole array tag/member
            seq, base = value, addr
        else:
            m = re.match(r"^(.*)\[(\d+(?:,\d+)*)\]$", addr)
            if m:
                try:
                    parent = self.db.get(m.group(1))
                except Exception:
                    parent = None
                if isinstance(parent, list):
                    idx = tuple(int(x) for x in m.group(2).split(","))
                    flat = getattr(self.db, "flat_index", None)
                    try:
                        start = flat(m.group(1), idx if len(idx) > 1 else idx[0]) if flat \
                            else idx[0]
                    except Exception:
                        raise CIPError(PATH_UNKNOWN)
                    seq, base = parent, m.group(1)
        if dtype not in TYPE_CODE:                        # struct read: Phase 3
            raise CIPError(NOT_SUPPORTED)
        if count < 1 or (seq is None and count != 1) or \
                (seq is not None and start + count > len(seq)):
            raise CIPError(GENERAL, EXT_BEYOND_END)
        return _Target(dtype, addr, seq, base, start, count, value,
                       getattr(self.db, "elem_address", None))

    def _apply(self, addr: str, value) -> None:
        """Write through the TagStore: forces and read-only tags are refused with
        a privilege violation; RUN queues for the next scan, PROGRAM writes now."""
        try:
            self.store.write(addr, value, source="cip")
        except TagStoreError as exc:
            if exc.code in ("forced", "readonly"):
                raise CIPError(PRIVILEGE)
            if exc.code == "unknown":
                raise CIPError(PATH_UNKNOWN)
            raise CIPError(INVALID_VALUE)

    def _write_values(self, t: "_Target", values: list) -> None:
        # validate every element first: a refused element writes nothing (all-or-nothing)
        for i, v in enumerate(values):
            try:
                self.store.check(t.element(i), v, source="cip")
            except TagStoreError as exc:
                raise CIPError(PRIVILEGE if exc.code in ("forced", "readonly") else
                               PATH_UNKNOWN if exc.code == "unknown" else INVALID_VALUE)
        if t.seq is not None:
            root = root_of(t.base)
            first, last = t.start, t.start + len(values)
            active = getattr(self.store, "is_force_active", self.store.is_forced)
            if any(active(t.element(i - t.start)) for i in range(first, last)) \
                    or active(t.base):
                raise CIPError(PRIVILEGE)
            if (self.store.access(t.base) if hasattr(self.store, "access")
                    else self.store.meta(root).access) != "rw":
                raise CIPError(PRIVILEGE)
            if not self.engine.running:
                with self.store.lock:                     # fast path: no address parsing
                    for i, v in enumerate(values):
                        t.seq[t.start + i] = coerce(t.dtype, v)
                    self.store._writers[t.base] = ("cip", time.time())
                return
        for i, v in enumerate(values):
            self._apply(t.element(i), v)

    def _check_type(self, code: int, dtype: str) -> None:
        if code != TYPE_CODE[dtype]:
            raise CIPError(GENERAL, EXT_TYPE_MISMATCH)

    # ---- tag services ----------------------------------------------------
    def _tag_service(self, service, addr, data, conn_size) -> bytes:
        handler = {SVC_READ: self._svc_read, SVC_READ_FRAG: self._svc_read_frag,
                   SVC_WRITE: self._svc_write, SVC_WRITE_FRAG: self._svc_write_frag,
                   SVC_RMW: self._svc_rmw}[service]
        return handler(service, addr, data, conn_size)

    def _svc_read(self, service, addr, data, conn_size) -> bytes:
        count = struct.unpack_from("<H", data, 0)[0] if len(data) >= 2 else 1
        t = self._target(addr, count)
        return reply(service, data=struct.pack("<H", TYPE_CODE[t.dtype]) + t.encode(0, count))

    def _svc_read_frag(self, service, addr, data, conn_size) -> bytes:
        count, offset = struct.unpack_from("<HI", data, 0)
        t = self._target(addr, count)
        size, total = SIZE[t.dtype], SIZE[t.dtype] * count
        room = max(size, conn_size - _REPLY_OVERHEAD - 2)
        room -= room % size
        first, skip = divmod(offset, size)
        n = min(count - first, -(-(room + skip) // size)) if offset < total else 0
        chunk = t.encode(first, n)[skip:skip + room] if n > 0 else b""
        status = PARTIAL if offset + len(chunk) < total else OK
        return reply(service, status, struct.pack("<H", TYPE_CODE[t.dtype]) + chunk)

    def _svc_write(self, service, addr, data, conn_size) -> bytes:
        code, count = struct.unpack_from("<HH", data, 0)
        t = self._target(addr, count)
        self._check_type(code, t.dtype)
        self._write_values(t, _decode(t.dtype, data[4:], count))
        return reply(service)

    def _svc_write_frag(self, service, addr, data, conn_size) -> bytes:
        code, count, offset = struct.unpack_from("<HHI", data, 0)
        t = self._target(addr, count)
        self._check_type(code, t.dtype)
        chunk, total = data[8:], SIZE[t.dtype] * count
        if offset + len(chunk) > total:
            raise CIPError(GENERAL, EXT_BEYOND_END)
        with self._lock:
            buf = self._frag.get(addr)
            if buf is None or len(buf) != total:
                buf = self._frag[addr] = bytearray(total)
            buf[offset:offset + len(chunk)] = chunk
            done = offset + len(chunk) == total
            if done:
                del self._frag[addr]
        if done:
            self._write_values(t, _decode(t.dtype, bytes(buf), count))
        return reply(service)

    def _svc_rmw(self, service, addr, data, conn_size) -> bytes:
        # mask size n, OR mask (bits to set), AND mask (bits to keep).
        # pycomm3 sends an 8-byte AND mask regardless of n; only n bytes are used.
        n = struct.unpack_from("<H", data, 0)[0]
        if len(data) < 2 + 2 * n:
            raise CIPError(NOT_ENOUGH_DATA)
        or_mask = int.from_bytes(data[2:2 + n], "little")
        and_mask = int.from_bytes(data[2 + n:2 + 2 * n], "little")
        t = self._target(addr, 1)
        bits = INT_BITS.get(t.dtype)
        if bits is None or n * 8 > bits:
            raise CIPError(GENERAL, EXT_TYPE_MISMATCH)
        untouched = ((1 << bits) - 1) ^ ((1 << (8 * n)) - 1)     # bytes beyond the mask
        # applied to the value current when the write lands (scan boundary in RUN)
        self._apply(t.element(0), BitMask(or_mask, and_mask | untouched, bits))
        return reply(service)

    # ---- multiple service packet -------------------------------------------
    def _multi(self, data, conn_size) -> bytes:
        count = struct.unpack_from("<H", data, 0)[0]
        offsets = list(struct.unpack_from(f"<{count}H", data, 2)) + [len(data)]
        replies = [self.handle(data[offsets[i]:offsets[i + 1]], conn_size)
                   for i in range(count)]
        status = OK if all(r[2] in (OK, PARTIAL) for r in replies) else EMBEDDED_ERR
        out_offsets, pos = [], 2 + 2 * count
        for r in replies:
            out_offsets.append(pos)
            pos += len(r)
        body = (struct.pack("<H", count) + struct.pack(f"<{count}H", *out_offsets)
                + b"".join(replies))
        return reply(SVC_MULTI, status, body)

    # ---- symbol object ------------------------------------------------------
    def _instance_id(self, key: str) -> int:
        """Stable Symbol instance id per name (survives tags added/removed at runtime)."""
        if key not in self._inst_ids:
            self._inst_ids[key] = len(self._inst_ids) + 1
        return self._inst_ids[key]

    def _invalidate(self, *_):
        self._symbols = None

    def _build_symbols(self):
        ctrl = self.engine.controller
        table = {None: []}
        by_inst = {}

        def entry(scope, name, dtype, dim, dims=()):
            if dtype not in TYPE_CODE or (dim and dtype == "BOOL"):
                return
            full = name if scope is None else f"Program:{scope}.{name}"
            if getattr(self.store, "access", None) and self.store.access(full) == "none":
                return                                  # External Access None: not listed
            inst = self._instance_id(full)
            shape = tuple(dims) if len(dims or ()) > 1 else ((dim,) if dim else ())
            stype = TYPE_CODE[dtype] | (len(shape) << 13)     # bits 13-14: dimension count
            table[scope].append((inst, name, stype, tuple((shape + (0, 0, 0))[:3]), SIZE[dtype]))
            by_inst[inst] = full

        decls = self.db.declarations() if hasattr(self.db, "declarations") else {
            t.name: t for t in ctrl.tags}
        programs = list(ctrl.programs)
        for full in decls:
            if full.startswith("Program:"):
                pname = full[len("Program:"):].split(".", 1)[0]
                if pname not in programs:
                    programs.append(pname)
        for full, t in decls.items():
            if not full.startswith("Program:"):
                entry(None, full, t.data_type, t.dim, getattr(t, "dims", ()))
        for pname in programs:
            table[None].append((self._instance_id(f"Program:{pname}"), f"Program:{pname}",
                                PROGRAM_SYMBOL_TYPE, (0, 0, 0), 0))
            table[pname] = []
        for full, t in decls.items():
            if full.startswith("Program:"):
                pname, _, tname = full[len("Program:"):].partition(".")
                entry(pname, tname, t.data_type, t.dim, getattr(t, "dims", ()))
        for scope in table:
            table[scope].sort()
        self._symbols = (table, by_inst)
        return self._symbols

    def _name_for_instance(self, inst: int) -> str:
        _, by_inst = self._symbols or self._build_symbols()
        if inst not in by_inst:
            raise CIPError(PATH_UNKNOWN)
        return by_inst[inst]

    @staticmethod
    def _attr(attr: int, rec) -> bytes:
        inst, name, stype, dims, size = rec
        if attr == 1:
            raw = name.encode("ascii")
            return struct.pack("<H", len(raw)) + raw
        if attr == 2:
            return struct.pack("<H", stype)
        if attr == 3:
            return struct.pack("<I", inst << 8)
        if attr == 5:
            return struct.pack("<I", 0x10000000 + (inst << 4))
        if attr == 6:
            return struct.pack("<I", BASE_TAG_BIT)
        if attr == 7:
            return struct.pack("<H", size)
        if attr == 8:
            return struct.pack("<3I", *dims)
        if attr == 10:
            return b"\x00"                                   # Read/Write
        raise CIPError(ATTR_NOT_SUPPORTED)

    def _list(self, service, program, start, data, conn_size) -> bytes:
        table, _ = self._symbols or self._build_symbols()
        if program not in table:
            raise CIPError(PATH_UNKNOWN)
        n = struct.unpack_from("<H", data, 0)[0]
        attrs = struct.unpack_from(f"<{n}H", data, 2)
        limit = conn_size - _REPLY_OVERHEAD
        out, status = b"", OK
        for rec in table[program]:
            if rec[0] < start:
                continue
            item = struct.pack("<I", rec[0]) + b"".join(self._attr(a, rec) for a in attrs)
            if out and len(out) + len(item) > limit:
                status = PARTIAL
                break
            out += item
        return reply(service, status, out)
