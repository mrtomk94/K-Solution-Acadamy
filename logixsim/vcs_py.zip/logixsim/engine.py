"""The soft controller: task scheduling, routine execution and run modes.

Scan model (see docs/INSTRUCTIONS.md, "Execution model"):

* One engine *cycle* = drain external writes, apply forces, run every periodic
  task that is due (highest priority first, at most once per cycle), run the
  continuous task once, apply forces again.
* Periodic task timing uses the controller clock (``sim_time``). In "realtime"
  timing a due periodic task of higher priority interrupts a lower-priority task
  between rungs (UID/UIE disable this), limited to half of the PC time so slow
  logic cannot starve lower-priority tasks. In "exact" timing the clock steps from
  one task release to the next, so every period runs and the controller runs
  slower than real time when the logic is heavy. Event tasks are not executed
  (Verify reports them).
* Without a <Tasks> section (programmatic controllers) every program in
  ``task_order`` runs each cycle.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass

from .instructions import SPECS, ExecContext, InstructionError, MajorFault, UnsupportedInstruction
from .isa.core import Frame, Status
from .ld_interp import LadderInterpreter, instructions
from .model import Controller, TagDB
from .st_interp import Interpreter as STInterpreter
from .tagstore import TagStore

MAX_CALL_DEPTH = 25


def _prio(task) -> int:
    """Logix task priority (1 = highest). The continuous task is below every
    periodic task."""
    if task is None or task.get("type") == "CONTINUOUS":
        return 100
    return int(task.get("priority") or 10)


@dataclass(frozen=True)
class BitMask:
    """A queued Read-Modify-Write: applied to the tag's value *at drain time*,
    so bit writes arriving in the same scan period don't overwrite each other
    and bits changed by logic in the meantime are kept."""
    or_mask: int          # bits to set
    and_mask: int         # bits to keep (0 = clear)
    bits: int             # integer width of the target tag

    def apply(self, old: int) -> int:
        full = (1 << self.bits) - 1
        new = ((int(old) & full) | self.or_mask) & self.and_mask & full
        return new - (1 << self.bits) if new >> (self.bits - 1) else new


class Engine:
    def __init__(self, controller: Controller | None = None, db=None):
        self.controller = controller if controller is not None else Controller()
        self.db = TagDB(self.controller) if db is None else db
        self.scan_lock = threading.RLock()   # held for a whole scan (consistent snapshots)
        self.store = TagStore(self.db, engine=self)
        self.scan_state: dict = {}
        self.resolve_cache: dict = {}        # per program: operand -> tag address
        self.status = Status()
        self.st = STInterpreter()
        self.ld = LadderInterpreter()

        self.running = False
        self.mode = "PROGRAM"              # PROGRAM | RUN | PAUSED | FAULTED
        self.sim_time = 0.0                # controller clock (s); advances only while scanning
        self.trace: dict[tuple[str, str], list[list[bool]]] = {}
        self.instr_errors: dict[tuple[str, str], dict[int, str]] = {}
        self.scan_count = 0
        self.scan_time_ms = 0.0
        self.target_period = 0.02          # 20 ms continuous-task cadence
        # Timing of the controller clock while running:
        #   "realtime" - the clock follows the PC clock; when the logic takes longer
        #                than a task's period, periods are missed (overlaps)
        #   "exact"    - the clock advances from one task period to the next, so every
        #                periodic task runs on every period; the controller then runs
        #                slower than real time when the logic is heavy (see ``speed``)
        self.timing = "realtime"
        self.speed = 1.0                   # controller seconds per PC second (smoothed)
        self._cont_due = 0.0               # exact timing: next continuous-task scan
        self._cur_prio = None              # priority of the task now running (preemption)
        self._preempt_at = 0.0
        self._preempt_base = (0.0, 0.0)
        self._interrupt_s = 0.0            # PC time spent in interrupting tasks (total)
        self.uid_depth = 0                 # UID nesting of the running task (no interrupts)
        self.watchdog_s = 0.5              # task watchdog (Logix default 500 ms)
        # The simulator runs logic in Python, far slower than a controller: the watchdog
        # limit is multiplied by this factor so a long but legitimate scan does not fault.
        # An endless loop still faults. 1 = the controller's limit exactly.
        self.watchdog_factor = 10.0
        self.report_overflow = getattr(self.controller, "report_overflow", True)   # controller option
        self.faults: list[str] = []
        self.minor_faults: list[dict] = []
        # GSV/SSV FaultLog counters and bits, per-program fault records, object settings
        self.fault_log = {"major_events": 0, "minor_events": 0, "major_bits": 0, "minor_bits": 0}
        self.fault_records: dict[str, dict] = {}
        self.system: dict = {}
        self.major_fault: dict | None = None
        self.minor_this_scan = False
        self.first_scan = True             # S:FS for the next scan
        self.task_stats: dict[str, dict] = {}
        self.edit_history: dict = {}          # (program, routine) -> snapshots for undo
        self.redo_history: dict = {}          # (program, routine) -> snapshots for redo
        self.edit_log: list[dict] = []        # applied online edits
        self.authoring = False                # Studio project: API-created tags join the model
        self.project_version = 0              # bumped by structure changes (project_ops)
        self.change_count = 0                 # any project change (structure or logic)
        self.project_undo: list = []          # structure-change undo stack (project_ops)

        self.max_faults = 200
        self._wq: list[tuple[str, object]] = []
        self._wq_lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._scan_t0 = 0.0
        self._labels: dict[tuple, dict] = {}

    # ---- fault log -------------------------------------------------------------
    def fault(self, msg: str, dedup: bool = False) -> None:
        if dedup and msg in self.faults:
            return
        self.faults.append(msg)
        if len(self.faults) > self.max_faults:
            del self.faults[:-self.max_faults]

    def minor_fault(self, ftype: int, code: int, text: str, location: str = "") -> None:
        """Record a minor fault (logic keeps running; S:MINOR set for this scan)."""
        if ftype == 4 and code == 4 and not self.report_overflow:
            return
        self.minor_this_scan = True
        self.fault_log["minor_events"] = (self.fault_log["minor_events"] + 1) & 0x7FFF
        self.fault_log["minor_bits"] |= 1 << {4: 4, 6: 6, 9: 9, 10: 10}.get(ftype, 4)
        prog = location.split("/", 1)[0] if location else ""
        if prog:
            self.fault_records.setdefault(prog, {})["minor"] = (ftype, code, time.time())
        for f in self.minor_faults:
            if (f["type"], f["code"], f["location"]) == (ftype, code, location):
                f["count"] += 1
                f["last_scan"] = self.scan_count
                return
        self.minor_faults.append({"type": ftype, "code": code, "text": text,
                                  "location": location, "count": 1,
                                  "first_scan": self.scan_count, "last_scan": self.scan_count})
        self.fault(f"MINOR FAULT (Type {ftype:02d}) (Code {code:02d}) {text}"
                   + (f" at {location}" if location else ""))
        if len(self.minor_faults) > self.max_faults:
            del self.minor_faults[:-self.max_faults]

    def _major(self, exc: MajorFault, location: str) -> None:
        self.fault_log["major_events"] = (self.fault_log["major_events"] + 1) & 0x7FFF
        self.fault_log["major_bits"] |= 1 << {1: 1, 3: 3, 4: 4, 6: 6, 11: 11}.get(exc.ftype, 4)
        prog = location.split("/", 1)[0] if location else ""
        if prog:
            self.fault_records.setdefault(prog, {})["major"] = (exc.ftype, exc.code, time.time())
        self.major_fault = {"type": exc.ftype, "code": exc.code, "text": exc.text,
                            "location": location, "scan": self.scan_count,
                            "sim_time": round(self.sim_time, 3)}
        self.fault(f"MAJOR FAULT (Type {exc.ftype:02d}) (Code {exc.code:02d}) {exc.text}"
                   + (f" at {location}" if location else "") + " - controller FAULTED")
        self.mode = "FAULTED"

    # ---- external (HMI / CIP) writes, applied between scans ----------
    def queue_write(self, address: str, value) -> None:
        with self._wq_lock:
            self._wq.append((address, value))

    def _drain_writes(self) -> None:
        with self._wq_lock:
            pending, self._wq = self._wq, []
        for addr, val in pending:
            try:
                if isinstance(val, BitMask):
                    val = val.apply(self.db.get(addr))
                self.db.set(addr, val)
            except Exception as exc:         # bad address from a client
                self.fault(f"write {addr}: {exc}")

    # ---- routine execution -----------------------------------------------------
    def _routine_labels(self, program, routine_name, routine) -> dict[str, int]:
        key = (program.name, routine_name, id(routine))
        labels = self._labels.get(key)
        if labels is None:
            labels = {}
            for n, text in enumerate(routine.rungs):
                try:
                    items = instructions(text)
                except Exception:
                    continue
                if items and items[0][0].upper() == "LBL" and items[0][1]:
                    labels.setdefault(items[0][1][0].strip().upper(), n)
            self._labels[key] = labels
        return labels

    def _watchdog(self) -> None:
        limit = self.watchdog_s * max(1.0, float(self.watchdog_factor or 1))
        if self._scan_t0 and time.perf_counter() - self._scan_t0 > limit:
            raise MajorFault(6, 1, f"Task watchdog expired ({self.watchdog_s * 1000:.0f} ms"
                                   + (f" × {self.watchdog_factor:g} for simulation" if self.watchdog_factor > 1 else "")
                                   + "): the logic ran too long — check for an endless loop")

    def run_routine(self, program, routine_name: str, ctx: ExecContext) -> None:
        routine = program.routines.get(routine_name)
        if routine is None:
            return
        where = f"{program.name}/{routine_name}"
        if routine.rtype == "ST":
            ctx.location = where
            try:
                self.st.exec_text(ctx, routine.text)
            except MajorFault as exc:
                if not getattr(exc, "location", None):
                    exc.location = where
                raise
            except UnsupportedInstruction:
                raise
            except InstructionError as exc:
                self.fault(f"{where}: {exc}", dedup=True)
            return
        if routine.rtype in ("FBD", "SFC"):
            self.fault(f"NOT SIMULATED: {routine.rtype} routine {where}", dedup=True)
            return
        self._run_rll(program, routine_name, routine, ctx, where)

    def _run_rll(self, program, routine_name, routine, ctx, where) -> None:
        rungs = routine.rungs
        traces: list = [None] * len(rungs)
        errors: dict[int, str] = {}
        labels = None
        zone = None                       # MCR zone state: None = no zone, else enabled flag
        frame = ctx.frame
        i, steps = 0, 0
        while i < len(rungs):
            steps += 1
            if steps % 512 == 0:
                self._watchdog()
            if self._cur_prio is not None and time.perf_counter() >= self._preempt_at:
                self._preempt()
            ctx.location = f"{where} rung {i}"
            ctx.jump = None
            ctx.mcr_seen = None
            tr: list[bool] = []
            try:
                try:
                    self.ld.eval_rung(ctx, rungs[i], tr, True if zone is None else zone)
                except IndexError as exc:            # subscript beyond an array
                    raise MajorFault(4, 20, f"Array subscript too large ({exc})") from None
            except MajorFault as exc:
                traces[i] = tr
                self.trace[(program.name, routine_name)] = traces
                if not getattr(exc, "location", None):
                    exc.location = ctx.location      # innermost rung, before callers unwind
                raise
            except UnsupportedInstruction as exc:
                errors[i] = f"instruction '{exc}' is not executed by VirtualControlStudio"
                self.fault(f"UNSUPPORTED instruction '{exc}' in {where} rung {i}", dedup=True)
            except Exception as exc:
                errors[i] = str(exc)
                self.fault(f"{where} rung {i}: {exc}", dedup=True)
            traces[i] = tr
            if ctx.mcr_seen is not None:
                zone = ctx.mcr_seen if zone is None else None
            if frame.stop:
                break
            if ctx.jump:
                if labels is None:
                    labels = self._routine_labels(program, routine_name, routine)
                target = labels.get(ctx.jump.upper())
                if target is None:
                    errors[i] = f"JMP to missing label {ctx.jump}"
                    self.fault(f"{where} rung {i}: JMP to missing label {ctx.jump}", dedup=True)
                    i += 1
                else:
                    self._watchdog()
                    i = target
                continue
            i += 1
        self.trace[(program.name, routine_name)] = traces
        if errors:
            self.instr_errors[(program.name, routine_name)] = errors
        else:
            self.instr_errors.pop((program.name, routine_name), None)

    def call_routine(self, ctx: ExecContext, name: str, inputs: list, returns: list[str]) -> None:
        """JSR: run ``name`` in the current program with a new call frame."""
        program = ctx.program
        if program is None or name not in program.routines:
            raise InstructionError(f"JSR: no routine '{name}' in this program")
        if len(ctx.frames) > MAX_CALL_DEPTH:
            # Logix Designer help: Major fault types and codes (Type 4 Code 94)
            raise MajorFault(4, 94, f"Nesting limits exceeded: JSR deeper than {MAX_CALL_DEPTH}")
        saved = ctx.location
        ctx.frames.append(Frame(inputs))
        try:
            self.run_routine(program, name, ctx)
        finally:
            fr = ctx.frames.pop()
            ctx.location = saved
        values = fr.returns or []
        for target, (v, t) in zip(returns, values):
            ctx.store(target, v, t, flags=False)

    def for_loop(self, ctx: ExecContext, args: list[str]) -> None:
        """FOR(Routine, Index, Initial, Terminal, Step)."""
        name, index = args[0].strip(), args[1]
        init, term, step = (ctx.read(a) for a in args[2:5])
        if step == 0:
            raise InstructionError("FOR step size 0")
        program = ctx.program
        if program is None or name not in program.routines:
            raise InstructionError(f"FOR: no routine '{name}' in this program")
        ctx.store(index, init, ctx.dtype(args[2]), flags=False)
        n = 0
        while True:
            i = ctx.read(index)
            if (step > 0 and i > term) or (step < 0 and i < term):
                break
            ctx.frames.append(Frame())
            try:
                self.run_routine(program, name, ctx)
            finally:
                fr = ctx.frames.pop()
            if fr.stop == "BRK":
                break
            ctx.store(index, ctx.read(index) + step, ctx.dtype(index), flags=False)
            n += 1
            if n % 256 == 0:
                self._watchdog()

    def call_aoi(self, ctx: ExecContext, aoi, args: list[str], rung: bool):
        from .aoi import execute
        return execute(self, ctx, aoi, args, rung)

    # ---- scanning ----------------------------------------------------
    def scan_once(self, now: float | None = None) -> None:
        with self.scan_lock:
            self._scan(now)

    def _next_due(self) -> float:
        """Exact timing: controller time of the next task release (a periodic task's
        next period, or the next continuous-task scan)."""
        c = self.controller
        due = [self._cont_due] if any(t["type"] == "CONTINUOUS" and not t.get("inhibited")
                                      for t in c.tasks) or not c.tasks else []
        for t in c.tasks:
            if t["type"] == "PERIODIC" and not t.get("inhibited"):
                st = self.task_stats.get(t["name"])
                due.append(self.sim_time if not st or st.get("next") is None else st["next"])
        return min(due) if due else self.sim_time + self.target_period

    def _schedule(self) -> list[tuple[dict | None, list[str]]]:
        """Tasks to run this cycle: due periodic tasks then the continuous task."""
        c = self.controller
        if not c.tasks:
            return [(None, list(c.task_order))]
        out = []
        periodic = sorted((t for t in c.tasks if t["type"] == "PERIODIC" and not t.get("inhibited")),
                          key=lambda t: (t.get("priority") or 10, t["name"]))
        for t in periodic:
            st = self.task_stats.setdefault(t["name"], {"runs": 0, "overlaps": 0, "next": None})
            rate = (t.get("rate_ms") or 10.0) / 1000.0
            if st["next"] is None:
                st["next"] = self.sim_time
            if self.sim_time + 1e-9 >= st["next"]:
                missed = int((self.sim_time - st["next"]) / rate) if rate else 0
                st["overlaps"] += max(0, missed)
                st["next"] += rate * (missed + 1)
                out.append((t, t["programs"]))
        if self.timing == "exact" and self.running:
            # every continuous-task scan uses the scan period of controller time, so
            # the periodic tasks are not held back by continuous scans
            if self.sim_time + 1e-9 < self._cont_due:
                return out
            self._cont_due = self.sim_time + self.target_period
        for t in c.tasks:
            if t["type"] == "CONTINUOUS" and not t.get("inhibited"):
                self.task_stats.setdefault(t["name"], {"runs": 0, "overlaps": 0, "next": None})
                out.append((t, t["programs"]))
        return out

    def _run_task(self, task, programs, now: float) -> None:
        uid, self.uid_depth = self.uid_depth, 0            # each task starts enabled
        try:
            self._run_task_body(task, programs, now)
        finally:
            self.uid_depth = uid                           # the interrupted task's state

    def _run_task_body(self, task, programs, now: float) -> None:
        tt = time.perf_counter()
        it0 = self._interrupt_s
        for prog_name in programs:
            program = self.controller.programs.get(prog_name)
            if program is None or not program.main or getattr(program, "disabled", False):
                continue
            ctx = ExecContext(self.db, now=now, engine=self, program=program,
                              first_scan=self.first_scan)
            pt0 = time.perf_counter()
            try:
                self.run_routine(program, program.main, ctx)
                us = int((time.perf_counter() - pt0) * 1e6)       # GSV Program scan times
                ps = self.system.setdefault(("pscan", prog_name), {"last": 0, "max": 0})
                ps["last"], ps["max"] = us, max(ps["max"], us)
            except MajorFault as exc:
                if not getattr(exc, "location", None):
                    exc.location = ctx.location
                raise
            except UnsupportedInstruction as exc:
                self.fault(f"UNSUPPORTED instruction '{exc}' in "
                           f"{prog_name}/{program.main}", dedup=True)
            except Exception as exc:
                self.fault(f"{prog_name}: {exc}", dedup=True)
        if task is not None:
            st = self.task_stats[task["name"]]
            st["runs"] += 1
            # the task's own execution time (time spent in interrupting tasks excluded)
            own = time.perf_counter() - tt - (self._interrupt_s - it0)
            st["last_ms"] = round(max(0.0, own) * 1000.0, 3)
            st["max_ms"] = max(st.get("max_ms", 0.0), st["last_ms"])

    def _preempt(self) -> None:
        """Real-time timing: a periodic task of higher priority than the running task
        interrupts it between rungs when its period comes due (as a controller
        interrupts a lower-priority task). Status flags are saved and restored.
        Interruptions take at most half of the PC time, so slow high-priority
        logic cannot starve the lower-priority tasks."""
        wall = time.perf_counter()
        self._preempt_at = wall + 0.001
        cur = self._cur_prio
        if cur is None or self.timing != "realtime" or not self.running or self.uid_depth:
            return
        base_wall, base_sim = self._preempt_base
        now = base_sim + min(wall - base_wall, 5.0)
        due = []
        for t in self.controller.tasks:
            if t["type"] != "PERIODIC" or t.get("inhibited") or _prio(t) >= cur:
                continue
            st = self.task_stats.get(t["name"])
            if st is None or st.get("next") is None or now + 1e-9 < st["next"]:
                continue
            due.append(t)
        if not due:
            return
        if now > self.sim_time:
            self.sim_time = now
        flags = (self.status.N, self.status.Z, self.status.V, self.status.C)
        try:
            for t in sorted(due, key=lambda t: (_prio(t), t["name"])):
                st = self.task_stats[t["name"]]
                rate = (t.get("rate_ms") or 10.0) / 1000.0
                missed = int((now - st["next"]) / rate) if rate else 0
                st["overlaps"] += max(0, missed)
                st["next"] += rate * (missed + 1)
                self._cur_prio = _prio(t)
                self._run_task(t, t["programs"], now)
        finally:
            self._cur_prio = cur
            self.status.N, self.status.Z, self.status.V, self.status.C = flags
            # the logic runs far slower than on a controller: give the interrupted task
            # at least as much time as the interruption took, so higher-priority tasks
            # that cannot keep up do not starve it (and trip its watchdog)
            spent = time.perf_counter() - wall
            self._interrupt_s += spent
            self._preempt_at = time.perf_counter() + max(0.001, spent)

    def _scan(self, now: float | None = None) -> None:
        if self.mode == "FAULTED":
            return
        if now is None:
            now = self.sim_time
        else:
            self.sim_time = now
        t0 = self._scan_t0 = time.perf_counter()
        self.minor_this_scan = False
        self._drain_writes()
        self.store.apply_forces()          # logic sees forced values ...
        location = ""
        self._preempt_base = (time.perf_counter(), now)
        self._preempt_at = self._preempt_base[0] + 0.001
        try:
            for task, programs in self._schedule():
                self._cur_prio = _prio(task)
                self._run_task(task, programs, now)
            self._cur_prio = None
        except MajorFault as exc:
            location = getattr(exc, "location", None) or ""
            self._cur_prio = None
            self._major(exc, location)
        finally:
            self._scan_t0 = 0.0
        self.store.apply_forces()          # ... and forces win over what logic wrote
        self.first_scan = False
        self.scan_count += 1
        self.scan_time_ms = (time.perf_counter() - t0) * 1000.0

    def step(self, now: float | None = None, dt: float | None = None) -> None:
        """Run exactly one scan while not running. ``dt`` advances the controller
        clock by that many seconds first (default: one scan period); ``now`` sets
        it to an absolute time. Timers only see controller-clock time."""
        if self.mode == "FAULTED":
            raise RuntimeError("controller has a major fault: use Reset or Program mode first")
        if now is None:
            self.sim_time += self.target_period if dt is None else dt
            now = self.sim_time
        self.scan_once(now)

    # ---- run modes --------------------------------------------------------------
    def start(self) -> None:
        """RUN. From PROGRAM (or FAULTED, which is cleared) this first does a
        prescan, like Program->Run on a Logix controller; from PAUSED it simply
        continues."""
        if self.running:
            return
        if self.mode == "FAULTED":
            self.major_fault = None
            self.mode = "PROGRAM"
        if self.mode == "PROGRAM":
            self.prescan()
            self.first_scan = True         # S:FS is set again on entering Run
        self._stop.clear()
        self.running = True
        self.mode = "RUN"
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def _loop(self) -> None:
        last = time.perf_counter()
        anchor_wall, anchor_sim = last, self.sim_time     # exact timing: pace to real time
        self._cont_due = self.sim_time
        win_wall, win_sim = last, self.sim_time           # speed measurement window
        cycle_sim = self.sim_time
        while not self._stop.is_set():
            cycle = time.perf_counter()
            if self.timing == "exact":
                nxt = max(self._next_due(), self.sim_time)
                ahead = (nxt - anchor_sim) - (cycle - anchor_wall)
                if ahead > 0:                  # never run faster than real time
                    time.sleep(min(ahead, 0.05))
                    if self._stop.is_set():
                        break
                    cycle = time.perf_counter()
                    nxt = max(self._next_due(), self.sim_time)
                    if (nxt - anchor_sim) - (cycle - anchor_wall) > 0:
                        last = cycle
                        continue
                elif ahead < -0.25:            # behind: do not try to catch up later
                    anchor_wall, anchor_sim = cycle, nxt
                self.sim_time = nxt
            else:
                # a stall never jumps timers far; time already used by preempting
                # tasks inside the last cycle is not counted twice
                self.sim_time = max(self.sim_time, cycle_sim + min(cycle - last, 5.0))
                anchor_wall, anchor_sim = cycle, self.sim_time
            cycle_sim = self.sim_time
            last = cycle
            self.scan_once(self.sim_time)
            if self.mode == "FAULTED":
                self.running = False
                return
            now = time.perf_counter()
            elapsed = now - cycle
            if now - win_wall >= 1.0:
                rate = (self.sim_time - win_sim) / (now - win_wall)
                self.speed = round(min(rate, 1.0) if self.timing == "exact" else rate, 4)
                win_wall, win_sim = now, self.sim_time
            # always leave the web server and connections some time, even when the
            # logic takes longer than the cycle (otherwise the UI stops responding)
            if self.timing == "exact":
                time.sleep(min(0.05, elapsed * 0.25))
            else:
                time.sleep(max(self.target_period - elapsed, min(0.05, elapsed * 0.25)))

    def _halt(self) -> None:
        self._stop.set()
        if self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout=1.0)
        self._thread = None
        self.running = False

    def stop(self) -> None:
        """PROGRAM mode: no scanning. Clears a major fault. The next start() prescans."""
        self._halt()
        self.mode = "PROGRAM"
        self.major_fault = None

    def pause(self) -> None:
        """Freeze: no scanning and the controller clock stops (timers hold)."""
        if self.mode != "RUN":
            return
        self._halt()
        if self.mode == "RUN":
            self.mode = "PAUSED"

    def prescan(self) -> None:
        """Program -> Run prescan: every routine of every program is scanned once
        with each instruction's documented prescan behaviour (OTE cleared, TON
        reset, ONS/CTU edge memory set, ...), AOI prescan routines run, and ST
        non-retentive assignments ([:=]) are reset to zero."""
        with self.scan_lock:
            for prog_name, program in self.controller.programs.items():
                ctx = ExecContext(self.db, now=self.sim_time, engine=self, program=program)
                ctx.prescan = True
                for routine in program.routines.values():
                    if routine.rtype == "RLL":
                        for rung in routine.rungs:
                            try:
                                items = instructions(rung)
                            except Exception:
                                continue
                            for name, args in items:
                                self._prescan_instr(ctx, name, args)
                    elif routine.rtype == "ST":
                        try:
                            self.st.prescan(ctx, routine.text)
                        except Exception:
                            pass
            self.scan_state.pop("aoi_prescanned", None)
            self.store.apply_forces()

    def _prescan_instr(self, ctx, name: str, args: list[str]) -> None:
        spec = SPECS.get(name.upper())
        try:
            if spec is None:
                from .aoi import prescan_call
                prescan_call(self, ctx, name, args)
            elif spec.prescan is not None:
                spec.prescan(ctx, args)
        except Exception:
            pass                               # unknown operand: Verify reports it

    def load(self, controller: Controller) -> None:
        """Replace the program (an L5X import). Same Engine and TagStore objects,
        so connectors and API references stay valid. Ends in PROGRAM mode."""
        self.stop()
        with self.scan_lock:
            self.controller = controller
            self.report_overflow = getattr(controller, "report_overflow", True)
            self.db = TagDB(controller)
            self.store.replace_db(self.db)
            self._clear_runtime()
            self.edit_history.clear()
            self.redo_history.clear()
            self.edit_log.clear()
            self.project_undo.clear()
            self.project_version = 0
            self.change_count = 0

    def _clear_runtime(self) -> None:
        self.scan_state.clear()
        self.resolve_cache.clear()
        getattr(self.db, "invalidate", lambda: None)()
        with self._wq_lock:
            self._wq.clear()
        self.faults.clear()
        self.minor_faults.clear()
        self.fault_log = {"major_events": 0, "minor_events": 0, "major_bits": 0, "minor_bits": 0}
        self.fault_records = {}
        self.system = {}
        self.major_fault = None
        self.trace.clear()
        self.instr_errors.clear()
        self.task_stats.clear()
        self._labels.clear()
        self.scan_count = 0
        self.sim_time = 0.0
        self.first_scan = True
        self.status = Status()
        wd = [t.get("watchdog_ms") for t in self.controller.tasks if t.get("watchdog_ms")]
        self.watchdog_s = (max(wd) / 1000.0) if wd else 0.5

    def reset(self) -> None:
        """Back to the project's initial state: PROGRAM mode, every tag from the
        L5X reloaded with its initial value, timers/counters/one-shots cleared,
        faults cleared, controller clock 0. Tags created at runtime keep their
        values; forces stay in place."""
        self.stop()
        with self.scan_lock:
            fresh = TagDB(self.controller)
            for name, value in fresh._store.items():
                if name in self.db._store:
                    self.db._store[name] = value
            self._clear_runtime()
            self.store.apply_forces()

    # ---- introspection ----------------------------------------------
    def state(self) -> dict:
        return {
            "running": self.running,
            "mode": self.mode,
            "sim_time": round(self.sim_time, 3),
            "scan_count": self.scan_count,
            "scan_time_ms": round(self.scan_time_ms, 3),
            "timing": self.timing,
            "speed": self.speed,
            "faults": list(self.faults),
            "major_fault": self.major_fault,
            "minor_faults": len(self.minor_faults),
            "controller": self.controller.name,
        }
