"""Instruction metadata: one :class:`Spec` per implemented instruction.

The spec is the single source of truth used by the ladder interpreter (input or
output behaviour), the ST interpreter, prescan, Verify (operand counts and data
types), the Studio UI (instruction box layout) and the generated instruction
reference (docs/INSTRUCTIONS.md).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from .core import REGISTRY

# operand type classes used in specs
INT = ("SINT", "INT", "DINT", "LINT", "USINT", "UINT", "UDINT", "ULINT")
NUM = INT + ("REAL", "LREAL")
BOOLISH = ("BOOL",)

# evidence levels (see docs/INSTRUCTIONS.md)
DOC = "doc"                # behaviour checked against official text retrieved for this work
RECALL = "doc-recall"      # follows the official reference as known; page cited; not re-read
BOUNDARY = "boundary"      # deliberate simulation boundary, documented


@dataclass
class Operand:
    name: str
    kind: str = "src"           # src | dest | tag | imm | label | routine | expr | any
    types: tuple = ()           # allowed data types; () = any
    optional: bool = False
    repeat: bool = False        # variable-length tail (JSR/SBR/RET parameters)


@dataclass
class Spec:
    mnemonic: str
    title: str
    family: str
    kind: str                   # "condition" | "action"
    operands: list[Operand]
    languages: tuple = ("LD", "ST")
    page: int | None = None
    status: str = "implemented"  # implemented | boundary
    evidence: str = RECALL
    notes: tuple = ()
    display: dict = field(default_factory=dict)
    aliases: tuple = ()
    fn: Callable | None = None
    prescan: Callable | None = None

    @property
    def input_like(self) -> bool:
        """Drawn as an input (left side) and highlighted by its own result."""
        return self.kind == "condition" or bool(self.display.get("input"))

    def min_args(self) -> int:
        return sum(1 for o in self.operands if not o.optional and not o.repeat)

    def max_args(self) -> int | None:
        return None if any(o.repeat for o in self.operands) else len(self.operands)

    def run(self, ctx, args, rung: bool) -> tuple[bool, bool]:
        """Execute in a ladder rung. Returns (rung-condition-out, highlight)."""
        if self.kind == "condition":
            cond = bool(self.fn(ctx, args))
            return rung and cond, cond
        out = bool(self.fn(ctx, args, rung=rung))
        return out, (out if self.display.get("input") else bool(rung))

    def to_json(self) -> dict:
        return {
            "mnemonic": self.mnemonic, "title": self.title, "family": self.family,
            "kind": self.kind, "input": self.input_like, "languages": list(self.languages),
            "page": self.page, "status": self.status, "evidence": self.evidence,
            "notes": list(self.notes), "aliases": list(self.aliases),
            "operands": [{"name": o.name, "kind": o.kind, "types": list(o.types),
                          "optional": o.optional, "repeat": o.repeat} for o in self.operands],
            "display": self.display,
        }


SPECS: dict[str, Spec] = {}


def instruction(mnemonic: str, title: str, family: str, kind: str, operands=(),
                page: int | None = None, notes=(), evidence: str = RECALL,
                languages=("LD", "ST"), display: dict | None = None, aliases=(),
                status: str = "implemented"):
    """Register an instruction implementation together with its metadata."""
    ops = [o if isinstance(o, Operand) else Operand(*o) if isinstance(o, tuple) else Operand(o)
           for o in operands]

    def deco(fn):
        spec = Spec(mnemonic, title, family, kind, ops, tuple(languages), page, status,
                    evidence, tuple(notes), dict(display or {}), tuple(aliases), fn)
        SPECS[mnemonic] = spec
        REGISTRY[mnemonic] = fn
        for a in aliases:
            SPECS[a] = spec
            REGISTRY[a] = fn
        return fn
    return deco


def prescan(*mnemonics: str):
    """Register the prescan behaviour (Program -> Run) of instructions."""
    def deco(fn):
        for m in mnemonics:
            SPECS[m].prescan = fn
        return fn
    return deco


def get(name: str) -> Spec | None:
    return SPECS.get(name.upper())
