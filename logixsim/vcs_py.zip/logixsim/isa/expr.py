"""Logix expressions (CPT, CMP, FAL, FSC and indirect array subscripts).

Grammar and precedence of ladder expressions (highest first; equal levels run
left to right), as given in the CMP / FSC topics of the Logix Designer help:

    ( )   functions   **   - (negate) NOT   * / MOD   + -   AND   XOR   OR
    < <= > >= = <>                (all six comparisons share the lowest level)

Structured Text has its own order (comparisons above AND) and its own parser
(logixsim/st_interp.py); only the evaluator below is shared with it.

Arithmetic is typed: if either operand is REAL the operation is done in REAL
(IEEE single precision), otherwise in DINT (LINT if a LINT is involved).
Integer division truncates toward zero; MOD is ``A - B * TRN(A / B)``.
AND / OR / XOR / NOT are bitwise on integers.
"""
from __future__ import annotations

import math
import re

from .values import (INT_BITS, arith_result, f32, literal, math_type, value_type, wrap)

_TOK = re.compile(r"""
    (?P<ws>\s+)
  | (?P<num>(?:2|8|16)\#[0-9A-Fa-f_]+|\d[\d_]*\.\d*(?:[eE][-+]?\d+)?|\d[\d_]*[eE][-+]?\d+|\d[\d_]*|\.\d+)
  | (?P<op>\*\*|<=|>=|<>|[-+*/()=<>,])
  | (?P<name>[A-Za-z_][A-Za-z0-9_:]*)
""", re.VERBOSE)

_KEYWORDS = {"AND", "OR", "XOR", "NOT", "MOD"}
FUNCTIONS = {
    "ABS", "SQR", "SQRT", "NEG", "SIN", "COS", "TAN", "ASN", "ASIN", "ACS", "ACOS",
    "ATN", "ATAN", "LN", "LOG", "DEG", "RAD", "TRN", "TRUNC", "FRD", "TOD",
}


class ExprError(SyntaxError):
    pass


def tokenize(text: str) -> list[tuple[str, str]]:
    toks, i = [], 0
    while i < len(text):
        m = _TOK.match(text, i)
        if not m:
            raise ExprError(f"bad expression near {text[i:i + 12]!r}")
        kind, val = m.lastgroup, m.group()
        i = m.end()
        if kind == "ws":
            continue
        if kind == "name":
            up = val.upper()
            # a name may continue as a tag path: members and [subscripts]
            j = i
            while j < len(text) and text[j] in ".[":
                if text[j] == "[":
                    depth, k = 1, j + 1
                    while k < len(text) and depth:
                        depth += {"[": 1, "]": -1}.get(text[k], 0)
                        k += 1
                    if depth:
                        raise ExprError("unbalanced [")
                    j = k
                else:
                    m2 = re.compile(r"\.(?:[A-Za-z_][A-Za-z0-9_]*|\d+|(?=\[))").match(text, j)
                    if not m2:
                        break
                    j = m2.end()
            path = text[i - len(val):j]
            i = j
            if path == val and up in _KEYWORDS:
                toks.append(("kw", up))
            elif path == val and up in FUNCTIONS and text[i:].lstrip().startswith("("):
                toks.append(("fn", up))
            else:
                toks.append(("tag", path))
        else:
            toks.append((kind, val))
    toks.append(("eof", ""))
    return toks


class _Parser:
    def __init__(self, toks):
        self.t, self.p = toks, 0

    def peek(self):
        return self.t[self.p]

    def take(self):
        tok = self.t[self.p]
        self.p += 1
        return tok

    def accept(self, kind, val=None):
        k, v = self.peek()
        if k == kind and (val is None or v == val):
            return self.take()
        return None

    def parse(self):
        node = self.cmpx()
        if self.peek()[0] != "eof":
            raise ExprError(f"unexpected {self.peek()[1]!r}")
        return node

    def _left(self, sub, ops):
        node = sub()
        while True:
            k, v = self.peek()
            if (k == "kw" and v in ops) or (k == "op" and v in ops):
                self.take()
                node = ("bin", v, node, sub())
            else:
                return node

    def cmpx(self):
        return self._left(self.orx, {"<", "<=", ">", ">=", "=", "<>"})

    def orx(self):
        return self._left(self.xorx, {"OR"})

    def xorx(self):
        return self._left(self.andx, {"XOR"})

    def andx(self):
        return self._left(self.add, {"AND"})

    def add(self):
        return self._left(self.mul, {"+", "-"})

    def mul(self):
        return self._left(self.unary, {"*", "/", "MOD"})

    def unary(self):
        if self.accept("op", "-"):
            return ("neg", self.unary())
        if self.accept("op", "+"):
            return self.unary()
        if self.accept("kw", "NOT"):
            return ("not", self.unary())
        return self.power()

    def power(self):
        node = self.primary()
        while self.accept("op", "**"):
            node = ("bin", "**", node, self.unary_power())
        return node

    def unary_power(self):
        if self.accept("op", "-"):
            return ("neg", self.unary_power())
        return self.primary()

    def primary(self):
        k, v = self.take()
        if k == "num":
            return ("lit", literal(v))
        if k == "tag":
            return ("tag", v)
        if k == "fn":
            if not self.accept("op", "("):
                raise ExprError(f"{v} needs (")
            arg = self.cmpx()
            if not self.accept("op", ")"):
                raise ExprError("missing )")
            return ("fn", v, arg)
        if k == "op" and v == "(":
            node = self.cmpx()
            if not self.accept("op", ")"):
                raise ExprError("missing )")
            return node
        raise ExprError(f"unexpected {v or k!r}")


_CACHE: dict[str, tuple] = {}


def parse(text: str):
    node = _CACHE.get(text)
    if node is None:
        node = _Parser(tokenize(text)).parse()
        if len(_CACHE) < 5000:
            _CACHE[text] = node
    return node


def tags_in(text: str) -> list[str]:
    """Tag references used by an expression (for Verify)."""
    return [v for k, v in tokenize(text) if k == "tag"]


# functions whose presence makes CMP / CPT convert every operand to REAL first
REAL_FUNCTIONS = {"SIN", "COS", "TAN", "ASN", "ASIN", "ACS", "ACOS", "ATN", "ATAN",
                  "LN", "LOG", "DEG", "RAD"}


def _wants_real(ctx, node, operands: bool) -> bool:
    """True when the expression has a REAL-forcing function or (``operands``) a
    REAL operand, so the whole expression is evaluated in REAL."""
    kind = node[0]
    if kind == "fn":
        return node[1] in REAL_FUNCTIONS or _wants_real(ctx, node[2], operands)
    if kind == "lit":
        return operands and isinstance(node[1], float)
    if kind == "tag":
        return operands and ctx.dtype(node[1]) == "REAL"
    return any(_wants_real(ctx, n, operands) for n in node[1:] if isinstance(n, tuple))


class _Eval:
    def __init__(self, ctx, real: bool = False):
        self.ctx = ctx
        self.overflow = False
        self.real = real           # every operand converted to REAL before use

    def ev(self, node):
        kind = node[0]
        if kind == "lit":
            v = node[1]
            if self.real and isinstance(v, (int, float)):
                return f32(v), "REAL"
            return v, value_type(v)
        if kind == "tag":
            v, t = self.ctx.value(node[1])
            if isinstance(v, (dict, list)):
                from .core import InstructionError
                raise InstructionError(f"'{node[1]}' is not an atomic value")
            if t == "BOOL":
                v, t = int(bool(v)), "DINT"
            if self.real and isinstance(v, (int, float)):
                return f32(v), "REAL"
            return v, t
        if kind == "neg":
            v, t = self.ev(node[1])
            return self._norm(-v, t if t in ("REAL", "LINT") else "DINT")
        if kind == "not":
            v, t = self.ev(node[1])
            if t == "REAL":
                return self._bad("NOT on a REAL value")
            return ~int(v), t if t == "LINT" else "DINT"
        if kind == "fn":
            return self.fn(node[1], *self.ev(node[2]))
        if kind == "bin":
            return self.bin(node[1], self.ev(node[2]), self.ev(node[3]))
        raise ExprError(f"bad node {kind}")

    def _bad(self, msg):
        from .core import InstructionError
        raise InstructionError(msg)

    def _norm(self, v, t):
        out, over = arith_result(v, t)
        self.overflow |= over
        return out, t

    def bin(self, o, left, right):
        (a, ta), (b, tb) = left, right
        if isinstance(a, str) or isinstance(b, str):
            if o in ("=", "<>"):
                return int((a == b) == (o == "=")), "DINT"
            return self._bad("strings can only be compared with = or <>")
        t = math_type(ta, tb)
        if t == "REAL":
            a, b = f32(a), f32(b)
        if o in ("<", "<=", ">", ">=", "=", "<>"):
            res = {"<": a < b, "<=": a <= b, ">": a > b, ">=": a >= b,
                   "=": a == b, "<>": a != b}[o]
            return int(res), "DINT"
        if o in ("AND", "OR", "XOR"):
            if t == "REAL":
                return self._bad(f"{o} needs integer operands")
            res = {"AND": a & b, "OR": a | b, "XOR": a ^ b}[o]
            return self._norm(res, t)
        if o == "+":
            return self._norm(a + b, t)
        if o == "-":
            return self._norm(a - b, t)
        if o == "*":
            return self._norm(a * b, t)
        if o == "/":
            return self._div(a, b, t)
        if o == "MOD":
            return self._mod(a, b, t)
        if o == "**":
            return self._pow(a, b)
        raise ExprError(f"bad operator {o}")

    def _div(self, a, b, t):
        if t == "REAL":
            if b == 0:
                self.overflow = True
                return (math.copysign(math.inf, a) if a else math.nan), t
            return self._norm(a / b, t)
        if b == 0:
            self.overflow = True
            return 0, t
        q = abs(a) // abs(b)
        return self._norm(q if (a >= 0) == (b >= 0) else -q, t)

    def _mod(self, a, b, t):
        if b == 0:
            self.overflow = True
            return (math.nan if t == "REAL" else 0), t
        if t == "REAL":
            return self._norm(a - b * math.trunc(a / b), t)
        q = abs(a) // abs(b)
        q = q if (a >= 0) == (b >= 0) else -q
        return self._norm(a - b * q, t)

    def _pow(self, a, b):
        try:
            r = math.pow(a, b)
        except (ValueError, OverflowError):
            self.overflow = True
            return math.nan, "REAL"
        return self._norm(r, "REAL")

    def _log(self, name, x):
        """LN / LOG: zero gives -INF, +INF stays +INF and NaN/negative give NaN, each
        with an overflow (Natural Log (LN), Log Base 10 (LOG) topics)."""
        if x == 0:
            self.overflow = True
            return -math.inf, "REAL"
        if math.isnan(x) or x < 0 or math.isinf(x):
            self.overflow = True
            return (math.inf if x > 0 else math.nan), "REAL"
        return self._norm(math.log(x) if name == "LN" else math.log10(x), "REAL")

    def fn(self, name, v, t):
        real = f32(v) if t != "REAL" else v
        try:
            if name == "ABS":
                return self._norm(abs(v), t if t in ("REAL", "LINT") else "DINT")
            if name == "NEG":
                return self._norm(-v, t if t in ("REAL", "LINT") else "DINT")
            if name in ("SQR", "SQRT"):
                return self._norm(math.sqrt(abs(real)), "REAL")
            if name == "SIN":
                return self._norm(math.sin(real), "REAL")
            if name == "COS":
                return self._norm(math.cos(real), "REAL")
            if name == "TAN":
                return self._norm(math.tan(real), "REAL")
            if name in ("ASN", "ASIN"):
                return self._norm(math.asin(real), "REAL")
            if name in ("ACS", "ACOS"):
                return self._norm(math.acos(real), "REAL")
            if name in ("ATN", "ATAN"):
                return self._norm(math.atan(real), "REAL")
            if name in ("LN", "LOG"):
                return self._log(name, real)
            if name == "DEG":
                return self._norm(real * 180.0 / math.pi, "REAL")
            if name == "RAD":
                return self._norm(real * math.pi / 180.0, "REAL")
            if name in ("TRN", "TRUNC"):
                return (float(math.trunc(v)), "REAL") if t == "REAL" else (v, t)
            if name == "FRD":
                return from_bcd(int(v)), "DINT"
            if name == "TOD":
                out, over = to_bcd(int(v))
                self.overflow |= over
                return out, "DINT"
        except (ValueError, OverflowError):
            self.overflow = True
            return math.nan, "REAL"
        raise ExprError(f"unknown function {name}")


def to_bcd(v: int) -> tuple[int, bool]:
    """Integer -> BCD (TOD). Negative or > 99,999,999 overflows."""
    if v < 0 or v > 99_999_999:
        return 0, True
    out, shift = 0, 0
    while v:
        out |= (v % 10) << shift
        v //= 10
        shift += 4
    return wrap(out, INT_BITS["DINT"])[0], False


def from_bcd(v: int) -> int:
    """BCD -> integer (FRD); nibbles > 9 are treated as their value (unverified)."""
    v &= 0xFFFFFFFF
    out, mul = 0, 1
    while v:
        out += (v & 0xF) * mul
        v >>= 4
        mul *= 10
    return out


def evaluate(ctx, text: str):
    """Evaluate an expression. Returns (value, Logix type); sets S:V on overflow."""
    ev = _Eval(ctx)
    val, t = ev.ev(parse(text))
    if ev.overflow:
        ctx.status.V = True
    return val, t


def evaluate_full(ctx, text: str, promote: str | None = None):
    """Like :func:`evaluate` but returns the overflow flag instead of setting S:V.
    ``promote``: None = each operation typed by its operands; "functions" = the
    whole expression in REAL when it uses SIN COS TAN ASN ACS ATN LN LOG DEG RAD
    (CPT); "operands" = also when any operand is REAL (CMP)."""
    node = parse(text)
    real = promote is not None and _wants_real(ctx, node, promote == "operands")
    ev = _Eval(ctx, real)
    val, t = ev.ev(node)
    return val, t, ev.overflow
