"""Move/Logical instructions (RM: Move/Logical Instructions, p.486-554)."""
from __future__ import annotations

from .core import InstructionError
from .spec import INT, NUM, Operand, instruction
from .values import INT_BITS, num, wrap

_BOX2 = {"rows": [["Source", 0], ["Dest", 1]]}


def _int_operand(ctx, operand) -> tuple[int, str]:
    v, t = ctx.value(operand)
    if t == "REAL" or isinstance(v, float):
        raise InstructionError(f"{operand}: bitwise instructions need integer operands")
    if t == "BOOL":
        return int(bool(v)), "DINT"
    return int(num(v)), t


@instruction("MOV", "Move", "Move/Logical", "action",
             [Operand("Source", "src", NUM + ("STRING",)), Operand("Dest", "dest", NUM + ("STRING",))],
             page=530, languages=("LD",), aliases=("MOVE",), display=_BOX2,
             notes=("Copies Source to Dest, converting to Dest's data type (REAL->integer rounds "
                    "to nearest, ties to even; out-of-range integers set S:V).",
                    "Sets S:N and S:Z from the value written.",))
def mov(ctx, args, rung=True):
    if rung:
        v, t = ctx.value(args[0])
        if isinstance(v, (dict, list)):
            raise InstructionError("MOV copies atomic values; use COP for structures/arrays")
        ctx.store(args[1], v, t)
    return bool(rung)


@instruction("MVM", "Masked Move", "Move/Logical", "action",
             [Operand("Source", "src", INT), Operand("Mask", "src", INT),
              Operand("Dest", "dest", INT)], page=523, languages=("LD",),
             display={"rows": [["Source", 0], ["Mask", 1],
                               ["Dest", 2]]},
             notes=("Dest = (Dest AND NOT Mask) OR (Source AND Mask): only the bits set in Mask "
                    "are copied.",))
def mvm(ctx, args, rung=True):
    if rung:
        src, _ = _int_operand(ctx, args[0])
        mask, _ = _int_operand(ctx, args[1])
        dest, dt = _int_operand(ctx, args[2])
        ctx.store(args[2], (dest & ~mask) | (src & mask), dt)
    return bool(rung)


@instruction("BTD", "Bit Field Distribute", "Move/Logical", "action",
             [Operand("Source", "src", INT), Operand("Source Bit", "imm", INT),
              Operand("Dest", "dest", INT), Operand("Dest Bit", "imm", INT),
              Operand("Length", "imm", INT)], page=487, languages=("LD",),
             display={"rows": [["Source", 0], ["Source Bit", 1], ["Dest", 2], ["Dest Bit", 3], ["Length", 4]]},
             notes=("Copies Length bits starting at Source Bit into Dest starting at Dest Bit; "
                    "other Dest bits are unchanged. Bits past the end of Dest are lost.",))
def btd(ctx, args, rung=True):
    if rung:
        src, _ = _int_operand(ctx, args[0])
        sbit = int(num(ctx.read(args[1])))
        dest, dt = _int_operand(ctx, args[2])
        dbit = int(num(ctx.read(args[3])))
        length = int(num(ctx.read(args[4])))
        bits = INT_BITS.get(dt, 32)
        field = (src >> sbit) & ((1 << length) - 1)
        mask = (((1 << length) - 1) << dbit) & ((1 << bits) - 1)
        out = (dest & ~mask) | ((field << dbit) & mask)
        ctx.write(args[2], wrap(out, bits)[0])
    return bool(rung)


@instruction("SWPB", "Swap Byte", "Move/Logical", "action",
             [Operand("Source", "src", ("INT", "DINT")), Operand("Order Mode", "imm"),
              Operand("Dest", "dest", ("INT", "DINT"))], page=534, languages=("LD",),
             display={"rows": [["Source", 0], ["Order Mode", 1], ["Dest", 2]]},
             notes=("INT: the two bytes are swapped (any mode).",
                    "DINT: REVERSE (ABCD->DCBA), WORD (ABCD->CDAB), HIGH/LOW (ABCD->BADC).",))
def swpb(ctx, args, rung=True):
    if rung:
        src, st = _int_operand(ctx, args[0])
        mode = args[1].strip().upper()
        if st == "INT":
            u = src & 0xFFFF
            out = ((u & 0xFF) << 8) | (u >> 8)
            ctx.store(args[2], wrap(out, 16)[0], "INT", flags=False)
        else:
            b = (src & 0xFFFFFFFF).to_bytes(4, "big")          # A B C D
            if mode in ("REVERSE", "0"):
                b = b[::-1]
            elif mode in ("WORD", "1"):
                b = b[2:] + b[:2]
            elif mode in ("HIGH/LOW", "HIGHLOW", "HIGH_LOW", "2"):
                b = bytes([b[1], b[0], b[3], b[2]])
            else:
                raise InstructionError(f"SWPB: unknown order mode {args[1]!r}")
            ctx.store(args[2], wrap(int.from_bytes(b, "big"), 32)[0], "DINT", flags=False)
    return bool(rung)


@instruction("CLR", "Clear", "Move/Logical", "action",
             [Operand("Dest", "dest", NUM)], page=521, languages=("LD",),
             display={"rows": [["Dest", 0]]},
             notes=("Dest = 0. Sets S:Z, clears S:N and S:V.",))
def clr(ctx, args, rung=True):
    if rung:
        t = ctx.dtype(args[0])
        ctx.store(args[0], 0.0 if t == "REAL" else 0, t)
    return bool(rung)


def _bitwise(mn, title, page, fn, alias=()):
    @instruction(mn, title, "Move/Logical", "action",
                 [Operand("Source A", "src", INT), Operand("Source B", "src", INT),
                  Operand("Dest", "dest", INT)], page=page, languages=("LD",), aliases=alias,
                 display={"rows": [["Source A", 0], ["Source B", 1],
                                   ["Dest", 2]]},
                 notes=("Bitwise operation on integers (smaller types are sign-extended). "
                        "Sets S:N and S:Z.",))
    def run(ctx, args, rung=True):
        if rung:
            a, ta = _int_operand(ctx, args[0])
            b, tb = _int_operand(ctx, args[1])
            t = "LINT" if "LINT" in (ta, tb) else "DINT"
            ctx.store(args[2], wrap(fn(a, b), INT_BITS[t])[0], t)
        return bool(rung)
    run.__name__ = mn.lower()
    return run


_bitwise("AND", "Bitwise And", 494, lambda a, b: a & b)
_bitwise("OR", "Bitwise Inclusive Or", 514, lambda a, b: a | b)
_bitwise("XOR", "Bitwise Exclusive Or", 501, lambda a, b: a ^ b)


@instruction("NOT", "Bitwise Not", "Move/Logical", "action",
             [Operand("Source", "src", INT), Operand("Dest", "dest", INT)], page=508,
             languages=("LD",), display=_BOX2,
             notes=("Dest = bitwise complement of Source. Sets S:N and S:Z.",))
def not_(ctx, args, rung=True):
    if rung:
        a, ta = _int_operand(ctx, args[0])
        ctx.store(args[1], ~a, "LINT" if ta == "LINT" else "DINT")
    return bool(rung)
