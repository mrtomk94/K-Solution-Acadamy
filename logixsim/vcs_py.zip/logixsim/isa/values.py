"""Logix numeric semantics: literals, data type promotion and conversion.

Documented rules used here (see docs/INSTRUCTIONS.md for sources):

* SINT/INT operands are converted to DINT (or REAL) before an instruction uses
  them, and converted back for a SINT/INT destination (1756-PM004).
* REAL is IEEE-754 single precision: every REAL result is rounded to 32 bits.
* REAL -> integer conversion rounds to the nearest integer, ties to even.
  [doc-recall, General Instructions RM "Data conversions"; to be confirmed]
* An integer result that does not fit the destination keeps its low-order bits
  and sets the overflow flag S:V. [doc-recall]
"""
from __future__ import annotations

import math
import re
import struct

INT_BITS = {"SINT": 8, "INT": 16, "DINT": 32, "LINT": 64}
# unsigned integers and LREAL (ControlLogix 5580 / CompactLogix 5380, v32+)
UINT_BITS = {"USINT": 8, "UINT": 16, "UDINT": 32, "ULINT": 64}
ALL_INT_BITS = {**INT_BITS, **UINT_BITS}
NUMERIC = set(ALL_INT_BITS) | {"REAL", "LREAL"}
ORDER = {"SINT": 0, "USINT": 0, "INT": 1, "UINT": 1, "DINT": 2, "UDINT": 2, "LINT": 3, "ULINT": 3,
         "REAL": 4, "LREAL": 5}

_LIT_INT = re.compile(r"^[-+]?\d[\d_]*$")
_LIT_REAL = re.compile(r"^[-+]?(\d[\d_]*\.\d*|\.\d+|\d[\d_]*)([eE][-+]?\d+)?$")
_LIT_BASED = re.compile(r"^([-+]?)(2|8|16)#([-+]?)([0-9A-Fa-f_]+)$")


def f32(x: float) -> float:
    """Round a Python float to IEEE single precision (Logix REAL)."""
    try:
        return struct.unpack("<f", struct.pack("<f", float(x)))[0]
    except OverflowError:
        return math.copysign(math.inf, x)


def wrap(value: int, bits: int) -> tuple[int, bool]:
    """Keep the low ``bits`` bits as a signed value; report overflow."""
    lo, hi = -(1 << (bits - 1)), (1 << (bits - 1)) - 1
    if lo <= value <= hi:
        return value, False
    value &= (1 << bits) - 1
    if value >= 1 << (bits - 1):
        value -= 1 << bits
    return value, True


def round_half_even(x: float) -> int:
    return int(round(x))           # Python rounds ties to even


_LIT_CACHE: dict = {}
_NOLIT = object()


def literal(text: str):
    """Parse a Logix numeric literal (``12``, ``-3``, ``1.5``, ``2.5e3``,
    ``16#FF``, ``2#1010_0101``, ``8#17``). Returns None when not a literal."""
    hit = _LIT_CACHE.get(text, _NOLIT)
    if hit is not _NOLIT:
        return hit
    out = _literal(text)
    if len(_LIT_CACHE) < 100_000:
        _LIT_CACHE[text] = out
    return out


def _literal(text: str):
    t = text.strip()
    if not t or not (t[0].isdigit() or t[0] in "+-."):
        return None
    m = _LIT_BASED.match(t)
    if m:
        sign = -1 if "-" in (m.group(1) + m.group(3)) else 1
        return sign * int(m.group(4).replace("_", ""), int(m.group(2)))
    if _LIT_INT.match(t):
        return int(t.replace("_", ""))
    if _LIT_REAL.match(t):
        return float(t.replace("_", ""))
    return None


def literal_type(text: str) -> str | None:
    v = literal(text)
    if v is None:
        return None
    if isinstance(v, float):
        return "REAL"
    return "DINT" if -(1 << 31) <= v < (1 << 31) else "LINT"


def value_type(v) -> str:
    """Logix type of a Python value produced by an expression."""
    if isinstance(v, bool):
        return "BOOL"
    if isinstance(v, float):
        return "REAL"
    if isinstance(v, int):
        return "DINT" if -(1 << 31) <= v < (1 << 31) else "LINT"
    if isinstance(v, str):
        return "STRING"
    return "?"


def math_type(*types: str) -> str:
    """Type an instruction computes in: REAL if any operand is REAL, LINT if any
    is LINT, otherwise DINT (SINT/INT/BOOL are promoted)."""
    if "LREAL" in types:
        return "LREAL"
    if "REAL" in types:
        return "REAL"
    if "LINT" in types or "ULINT" in types or "UDINT" in types:
        return "LINT"                 # a UDINT does not fit a DINT computation
    return "DINT"


def num(v) -> int | float:
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, (int, float)):
        return v
    raise TypeError(f"not a number: {v!r}")


def as_type(v, t: str) -> int | float:
    """Promote an operand value to the computation type."""
    v = num(v)
    if t == "LREAL":
        return float(v)
    if t == "REAL":
        return f32(v)
    if isinstance(v, float):
        out, _ = to_int(v, INT_BITS[t])
        return out
    return v


def to_int(x: float, bits: int) -> tuple[int, bool]:
    if math.isnan(x) or math.isinf(x):
        return 0, True
    return wrap(round_half_even(x), bits)


def store_convert(value, vtype: str, dtype: str):
    """Convert ``value`` (Logix type ``vtype``) for a ``dtype`` destination.
    Returns (converted value, overflow)."""
    if dtype == "BOOL":
        return bool(value), False
    if dtype == "REAL":
        x = f32(num(value))
        return x, (math.isinf(x) and not (isinstance(value, float) and math.isinf(value)))
    if dtype == "LREAL":
        return float(num(value)), False
    if dtype in UINT_BITS:
        bits = UINT_BITS[dtype]
        v = num(value)
        if isinstance(v, float):
            if math.isnan(v) or math.isinf(v):
                return 0, True
            v = round_half_even(v)
        v = int(v)
        return v & ((1 << bits) - 1), not (0 <= v < (1 << bits))
    if dtype in INT_BITS:
        bits = INT_BITS[dtype]
        v = num(value)
        if isinstance(v, float):
            return to_int(v, bits)
        return wrap(int(v), bits)
    from ..model import STRING_TYPES, string_max
    if dtype in STRING_TYPES:
        text = str(value)
        return text[:string_max(dtype)], len(text) > string_max(dtype)
    return value, False


def arith_result(v, t: str) -> tuple[int | float, bool]:
    """Normalise a computed result to its computation type; report overflow."""
    if t == "LREAL":
        return float(v), False
    if t == "REAL":
        x = f32(v)
        return x, math.isinf(x) and not (isinstance(v, float) and math.isinf(v))
    return wrap(int(v), INT_BITS[t])


_NICE: dict[float, float] = {}


def nice_real(x: float) -> float:
    """The shortest decimal that is the same REAL (e.g. 1.2000000476837158 -> 1.2),
    for display and JSON. Writing it back gives the identical REAL."""
    if not isinstance(x, float) or x != x or x in (math.inf, -math.inf):
        return x
    hit = _NICE.get(x)
    if hit is not None:
        return hit
    out = x
    for digits in range(1, 10):
        cand = float(f"{x:.{digits}g}")
        if f32(cand) == x:
            out = cand
            break
    if len(_NICE) < 200_000:
        _NICE[x] = out
    return out
