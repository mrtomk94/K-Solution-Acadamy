"""Program control instructions (RM: Program Control p.669-704, For/Break p.705-709)
and simulation-boundary I/O instructions.

Routine-level flow (JMP targets, MCR zones, RET/TND ending a routine, FOR
loops) is carried out by the engine's routine runner; the instructions here
only record what was requested in the execution context.
"""
from __future__ import annotations

from .core import InstructionError
from .spec import BOUNDARY, NUM, Operand, instruction


@instruction("AFI", "Always False", "Program Control", "condition", [], page=670,
             languages=("LD",), notes=("Rung-condition-out is always false (used to disable a "
                                       "rung for testing).",))
def afi(ctx, args):
    return False


@instruction("NOP", "No Operation", "Program Control", "action", [], page=688,
             languages=("LD",), notes=("No effect; rung-condition-out = rung-condition-in.",))
def nop(ctx, args, rung=True):
    return bool(rung)


@instruction("LBL", "Label", "Program Control", "condition", [Operand("Label Name", "label")],
             page=673, languages=("LD",),
             notes=("Target of a JMP. Must be the first instruction on its rung; otherwise it "
                    "passes rung-condition-in through.",))
def lbl(ctx, args):
    return True


@instruction("JMP", "Jump to Label", "Program Control", "action",
             [Operand("Label Name", "label")], page=673, languages=("LD",),
             notes=("Rung true: execution continues at the rung whose first instruction is "
                    "LBL(name) in the same routine (forward or backward); the rest of the JMP "
                    "rung still executes. Rungs skipped are not scanned (their outputs keep "
                    "their state).",
                    "Backward jumps that never end trip the task watchdog (major fault Type 6 "
                    "Code 1)."))
def jmp(ctx, args, rung=True):
    if rung:
        ctx.jump = args[0].strip()
    return bool(rung)


@instruction("JSR", "Jump to Subroutine", "Program Control", "action",
             [Operand("Routine Name", "routine"), Operand("Input Count", "imm", optional=True),
              Operand("Parameter", "src", optional=True, repeat=True)], page=675,
             languages=("LD", "ST"),
             display={"rows": [["Routine Name", 0], ["Input Par", "*in"], ["Return Par", "*ret"]]},
             notes=("JSR(Routine, InputCount, Input..., Return...). Rung true: input values are "
                    "captured, the routine runs, then values from its RET are written to the "
                    "return parameters (converted to their types).",
                    "Up to 25 nested subroutine calls; one more is major fault Type 4 Code 94, "
                    "nesting limits exceeded (confirmed: Logix Designer help, Jump to Subroutine "
                    "(JSR), Subroutine (SBR), and Return (RET); Major fault types and codes)."))
def jsr(ctx, args, rung=True):
    if rung and args:
        if ctx.engine is None:
            raise InstructionError("JSR needs the engine")
        n_in = int(ctx.read(args[1])) if len(args) > 1 and args[1].strip() not in ("", "?") else 0
        params = args[2:]
        if n_in > len(params):
            raise InstructionError(f"JSR input count {n_in} but only {len(params)} parameters")
        inputs = [ctx.value(p) for p in params[:n_in]]
        ctx.engine.call_routine(ctx, args[0].strip(), inputs, params[n_in:])
    return bool(rung)


@instruction("SBR", "Subroutine", "Program Control", "action",
             [Operand("Input Par", "dest", optional=True, repeat=True)], page=675,
             languages=("LD", "ST"), display={"input": True},
             notes=("First instruction of a subroutine called with parameters: copies the JSR "
                    "input values into its parameters (converted to their types).",
                    "When the routine is not called by a JSR with inputs, SBR does nothing."))
def sbr(ctx, args, rung=True):
    fr = ctx.frame
    if fr.inputs and not fr.sbr_done:
        if len(args) < len(fr.inputs):
            raise InstructionError(f"SBR has {len(args)} parameters, JSR passed {len(fr.inputs)}")
        for target, (v, t) in zip(args, fr.inputs):
            ctx.store(target, v, t, flags=False)
        fr.sbr_done = True
    return bool(rung)


@instruction("RET", "Return", "Program Control", "action",
             [Operand("Return Par", "src", optional=True, repeat=True)], page=675,
             languages=("LD", "ST"),
             notes=("Rung true: ends the routine and hands its parameter values back to the "
                    "JSR return parameters.",))
def ret(ctx, args, rung=True):
    if rung:
        ctx.frame.returns = [ctx.value(a) for a in args if a.strip() not in ("", "?")]
        ctx.frame.stop = "RET"
    return bool(rung)


@instruction("TND", "Temporary End", "Program Control", "action", [], page=694,
             languages=("LD", "ST"),
             notes=("Rung true: the rest of the current routine is not executed this scan "
                    "(execution returns to the caller); in the main routine the program ends "
                    "for this scan (confirmed: Logix Designer help, Temporary End (TND))."))
def tnd(ctx, args, rung=True):
    if rung:
        ctx.frame.stop = "TND"
    return bool(rung)


@instruction("MCR", "Master Control Reset", "Program Control", "action", [], page=685,
             languages=("LD",),
             notes=("A conditional MCR starts a zone, the next unconditional MCR ends it. When "
                    "the zone's MCR rung is false, every rung in the zone is executed with "
                    "rung-condition-in false (non-retentive outputs turn off; OTL/OTU and "
                    "retentive data keep their state).",))
def mcr(ctx, args, rung=True):
    ctx.mcr_seen = bool(rung)
    return bool(rung)


@instruction("FOR", "For", "For/Break", "action",
             [Operand("Routine Name", "routine"), Operand("Index", "dest", NUM),
              Operand("Initial Value", "src", NUM), Operand("Terminal Value", "src", NUM),
              Operand("Step Size", "src", NUM)], page=706, languages=("LD",),
             display={"rows": [["Routine name", 0], ["Index", 1], ["Initial", 2],
                               ["Terminal", 3], ["Step size", 4]]},
             notes=("Rung true: Index = Initial; while Index <= Terminal (>= for a negative "
                    "step) the routine is called and Index += Step. BRK ends the loop.",
                    "Long loops can trip the task watchdog (major fault Type 6 Code 1)."))
def for_(ctx, args, rung=True):
    if rung:
        ctx.engine.for_loop(ctx, args)
    return bool(rung)


@instruction("BRK", "Break", "For/Break", "action", [], page=705, languages=("LD",),
             notes=("Rung true: ends the current FOR loop (and the routine it called).",))
def brk(ctx, args, rung=True):
    if rung:
        ctx.frame.stop = "BRK"
    return bool(rung)


_INTERRUPTS = ("Rung true: UID stops periodic tasks of higher priority from interrupting "
               "this task until UIE (nested: each UID needs a UIE). The disable ends when "
               "the task finishes. Interrupts happen between rungs in Real time timing.",)


@instruction("UID", "User Interrupt Disable", "Program Control", "action", [], page=700,
             languages=("LD", "ST"), notes=_INTERRUPTS)
def uid(ctx, args, rung=True):
    if rung and ctx.engine is not None and not ctx.prescan:
        ctx.engine.uid_depth += 1
    return bool(rung)


@instruction("UIE", "User Interrupt Enable", "Program Control", "action", [], page=700,
             languages=("LD", "ST"), notes=_INTERRUPTS)
def uie(ctx, args, rung=True):
    if rung and ctx.engine is not None and not ctx.prescan and ctx.engine.uid_depth > 0:
        ctx.engine.uid_depth -= 1
    return bool(rung)


@instruction("IOT", "Immediate Output", "Input/Output", "action",
             [Operand("Update Tag", "tag")], page=209, languages=("LD", "ST"),
             status="boundary", evidence=BOUNDARY,
             notes=("SIMULATION BOUNDARY: VirtualControlStudio has no buffered I/O update; output tags are "
                    "visible to connectors as soon as logic writes them, so IOT has no further "
                    "effect.",))
def iot(ctx, args, rung=True):
    return bool(rung)


# ---- GSV / SSV: controller status objects (see isa/system.py) --------------------------
_SYS_NOTES = ("Simulated objects: WallClockTime, CST, FaultLog, Program, Task, Module, "
              "ControllerDevice, Controller (the attributes listed in isa/system.py). Values "
              "come from the simulator: the PC clock, its own fault log and scan times; every "
              "configured module reports Running.",
              "Values are copied as bytes into Dest starting at the operand (an array element "
              "or a structure member fills the following elements/members).",
              "A class or attribute that is not simulated raises minor fault Type 4 Code 6 "
              "and leaves Dest unchanged; an unknown instance raises Type 4 Code 5.")


@instruction("GSV", "Get System Value", "Input/Output", "action",
             [Operand("Class Name", "imm"), Operand("Instance Name", "imm"),
              Operand("Attribute Name", "imm"), Operand("Dest", "dest")],
             page=182, languages=("LD", "ST"),
             display={"rows": [["Class Name", 0], ["Instance Name", 1], ["Attribute Name", 2],
                               ["Dest", 3]]},
             notes=_SYS_NOTES + ("MODULE ForceStatus: bit 0 forces installed, bit 1 forces "
                                 "enabled (1756-PM004, Check Force Status).",))
def gsv(ctx, args, rung=True):
    if rung:
        from .system import gsv as _gsv
        _gsv(ctx, args[0], args[1], args[2], args[3])
    return bool(rung)


@instruction("SSV", "Set System Value", "Input/Output", "action",
             [Operand("Class Name", "imm"), Operand("Instance Name", "imm"),
              Operand("Attribute Name", "imm"), Operand("Source", "src")],
             page=182, languages=("LD", "ST"),
             display={"rows": [["Class Name", 0], ["Instance Name", 1], ["Attribute Name", 2],
                               ["Source", 3]]},
             notes=_SYS_NOTES + ("Settable here: WallClockTime (DateTime, LocalDateTime, "
                                 "CurrentValue, ApplyDST, DSTAdjustment), FaultLog counters and "
                                 "bits, Program fault records and DisableFlag, Task inhibit / "
                                 "rate / watchdog / overlap count, Module Mode, Controller time "
                                 "slice.",))
def ssv(ctx, args, rung=True):
    if rung:
        from .system import ssv as _ssv
        _ssv(ctx, args[0], args[1], args[2], args[3])
    return bool(rung)


# ---- MSG: a simulation boundary ------------------------------------------------------------
@instruction("MSG", "Message", "Input/Output", "action",
             [Operand("Message Control", "tag", ("MESSAGE",))], page=141, languages=("LD", "ST"),
             status="boundary", evidence=BOUNDARY,
             display={"rows": [["Message Control", 0]], "bits": ["EN", "DN", "ER"], "bits_op": 0},
             notes=("SIMULATION BOUNDARY: VirtualControlStudio has no network path behind a MSG. "
                    "On a false-to-true rung the message starts (EN and EW set) and then waits; it "
                    "never completes (DN) or fails (ER) by itself, as with a device that does not "
                    "answer. Logic and the HMI can set DN/ER on the MESSAGE tag to test the "
                    "program's reaction.",
                    "EN follows the rung while the message is not done (a false rung clears EN "
                    "once DN or ER is set)."))
def msg(ctx, args, rung=True):
    m = ctx.resolve(args[0])
    ctx.guard(m, args[0])
    get = lambda k: bool(ctx.db.get(f"{m}.{k}"))                  # noqa: E731
    key = ("msg", m)
    was = ctx.scan_state.get(key, False)
    if rung and not was and not get("EN"):
        ctx.db.set(f"{m}.EN", True)
        ctx.db.set(f"{m}.EW", True)
        ctx.db.set(f"{m}.DN", False)
        ctx.db.set(f"{m}.ER", False)
    elif not rung and (get("DN") or get("ER")):
        ctx.db.set(f"{m}.EN", False)
    ctx.scan_state[key] = bool(rung)
    return bool(rung)
