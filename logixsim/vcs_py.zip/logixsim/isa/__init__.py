"""VirtualControlStudio instruction set: one module per instruction family.

Importing this package registers every implemented instruction in
:data:`logixsim.isa.spec.SPECS` (metadata) and :data:`logixsim.isa.core.REGISTRY`
(callables).
"""
from . import bits, compare, compute, files, move, program, shift, strings, timers  # noqa: F401
from .catalog import catalog, lookup  # noqa: F401
from .core import (REGISTRY, ExecContext, InstructionError, MajorFault,  # noqa: F401
                   UnsupportedInstruction, op)
from .spec import SPECS, Spec, get  # noqa: F401
