"""GSV / SSV: the controller's status objects (Get / Set System Value).

The attributes and their data types follow the Logix Designer help topics
"Access the ... object" (WallClockTime, CST, FaultLog, Program, Task, Module,
ControllerDevice, Controller) and 1756-PM004/PM015. Values are produced from
the simulator's own state:

* WallClockTime: the PC clock (UTC) plus an offset that SSV can change; local
  time uses the PC's time zone. ApplyDST / DSTAdjustment are stored and returned.
* CST: the simulated controller clock in microseconds.
* FaultLog: counters and fault bits kept by the engine (SSV can reset them).
* Program: scan times, the major / minor fault records (DINT[11]: TimeLow,
  TimeHigh, Type INT, Code INT, Info DINT[8]), DisableFlag.
* Task: scan times, rate, priority, watchdog, inhibit, overlap count.
* Module: every configured module reports Running (EntryStatus 16#4000, no fault)
  -- the simulator has no real connections; LEDStatus 3 (all running) or 0 (none).
* ControllerDevice: the catalog number from the project (DeviceName), vendor 1,
  type 14, product code 53 (emulator), revision from the project.

A class or attribute that is not simulated (or not settable) raises minor fault
Type 4 Code 6 like an unknown attribute, and Dest is left unchanged.

Values are copied as bytes into the destination starting at the operand, in
memory order -- as the controller does, so ``Wrk_Now.Yr`` fills Yr, Mo, Da, ...
and ``Arr[0]`` fills the following elements.
"""
from __future__ import annotations

import struct
import time

from ..model import STRING_TYPES
from .core import InstructionError

_FMT = {"SINT": "<b", "INT": "<h", "DINT": "<i", "LINT": "<q", "REAL": "<f"}
_SIZE = {"SINT": 1, "INT": 2, "DINT": 4, "LINT": 8, "REAL": 4, "BOOL": 1}


# ---- bytes <-> tag memory --------------------------------------------------------
def _leaves(ctx, operand: str):
    """(address, data type) of the atomic leaves of the operand's tag, in memory
    order, starting at the operand."""
    addr = ctx.db.canonical(ctx.resolve(operand))
    root, _ = ctx.db.declaration_of(addr)
    if root is None:
        raise InstructionError(f"'{operand}' is not a tag")
    out = []

    def walk(prefix, v):
        if isinstance(v, dict):
            for k, x in v.items():
                walk(f"{prefix}.{k}", x)
        elif isinstance(v, list):
            for i, x in enumerate(v):
                walk(ctx.db.elem_address(prefix, i) if prefix == root else f"{prefix}[{i}]", x)
        else:
            out.append(prefix)

    walk(root, ctx.db.get(root))
    start = next((i for i, a in enumerate(out) if a == addr or a.startswith(addr + ".")
                  or a.startswith(addr + "[")), None)
    if start is None:
        raise InstructionError(f"'{operand}': cannot place a value there")
    return [(a, ctx.db.data_type(a)) for a in out[start:]]


def write_bytes(ctx, operand: str, data: bytes) -> None:
    """Copy ``data`` into the tag memory that starts at ``operand``."""
    ctx.guard(ctx.resolve(operand), operand)
    pos = 0
    for addr, dt in _leaves(ctx, operand):
        if pos >= len(data):
            break
        if dt in STRING_TYPES or dt not in _SIZE:
            break
        size = _SIZE[dt]
        pos = (pos + size - 1) // size * size if size > 1 else pos     # natural alignment
        chunk = data[pos:pos + size].ljust(size, b"\x00")
        if dt == "BOOL":
            ctx.db.set(addr, bool(chunk[0]))
        else:
            ctx.db.set(addr, struct.unpack(_FMT[dt], chunk)[0])
        pos += size


def read_bytes(ctx, operand: str, length: int) -> bytes:
    """The ``length`` bytes of tag memory that start at ``operand``."""
    out = b""
    for addr, dt in _leaves(ctx, operand):
        if len(out) >= length or dt not in _SIZE:
            break
        size = _SIZE[dt]
        if size > 1:
            out = out.ljust((len(out) + size - 1) // size * size, b"\x00")
        v = ctx.db.get(addr)
        out += bytes([1 if v else 0]) if dt == "BOOL" else struct.pack(_FMT[dt], v)
    return out[:length].ljust(length, b"\x00")


def _pack(fmt: str, *values) -> bytes:
    return struct.pack("<" + fmt, *values)


def _unpack(fmt: str, data: bytes):
    return struct.unpack("<" + fmt, data[:struct.calcsize("<" + fmt)])


# ---- object state ---------------------------------------------------------------------
def _sys(ctx) -> dict:
    eng = ctx.engine
    return eng.system if eng is not None else {}


def _now_us(ctx) -> int:
    return int((time.time() + _sys(ctx).get("clock_offset_s", 0.0)) * 1_000_000)


def _datetime(us: int, local: bool) -> list[int]:
    secs, micro = divmod(us, 1_000_000)
    t = time.localtime(secs) if local else time.gmtime(secs)
    return [t.tm_year, t.tm_mon, t.tm_mday, t.tm_hour, t.tm_min, t.tm_sec, micro]


def _set_datetime(ctx, values, local: bool) -> None:
    y, mo, d, h, mi, s, us = (list(values) + [0] * 7)[:7]
    try:
        tt = (y, mo, d, h, mi, s, 0, 0, -1)
        target = (time.mktime(tt) if local else _timegm(tt)) + us / 1e6
    except (OverflowError, ValueError):
        raise InstructionError("SSV WallClockTime: not a valid date and time")
    _sys(ctx)["clock_offset_s"] = target - time.time()


def _timegm(tt) -> float:
    import calendar
    return float(calendar.timegm(tt))


def _program(ctx, instance: str):
    eng = ctx.engine
    if instance.upper() in ("", "THIS"):
        return ctx.program.name if ctx.program is not None else None
    for name in eng.controller.programs:
        if name.upper() == instance.upper():
            return name
    return None


def _task(ctx, instance: str):
    eng = ctx.engine
    tasks = eng.controller.tasks
    if instance.upper() in ("", "THIS"):
        prog = ctx.program.name if ctx.program is not None else None
        return next((t for t in tasks if prog in t.get("programs", [])), None)
    return next((t for t in tasks if t["name"].upper() == instance.upper()), None)


def _record(ctx, prog: str, which: str) -> bytes:
    rec = ctx.engine.system.get(("record", prog, which))
    if rec is not None:
        return rec
    hit = ctx.engine.fault_records.get(prog, {}).get(which)
    if hit is None:
        return b"\x00" * 44
    ftype, code, when = hit
    us = int(when * 1_000_000)
    return _pack("IIhh", us & 0xFFFFFFFF, (us >> 32) & 0xFFFFFFFF, ftype, code) + b"\x00" * 32


def _status_word(ctx) -> int:
    eng = ctx.engine
    mode = {"RUN": 0b0110, "PROGRAM": 0b0111, "FAULTED": 0b0101}.get(eng.mode, 0b0111)
    fault = 0b0100 if eng.major_fault else (0b0001 if eng.minor_faults else 0)
    return (mode << 4) | (fault << 8) | (0b11 << 12)          # keyswitch in remote


# GET: (class, attribute) -> function(ctx, instance) -> bytes
def _get_table():
    def wct_cur(ctx, inst):
        return _pack("q", _now_us(ctx))          # DINT[0] low 32 bits, DINT[1] high

    def dint_list(vals):
        return b"".join(_pack("i", int(x)) for x in vals)

    eng_tasks = lambda ctx, inst: _task(ctx, inst)                              # noqa: E731

    def task_attr(field, default=0, scale=1.0):
        def f(ctx, inst):
            t = eng_tasks(ctx, inst)
            if t is None:
                raise LookupError("task")
            st = ctx.engine.task_stats.get(t["name"], {})
            over = ctx.engine.system.get(("task", t["name"]), {})
            if field in over:
                return _pack("i", int(over[field]))
            v = {"last": st.get("last_ms", 0) * 1000, "max": st.get("max_ms", 0) * 1000,
                 "rate": (t.get("rate_ms") or 0) * 1000, "prio": t.get("priority") or 10,
                 "wd": (t.get("watchdog_ms") or 500) * 1000, "inh": 1 if t.get("inhibited") else 0,
                 "over": st.get("overlaps", 0), "status": 0}.get(field, default)
            return _pack("i", int(v))
        return f

    def prog_scan(field):
        def f(ctx, inst):
            p = _program(ctx, inst)
            if p is None:
                raise LookupError("program")
            over = ctx.engine.system.get(("program", p), {})
            if field in over:
                return _pack("i", int(over[field]))
            st = ctx.engine.system.get(("pscan", p), {})
            return _pack("i", int(st.get(field, 0)))
        return f

    def module_known(ctx, inst):
        names = getattr(ctx.engine.controller, "module_names", []) or []
        if inst and not any(n.upper() == inst.upper() for n in names):
            raise LookupError("module")

    def entry(ctx, inst):
        module_known(ctx, inst)
        mode = ctx.engine.system.get(("module", inst.upper()), {}).get("mode", 0)
        return _pack("h", 0x6000 if mode & 4 else 0x4000)

    def device_name(ctx, inst):
        name = (ctx.engine.controller.processor or "VirtualControlStudio")[:32].encode("latin-1", "replace")
        return bytes([len(name)]) + name.ljust(32, b"\x00")

    def rev(ctx, inst):
        try:
            major, minor = (ctx.engine.controller.revision or "0.0").split(".")[:2]
            return _pack("h", (int(minor) << 8) | (int(major) & 0xFF))
        except ValueError:
            return _pack("h", 0)

    fl = lambda key, fmt: (lambda ctx, inst: _pack(fmt, ctx.engine.fault_log[key]))  # noqa: E731
    return {
        ("WALLCLOCKTIME", "CURRENTVALUE"): wct_cur,
        ("WALLCLOCKTIME", "DATETIME"): lambda ctx, inst: dint_list(_datetime(_now_us(ctx), False)),
        ("WALLCLOCKTIME", "LOCALDATETIME"): lambda ctx, inst: dint_list(_datetime(_now_us(ctx), True)),
        ("WALLCLOCKTIME", "CSTOFFSET"): lambda ctx, inst: _pack("q", _now_us(ctx) - int(ctx.engine.sim_time * 1e6)),
        ("WALLCLOCKTIME", "APPLYDST"): lambda ctx, inst: _pack("b", _sys(ctx).get("apply_dst", 0)),
        ("WALLCLOCKTIME", "DSTADJUSTMENT"): lambda ctx, inst: _pack("h", _sys(ctx).get("dst_adjust", 0)),
        ("CST", "CURRENTVALUE"): lambda ctx, inst: _pack("q", int(ctx.engine.sim_time * 1e6)),
        ("CST", "CURRENTSTATUS"): lambda ctx, inst: _pack("h", 0),
        ("FAULTLOG", "MAJOREVENTS"): fl("major_events", "h"),
        ("FAULTLOG", "MINOREVENTS"): fl("minor_events", "h"),
        ("FAULTLOG", "MAJORFAULTBITS"): fl("major_bits", "i"),
        ("FAULTLOG", "MINORFAULTBITS"): fl("minor_bits", "i"),
        ("PROGRAM", "MAJORFAULTRECORD"): lambda ctx, inst: _record(ctx, _need(_program(ctx, inst)), "major"),
        ("PROGRAM", "MINORFAULTRECORD"): lambda ctx, inst: _record(ctx, _need(_program(ctx, inst)), "minor"),
        ("PROGRAM", "DISABLEFLAG"): lambda ctx, inst: _pack("b", 1 if ctx.engine.controller.programs[_need(_program(ctx, inst))].disabled else 0),
        ("PROGRAM", "LASTSCANTIME"): prog_scan("last"),
        ("PROGRAM", "MAXSCANTIME"): prog_scan("max"),
        ("PROGRAM", "INSTANCE"): lambda ctx, inst: _pack("i", list(ctx.engine.controller.programs).index(_need(_program(ctx, inst))) + 1),
        ("TASK", "LASTSCANTIME"): task_attr("last"),
        ("TASK", "MAXIMUMSCANTIME"): task_attr("max"),
        ("TASK", "MAXSCANTIME"): task_attr("max"),
        ("TASK", "RATE"): task_attr("rate"),
        ("TASK", "PRIORITY"): lambda ctx, inst: task_attr("prio")(ctx, inst)[:2],
        ("TASK", "WATCHDOG"): task_attr("wd"),
        ("TASK", "INHIBITTASK"): task_attr("inh"),
        ("TASK", "OVERLAPCOUNT"): task_attr("over"),
        ("TASK", "STATUS"): task_attr("status"),
        ("MODULE", "ENTRYSTATUS"): entry,
        ("MODULE", "FAULTCODE"): lambda ctx, inst: (module_known(ctx, inst), _pack("h", 0))[1],
        ("MODULE", "FAULTINFO"): lambda ctx, inst: (module_known(ctx, inst), _pack("i", 0))[1],
        ("MODULE", "LEDSTATUS"): lambda ctx, inst: _pack("h", 3 if getattr(ctx.engine.controller, "module_names", None) else 0),
        ("MODULE", "FORCESTATUS"): lambda ctx, inst: _pack("h", ctx.engine.store.force_status()),
        ("MODULE", "MODE"): lambda ctx, inst: (module_known(ctx, inst), _pack("h", ctx.engine.system.get(("module", inst.upper()), {}).get("mode", 0)))[1],
        ("MODULE", "INSTANCE"): lambda ctx, inst: (module_known(ctx, inst), _pack("i", 1 + [n.upper() for n in ctx.engine.controller.module_names].index(inst.upper())))[1],
        ("CONTROLLERDEVICE", "DEVICENAME"): device_name,
        ("CONTROLLERDEVICE", "VENDOR"): lambda ctx, inst: _pack("h", 1),
        ("CONTROLLERDEVICE", "TYPE"): lambda ctx, inst: _pack("h", 14),
        ("CONTROLLERDEVICE", "PRODUCTCODE"): lambda ctx, inst: _pack("h", 53),
        ("CONTROLLERDEVICE", "PRODUCTREV"): rev,
        ("CONTROLLERDEVICE", "SERIALNUMBER"): lambda ctx, inst: _pack("i", 0x00C0FFEE),
        ("CONTROLLERDEVICE", "STATUS"): lambda ctx, inst: _pack("h", _status_word(ctx)),
        ("CONTROLLER", "TIMESLICE"): lambda ctx, inst: _pack("h", _sys(ctx).get("timeslice", 20)),
        ("CONTROLLER", "SHAREUNUSEDTIMESLICE"): lambda ctx, inst: _pack("h", _sys(ctx).get("share", 1)),
    }


def _need(v):
    if v is None:
        raise LookupError("instance")
    return v


# SET: (class, attribute) -> (number of bytes, function(ctx, instance, data))
def _set_table():
    def store(key, fmt):
        def f(ctx, inst, data):
            _sys(ctx)[key] = _unpack(fmt, data)[0]
        return f

    def flog(key, fmt):
        def f(ctx, inst, data):
            ctx.engine.fault_log[key] = _unpack(fmt, data)[0]
        return f

    def record(which):
        def f(ctx, inst, data):
            p = _need(_program(ctx, inst))
            ctx.engine.system[("record", p, which)] = bytes(data[:44]).ljust(44, b"\x00")
            ftype, code = _unpack("hh", data[8:12])
            if which == "major" and ftype == 0 and code == 0:
                ctx.engine.fault_records.get(p, {}).pop("major", None)
        return f

    def prog_disable(ctx, inst, data):
        ctx.engine.controller.programs[_need(_program(ctx, inst))].disabled = bool(_unpack("b", data)[0])

    def task_set(field):
        def f(ctx, inst, data):
            t = _task(ctx, inst)
            if t is None:
                raise LookupError("task")
            v = _unpack("i", data)[0]
            if field == "inh":
                t["inhibited"] = bool(v)
            elif field == "rate" and v > 0:
                t["rate_ms"] = v / 1000.0
            elif field == "wd" and v > 0:
                t["watchdog_ms"] = v / 1000.0
            else:
                ctx.engine.system.setdefault(("task", t["name"]), {})[field] = v
                if field == "over":
                    ctx.engine.task_stats.get(t["name"], {})["overlaps"] = v
        return f

    def module_mode(ctx, inst, data):
        ctx.engine.system.setdefault(("module", inst.upper()), {})["mode"] = _unpack("h", data)[0]

    return {
        ("WALLCLOCKTIME", "APPLYDST"): (1, store("apply_dst", "b")),
        ("WALLCLOCKTIME", "DSTADJUSTMENT"): (2, store("dst_adjust", "h")),
        ("WALLCLOCKTIME", "DATETIME"): (28, lambda ctx, inst, d: _set_datetime(ctx, _unpack("7i", d), False)),
        ("WALLCLOCKTIME", "LOCALDATETIME"): (28, lambda ctx, inst, d: _set_datetime(ctx, _unpack("7i", d), True)),
        ("WALLCLOCKTIME", "CURRENTVALUE"): (8, lambda ctx, inst, d: _sys(ctx).__setitem__(
            "clock_offset_s", _unpack("q", d)[0] / 1e6 - time.time())),
        ("FAULTLOG", "MAJOREVENTS"): (2, flog("major_events", "h")),
        ("FAULTLOG", "MINOREVENTS"): (2, flog("minor_events", "h")),
        ("FAULTLOG", "MAJORFAULTBITS"): (4, flog("major_bits", "i")),
        ("FAULTLOG", "MINORFAULTBITS"): (4, flog("minor_bits", "i")),
        ("PROGRAM", "MAJORFAULTRECORD"): (44, record("major")),
        ("PROGRAM", "MINORFAULTRECORD"): (44, record("minor")),
        ("PROGRAM", "DISABLEFLAG"): (1, prog_disable),
        ("TASK", "INHIBITTASK"): (4, task_set("inh")),
        ("TASK", "RATE"): (4, task_set("rate")),
        ("TASK", "WATCHDOG"): (4, task_set("wd")),
        ("TASK", "OVERLAPCOUNT"): (4, task_set("over")),
        ("TASK", "MAXIMUMSCANTIME"): (4, task_set("max")),
        ("TASK", "STATUS"): (4, task_set("status")),
        ("MODULE", "MODE"): (2, module_mode),
        ("CONTROLLER", "TIMESLICE"): (2, store("timeslice", "h")),
        ("CONTROLLER", "SHAREUNUSEDTIMESLICE"): (2, store("share", "h")),
    }


GET = _get_table()
SET = _set_table()


def simulated(cls: str, attr: str, set_: bool = False) -> bool:
    return (cls.upper(), attr.upper()) in (SET if set_ else GET)


def gsv(ctx, cls: str, instance: str, attr: str, dest: str) -> None:
    key = (cls.strip().upper(), attr.strip().upper())
    fn = GET.get(key)
    if fn is None:
        ctx.minor_fault(4, 6, f"GSV {cls}.{attr} is not simulated by VirtualControlStudio")
        return
    try:
        data = fn(ctx, instance.strip().strip("?"))
    except LookupError:
        ctx.minor_fault(4, 5, f"GSV {cls}: instance '{instance}' not found")
        return
    write_bytes(ctx, dest, data)


def ssv(ctx, cls: str, instance: str, attr: str, source: str) -> None:
    key = (cls.strip().upper(), attr.strip().upper())
    hit = SET.get(key)
    if hit is None:
        ctx.minor_fault(4, 6, f"SSV {cls}.{attr} cannot be set (or is not simulated)")
        return
    size, fn = hit
    try:
        fn(ctx, instance.strip().strip("?"), read_bytes(ctx, source, size))
    except LookupError:
        ctx.minor_fault(4, 5, f"SSV {cls}: instance '{instance}' not found")
