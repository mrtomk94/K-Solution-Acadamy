"""Bit instructions: XIC XIO OTE OTL OTU ONS OSR OSF (RM: Bit Instructions, p.72-91)."""
from __future__ import annotations

from .spec import DOC, Operand, instruction, prescan

_B = ("BOOL",)


@instruction("XIC", "Examine If Closed", "Bit", "condition",
             [Operand("Data Bit", "tag", _B)], page=88, evidence=DOC, languages=("LD",),
             notes=("Rung-condition-out is true when the bit is 1.",))
def xic(ctx, args):
    return bool(ctx.read(args[0]))


@instruction("XIO", "Examine If Open", "Bit", "condition",
             [Operand("Data Bit", "tag", _B)], page=90, evidence=DOC, languages=("LD",),
             notes=("Rung-condition-out is true when the bit is 0.",))
def xio(ctx, args):
    return not bool(ctx.read(args[0]))


@instruction("OTE", "Output Energize", "Bit", "action",
             [Operand("Data Bit", "tag", _B)], page=84, evidence=DOC, languages=("LD",),
             notes=("Writes rung-condition-in to the bit every scan (1 when true, 0 when false).",
                    "Prescan: the bit is cleared."))
def ote(ctx, args, rung=True):
    ctx.write(args[0], bool(rung))
    return bool(rung)


@prescan("OTE")
def _ote_pre(ctx, args):
    ctx.write(args[0], False)


@instruction("OTL", "Output Latch", "Bit", "action",
             [Operand("Data Bit", "tag", _B)], page=85, languages=("LD",),
             notes=("Sets the bit when rung-condition-in is true; otherwise the bit is not changed "
                    "(retentive).", "Prescan: no action."))
def otl(ctx, args, rung=True):
    if rung:
        ctx.write(args[0], True)
    return bool(rung)


@instruction("OTU", "Output Unlatch", "Bit", "action",
             [Operand("Data Bit", "tag", _B)], page=86, languages=("LD",),
             notes=("Clears the bit when rung-condition-in is true; otherwise no change.",
                    "Prescan: no action."))
def otu(ctx, args, rung=True):
    if rung:
        ctx.write(args[0], False)
    return bool(rung)


@instruction("ONS", "One Shot", "Bit", "action",
             [Operand("Storage Bit", "tag", _B)], page=72, languages=("LD",),
             display={"input": True},
             notes=("Rung-in true and storage bit 0: storage bit set, rung-out true for this scan.",
                    "Rung-in true and storage bit 1: rung-out false.",
                    "Rung-in false: storage bit cleared, rung-out false.",
                    "The storage bit is an ordinary tag: give each ONS its own bit.",
                    "Prescan: storage bit set so the ONS cannot fire on the first scan."))
def ons(ctx, args, rung=True):
    stored = bool(ctx.read(args[0]))
    if rung:
        if not stored:
            ctx.write(args[0], True)
            return True
        return False
    if stored:
        ctx.write(args[0], False)
    return False


@prescan("ONS")
def _ons_pre(ctx, args):
    ctx.write(args[0], True)


@instruction("OSR", "One Shot Rising", "Bit", "action",
             [Operand("Storage Bit", "tag", _B), Operand("Output Bit", "tag", _B)],
             page=79, languages=("LD",),
             notes=("Output instruction: rung-condition-out = rung-condition-in.",
                    "Rising edge (rung-in true, storage 0): output bit set for one scan, storage set.",
                    "Rung-in false: storage and output bit cleared.",
                    "Prescan: storage bit set, output bit cleared."))
def osr(ctx, args, rung=True):
    stored = bool(ctx.read(args[0]))
    if rung:
        ctx.write(args[1], not stored)
        if not stored:
            ctx.write(args[0], True)
    else:
        ctx.write(args[0], False)
        ctx.write(args[1], False)
    return bool(rung)


@prescan("OSR")
def _osr_pre(ctx, args):
    ctx.write(args[0], True)
    ctx.write(args[1], False)


@instruction("OSF", "One Shot Falling", "Bit", "action",
             [Operand("Storage Bit", "tag", _B), Operand("Output Bit", "tag", _B)],
             page=74, languages=("LD",),
             notes=("Output instruction: rung-condition-out = rung-condition-in.",
                    "Falling edge (rung-in false, storage 1): output bit set for one scan, "
                    "storage cleared.", "Rung-in true: storage set, output cleared.",
                    "Prescan: storage bit cleared, output bit cleared."))
def osf(ctx, args, rung=True):
    stored = bool(ctx.read(args[0]))
    if rung:
        ctx.write(args[0], True)
        ctx.write(args[1], False)
    else:
        ctx.write(args[1], stored)
        if stored:
            ctx.write(args[0], False)
    return bool(rung)


@prescan("OSF")
def _osf_pre(ctx, args):
    ctx.write(args[0], False)
    ctx.write(args[1], False)
