"""Timer and counter instructions (RM: Timer and Counter Instructions, p.92-140).

Timing model: every timer instance keeps its own last-execution timestamp of
the *controller clock* (``ctx.now``, seconds) in the engine's per-instance state,
keyed by the timer's tag address. ACC advances by the elapsed whole
milliseconds between two executions of the instruction (the sub-millisecond
remainder is carried), so results are deterministic with ``Engine.step(dt=...)``
and independent of the PC's speed. The first enabled execution only captures
the timestamp (ACC unchanged).
"""
from __future__ import annotations

from .core import InstructionError, MajorFault
from .spec import Operand, instruction, prescan

_T = ("TIMER",)
_C = ("COUNTER",)
_FT = ("FBD_TIMER",)
_FC = ("FBD_COUNTER",)


def _elapsed(ctx, t: str) -> int:
    """Whole ms since the previous execution of this timer instance. Time is
    handled in integer microseconds so repeated steps are exact."""
    key = ("tmr", t)
    now_us = round(ctx.now * 1_000_000)
    last = ctx.scan_state.get(key)
    if last is None:
        ctx.scan_state[key] = (now_us, 0)
        return 0
    t0, frac = last
    us = max(0, now_us - t0) + frac
    ctx.scan_state[key] = (now_us, us % 1000)
    return us // 1000


def _forget(ctx, t: str) -> None:
    ctx.scan_state.pop(("tmr", t), None)


def _get(ctx, t, m):
    return ctx.db.get(f"{t}.{m}")


def _set(ctx, t, **members):
    ctx.guard(t)
    for m, v in members.items():
        ctx.db.set(f"{t}.{m}", v)


def _bad_timer(ctx, t, pre, acc) -> bool:
    """Negative PRE or ACC: major fault Type 4 Code 34 (doc-recall, confirmed by an
    independent review; listed among the major program faults)."""
    if pre < 0 or acc < 0:
        raise MajorFault(4, 34, f"Timer {t} has a negative preset or accumulated value")
    return False


def _paused(ctx, t) -> bool:
    """TON/RTO with the rung true and DN set: timing is paused. The elapsed time is
    consumed (not counted) and only EN/TT are updated."""
    if not _get(ctx, t, "DN"):
        return False
    _elapsed(ctx, t)
    _set(ctx, t, EN=True, TT=False)
    return True


_TIMER_BOX = {"rows": [["Timer", 0], ["Preset", ".PRE"], ["Accum", ".ACC"]],
              "bits": ["EN", "TT", "DN"]}
_COUNTER_BOX = {"rows": [["Counter", 0], ["Preset", ".PRE"], ["Accum", ".ACC"]]}


@instruction("TON", "Timer On Delay", "Timer/Counter", "action",
             [Operand("Timer", "tag", _T), Operand("Preset", "imm", optional=True),
              Operand("Accum", "imm", optional=True)], page=130, languages=("LD",),
             display=_TIMER_BOX,
             notes=("Rung true: EN set; ACC accumulates (1 ms resolution) while ACC < PRE with TT "
                    "set; when ACC >= PRE, DN set, TT cleared and ACC held at PRE.",
                    "Rung false: EN, TT, DN cleared and ACC = 0.",
                    "Preset/Accum operands in the rung text are the tag's PRE/ACC shown on the "
                    "instruction face; VirtualControlStudio uses the tag members.",
                    "Negative PRE or ACC: major fault Type 4 Code 34 (controller faults).",
                    "Prescan: EN, TT, DN cleared, ACC = 0.",
                    "While enabled, DN gates timing: setting DN pauses it (ACC frozen, TT off) and "
                    "clearing DN resumes it, so raising PRE after DN does not restart the timer "
                    "(confirmed: Logix Designer help, Timer On Delay (TON)).",
                    "UNVERIFIED: ACC held exactly at PRE once done. Help text is silent on this."))
def ton(ctx, args, rung=True):
    t = args[0]
    pre, acc = _get(ctx, t, "PRE"), _get(ctx, t, "ACC")
    if _bad_timer(ctx, t, pre, acc):
        return bool(rung)
    if rung:
        if _paused(ctx, t):
            return bool(rung)
        if acc < pre:
            acc = min(acc + _elapsed(ctx, t), pre)
        else:
            _elapsed(ctx, t)
        done = acc >= pre
        _set(ctx, t, ACC=acc, EN=True, DN=done, TT=not done)
    else:
        _forget(ctx, t)
        _set(ctx, t, ACC=0, EN=False, TT=False, DN=False)
    return bool(rung)


@instruction("TOF", "Timer Off Delay", "Timer/Counter", "action",
             [Operand("Timer", "tag", _T), Operand("Preset", "imm", optional=True),
              Operand("Accum", "imm", optional=True)], page=120, languages=("LD",),
             display=_TIMER_BOX,
             notes=("Rung true: EN and DN set, TT cleared, ACC = 0.",
                    "Rung false: EN cleared; while DN is set ACC accumulates with TT set; when "
                    "ACC >= PRE, DN and TT cleared (ACC held at PRE).",
                    "Prescan: EN, TT, DN cleared and ACC = PRE (so the output is off after "
                    "Program->Run).",
                    "Do not use RES on a TOF: it clears ACC and the status bits."))
def tof(ctx, args, rung=True):
    t = args[0]
    pre, acc = _get(ctx, t, "PRE"), _get(ctx, t, "ACC")
    if _bad_timer(ctx, t, pre, acc):
        return bool(rung)
    if rung:
        _forget(ctx, t)
        _set(ctx, t, ACC=0, EN=True, DN=True, TT=False)
    elif _get(ctx, t, "DN"):
        acc = min(acc + _elapsed(ctx, t), pre)
        if acc >= pre:
            _forget(ctx, t)
            _set(ctx, t, ACC=acc, EN=False, DN=False, TT=False)
        else:
            _set(ctx, t, ACC=acc, EN=False, TT=True)
    else:
        _forget(ctx, t)
        _set(ctx, t, EN=False, TT=False)
    return bool(rung)


@instruction("RTO", "Retentive Timer On", "Timer/Counter", "action",
             [Operand("Timer", "tag", _T), Operand("Preset", "imm", optional=True),
              Operand("Accum", "imm", optional=True)], page=110, languages=("LD",),
             display=_TIMER_BOX,
             notes=("Rung true: EN set; ACC accumulates with TT set until ACC >= PRE, then DN set.",
                    "Rung false: EN and TT cleared; ACC and DN are retained. Use RES to clear.",
                    "While enabled, setting DN pauses timing and clearing DN resumes it "
                    "(confirmed: Logix Designer help, Retentive Timer On (RTO)).",
                    "Prescan: EN and TT cleared; DN and ACC retained (confirmed: Logix Designer "
                    "help, Retentive Timer On (RTO))."))
def rto(ctx, args, rung=True):
    t = args[0]
    pre, acc = _get(ctx, t, "PRE"), _get(ctx, t, "ACC")
    if _bad_timer(ctx, t, pre, acc):
        return bool(rung)
    if rung:
        if _paused(ctx, t):
            return bool(rung)
        if acc < pre:
            acc = min(acc + _elapsed(ctx, t), pre)
        else:
            _elapsed(ctx, t)
        done = acc >= pre
        _set(ctx, t, ACC=acc, EN=True, DN=done, TT=not done)
    else:
        _forget(ctx, t)
        _set(ctx, t, EN=False, TT=False)
    return bool(rung)


@prescan("TON")
def _ton_pre(ctx, args):
    t = ctx.resolve(args[0])
    _forget(ctx, t)
    _set(ctx, t, EN=False, TT=False, DN=False, ACC=0)


@prescan("RTO")
def _rto_pre(ctx, args):
    t = ctx.resolve(args[0])
    _forget(ctx, t)
    _set(ctx, t, EN=False, TT=False)


@prescan("TOF")
def _tof_pre(ctx, args):
    t = ctx.resolve(args[0])
    _forget(ctx, t)
    _set(ctx, t, EN=False, TT=False, DN=False, ACC=_get(ctx, t, "PRE"))


_RES_MEMBERS = {
    "TIMER": dict(ACC=0, EN=False, TT=False, DN=False),
    "COUNTER": dict(ACC=0, CU=False, CD=False, DN=False, OV=False, UN=False),
    "CONTROL": dict(POS=0, EN=False, EU=False, DN=False, EM=False, ER=False, UL=False,
                    IN=False, FD=False),
}


@instruction("RES", "Reset", "Timer/Counter", "action",
             [Operand("Structure", "tag", ("TIMER", "COUNTER", "CONTROL"))], page=106,
             languages=("LD",),
             notes=("TIMER: ACC, EN, TT, DN cleared. COUNTER: ACC, CU, CD, DN, OV, UN cleared. "
                    "CONTROL: POS, EN, EU, DN, EM, ER, UL, IN, FD cleared.",
                    "Executes only when rung-condition-in is true."))
def res(ctx, args, rung=True):
    if rung:
        t = args[0]
        kind = ctx.dtype(t)
        members = _RES_MEMBERS.get(kind)
        if members is None:
            raise InstructionError(f"RES needs a TIMER, COUNTER or CONTROL, not {kind}")
        _set(ctx, t, **members)
        _forget(ctx, t)
    return bool(rung)


def _count(ctx, c, step):
    """Count with 32-bit wrap. Wrapping up past the maximum sets OV, unless the
    counter had underflowed (UN set): then it is returning to range and UN is
    cleared instead (and vice versa for CTD). UNVERIFIED. Help text is silent on this."""
    acc = _get(ctx, c, "ACC") + step
    if acc > 0x7FFFFFFF:
        acc -= 1 << 32
        if _get(ctx, c, "UN"):
            _set(ctx, c, ACC=acc, UN=False)
        else:
            _set(ctx, c, ACC=acc, OV=True)
    elif acc < -0x80000000:
        acc += 1 << 32
        if _get(ctx, c, "OV"):
            _set(ctx, c, ACC=acc, OV=False)
        else:
            _set(ctx, c, ACC=acc, UN=True)
    else:
        _set(ctx, c, ACC=acc)


@instruction("CTU", "Count Up", "Timer/Counter", "action",
             [Operand("Counter", "tag", _C), Operand("Preset", "imm", optional=True),
              Operand("Accum", "imm", optional=True)], page=97, languages=("LD",),
             display={**_COUNTER_BOX, "bits": ["CU", "DN"]},
             notes=("Counts on each false->true rung transition: the CU bit is the edge memory "
                    "(ACC += 1 when rung true and CU was 0; CU = rung).",
                    "DN = ACC >= PRE (updated every execution).",
                    "ACC above 2,147,483,647 wraps to -2,147,483,648 and sets OV.",
                    "Prescan: CU set so the counter cannot count on the first scan.",
                    "UNVERIFIED: wrapping back after an underflow clears UN instead of setting "
                    "OV (and the reverse for CTD); otherwise OV/UN are cleared by RES. Help text "
                    "is silent on this."))
def ctu(ctx, args, rung=True):
    c = args[0]
    if rung and not _get(ctx, c, "CU"):
        _count(ctx, c, +1)
    _set(ctx, c, CU=bool(rung), DN=_get(ctx, c, "ACC") >= _get(ctx, c, "PRE"))
    return bool(rung)


@instruction("CTD", "Count Down", "Timer/Counter", "action",
             [Operand("Counter", "tag", _C), Operand("Preset", "imm", optional=True),
              Operand("Accum", "imm", optional=True)], page=92, languages=("LD",),
             display={**_COUNTER_BOX, "bits": ["CD", "DN"]},
             notes=("Counts down on each false->true rung transition (CD bit is the edge memory).",
                    "DN = ACC >= PRE. ACC below -2,147,483,648 wraps and sets UN.",
                    "Prescan: CD set."))
def ctd(ctx, args, rung=True):
    c = args[0]
    if rung and not _get(ctx, c, "CD"):
        _count(ctx, c, -1)
    _set(ctx, c, CD=bool(rung), DN=_get(ctx, c, "ACC") >= _get(ctx, c, "PRE"))
    return bool(rung)


@prescan("CTU")
def _ctu_pre(ctx, args):
    _set(ctx, ctx.resolve(args[0]), CU=True)


@prescan("CTD")
def _ctd_pre(ctx, args):
    _set(ctx, ctx.resolve(args[0]), CD=True)


# ---- function-block style timers/counters (ST / FBD; structure operand) ----------
def _fbd_timer(ctx, t, kind):
    pre, acc = _get(ctx, t, "PRE"), _get(ctx, t, "ACC")
    enable = bool(_get(ctx, t, "TimerEnable"))
    _set(ctx, t, EnableIn=True, EnableOut=True)
    if pre < 0:
        _set(ctx, t, PresetInv=True, InstructFault=True, Status=3)
        _forget(ctx, t)
        return
    _set(ctx, t, PresetInv=False, InstructFault=False, Status=0)
    if acc < 0:
        acc = 0
    if kind == "RTOR" and ("fbd_ran", t) not in ctx.scan_state:
        ctx.scan_state[("fbd_ran", t)] = True       # instruction first run
        _set(ctx, t, EN=False, TT=False, DN=False)
    if _get(ctx, t, "Reset"):
        _forget(ctx, t)
        _set(ctx, t, ACC=pre if kind == "TOFR" else 0, EN=False, TT=False, DN=False)
        return
    if kind in ("TONR", "RTOR"):
        if enable:
            acc = min(acc + _elapsed(ctx, t), pre) if acc < pre else acc
            done = acc >= pre
            _set(ctx, t, ACC=acc, EN=True, DN=done, TT=not done)
        else:
            _forget(ctx, t)
            if kind == "TONR":
                _set(ctx, t, ACC=0, EN=False, TT=False, DN=False)
            else:
                _set(ctx, t, EN=False, TT=False)
    else:                                           # TOFR
        if enable:
            _forget(ctx, t)
            _set(ctx, t, ACC=0, EN=True, DN=True, TT=False)
        elif _get(ctx, t, "DN"):
            acc = min(acc + _elapsed(ctx, t), pre)
            done = acc >= pre
            _set(ctx, t, ACC=acc, EN=False, DN=not done, TT=not done)
            if done:
                _forget(ctx, t)
        else:
            _set(ctx, t, EN=False, TT=False)


_FBD_NOTES = ("Function-block form (ST/FBD): inputs TimerEnable, PRE, Reset are members of the "
              "FBD_TIMER structure; EnableIn is always true in ST.",
              "Reset = 1 clears EN, TT and DN and sets ACC = 0 (TONR, RTOR) or ACC = PRE "
              "(TOFR); TONR/RTOR time again once Reset clears if still enabled, TOFR does not "
              "start timing again by itself (confirmed: Logix Designer help, Timer On Delay "
              "with Reset (TONR); Timer Off Delay with Reset (TOFR); Retentive Timer On with "
              "Reset (RTOR)).",
              "PRE < 0 sets PresetInv (Status.1) and InstructFault (Status.0), so Status = 3, "
              "and the timer does not run (confirmed: same topics).",
              "Prescan clears EnableIn/EnableOut. First scan: TONR clears EN, TT, DN and "
              "ACC; TOFR clears EN, TT, DN and keeps ACC. RTOR clears EN, TT, DN on its first "
              "run after a download (confirmed: same topics).")


@instruction("TONR", "Timer On Delay with Reset", "Timer/Counter", "action",
             [Operand("Timer", "tag", _FT)], page=136, languages=("ST", "FBD"), notes=_FBD_NOTES)
def tonr(ctx, args, rung=True):
    _fbd_timer(ctx, args[0], "TONR")
    return bool(rung)


@instruction("TOFR", "Timer Off Delay with Reset", "Timer/Counter", "action",
             [Operand("Timer", "tag", _FT)], page=126, languages=("ST", "FBD"), notes=_FBD_NOTES)
def tofr(ctx, args, rung=True):
    _fbd_timer(ctx, args[0], "TOFR")
    return bool(rung)


@instruction("RTOR", "Retentive Timer On with Reset", "Timer/Counter", "action",
             [Operand("Timer", "tag", _FT)], page=115, languages=("ST", "FBD"), notes=_FBD_NOTES)
def rtor(ctx, args, rung=True):
    _fbd_timer(ctx, args[0], "RTOR")
    return bool(rung)


@instruction("CTUD", "Count Up/Down", "Timer/Counter", "action",
             [Operand("Counter", "tag", _FC)], page=102, languages=("ST", "FBD"),
             notes=("Counts up on a CUEnable false->true transition and down on a CDEnable "
                    "transition (CU / CD hold the previous enable states).",
                    "Reset = 1: ACC = 0 and DN, OV, UN cleared. DN = ACC >= PRE.",
                    "First scan / first run: a 0->1 transition of CUEnable or CDEnable is needed "
                    "before ACC changes (confirmed: Logix Designer help, Count Up/Down (CTUD)).",
                    "UNVERIFIED: whether counting is suppressed while Reset is set. Help text is "
                    "silent on this."))
def ctud(ctx, args, rung=True):
    c = args[0]
    _set(ctx, c, EnableIn=True, EnableOut=True)
    up, down = bool(_get(ctx, c, "CUEnable")), bool(_get(ctx, c, "CDEnable"))
    if _get(ctx, c, "Reset"):
        _set(ctx, c, ACC=0, OV=False, UN=False)
    else:
        if up and not _get(ctx, c, "CU"):
            _count(ctx, c, +1)
        if down and not _get(ctx, c, "CD"):
            _count(ctx, c, -1)
    _set(ctx, c, CU=up, CD=down, DN=_get(ctx, c, "ACC") >= _get(ctx, c, "PRE"))
    return bool(rung)


@instruction("OSRI", "One Shot Rising with Input", "Bit", "action",
             [Operand("OSRI tag", "tag", ("FBD_ONESHOT",))], page=81, languages=("ST", "FBD"),
             notes=("OutputBit = 1 for one execution when InputBit goes 0->1.",
                    "The previous InputBit is kept per instance by VirtualControlStudio (hidden storage).",
                    "Prescan: storage set, so a 0->1 transition is needed and there is no "
                    "output on the first scan (confirmed: Logix Designer help, One Shot Rising "
                    "with Input (OSRI))."))
def osri(ctx, args, rung=True):
    t = args[0]
    cur = bool(_get(ctx, t, "InputBit"))
    prev = ctx.scan_state.get(("osri", t), False)
    _set(ctx, t, OutputBit=cur and not prev, EnableOut=True)
    ctx.scan_state[("osri", t)] = cur
    return bool(rung)


@instruction("OSFI", "One Shot Falling with Input", "Bit", "action",
             [Operand("OSFI tag", "tag", ("FBD_ONESHOT",))], page=76, languages=("ST", "FBD"),
             notes=("OutputBit = 1 for one execution when InputBit goes 1->0.",
                    "Prescan: storage cleared, so a 1->0 transition is needed (confirmed: Logix "
                    "Designer help, One Shot Falling with Input (OSFI))."))
def osfi(ctx, args, rung=True):
    t = args[0]
    cur = bool(_get(ctx, t, "InputBit"))
    prev = ctx.scan_state.get(("osfi", t), False)
    _set(ctx, t, OutputBit=prev and not cur, EnableOut=True)
    ctx.scan_state[("osfi", t)] = cur
    return bool(rung)


@prescan("OSRI")
def _osri_pre(ctx, args):
    ctx.scan_state[("osri", ctx.resolve(args[0]))] = True


@prescan("OSFI")
def _osfi_pre(ctx, args):
    ctx.scan_state[("osfi", ctx.resolve(args[0]))] = False


def _fbd_timer_pre(ctx, args, first_scan: dict):
    t = ctx.resolve(args[0])
    _forget(ctx, t)
    _set(ctx, t, EnableIn=False, EnableOut=False, **first_scan)


@prescan("TONR")
def _tonr_pre(ctx, args):
    _fbd_timer_pre(ctx, args, dict(EN=False, TT=False, DN=False, ACC=0))


@prescan("TOFR")
def _tofr_pre(ctx, args):
    _fbd_timer_pre(ctx, args, dict(EN=False, TT=False, DN=False))


@prescan("RTOR")
def _rtor_pre(ctx, args):
    _fbd_timer_pre(ctx, args, {})


@prescan("CTUD")
def _ctud_pre(ctx, args):
    _set(ctx, ctx.resolve(args[0]), EnableIn=False, EnableOut=False, CU=True, CD=True)
