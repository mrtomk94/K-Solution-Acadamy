"""Byte image of Logix data, for COP / CPS / FLL.

COP copies *bytes* (no data conversion), so copying between different types
(e.g. a UDT into a DINT array) needs the controller's memory layout. The rules
below are the commonly documented ones and are marked UNVERIFIED where the
official text was not available:

* SINT 1, INT 2, DINT 4, LINT 8, REAL 4 bytes, little-endian, naturally aligned.
* Consecutive BOOL members of a structure share a hidden SINT host (8 per byte).
* Array members are aligned to 4 bytes. [UNVERIFIED: help text is silent on this
  for members inside a structure]
* A structure is aligned to its largest member and its size is rounded up to that
  alignment; LINT members align on 8 bytes (confirmed: Logix Designer help, LINT
  data types within this tag now align on 8-byte boundaries). The minimum
  alignment of 4 bytes for small structures is [UNVERIFIED: help text is silent on
  this].
* TIMER / COUNTER / CONTROL: a DINT of status bits followed by PRE/ACC
  (LEN/POS). Status bit numbers: TIMER EN 31, TT 30, DN 29; COUNTER CU 31, CD 30,
  DN 29, OV 28, UN 27; CONTROL EN 31, EU 30, DN 29, EM 28, ER 27, UL 26, IN 25,
  FD 24.
* STRING: DINT LEN followed by SINT DATA[82] (88 bytes).
"""
from __future__ import annotations

import struct

from .values import f32

ATOM = {"SINT": (1, "<b"), "INT": (2, "<h"), "DINT": (4, "<i"), "LINT": (8, "<q"),
        "REAL": (4, "<f")}
STATUS_WORD = {
    "TIMER": ({"EN": 31, "TT": 30, "DN": 29}, ("PRE", "ACC")),
    "COUNTER": ({"CU": 31, "CD": 30, "DN": 29, "OV": 28, "UN": 27}, ("PRE", "ACC")),
    "CONTROL": ({"EN": 31, "EU": 30, "DN": 29, "EM": 28, "ER": 27, "UL": 26, "IN": 25,
                 "FD": 24}, ("LEN", "POS")),
}
STRING_DATA = 82


def _is_string(dtype: str) -> bool:
    from ..model import STRING_TYPES
    return dtype in STRING_TYPES


def _slen(dtype: str) -> int:
    from ..model import string_max
    return string_max(dtype)


def _align(n: int, a: int) -> int:
    return (n + a - 1) // a * a


class Layout:
    def __init__(self, types: dict):
        self.types = types
        self._cache: dict[str, tuple] = {}

    # ---- sizes -------------------------------------------------------------
    def size(self, dtype: str, dim: int = 0) -> int:
        if dim:
            if dtype == "BOOL":
                return _align(dim, 32) // 8
            return self.size(dtype) * dim
        return self.plan(dtype)[0]

    def align(self, dtype: str) -> int:
        return self.plan(dtype)[1]

    def plan(self, dtype: str):
        """(size, align, fields) - fields: (name, kind, offset, extra)."""
        if dtype in self._cache:
            return self._cache[dtype]
        if dtype in ATOM:
            sz = ATOM[dtype][0]
            out = (sz, sz, None)
        elif dtype == "BOOL":
            out = (1, 1, None)
        elif dtype in STATUS_WORD:
            out = (12, 4, None)
        elif _is_string(dtype):
            out = (_align(4 + _slen(dtype), 4), 4, None)   # STRING: 4 + 82 padded to 88
        elif dtype in self.types:
            out = self._struct(dtype)
        else:
            out = (4, 4, None)                        # opaque/unknown: one DINT
        self._cache[dtype] = out
        return out

    def _struct(self, dtype: str):
        fields, off, host, used, max_align = [], 0, None, 8, 4
        for m in self.types[dtype].members:
            if m.data_type == "BOOL" and not m.dim:
                if host is None or used >= 8:
                    host, used = off, 0
                    off += 1
                fields.append((m.name, "bit", host, used))
                used += 1
                continue
            host = None
            if m.dim:
                a = max(4, self.align(m.data_type) if m.data_type != "BOOL" else 4)
                off = _align(off, a)
                fields.append((m.name, "array", off, (m.data_type, m.dim)))
                off += self.size(m.data_type, m.dim)
            else:
                a = self.align(m.data_type)
                off = _align(off, a)
                fields.append((m.name, "value", off, m.data_type))
                off += self.size(m.data_type)
            max_align = max(max_align, a)
        return (_align(max(off, 1), max_align), max_align, fields)

    # ---- encode / decode ---------------------------------------------------
    def encode(self, value, dtype: str, dim: int = 0) -> bytes:
        if dim:
            if dtype == "BOOL":
                buf = bytearray(self.size("BOOL", dim))
                for i, b in enumerate(value):
                    if b:
                        buf[i // 8] |= 1 << (i % 8)
                return bytes(buf)
            return b"".join(self.encode(v, dtype) for v in value)
        if dtype in ATOM:
            fmt = ATOM[dtype][1]
            if dtype == "REAL":
                return struct.pack(fmt, float(value))
            bits = ATOM[dtype][0] * 8
            v = int(value) & ((1 << bits) - 1)
            return v.to_bytes(bits // 8, "little")
        if dtype == "BOOL":
            return b"\x01" if value else b"\x00"
        if dtype in STATUS_WORD:
            bits, (a, b) = STATUS_WORD[dtype]
            word = 0
            for name, n in bits.items():
                if value.get(name):
                    word |= 1 << n
            return (word.to_bytes(4, "little") + struct.pack("<i", int(value.get(a, 0)))
                    + struct.pack("<i", int(value.get(b, 0))))
        if _is_string(dtype):
            n = _slen(dtype)
            raw = str(value).encode("latin-1", "replace")[:n]
            body = struct.pack("<i", len(raw)) + raw.ljust(n, b"\x00")
            return body.ljust(self.size(dtype), b"\x00")
        size, _, fields = self.plan(dtype)
        if fields is None or not isinstance(value, dict):
            return int(value or 0).to_bytes(4, "little", signed=True) if isinstance(value, int) \
                else bytes(size)
        buf = bytearray(size)
        for name, kind, off, extra in fields:
            v = value.get(name)
            if kind == "bit":
                if v:
                    buf[off] |= 1 << extra
            elif kind == "array":
                et, dim = extra
                data = self.encode(v, et, dim)
                buf[off:off + len(data)] = data
            else:
                data = self.encode(v, extra)
                buf[off:off + len(data)] = data
        return bytes(buf)

    def decode(self, data: bytes, dtype: str, dim: int = 0):
        if dim:
            if dtype == "BOOL":
                return [bool(data[i // 8] >> (i % 8) & 1) for i in range(dim)]
            es = self.size(dtype)
            return [self.decode(data[i * es:(i + 1) * es], dtype) for i in range(dim)]
        if dtype in ATOM:
            sz, fmt = ATOM[dtype]
            v = struct.unpack(fmt, data[:sz])[0]
            return f32(v) if dtype == "REAL" else v
        if dtype == "BOOL":
            return bool(data[0] & 1)
        if dtype in STATUS_WORD:
            bits, (a, b) = STATUS_WORD[dtype]
            word = int.from_bytes(data[:4], "little")
            out = {name: bool(word >> n & 1) for name, n in bits.items()}
            out[a] = struct.unpack("<i", data[4:8])[0]
            out[b] = struct.unpack("<i", data[8:12])[0]
            return out
        if _is_string(dtype):
            n = max(0, min(struct.unpack("<i", data[:4])[0], _slen(dtype)))
            return data[4:4 + n].decode("latin-1")
        size, _, fields = self.plan(dtype)
        if fields is None:
            return struct.unpack("<i", data[:4])[0]
        out = {}
        for name, kind, off, extra in fields:
            if kind == "bit":
                out[name] = bool(data[off] >> extra & 1)
            elif kind == "array":
                et, dim = extra
                out[name] = self.decode(data[off:off + self.size(et, dim)], et, dim)
            else:
                out[name] = self.decode(data[off:off + self.size(extra)], extra)
        return out
