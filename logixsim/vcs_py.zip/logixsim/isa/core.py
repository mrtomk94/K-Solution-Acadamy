"""Execution context, registry and fault types shared by every instruction.

An instruction implementation never touches the UI. It receives an
:class:`ExecContext` (tag access, controller clock, status flags, faults) and
its operand strings, and returns the rung-condition-out.

Calling conventions (kept compatible with the original ``REGISTRY``):

* *condition* instructions (XIC, EQU, ...): ``fn(ctx, args) -> bool`` - the
  instruction's own result; the ladder interpreter ANDs it with rung-in.
* *action* instructions (OTE, TON, MOV, ONS, ...): ``fn(ctx, args, rung=True)
  -> bool`` - they receive rung-condition-in and return rung-condition-out.
"""
from __future__ import annotations

import re
from typing import Any, Callable

from .values import (ALL_INT_BITS, INT_BITS, literal, literal_type, store_convert)
from ..model import BitIndexError

REGISTRY: dict[str, Callable] = {}


def op(name: str):
    """Low-level registration (legacy). Prefer :func:`logixsim.isa.spec.instruction`."""
    def deco(fn):
        REGISTRY[name] = fn
        return fn
    return deco


class UnsupportedInstruction(Exception):
    """Raised loudly when a routine uses an instruction VirtualControlStudio does not execute."""


class InstructionError(Exception):
    """An instruction could not execute (bad operand, wrong type). Reported, not fatal."""


class MajorFault(Exception):
    """A Logix major fault: the controller stops executing logic (FAULTED)."""

    def __init__(self, ftype: int, code: int, text: str):
        super().__init__(f"Major fault (Type {ftype:02d}) (Code {code:02d}) {text}")
        self.ftype, self.code, self.text = ftype, code, text


class _ControlFlow(Exception):
    """Internal: unwinds a routine for RET / TND / BRK."""


_ROOT = re.compile(r"(?:Program:[A-Za-z_][A-Za-z0-9_]*\.)?[A-Za-z_][A-Za-z0-9_:]*")
_STATIC_IDX = re.compile(r"\[\s*\d+\s*(?:,\s*\d+\s*)*\]")


class Status:
    """Arithmetic status flags (S:N, S:Z, S:V, S:C). Each instruction that
    affects them overwrites them; they are only meaningful right after it."""
    __slots__ = ("N", "Z", "V", "C")

    def __init__(self):
        self.N = self.Z = self.V = self.C = False


class Frame:
    """One JSR / FOR call level (parameters, returns, loop break)."""

    def __init__(self, inputs=None):
        self.inputs = inputs or []       # JSR input values (value, type)
        self.sbr_done = False
        self.returns: list | None = None
        self.stop: str | None = None     # "RET", "TND", "BRK"


class ExecContext:
    """Per-scan execution context handed to every instruction."""

    def __init__(self, db, now: float = 0.0, engine=None, program=None,
                 first_scan: bool = False):
        self.db = db
        self.now = now
        self.engine = engine
        self.program = program
        self.first_scan = first_scan
        self.scan_state: dict = {} if engine is None else engine.scan_state
        self.status = Status() if engine is None else engine.status
        self.prescan = False
        self.frames: list[Frame] = [Frame()]
        self.jump: str | None = None     # label requested by JMP (this rung)
        self.mcr_seen: bool | None = None  # rung-in at an MCR on this rung
        self.location = ""               # program/routine rung for diagnostics
        # operand -> address cache, kept across scans per program (cleared by the
        # engine when tags are created/deleted)
        if engine is not None and program is not None:
            self._cache = engine.resolve_cache.setdefault(getattr(program, "name", ""), {})
        else:
            self._cache: dict[str, str] = {}

    # ---- operand helpers ------------------------------------------------
    @property
    def frame(self) -> Frame:
        return self.frames[-1]

    def resolve(self, operand: str) -> str:
        """Map a tag reference to its TagDB address. Inside a program a
        program-scoped tag wins over a controller tag of the same name.
        Indirect subscripts (``Arr[Idx]``, ``Arr[i+1]``, ``Word.[Bit]``) are
        evaluated now; an out-of-range subscript is a major fault (Type 4 Code 20),
        as documented for every Logix instruction."""
        operand = operand.strip()
        if ".@" in operand:                       # extended property: resolved when read
            return operand
        hit = self._cache.get(operand)
        if hit is not None:
            return hit
        out, static = self._resolve(operand)
        if static:
            self._cache[operand] = out
        return out

    def _scope(self, name: str) -> str:
        """A program tag (or program alias) wins over a controller tag of the same
        name; names are not case sensitive (the declared spelling is returned)."""
        find = getattr(self.db, "find_root", None)
        if self.program is None or name.startswith("Program:"):
            return (find(name) if find else None) or name
        local = f"Program:{self.program.name}.{name}"
        if find is not None:
            hit = find(local)
            if hit is not None:
                return hit
            if self.db.alias_key(local) is not None:
                return self.db.alias_key(local)
            return find(name) or self.db.alias_key(name) or name
        has = getattr(self.db, "has_tag", None)
        if has is not None and has(local):
            return local
        return name

    def _resolve(self, op: str) -> tuple[str, bool]:
        if not op or op == "?" or op[:2].upper() == "S:":
            return op, True
        tpl = _TEMPLATES.get(op)
        if tpl is None:
            tpl = _template(op)
            if len(_TEMPLATES) < 100_000:
                _TEMPLATES[op] = tpl
        if tpl is False:
            return op, True
        rname, segs = tpl[0], tpl[1]
        key = "\x00" + rname
        root = self._cache.get(key)
        if root is None:
            root = self._scope(rname)
            self._cache[key] = root
        if segs is None:                       # no subscripts (or only plain text)
            return root + tpl[2], True
        out, static = [root], True
        for seg in segs:
            if type(seg) is str:
                out.append(seg)
                continue
            static = False
            exprs, bit = seg
            if bit:                                  # Word.[Idx] -> Word.N
                out.append(str(self._index(exprs[0], True)))
            else:
                out.append("[" + ",".join(str(self._index(e)) for e in exprs) + "]")
        return "".join(out), static

    def _index(self, expr: str, bit: bool = False) -> int:
        hit = _SIMPLE_IDX.get(expr)
        if hit is None:
            hit = _SIMPLE_IDX[expr] = bool(_PLAIN_TAG.fullmatch(expr)) and \
                expr.lower() not in _EXPR_WORDS
        if hit:                                      # a plain tag: read it directly
            val = self.read(expr)
            if isinstance(val, bool):
                val = int(val)
        else:
            from .expr import evaluate
            val, _ = evaluate(self, expr)
        if isinstance(val, float):
            val = int(val)
        if val < 0:
            if bit:
                raise MajorFault(4, 83, f"Bit index out of range: [{expr}] = {val}")
            raise MajorFault(4, 20, f"Array subscript too large (or negative): [{expr}] = {val}")
        return int(val)

    def dtype(self, operand: str) -> str:
        """Data type of an operand (tag address or literal)."""
        operand = operand.strip()
        if operand[:2].upper() == "S:":
            return "BOOL" if operand.upper() in ("S:FS", "S:N", "S:Z", "S:V", "S:C", "S:MINOR") \
                else "DINT"
        lt = literal_type(operand)
        if lt:
            return lt
        if len(operand) >= 2 and operand[0] == operand[-1] == "'":
            return "STRING"
        if ".@" in operand:                       # extended property: type of its tag
            operand = operand.split(".@", 1)[0]
        key = "\x01" + operand
        hit = self._cache.get(key)
        if hit is not None:
            return hit
        try:
            out = self.db.data_type(self.resolve(operand))
            self._cache[key] = out           # the type does not depend on subscript values
            return out
        except MajorFault:
            raise
        except Exception:
            raise InstructionError(f"unknown tag '{operand}'")

    def is_tag(self, operand: str) -> bool:
        operand = operand.strip()
        if not operand or operand == "?" or literal_type(operand):
            return False
        try:
            self.db.data_type(self.resolve(operand))
            return True
        except Exception:
            return False

    def _system(self, operand: str):
        u = operand.upper()
        if u == "S:FS":
            return self.first_scan
        if u in ("S:N", "S:Z", "S:V", "S:C"):
            return getattr(self.status, u[2])
        if u == "S:MINOR":
            return bool(self.engine and self.engine.minor_this_scan)
        return False

    def read(self, operand: str):
        hit = self._cache.get("\x02" + operand)
        if hit is not None:                     # a static tag address seen before
            try:
                return self.db.get(hit)
            except Exception:
                del self._cache["\x02" + operand]
        return self._read(operand)

    def _read(self, operand: str):
        raw = operand
        operand = operand.strip()
        if operand in ("", "?"):
            return None
        if operand[:2].upper() == "S:":
            return self._system(operand)
        lit = literal(operand)
        if lit is not None:
            return lit
        if len(operand) >= 2 and operand[0] == operand[-1] == "'":     # ST string literal
            return operand[1:-1].replace("''", "'")
        if ".@" in operand:
            return self._extended(operand)
        addr = self.resolve(operand)
        try:
            out = self.db.get(addr)
            if self._cache.get(operand) == addr:      # static: remember for next time
                self._cache["\x02" + raw] = addr
            return out
        except BitIndexError:
            raise MajorFault(4, 83, f"Bit index out of range: {operand}")
        except IndexError:
            raise MajorFault(4, 20, f"Array subscript too large: {operand}")
        except Exception:
            pass
        low = operand.lower()
        if low == "true":
            return True
        if low == "false":
            return False
        raise InstructionError(f"unknown tag '{operand}'")

    def value(self, operand: str) -> tuple[Any, str]:
        """(value, data type) of an operand."""
        return self.read(operand), self.dtype(operand)

    def write(self, operand: str, value) -> None:
        operand = operand.strip()
        if operand[:2].upper() == "S:":          # status flags are not writable here
            return
        if ".@" in operand:
            raise InstructionError(f"'{operand}': extended properties cannot be written by logic")
        addr = self.resolve(operand)
        self.guard(addr, operand)
        try:
            self.db.set(addr, value)
        except BitIndexError:
            raise MajorFault(4, 83, f"Bit index out of range: {operand}")
        except IndexError:
            raise MajorFault(4, 20, f"Array subscript too large: {operand}")

    def guard(self, addr: str, operand: str | None = None) -> None:
        """Logic may not change a Constant tag (1756-PM004, Constant Value Tags)."""
        is_const = getattr(self.db, "is_constant", None)
        if is_const is not None and is_const(addr):
            raise InstructionError(f"'{operand or addr}' is a constant tag; logic cannot change it")

    _TYPE_LIMITS = {"SINT": (-128, 127), "INT": (-32768, 32767),
                    "DINT": (-2147483648, 2147483647),
                    "LINT": (-9223372036854775808, 9223372036854775807),
                    "REAL": (-3.402823e38, 3.402823e38),
                    "USINT": (0, 255), "UINT": (0, 65535), "UDINT": (0, 4294967295),
                    "ULINT": (0, 18446744073709551615), "LREAL": (-1.7976931348623157e308, 1.7976931348623157e308)}

    def _extended(self, operand: str):
        """``Tag.@Min`` / ``Tag.@Max``: limit extended properties, read-only in logic.
        An element without its own value uses the array tag's; an indirect reference
        with no value configured uses the data type's limit."""
        base, prop = operand.split(".@", 1)
        prop = prop.strip().lower()
        if prop not in ("min", "max"):
            raise InstructionError(f"'{operand}': only @Min and @Max can be used in logic")
        addr = self.resolve(base)
        dtype = self.db.data_type(addr)
        if dtype not in self._TYPE_LIMITS:
            raise InstructionError(f"'{operand}': limit properties need a SINT, INT, DINT, LINT or REAL tag")
        store = getattr(self.engine, "store", None)
        value = store.extended(addr, prop) if store is not None else None
        if value is None:
            if "[" in base and not _STATIC_IDX_ANY.fullmatch(base):
                return self._TYPE_LIMITS[dtype][0 if prop == "min" else 1]
            raise InstructionError(f"'{operand}': the @{prop.title()} extended property is not "
                                   f"defined for this tag")
        return value

    def store(self, dest: str, value, vtype: str, flags: bool = True) -> Any:
        """Write ``value`` (of Logix type ``vtype``) to ``dest`` with the Logix
        data conversion rules; updates S:N/S:Z (and S:V on overflow)."""
        dtype = self.dtype(dest)
        out, overflow = store_convert(value, vtype, dtype)
        self.write(dest, out)
        if flags:
            self.set_flags(out, overflow=overflow)
        elif overflow:
            self.overflow()
        return out

    # ---- status / faults -------------------------------------------------
    def set_flags(self, result, overflow: bool = False, carry: bool | None = None) -> None:
        st = self.status
        if isinstance(result, (int, float)) and not isinstance(result, bool):
            st.N = result < 0
            st.Z = result == 0
        st.V = bool(overflow)
        if carry is not None:
            st.C = bool(carry)
        if overflow:
            self.overflow()

    def overflow(self) -> None:
        self.status.V = True
        self.minor_fault(4, 4, "Arithmetic overflow")

    def minor_fault(self, ftype: int, code: int, text: str) -> None:
        if self.engine is not None and not self.prescan:
            self.engine.minor_fault(ftype, code, text, self.location)

    def bits_of(self, dtype: str) -> int:
        return ALL_INT_BITS.get(dtype, 32)


_STATIC_IDX_ANY = re.compile(r"[^\[]*(\[[\d,\s]+\][^\[]*)*")


_TEMPLATES: dict = {}
_SIMPLE_IDX: dict = {}
_PLAIN_TAG = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*")
_EXPR_WORDS = {"not", "and", "or", "xor", "mod", "abs", "sqr", "sqrt", "trn", "frd", "tod",
               "true", "false"}


def _template(op: str):
    """Parse an operand once: (root name, segments | None[, tail]). A segment is
    literal text or (subscript expressions, is_bit_index)."""
    m = _ROOT.match(op)
    if not m:
        return False
    rname, rest = m.group(), op[m.end():]
    if "[" not in rest:
        return (rname, None, rest)
    segs, buf, i = [], [], 0
    while i < len(rest):
        ch = rest[i]
        if ch == "[":
            depth, j = 1, i + 1
            while j < len(rest) and depth:
                depth += {"[": 1, "]": -1}.get(rest[j], 0)
                j += 1
            inner = rest[i + 1:j - 1]
            bit = (buf[-1] == ".") if buf else (segs and type(segs[-1]) is str and segs[-1].endswith("."))
            if _STATIC_IDX.fullmatch(f"[{inner}]") and not bit:
                buf.append(f"[{inner.replace(' ', '')}]")
            else:
                if buf:
                    segs.append("".join(buf))
                    buf = []
                segs.append((tuple(p.strip() for p in _split_top(inner)), bool(bit)))
            i = j
        else:
            buf.append(ch)
            i += 1
    if buf:
        segs.append("".join(buf))
    if all(type(x) is str for x in segs):
        return (rname, None, "".join(segs))
    return (rname, segs)


def _split_top(text: str) -> list[str]:
    """Split 'a,b[1,2]' on top-level commas."""
    out, depth, cur = [], 0, ""
    for c in text:
        if c in "([":
            depth += 1
        elif c in ")]":
            depth -= 1
        if c == "," and depth == 0:
            out.append(cur)
            cur = ""
        else:
            cur += c
    out.append(cur)
    return [p.strip() for p in out]
