"""Array (file)/shift and sequencer instructions: BSL BSR FFL FFU LFL LFU SQO SQI SQL
(RM: p.622-668).

All of them use a CONTROL structure. LEN/POS come from the CONTROL tag (the
Length/Position operands in the rung text are its LEN/POS shown on the
instruction face). An invalid LEN or POS is a major fault Type 4 Code 20
(documented). Loads/unloads/shifts happen on a false->true rung transition,
detected with the CONTROL's EN (load) or EU (unload) bit.
"""
from __future__ import annotations

import copy

from .core import MajorFault
from .files import region
from .spec import INT, Operand, instruction, prescan
from .values import num, store_convert

_CTRL = ("CONTROL",)


def _g(ctx, c, m):
    return ctx.db.get(f"{c}.{m}")


def _s(ctx, c, **kw):
    ctx.guard(c)
    for m, v in kw.items():
        ctx.db.set(f"{c}.{m}", v)


def _lenpos(ctx, c, inst, need_len=True):
    length, pos = _g(ctx, c, "LEN"), _g(ctx, c, "POS")
    if length < 0 or pos < 0 or (need_len and length == 0):
        raise MajorFault(4, 20, f"{inst}: invalid LEN ({length}) or POS ({pos}) in {c}")
    return length, pos


def _edge(ctx, c, bit, rung) -> bool:
    """Update the enable bit; True on a false->true transition."""
    was = bool(_g(ctx, c, bit))
    _s(ctx, c, **{bit: bool(rung)})
    return bool(rung) and not was


_SHIFT_NOTES = (
    "Shifts once per false->true rung transition (EN is the edge memory).",
    "The bit shifted out goes to UL; DN is set after each shift. Rung false clears EN, DN, "
    "ER and POS (confirmed: Logix Designer help, Bit Shift Left (BSL); Bit Shift Right (BSR)).",
    "Array is a DINT array; bits are numbered across elements (element n bit b = n*32+b).",
    "Prescan: EN, DN, ER and POS cleared, so a rung that is true on the first scan shifts "
    "once (confirmed: Logix Designer help, Bit Shift Left (BSL); Bit Shift Right (BSR)).",
)


def _bits(ctx, operand, length, inst):
    ctx.guard(ctx.resolve(operand), operand)
    seq, start, dtype = region(ctx, operand)
    if dtype != "DINT":
        raise MajorFault(4, 20, f"{inst}: array must be DINT, not {dtype}")
    words = (length + 31) // 32
    if len(seq) - start < words:
        raise MajorFault(4, 20, f"{inst}: LEN {length} is beyond the end of {operand}")
    bits = [bool(int(seq[start + i // 32]) >> (i % 32) & 1) for i in range(length)]
    return seq, start, bits


def _put_bits(seq, start, bits):
    for w in range((len(bits) + 31) // 32):
        word = int(seq[start + w]) & 0xFFFFFFFF
        for b in range(32):
            i = w * 32 + b
            if i < len(bits):
                word = word | (1 << b) if bits[i] else word & ~(1 << b)
        seq[start + w] = word - (1 << 32) if word >= 1 << 31 else word


def _shift(ctx, args, rung, left: bool, inst):
    arr, c, src = args[0], args[1], args[2]
    if not _edge(ctx, c, "EN", rung):
        if not rung:
            _s(ctx, c, DN=False, ER=False, POS=0)
        return
    length, _ = _lenpos(ctx, c, inst)
    seq, start, bits = _bits(ctx, arr, length, inst)
    inbit = bool(ctx.read(src))
    if left:
        ul = bits[-1]
        bits = [inbit] + bits[:-1]
    else:
        ul = bits[0]
        bits = bits[1:] + [inbit]
    _put_bits(seq, start, bits)
    _s(ctx, c, UL=ul, DN=True, POS=length)


@instruction("BSL", "Bit Shift Left", "Array (File)/Shift", "action",
             [Operand("Array", "tag", ("DINT",)), Operand("Control", "tag", _CTRL),
              Operand("Source Bit", "src", ("BOOL",)), Operand("Length", "imm")],
             page=622, languages=("LD",),
             display={"rows": [["Array", 0], ["Control", 1], ["Source Bit", 2],
                               ["Length", "1.LEN"]], "bits": ["EN", "DN", "ER", "UL"], "bits_op": 1},
             notes=_SHIFT_NOTES + ("Left: bit 0 <- Source Bit, bit LEN-1 -> UL.",))
def bsl(ctx, args, rung=True):
    _shift(ctx, args, rung, True, "BSL")
    return bool(rung)


@instruction("BSR", "Bit Shift Right", "Array (File)/Shift", "action",
             [Operand("Array", "tag", ("DINT",)), Operand("Control", "tag", _CTRL),
              Operand("Source Bit", "src", ("BOOL",)), Operand("Length", "imm")],
             page=626, languages=("LD",),
             display={"rows": [["Array", 0], ["Control", 1], ["Source Bit", 2],
                               ["Length", "1.LEN"]], "bits": ["EN", "DN", "ER", "UL"], "bits_op": 1},
             notes=_SHIFT_NOTES + ("Right: bit LEN-1 <- Source Bit, bit 0 -> UL.",))
def bsr(ctx, args, rung=True):
    _shift(ctx, args, rung, False, "BSR")
    return bool(rung)


def _stack(ctx, operand, length, inst):
    if inst not in ("SQO", "SQI"):                   # these only read the array
        ctx.guard(ctx.resolve(operand), operand)
    seq, start, dtype = region(ctx, operand)
    if len(seq) - start < length:
        raise MajorFault(4, 20, f"{inst}: LEN {length} is beyond the end of {operand}")
    return seq, start, dtype


def _status(ctx, c, length, pos):
    _s(ctx, c, DN=pos >= length, EM=pos == 0)


_STACK_NOTES = (
    "Load (EN) and unload (EU) happen on false->true transitions; the same CONTROL is "
    "shared by the load and unload instruction.",
    "DN = stack full (POS >= LEN); EM = stack empty (POS = 0).",
    "LEN <= 0 or POS < 0: EM and DN set and nothing is loaded or unloaded (no fault) "
    "(confirmed: Logix Designer help, FIFO Load (FFL); FIFO Unload (FFU); LIFO Load (LFL); "
    "LIFO Unload (LFU)).",
    "Prescan: EU set for FFU so prescan cannot cause a false unload (confirmed: Logix "
    "Designer help, FIFO Unload (FFU)). UNVERIFIED: EN set for FFL/LFL and EU for LFU "
    "(VirtualControlStudio does the same as FFU). Help text is silent on this.",
)


@instruction("FFL", "FIFO Load", "Array (File)/Shift", "action",
             [Operand("Source", "src"), Operand("FIFO", "tag"),
              Operand("Control", "tag", _CTRL), Operand("Length", "imm"),
              Operand("Position", "imm")], page=630, languages=("LD",),
             display={"rows": [["Source", 0], ["FIFO", 1], ["Control", 2],
                               ["Length", "2.LEN"], ["Position", "2.POS"]],
                      "bits": ["EN", "DN", "EM"], "bits_op": 2},
             notes=_STACK_NOTES + ("Load: FIFO[POS] = Source (converted), POS += 1; when full "
                                   "nothing is loaded.",))
def ffl(ctx, args, rung=True):
    _load(ctx, args, rung, "FFL")
    return bool(rung)


@instruction("LFL", "LIFO Load", "Array (File)/Shift", "action",
             [Operand("Source", "src"), Operand("LIFO", "tag"),
              Operand("Control", "tag", _CTRL), Operand("Length", "imm"),
              Operand("Position", "imm")], page=643, languages=("LD",),
             display={"rows": [["Source", 0], ["LIFO", 1], ["Control", 2],
                               ["Length", "2.LEN"], ["Position", "2.POS"]],
                      "bits": ["EN", "DN", "EM"], "bits_op": 2},
             notes=_STACK_NOTES + ("Load: LIFO[POS] = Source, POS += 1.",))
def lfl(ctx, args, rung=True):
    _load(ctx, args, rung, "LFL")
    return bool(rung)


def _blank(ctx, dtype):
    """The cleared value of one element (0, 0.0, '' or a zeroed structure)."""
    if dtype == "REAL":
        return 0.0
    if dtype in ("SINT", "INT", "DINT", "LINT", "BOOL"):
        return 0
    return ctx.db._default(dtype, 0)


def _unload_to(ctx, dest, value, dtype):
    if isinstance(value, (dict, list)):
        ctx.guard(ctx.resolve(dest), dest)
        ctx.write(dest, copy.deepcopy(value))
    else:
        ctx.store(dest, value, dtype)


def _empty_if_bad(ctx, c) -> bool:
    """LEN <= 0 or POS < 0: EM and DN set, nothing else happens."""
    length, pos = _g(ctx, c, "LEN"), _g(ctx, c, "POS")
    if length <= 0 or pos < 0:
        _s(ctx, c, EM=True, DN=True)
        return True
    return False


def _load(ctx, args, rung, inst):
    src, stack, c = args[0], args[1], args[2]
    if not _edge(ctx, c, "EN", rung) or _empty_if_bad(ctx, c):
        return
    length, pos = _lenpos(ctx, c, inst)
    seq, start, dtype = _stack(ctx, stack, length, inst)
    if pos > length:
        raise MajorFault(4, 20, f"{inst}: POS {pos} > LEN {length}")
    if pos < length:
        v, vt = ctx.value(src)
        if isinstance(v, (dict, list)):               # a structure element: copied whole
            seq[start + pos] = copy.deepcopy(v)
        else:
            seq[start + pos], _ = store_convert(v, vt, dtype)
        pos += 1
        _s(ctx, c, POS=pos)
    _status(ctx, c, length, pos)


@instruction("FFU", "FIFO Unload", "Array (File)/Shift", "action",
             [Operand("FIFO", "tag"), Operand("Dest", "dest"),
              Operand("Control", "tag", _CTRL), Operand("Length", "imm"),
              Operand("Position", "imm")], page=637, languages=("LD",),
             display={"rows": [["FIFO", 0], ["Dest", 1], ["Control", 2],
                               ["Length", "2.LEN"], ["Position", "2.POS"]],
                      "bits": ["EU", "DN", "EM"], "bits_op": 2},
             notes=_STACK_NOTES + ("Unload: Dest = FIFO[0], elements move down one place, "
                                   "the last element is cleared, POS -= 1. Empty FIFO: Dest = 0 "
                                   "and EM set (confirmed: Logix Designer help, FIFO Unload "
                                   "(FFU)).", "UNVERIFIED: the vacated last element is set to 0. "
                                   "Help text is silent on this.",))
def ffu(ctx, args, rung=True):
    stack, dest, c = args[0], args[1], args[2]
    if _edge(ctx, c, "EU", rung) and not _empty_if_bad(ctx, c):
        length, pos = _lenpos(ctx, c, "FFU")
        seq, start, dtype = _stack(ctx, stack, length, "FFU")
        if pos > 0:
            _unload_to(ctx, dest, seq[start], dtype)
            for i in range(length - 1):
                seq[start + i] = seq[start + i + 1]
            seq[start + length - 1] = _blank(ctx, dtype)
            pos -= 1
            _s(ctx, c, POS=pos)
        else:
            ctx.store(dest, 0, "DINT")
        _status(ctx, c, length, pos)
    return bool(rung)


@instruction("LFU", "LIFO Unload", "Array (File)/Shift", "action",
             [Operand("LIFO", "tag"), Operand("Dest", "dest"),
              Operand("Control", "tag", _CTRL), Operand("Length", "imm"),
              Operand("Position", "imm")], page=650, languages=("LD",),
             display={"rows": [["LIFO", 0], ["Dest", 1], ["Control", 2],
                               ["Length", "2.LEN"], ["Position", "2.POS"]],
                      "bits": ["EU", "DN", "EM"], "bits_op": 2},
             notes=_STACK_NOTES + ("Unload: POS -= 1, Dest = LIFO[POS], that element is "
                                   "cleared to 0. Empty LIFO: Dest = 0 (confirmed: Logix "
                                   "Designer help, LIFO Unload (LFU)).",
                                   "Reading past the end of the array sets ER and is a major "
                                   "fault Type 4 Code 20 (confirmed: same topic).",))
def lfu(ctx, args, rung=True):
    stack, dest, c = args[0], args[1], args[2]
    if _edge(ctx, c, "EU", rung) and not _empty_if_bad(ctx, c):
        length, pos = _lenpos(ctx, c, "LFU")
        try:
            seq, start, dtype = _stack(ctx, stack, length, "LFU")
        except MajorFault:
            _s(ctx, c, ER=True)
            raise
        if pos > 0:
            pos -= 1
            _unload_to(ctx, dest, seq[start + pos], dtype)
            seq[start + pos] = _blank(ctx, dtype)
            _s(ctx, c, POS=pos)
        else:
            ctx.store(dest, 0, "DINT")
        _status(ctx, c, length, pos)
    return bool(rung)


_SEQ_NOTES = (
    "Steps on a false->true rung transition: POS += 1; after POS = LEN it wraps to 1 "
    "(element 0 is the start-up step).",
    "DN is set when POS = LEN.",
    "POS = 0 (the RES / initial value) steps to 1 on the first transition (confirmed: Logix "
    "Designer help, Sequencer Output (SQO)).",
)


def _seq_step(ctx, c, inst):
    length, pos = _lenpos(ctx, c, inst)
    if pos > length:
        raise MajorFault(4, 20, f"{inst}: POS {pos} > LEN {length}")
    pos = 1 if pos >= length else pos + 1
    _s(ctx, c, POS=pos, DN=pos == length)
    return length, pos


@instruction("SQO", "Sequencer Output", "Sequencer", "action",
             [Operand("Array", "tag", INT), Operand("Mask", "src", INT), Operand("Dest", "dest", INT),
              Operand("Control", "tag", _CTRL), Operand("Length", "imm"),
              Operand("Position", "imm")], page=665, languages=("LD",),
             display={"rows": [["Array", 0], ["Mask", 1], ["Dest", 2],
                               ["Control", 3], ["Length", "3.LEN"], ["Position", "3.POS"]],
                      "bits": ["EN", "DN", "ER"], "bits_op": 3},
             notes=_SEQ_NOTES + ("Dest = (Dest AND NOT Mask) OR (Array[POS] AND Mask), done on "
                                 "every scan while EN is true, not only on the transition "
                                 "(confirmed: Logix Designer help, Sequencer Output (SQO)).",))
def sqo(ctx, args, rung=True):
    arr, mask, dest, c = args[0], args[1], args[2], args[3]
    if _edge(ctx, c, "EN", rung):
        length, pos = _seq_step(ctx, c, "SQO")
    elif rung:
        length, pos = _lenpos(ctx, c, "SQO")
        if pos > length:
            raise MajorFault(4, 20, f"SQO: POS {pos} > LEN {length}")
    if rung:
        seq, start, _ = _stack(ctx, arr, length + 1, "SQO")
        m = int(num(ctx.read(mask)))
        d, dt = ctx.value(dest)
        ctx.store(dest, (int(d) & ~m) | (int(seq[start + pos]) & m), dt)
    return bool(rung)


@instruction("SQI", "Sequencer Input", "Sequencer", "condition",
             [Operand("Array", "tag", INT), Operand("Mask", "src", INT),
              Operand("Source", "src", INT), Operand("Control", "tag", _CTRL),
              Operand("Length", "imm"), Operand("Position", "imm")], page=658, languages=("LD",),
             display={"rows": [["Array", 0], ["Mask", 1], ["Source", 2],
                               ["Control", 3], ["Length", "3.LEN"], ["Position", "3.POS"]]},
             notes=("True when (Source AND Mask) = (Array[POS] AND Mask); POS is not changed.",))
def sqi(ctx, args):
    arr, mask, src, c = args[0], args[1], args[2], args[3]
    length, pos = _lenpos(ctx, c, "SQI")
    if pos > length:
        raise MajorFault(4, 20, f"SQI: POS {pos} > LEN {length}")
    seq, start, _ = _stack(ctx, arr, pos + 1, "SQI")
    m = int(num(ctx.read(mask)))
    return (int(num(ctx.read(src))) & m) == (int(seq[start + pos]) & m)


@instruction("SQL", "Sequencer Load", "Sequencer", "action",
             [Operand("Array", "tag", INT), Operand("Source", "src", INT),
              Operand("Control", "tag", _CTRL), Operand("Length", "imm"),
              Operand("Position", "imm")], page=661, languages=("LD",),
             display={"rows": [["Array", 0], ["Source", 1], ["Control", 2],
                               ["Length", "2.LEN"], ["Position", "2.POS"]],
                      "bits": ["EN", "DN", "ER"], "bits_op": 2},
             notes=_SEQ_NOTES + ("Array[POS] = Source after stepping.",))
def sql(ctx, args, rung=True):
    arr, src, c = args[0], args[1], args[2]
    if _edge(ctx, c, "EN", rung):
        length, pos = _seq_step(ctx, c, "SQL")
        seq, start, dtype = _stack(ctx, arr, length + 1, "SQL")
        v, vt = ctx.value(src)
        seq[start + pos], _ = store_convert(v, vt, dtype)
    return bool(rung)


@prescan("FFL", "LFL", "SQO", "SQL")
def _en_pre(ctx, args):
    for a in args:
        try:
            if ctx.dtype(a) == "CONTROL":
                _s(ctx, ctx.resolve(a), EN=True)
                return
        except Exception:
            continue


@prescan("BSL", "BSR")
def _shift_pre(ctx, args):
    _s(ctx, ctx.resolve(args[1]), EN=False, DN=False, ER=False, POS=0)


@prescan("FFU", "LFU")
def _eu_pre(ctx, args):
    for a in args:
        try:
            if ctx.dtype(a) == "CONTROL":
                _s(ctx, ctx.resolve(a), EU=True)
                return
        except Exception:
            continue
