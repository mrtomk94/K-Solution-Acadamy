"""Array (file)/misc instructions: COP CPS FLL FAL FSC AVE STD SRT SIZE
(RM: Array File-Misc Instructions, p.555-621)."""
from __future__ import annotations

import math
import re

from ..model import STRING_TYPES, string_max
from .core import InstructionError, MajorFault
from .expr import evaluate_full
from .layout import Layout
from .spec import NUM, Operand, instruction
from .values import f32, num, store_convert


class _Single:
    """A scalar/structure tag seen as a one-element region."""

    def __init__(self, container, key):
        self.c, self.k = container, key

    def __len__(self):
        return 1

    def __getitem__(self, i):
        if i != 0:
            raise IndexError(i)
        return self.c[self.k]

    def __setitem__(self, i, v):
        if i != 0:
            raise IndexError(i)
        self.c[self.k] = v


class _StrData:
    """The DATA bytes of a string tag (held as text) as a SINT sequence, so COP/CPS
    can copy to and from ``Str.DATA[n]``. Writing past LEN extends the text (the
    simulator keeps only LEN characters)."""

    def __init__(self, container, key, size):
        self.c, self.k, self.size = container, key, size

    def __len__(self):
        return self.size

    def __getitem__(self, i):
        if isinstance(i, slice):
            return [self[j] for j in range(*i.indices(self.size))]
        t = self.c[self.k]
        v = ord(t[i]) if i < len(t) else 0
        return v - 256 if v > 127 else v

    def __setitem__(self, i, v):
        if not 0 <= i < self.size:
            raise IndexError(i)
        t = self.c[self.k]
        ch = chr(int(v) & 0xFF)
        if i < len(t):
            self.c[self.k] = t[:i] + ch + t[i + 1:]
        elif ch != "\x00":
            self.c[self.k] = t.ljust(i, "\x00") + ch


_STR_DATA = re.compile(r"^(.*)\.DATA(?:\[\s*(\d+)\s*\])?$", re.I)


def region(ctx, operand: str):
    """(sequence, start index, element type) of the memory an operand starts at:
    ``Arr[3]`` -> the array from element 3; ``Arr`` -> the whole array; a scalar or
    structure -> itself; ``Str.DATA[n]`` -> the string's characters from n."""
    addr = ctx.db.dealias(ctx.resolve(operand))
    sm = _STR_DATA.match(addr)
    if sm:
        try:
            container, key, dtype = ctx.db._resolve(sm.group(1))
        except Exception:
            container = dtype = None
        if dtype in STRING_TYPES:
            start = int(sm.group(2) or 0)
            if start >= string_max(dtype):
                raise MajorFault(4, 20, f"Array subscript too large: {operand}")
            return _StrData(container, key, string_max(dtype)), start, "SINT"
    try:
        container, key, dtype = ctx.db._resolve(addr)
        val = container[key]
    except IndexError:
        raise MajorFault(4, 20, f"Array subscript too large: {operand}")
    except Exception:
        raise InstructionError(f"'{operand}' is not a tag (bit addresses cannot be copied)")
    if isinstance(container, list):
        return container, key, dtype
    if isinstance(val, list):
        return val, 0, dtype
    return _Single(container, key), 0, dtype


def layout(ctx) -> Layout:
    lay = getattr(ctx.db, "_layout", None)
    if lay is None or lay.types is not ctx.db._types:
        lay = Layout(ctx.db._types)
        ctx.db._layout = lay
    return lay


def _copy(ctx, args):
    ctx.guard(ctx.resolve(args[1]), args[1])
    src, si, st = region(ctx, args[0])
    dst, di, dt = region(ctx, args[1])
    length = int(num(ctx.read(args[2])))
    if length <= 0:
        return
    if "BOOL" in (st, dt):
        raise InstructionError("COP/CPS do not operate on BOOL arrays")
    lay = layout(ctx)
    if src is dst and si < di:
        # same array, Dest after Source: a forward byte copy, so data already copied is
        # read again (COP(a[0],a[1],n) replicates a[0])
        for k in range(min(length, len(dst) - di, len(src) - si)):
            dst[di + k] = src[si + k]
        return
    es = lay.size(dt)
    need = length * es
    buf = bytearray()
    i = si
    while len(buf) < need and i < len(src):
        buf += lay.encode(src[i], st)
        i += 1
    n = min(length, len(dst) - di)
    for k in range(n):
        chunk = bytes(buf[k * es:(k + 1) * es])
        if not chunk:
            break
        if len(chunk) < es:
            chunk += lay.encode(dst[di + k], dt)[len(chunk):]
        dst[di + k] = lay.decode(chunk, dt)


_COPY_NOTES = (
    "Copies Length elements *of the Dest type* as raw bytes from Source to Dest; no data "
    "conversion (use MOV for that). Source and Dest may be different types (e.g. a UDT into a "
    "DINT array) - see the byte layout notes in logixsim/isa/layout.py.",
    "Starting at an array element (Arr[3]) the copy continues into the following elements.",
    "Copy is clipped at the end of the destination array and at the end of the source tag "
    "(5580: the source tag size also limits the copy; confirmed: Logix Designer help, Copy "
    "File (COP), Synchronous Copy File (CPS)).",
    "Source and Dest in the same array with Dest after Source copy forward, so "
    "COP(Arr[0],Arr[1],n) replicates Arr[0] (confirmed: same topic).",
    "UNVERIFIED: VirtualControlStudio clips at the end of a member array; the help puts the "
    "limit at the end of the base tag (deferred).",
    "BOOL arrays are not supported (as documented for most array instructions).",
)


@instruction("COP", "Copy File", "Array (File)/Misc", "action",
             [Operand("Source", "tag"), Operand("Dest", "tag"), Operand("Length", "src", NUM)],
             page=556, languages=("LD", "ST"),
             display={"rows": [["Source", 0], ["Dest", 1], ["Length", 2]]},
             notes=_COPY_NOTES)
def cop(ctx, args, rung=True):
    if rung:
        _copy(ctx, args)
    return bool(rung)


@instruction("CPS", "Synchronous Copy File", "Array (File)/Misc", "action",
             [Operand("Source", "tag"), Operand("Dest", "tag"), Operand("Length", "src", NUM)],
             page=556, languages=("LD", "ST"),
             display={"rows": [["Source", 0], ["Dest", 1], ["Length", 2]]},
             notes=_COPY_NOTES + (
                 "On a controller CPS cannot be interrupted, so I/O or communication cannot "
                 "change Source/Dest during the copy. In VirtualControlStudio external writes are only "
                 "applied between scans, so COP and CPS are equally consistent.",))
def cps(ctx, args, rung=True):
    if rung:
        _copy(ctx, args)
    return bool(rung)


@instruction("FLL", "File Fill", "Array (File)/Misc", "action",
             [Operand("Source", "src", NUM), Operand("Dest", "tag"), Operand("Length", "src", NUM)],
             page=586, languages=("LD",),
             display={"rows": [["Source", 0], ["Dest", 1], ["Length", 2]]},
             notes=("Writes Source into Length elements starting at Dest, converted to the "
                    "element type (clipped at the end of the array).",
                    "Structure elements are filled byte-wise with Source's byte image, without "
                    "conversion (FLL 0 clears them) (confirmed: Logix Designer help, File Fill "
                    "(FLL)).", "UNVERIFIED: how the pattern lines up across elements whose size "
                    "is not a multiple of the Source size. Help text is silent on this."))
def fll(ctx, args, rung=True):
    if rung:
        v, vt = ctx.value(args[0])
        ctx.guard(ctx.resolve(args[1]), args[1])
        dst, di, dt = region(ctx, args[1])
        length = int(num(ctx.read(args[2])))
        n = max(0, min(length, len(dst) - di))
        lay = layout(ctx)
        for k in range(n):
            if dt in ("SINT", "INT", "DINT", "LINT", "REAL", "BOOL"):
                dst[di + k], _ = store_convert(v, vt, dt)
            else:
                size = lay.size(dt)
                pat = lay.encode(v, vt if vt in ("SINT", "INT", "DINT", "LINT", "REAL")
                                 else "DINT")
                data = (pat * (size // len(pat) + 1))[:size]
                dst[di + k] = lay.decode(data, dt)
    return bool(rung)


@instruction("SIZE", "Size In Elements", "Array (File)/Misc", "action",
             [Operand("Source", "tag"), Operand("Dimension To Vary", "imm"),
              Operand("Size", "dest", NUM)], page=611, languages=("LD", "ST"),
             display={"rows": [["Source", 0], ["Dim. To Vary", 1], ["Size", 2]]},
             notes=("Size = number of elements of the Source array (VirtualControlStudio arrays are "
                    "one-dimensional, so Dimension To Vary must be 0).",
                    "A string DATA member (e.g. Str.DATA[0]) returns its size, 82 for STRING "
                    "(confirmed: Logix Designer help, Size In Elements (SIZE)).",
                    "UNVERIFIED: a bare STRING tag also returns 82. Help text is silent on this."))
def size(ctx, args, rung=True):
    if rung:
        addr = ctx.db.dealias(ctx.resolve(args[0]))
        m = _STRING_DATA.match(addr)
        if m and ctx.dtype(m.group(1)) in STRING_TYPES:
            ctx.store(args[2], string_max(ctx.dtype(m.group(1))), "DINT")
            return bool(rung)
        container, key, dtype = ctx.db._resolve(addr)
        val = container[key] if not isinstance(container, list) else container
        if isinstance(val, list):
            n = len(val)
        elif dtype in STRING_TYPES:
            n = string_max(dtype)
        else:
            n = 1
        ctx.store(args[2], n, "DINT")
    return bool(rung)


_STRING_DATA = re.compile(r"^(.*)\.DATA(?:\[\s*\d+\s*\])?$")


# ---- CONTROL-based file instructions --------------------------------------------
def _ctl(ctx, c, m):
    return ctx.db.get(f"{c}.{m}")


def _cset(ctx, c, **kw):
    ctx.guard(c)
    for m, v in kw.items():
        ctx.db.set(f"{c}.{m}", v)


def _check_ctl(ctx, c, inst, negative_code=21):
    """Negative POS or LEN: major fault Type 4 Code 21 (FAL, FSC, STD, SRT topics);
    POS beyond LEN: Type 4 Code 20."""
    length, pos = _ctl(ctx, c, "LEN"), _ctl(ctx, c, "POS")
    if length < 0 or pos < 0:
        raise MajorFault(4, negative_code, f"{inst}: negative POS ({pos}) or LEN ({length}) in {c}")
    if length and pos > length:
        raise MajorFault(4, 20, f"{inst}: invalid POS ({pos}) or LEN ({length}) in {c}")
    return length, pos


def _mode(ctx, text):
    t = text.strip().upper()
    if t in ("ALL", "INC"):
        return t
    n = ctx.read(text)
    if not isinstance(n, int) or n <= 0:
        raise InstructionError(f"bad mode {text!r} (ALL, INC or a number of elements)")
    return int(n)


def numeric_running(ctx, c, mode) -> bool:
    """Numeric mode, triggered and not finished: it keeps running every scan
    whatever the rung does (FAL / FSC topics)."""
    if not isinstance(mode, int):
        return False
    pos, length = _ctl(ctx, c, "POS"), _ctl(ctx, c, "LEN")
    return (0 < pos < length and not _ctl(ctx, c, "DN") and not _ctl(ctx, c, "ER")
            and not _ctl(ctx, c, "IN"))


def _file_step(ctx, c, inst, mode, rung, work):
    """Common FAL/FSC control: returns after processing per the mode.
    ``work(pos)`` processes one element and returns False to stop."""
    if not rung:
        en, dn = _ctl(ctx, c, "EN"), _ctl(ctx, c, "DN")
        _cset(ctx, c, EN=False)
        if dn or (en and mode == "ALL"):
            _cset(ctx, c, DN=False, ER=False, POS=0)
            return
        if not numeric_running(ctx, c, mode):
            return
    length, pos = _check_ctl(ctx, c, inst)
    rising = not _ctl(ctx, c, "EN")
    if rung:
        _cset(ctx, c, EN=True)
    if _ctl(ctx, c, "DN") or _ctl(ctx, c, "ER"):
        return
    if mode == "INC" and not rising:
        return
    count = length if mode == "ALL" else 1 if mode == "INC" else mode
    done = 0
    while pos < length and done < count:
        _cset(ctx, c, POS=pos)
        cont = work(pos)
        done += 1
        pos += 1
        if cont is False:
            return
    if pos >= length:
        _cset(ctx, c, DN=True, POS=length)
    else:
        _cset(ctx, c, POS=pos)


_FILE_NOTES = (
    "Modes: ALL = every element in one scan on the false->true transition; INC = one element "
    "per false->true transition; a number N = N elements per scan once triggered by a "
    "false->true transition, continuing every scan until done whatever the rung does; EN "
    "follows the rung and, when the rung is already false at completion, DN and POS clear "
    "one scan later (confirmed: Logix Designer help, File Arithmetic and Logic (FAL); File "
    "Search and Compare (FSC)).",
    "Each element is processed with Control.POS = its index (use [Control.POS] in operands).",
    "Negative POS or LEN: major fault Type 4 Code 21 (confirmed: same topics). POS beyond "
    "LEN: Type 4 Code 20.",
    "DN set with POS = LEN at completion; rung false then clears EN, DN and POS (confirmed: "
    "same topics). UNVERIFIED: ER also cleared then. Help text is silent on this.",
    "Expression precedence: ( ), functions, **, negate/NOT, * / MOD, + -, AND, XOR, OR "
    "(confirmed: same topics); comparisons on one lowest level (FSC topic).",
    "Prescan: no action, the CONTROL bits are left alone (confirmed: same topics).",
)


@instruction("FAL", "File Arithmetic and Logic", "Array (File)/Misc", "action",
             [Operand("Control", "tag", ("CONTROL",)), Operand("Length", "imm"),
              Operand("Position", "imm"), Operand("Mode", "imm"), Operand("Dest", "elem"),
              Operand("Expression", "expr")], page=565, languages=("LD",),
             display={"rows": [["Control", 0], ["Length", ".LEN"], ["Position", ".POS"],
                               ["Mode", 3], ["Dest", 4], ["Expression", 5]],
                      "bits": ["EN", "DN", "ER"]},
             notes=_FILE_NOTES + (
                 "An overflow in the expression sets ER and stops the instruction with POS at "
                 "that element (confirmed: Logix Designer help, File Arithmetic and Logic "
                 "(FAL)). UNVERIFIED: whether Dest is written for that element "
                 "(VirtualControlStudio does not). Help text is silent on this.",))
def fal(ctx, args, rung=True):
    c = args[0]
    mode = _mode(ctx, args[3])
    expr = ",".join(args[5:])

    def work(pos):
        val, vt, over = evaluate_full(ctx, expr)
        if over:
            ctx.overflow()
            _cset(ctx, c, ER=True)
            return False
        ctx.store(args[4], val, vt)
        return True

    _file_step(ctx, c, "FAL", mode, rung, work)
    return bool(rung)


@instruction("FSC", "File Search and Compare", "Array (File)/Misc", "action",
             [Operand("Control", "tag", ("CONTROL",)), Operand("Length", "imm"),
              Operand("Position", "imm"), Operand("Mode", "imm"), Operand("Expression", "expr")],
             page=589, languages=("LD",),
             display={"rows": [["Control", 0], ["Length", ".LEN"], ["Position", ".POS"],
                               ["Mode", 3], ["Expression", 4]],
                      "bits": ["EN", "DN", "ER", "FD", "IN"]},
             notes=_FILE_NOTES + (
                 "When the expression is true for an element: FD and IN set, POS = that "
                 "element, search pauses. Clear IN to continue with the next element.",))
def fsc(ctx, args, rung=True):
    c = args[0]
    mode = _mode(ctx, args[3])
    expr = ",".join(args[4:])
    if rung and _ctl(ctx, c, "IN"):
        _cset(ctx, c, EN=True)
        return bool(rung)
    if rung and _ctl(ctx, c, "FD") and not _ctl(ctx, c, "IN"):
        # resume after a found element
        _cset(ctx, c, FD=False, POS=_ctl(ctx, c, "POS") + 1)

    def work(pos):
        val, _, _ = evaluate_full(ctx, expr)
        if val:
            _cset(ctx, c, FD=True, IN=True, POS=pos)
            return False
        return True

    if not rung:
        if _ctl(ctx, c, "IN") and isinstance(mode, int) and not _ctl(ctx, c, "DN"):
            _cset(ctx, c, EN=False)                 # numeric search paused on a find
            return bool(rung)
        if not numeric_running(ctx, c, mode):
            _cset(ctx, c, FD=False, IN=False)
    _file_step(ctx, c, "FSC", mode, rung, work)
    return bool(rung)


def _elements(ctx, operand, length):
    seq, start, dtype = region(ctx, operand)
    if len(seq) - start < length:
        raise MajorFault(4, 20, f"{operand}: LEN {length} beyond the end of the array")
    return seq, start, dtype


def _stat_instr(ctx, args, rung, compute, dest_index, ctl_index, inst, negative_code=21):
    c = args[ctl_index]
    if not rung:
        _cset(ctx, c, EN=False, DN=False, ER=False, POS=0)
        return
    if _ctl(ctx, c, "EN") or _ctl(ctx, c, "ER"):
        return
    length, _ = _check_ctl(ctx, c, inst, negative_code)
    _cset(ctx, c, EN=True)
    if inst == "SRT":                              # sorts the array in place
        ctx.guard(ctx.resolve(args[0]), args[0])
    seq, start, dtype = _elements(ctx, args[0], length)
    bad = compute(seq, start, dtype, length, dest_index)
    if bad is not None:                    # overflow at element ``bad``
        _cset(ctx, c, ER=True, POS=bad)
        return
    _cset(ctx, c, DN=True, POS=length)


def _f32_sum(values):
    """REAL running sum; returns (sum, index of the element that overflowed or None)."""
    total = 0.0
    for i, v in enumerate(values):
        total = f32(total + v)
        if math.isinf(total):
            return total, i
    return total, None


_STAT_NOTES = ("Executes on the false->true rung transition over Control.LEN elements starting "
               "at the Array operand; DN set when done; rung false clears EN, DN, ER, POS.",
               "Only one-dimensional arrays (Dimension To Vary = 0).",
               "The whole array is processed in one scan (no incremental POS) (confirmed: Logix "
               "Designer help, File Standard Deviation (STD); File Average (AVE); File Sort "
               "(SRT)).")


@instruction("AVE", "File Average", "Array (File)/Misc", "action",
             [Operand("Array", "tag", NUM), Operand("Dimension To Vary", "imm"),
              Operand("Dest", "dest", NUM), Operand("Control", "tag", ("CONTROL",)),
              Operand("Length", "imm"), Operand("Position", "imm")], page=581, languages=("LD",),
             display={"rows": [["Array", 0], ["Dest", 2], ["Control", 3],
                               ["Length", "3.LEN"], ["Position", "3.POS"]],
                      "bits": ["EN", "DN", "ER"], "bits_op": 3},
             notes=_STAT_NOTES + ("Average computed in REAL; an integer Dest is rounded.",
                                  "An overflow while adding sets ER, leaves POS at that element "
                                  "and stops; Dest is not written (confirmed: Logix Designer "
                                  "help, File Average (AVE)).",))
def ave(ctx, args, rung=True):
    def compute(seq, start, dtype, n, di):
        total, bad = _f32_sum(num(seq[start + i]) for i in range(n))
        if bad is not None:
            ctx.overflow()
            return bad
        ctx.store(args[di], f32(total / n) if n else 0.0, "REAL")
        return None
    c = args[3]
    if rung and _ctl(ctx, c, "LEN") == 0:
        raise MajorFault(4, 20, f"AVE: LEN 0 in {c}")
    _stat_instr(ctx, args, rung, compute, 2, 3, "AVE", negative_code=20)
    return bool(rung)


@instruction("STD", "File Standard Deviation", "Array (File)/Misc", "action",
             [Operand("Array", "tag", NUM), Operand("Dimension To Vary", "imm"),
              Operand("Dest", "dest", ("REAL",)), Operand("Control", "tag", ("CONTROL",)),
              Operand("Length", "imm"), Operand("Position", "imm")], page=606, languages=("LD",),
             display={"rows": [["Array", 0], ["Dest", 2], ["Control", 3],
                               ["Length", "3.LEN"], ["Position", "3.POS"]],
                      "bits": ["EN", "DN", "ER"], "bits_op": 3},
             notes=_STAT_NOTES + (
                 "Negative POS or LEN: major fault Type 4 Code 21 (confirmed: Logix Designer "
                 "help, File Standard Deviation (STD)).",
                 "An overflow sets ER with POS at the element that caused it, and the "
                 "instruction does not execute again until ER is cleared (rung false clears "
                 "it) (confirmed: same topic).",
                 "UNVERIFIED: sample standard deviation (divides by N-1); the formula did not "
                 "survive in the help text. Help text is silent on this."))
def std(ctx, args, rung=True):
    def compute(seq, start, dtype, n, di):
        vals = [float(num(seq[start + i])) for i in range(n)]
        total, bad = _f32_sum(vals)
        if bad is None and n > 1:
            mean = total / n
            _, bad = _f32_sum((v - mean) ** 2 for v in vals)
        if bad is not None:
            ctx.overflow()
            return bad
        out = math.sqrt(sum((v - total / n) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        ctx.store(args[di], f32(out), "REAL")
        return None
    _stat_instr(ctx, args, rung, compute, 2, 3, "STD")
    return bool(rung)


@instruction("SRT", "File Sort", "Array (File)/Misc", "action",
             [Operand("Array", "tag", NUM), Operand("Dimension To Vary", "imm"),
              Operand("Control", "tag", ("CONTROL",)), Operand("Length", "imm"),
              Operand("Position", "imm")], page=601, languages=("LD",),
             display={"rows": [["Array", 0], ["Control", 2], ["Length", "2.LEN"],
                               ["Position", "2.POS"]], "bits": ["EN", "DN", "ER"], "bits_op": 2},
             notes=_STAT_NOTES + ("Sorts the elements into ascending order.",
                                  "Negative POS or LEN: major fault Type 4 Code 21 (confirmed: "
                                  "Logix Designer help, File Sort (SRT)).",))
def srt(ctx, args, rung=True):
    def compute(seq, start, dtype, n, di):
        part = sorted(seq[start + i] for i in range(n))
        for i, v in enumerate(part):
            seq[start + i] = v
        return None
    _stat_instr(ctx, args, rung, compute, None, 2, "SRT")
    return bool(rung)


