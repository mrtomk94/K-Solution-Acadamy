"""Instruction catalog: every documented Logix instruction VirtualControlStudio knows about,
including those it does not execute, with the reason.

Pages refer to *Logix 5000 Controllers General Instructions Reference Manual*,
publication 1756-RM018A-EN-P (September 2025; formerly 1756-RM003). The table of
contents of that edition was retrieved for this work; the page numbers come from
it. Process/drives, motion and safety instructions are documented in separate
Rockwell manuals (1756-RM006, MOTION-RM002, 1756-RM099) that were not reviewed;
those families are listed for recognition only and are not exhaustive.
"""
from __future__ import annotations

from .spec import SPECS

# status values
MISSING = "missing"            # documented, planned, not implemented yet
UNSUPPORTED = "unsupported"    # unsupported by design (needs hardware / certification / SFC)

# (mnemonic, title, family, page, status, reason)
_GENERAL = [
    ("ASO", "Alarm Set Operation", "Alarm", 17, MISSING, "alarm instructions not implemented"),
    ("ALMA", "Analog Alarm", "Alarm", 20, MISSING, "alarm instructions not implemented"),
    ("ALMD", "Digital Alarm", "Alarm", 53, MISSING, "alarm instructions not implemented"),
    ("REF", "Reference", "Input/Output", 214, MISSING, "not implemented"),
    ("IsINF", "Is Infinity", "Compare", 378, MISSING, "not implemented"),
    ("IsNAN", "Is Not a Number", "Compare", 380, MISSING, "not implemented"),
    ("BTDT", "Bit Field Distribute with Target", "Move/Logical", 490, MISSING, "FBD form"),
    ("MVMT", "Masked Move with Target", "Move/Logical", 526, MISSING, "FBD form"),
    ("BAND", "Boolean AND", "Move/Logical", 538, MISSING, "FBD form"),
    ("BXOR", "Boolean Exclusive OR", "Move/Logical", 542, MISSING, "FBD form"),
    ("BNOT", "Boolean NOT", "Move/Logical", 546, MISSING, "FBD form"),
    ("BOR", "Boolean OR", "Move/Logical", 550, MISSING, "FBD form"),
    ("EOT", "End of Transition", "Program Control", 671, UNSUPPORTED, "SFC is not simulated"),
    ("SFP", "Pause SFC", "Program Control", 690, UNSUPPORTED, "SFC is not simulated"),
    ("SFR", "Reset SFC", "Program Control", 692, UNSUPPORTED, "SFC is not simulated"),
    ("EVENT", "Trigger Event Task", "Program Control", 696, MISSING,
     "event tasks are not simulated yet"),
    ("UNK", "Unknown Instruction", "Program Control", 703, UNSUPPORTED,
     "placeholder for an instruction the controller does not know"),
    ("DTR", "Data Transition", "Special", 710, MISSING, "not implemented"),
    ("DDT", "Diagnostic Detect", "Special", 713, MISSING, "not implemented"),
    ("FBC", "File Bit Comparison", "Special", 721, MISSING, "not implemented"),
    ("PID", "Proportional Integral Derivative", "Special", 729, MISSING,
     "planned (needs loop-update timing model)"),
    ("ATAN2", "Two-Argument Arctangent", "Trigonometric", 767, MISSING, "ST/FBD function"),
    ("LV", "License Validation", "License", 866, UNSUPPORTED, "no license services"),
    # ASCII serial port instructions (General Instructions RM, ASCII Serial Port chapter)
    ("ABL", "ASCII Test for Buffer Line", "ASCII Serial Port", None, UNSUPPORTED,
     "no serial port in the simulator"),
    ("ACB", "ASCII Chars in Buffer", "ASCII Serial Port", None, UNSUPPORTED, "no serial port"),
    ("ACL", "ASCII Clear Buffer", "ASCII Serial Port", None, UNSUPPORTED, "no serial port"),
    ("AHL", "ASCII Handshake Lines", "ASCII Serial Port", None, UNSUPPORTED, "no serial port"),
    ("ARD", "ASCII Read", "ASCII Serial Port", None, UNSUPPORTED, "no serial port"),
    ("ARL", "ASCII Read Line", "ASCII Serial Port", None, UNSUPPORTED, "no serial port"),
    ("AWA", "ASCII Write Append", "ASCII Serial Port", None, UNSUPPORTED, "no serial port"),
    ("AWT", "ASCII Write", "ASCII Serial Port", None, UNSUPPORTED, "no serial port"),
]

# Families documented in other manuals; recognised so Verify can explain them.
_PROCESS = ("ALM DEDT D2SD D3SD FGEN HLL HMIBC INTG LDL2 LDLG MAVE MAXC MINC MMC MSTD MUX "
            "PI PIDE PMUL POSP RLIM RMPS SCL SCRV SEL SETD RESD SNEG SOC SRTP SSUM TOT UPDN "
            "HPF LPF NTCH DFF JKFF DERV ESEL ").split()
_MOTION = ("MAAT MAFR MAG MAH MAJ MAM MAOC MAPC MAR MAS MASD MASR MATC MAW MCCD MCCM MCCP MCD "
           "MCLM MCPM MCS MCSD MCSR MCSV MCT MCTO MCTP MCTPO MDAC MDCC MDF MDO MDOC MDR MDS "
           "MDW MGS MGSD MGSP MGSR MRAT MRHD MRP MSF MSO").split()
_SAFETY = ("CROUT DCA DCAF DCM DCS DCSRT DCST DCSTL DCSTM DIN EMSS ENPEN EPMS ESTOP FPMS FSBM "
           "LC RIN ROUT SMAT THRS THRSE TSAM TSSM AVC CBCM CBIM CBSSM SFX SDI SLS SMT SPV "
           "SS1 SS2 SOS STO SBC").split()
_PHASE = ("PATT PCLF PCMD PDET POVR PPD PRNP PSC PXRQ SATT SCLF SCMD SOVR SASI").split()


def catalog() -> list[dict]:
    """Every known instruction with its VirtualControlStudio status."""
    out: dict[str, dict] = {}
    for mn, spec in SPECS.items():
        if mn != spec.mnemonic:
            continue
        out[mn] = {"mnemonic": mn, "title": spec.title, "family": spec.family,
                   "page": spec.page, "status": spec.status, "evidence": spec.evidence,
                   "languages": list(spec.languages), "aliases": list(spec.aliases),
                   "reason": ""}
    for mn, title, fam, page, status, reason in _GENERAL:
        out.setdefault(mn.upper(), {"mnemonic": mn, "title": title, "family": fam,
                                    "page": page, "status": status, "evidence": "",
                                    "languages": [], "aliases": [], "reason": reason})
    for fam, names, status, reason in (
            ("Process/Drives", _PROCESS, MISSING,
             "process/drives instruction (1756-RM006) not implemented"),
            ("Motion", _MOTION, UNSUPPORTED, "motion needs axes and a motion planner"),
            ("Safety", _SAFETY, UNSUPPORTED, "safety instructions are not simulated "
                                             "(certified safety task)"),
            ("Equipment Phase/Sequence", _PHASE, UNSUPPORTED,
             "PhaseManager / equipment sequences are not simulated")):
        for mn in names:
            out.setdefault(mn, {"mnemonic": mn, "title": "", "family": fam, "page": None,
                                "status": status, "evidence": "", "languages": [],
                                "aliases": [], "reason": reason})
    return sorted(out.values(), key=lambda e: (e["family"], e["mnemonic"]))


def lookup(name: str) -> dict | None:
    up = name.upper()
    spec = SPECS.get(up)
    if spec is not None:
        return {"mnemonic": spec.mnemonic, "status": spec.status, "reason": ""}
    for e in catalog():
        if e["mnemonic"].upper() == up:
            return e
    return None
