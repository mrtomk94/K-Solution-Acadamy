"""Compute/math, trigonometric, advanced math and math conversion instructions
(RM: p.427-485, 749-832)."""
from __future__ import annotations

import math

from .expr import _Eval, evaluate_full
from .spec import INT, NUM, Operand, instruction
from .values import INT_BITS, f32, math_type, num

_MATH_NOTES = (
    "SINT/INT operands are promoted; the operation is done in REAL if any source is REAL, "
    "otherwise in DINT (LINT if a LINT is involved).",
    "The result is converted to the destination type: REAL->integer rounds to nearest "
    "(ties to even); integers that do not fit keep their low bits and set S:V.",
    "Sets S:N, S:Z, S:V; arithmetic overflow raises minor fault Type 4 Code 4.",
)

_BOX3 = {"rows": [["Source A", 0], ["Source B", 1],
                  ["Dest", 2]]}
_BOX2 = {"rows": [["Source", 0], ["Dest", 1]]}


def _finish(ctx, dest, value, vtype, over=False, carry=None):
    ctx.store(dest, value, vtype)
    if over:
        ctx.overflow()
    if carry is not None:
        ctx.status.C = carry


def _operands(ctx, a, b, dest=None, real_if_dest=False):
    (va, ta), (vb, tb) = ctx.value(a), ctx.value(b)
    types = [ta, tb]
    if real_if_dest and dest is not None and ctx.dtype(dest) == "REAL":
        types.append("REAL")
    t = math_type(*types)
    va, vb = num(va), num(vb)
    if t == "REAL":
        return f32(va), f32(vb), t
    return int(va) if not isinstance(va, float) else va, \
        int(vb) if not isinstance(vb, float) else vb, t


def _binary(mn, title, page, extra_notes=(), real_if_dest=False):
    def deco(compute):
        @instruction(mn, title, "Compute/Math", "action",
                     [Operand("Source A", "src", NUM), Operand("Source B", "src", NUM),
                      Operand("Dest", "dest", NUM)], page=page, languages=("LD",),
                     display=_BOX3, notes=_MATH_NOTES + tuple(extra_notes))
        def run(ctx, args, rung=True):
            if rung:
                a, b, t = _operands(ctx, args[0], args[1], args[2], real_if_dest)
                ev = _Eval(ctx)
                val, vt = compute(ev, a, b, t)
                carry = None
                if t in INT_BITS and mn in ("ADD", "SUB"):
                    bits = INT_BITS[t]
                    mask = (1 << bits) - 1
                    ua, ub = a & mask, b & mask
                    carry = (ua + ub > mask) if mn == "ADD" else (ua < ub)
                _finish(ctx, args[2], val, vt, ev.overflow, carry)
            return bool(rung)
        run.__name__ = mn.lower()
        return run
    return deco


@_binary("ADD", "Add", 434, ("S:C is set on a carry out of the most significant bit of the "
                             "integer computation; REAL leaves S:C alone (confirmed: Logix "
                             "Designer help, Math Status Flags).",))
def _add(ev, a, b, t):
    return ev.bin("+", (a, t), (b, t))


@_binary("SUB", "Subtract", 476, ("UNVERIFIED: S:C borrow semantics (VirtualControlStudio sets S:C "
                                  "on an unsigned borrow). Help text is silent on this.",))
def _sub(ev, a, b, t):
    return ev.bin("-", (a, t), (b, t))


@_binary("MUL", "Multiply", 458)
def _mul(ev, a, b, t):
    return ev.bin("*", (a, t), (b, t))


@_binary("DIV", "Divide", 445,
         ("All-integer operands with an integer Dest: the fractional part is truncated. "
          "A REAL source or a REAL Dest: computed in REAL (rounded if Dest is an integer).",
          "Source B = 0: the result is Source A (converted to Dest), S:V set and minor fault "
          "Type 4 Code 4 (confirmed: Logix Designer help, Divide (DIV)). The '/' operator "
          "inside CPT/CMP/ST expressions is unchanged (0 or +/-INF)."),
         real_if_dest=True)
def _div(ev, a, b, t):
    if b == 0:
        ev.overflow = True
        return a, t
    return ev.bin("/", (a, t), (b, t))


@_binary("MOD", "Modulo", 451,
         ("Dest = Source A - (Source B * TRN(Source A / Source B)): the remainder has the sign "
          "of Source A.", "Source B = 0: the result is 0 (0.0 for REAL), S:V set and minor "
                          "fault Type 4 Code 4 (confirmed: Logix Designer help, Modulo (MOD))."))
def _mod(ev, a, b, t):
    if b == 0:
        ev.overflow = True
        return (0.0 if t == "REAL" else 0), t
    return ev.bin("MOD", (a, t), (b, t))


def _unary(mn, title, page, family="Compute/Math", types=NUM, notes=(), aliases=(),
           languages=("LD",)):
    def deco(compute):
        @instruction(mn, title, family, "action",
                     [Operand("Source", "src", types), Operand("Dest", "dest", NUM)],
                     page=page, languages=languages, display=_BOX2,
                     notes=tuple(notes), aliases=aliases)
        def run(ctx, args, rung=True):
            if rung:
                v, t = ctx.value(args[0])
                if t == "BOOL":
                    v, t = int(bool(v)), "DINT"
                ev = _Eval(ctx)
                ev.dest_type = ctx.dtype(args[1])
                val, vt = compute(ev, num(v), t if t in ("REAL", "LINT") else "DINT")
                _finish(ctx, args[1], val, vt, ev.overflow)
            return bool(rung)
        run.__name__ = mn.lower()
        return run
    return deco


@_unary("NEG", "Negate", 464, notes=("Dest = 0 - Source; negating the most negative integer "
                                     "overflows (S:V).",))
def _neg(ev, v, t):
    return ev.fn("NEG", v, t)


@_unary("ABS", "Absolute Value", 428, notes=("Dest = |Source|.",))
def _abs(ev, v, t):
    return ev.fn("ABS", v, t)


@_unary("SQR", "Square Root", 470, aliases=("SQRT",),
        notes=("Dest = square root of |Source| (a negative Source uses its absolute value).",
               "Computed in REAL; an integer Dest is rounded."))
def _sqr(ev, v, t):
    return ev.fn("SQR", v, t)


_TRIG_NOTES = ("Computed in REAL (radians); an integer Dest is rounded.",
               "Domain errors give NaN in a REAL Dest with S:V and an overflow minor fault "
               "(e.g. ASN of 2); LN/LOG of 0 give -INF and of +INF give +INF, both with the "
               "overflow (confirmed: Logix Designer help, Arc Sine (ASN, ASIN); Arc Cosine "
               "(ACS, ACOS); Natural Log (LN); Log Base 10 (LOG)).",
               "UNVERIFIED: value written to an integer Dest on a domain error "
               "(VirtualControlStudio writes 0). Help text is silent on this.")
for _mn, _title, _page, _fn, _alias in (
        ("SIN", "Sine", 776, "SIN", ()), ("COS", "Cosine", 771, "COS", ()),
        ("TAN", "Tangent", 782, "TAN", ()), ("ASN", "Arc Sine", 755, "ASN", ("ASIN",)),
        ("ACS", "Arc Cosine", 749, "ACS", ("ACOS",)), ("ATN", "Arc Tangent", 761, "ATN", ("ATAN",)),
        ("LN", "Natural Log", 794, "LN", ()), ("LOG", "Log Base 10", 788, "LOG", ()),
        ("DEG", "Degrees", 816, "DEG", ()), ("RAD", "Radians", 821, "RAD", ())):
    _family = "Trigonometric" if _page >= 749 and _page < 788 else \
        ("Advanced Math" if _page < 807 else "Math Conversion")

    def _make(fname):
        def compute(ev, v, t):
            return ev.fn(fname, v, t)
        return compute
    _unary(_mn, _title, _page, _family, notes=_TRIG_NOTES, aliases=_alias)(_make(_fn))


@_unary("TRN", "Truncate", 827, "Math Conversion", aliases=("TRUNC",),
        notes=("Removes the fractional part of a REAL (toward zero) without rounding.",))
def _trn(ev, v, t):
    return ev.fn("TRN", v, t)


@_unary("TOD", "Convert to BCD", 807, "Math Conversion", types=INT, aliases=("TO_BCD",),
        notes=("Integer -> BCD. A negative Source writes 0; a Source > 99,999,999 writes all "
               "nines in the Dest width (16#9999_9999 DINT, 16#9999 INT, 16#99 SINT) "
               "(confirmed: Logix Designer help, Convert to BCD (TOD)).",
               "UNVERIFIED: S:V and minor fault Type 4 Code 4 on either case "
               "(VirtualControlStudio sets them). Help text is silent on this."))
def _tod(ev, v, t):
    if v > 99_999_999:
        ev.overflow = True
        dest = getattr(ev, "dest_type", "DINT")
        nines = {"SINT": (0x99, 8), "INT": (0x9999, 16)}.get(dest, (0x99999999, 32))
        return nines[0] - (1 << nines[1]), ("DINT" if nines[1] == 32 else dest)
    return ev.fn("TOD", v, t)


@_unary("FRD", "Convert to Integer", 812, "Math Conversion", types=INT, aliases=("BCD_TO",),
        notes=("BCD -> integer. UNVERIFIED: handling of invalid BCD nibbles (> 9). Help "
               "text is silent on this.",))
def _frd(ev, v, t):
    return ev.fn("FRD", v, t)


@instruction("XPY", "X to the Power of Y", "Advanced Math", "action",
             [Operand("Source X", "src", NUM), Operand("Source Y", "src", NUM),
              Operand("Dest", "dest", NUM)], page=800, languages=("LD",), aliases=("EXPT",),
             display={"rows": [["Source X", 0], ["Source Y", 1],
                               ["Dest", 2]]},
             notes=("Dest = X ** Y computed in REAL.",
                    "A negative X with a non-integer Y sets S:V. UNVERIFIED: Dest value then. "
                    "Help text is silent on this."))
def xpy(ctx, args, rung=True):
    if rung:
        x, y = num(ctx.read(args[0])), num(ctx.read(args[1]))
        ev = _Eval(ctx)
        val, vt = ev.bin("**", (x, "REAL"), (y, "REAL"))
        _finish(ctx, args[2], val, vt, ev.overflow)
    return bool(rung)


@instruction("CPT", "Compute", "Compute/Math", "action",
             [Operand("Dest", "dest", NUM), Operand("Expression", "expr")], page=441,
             languages=("LD",),
             display={"rows": [["Dest", 0], ["Expression", 1]]},
             notes=("Evaluates the expression and stores it in Dest with the usual conversion.",
                    "Operators: + - * / MOD ** AND OR XOR NOT; functions ABS ACS ASN ATN COS DEG "
                    "FRD LN LOG RAD SIN SQR TAN TOD TRN.",
                    "Pure-integer expressions stay integer (integer division truncates). If "
                    "the expression uses SIN, COS, TAN, ASN, ACS, ATN, LN, LOG, DEG or RAD every "
                    "operand is converted to REAL first (confirmed: Logix Designer help, "
                    "Compute (CPT)). Otherwise each operation is typed by its own operands "
                    "(REAL if either is REAL): the topic's REAL-operand rule names LREAL, which "
                    "VirtualControlStudio does not model.",
                    "Precedence (highest first): ( ), functions, **, negate/NOT, * / MOD, + -, "
                    "AND, XOR, OR (confirmed: Logix Designer help, Compute (CPT)). UNVERIFIED: "
                    "comparisons are not CPT operators in the help; VirtualControlStudio accepts "
                    "them at the lowest level, as for CMP. Help text is silent on this."))
def cpt(ctx, args, rung=True):
    if rung:
        val, vt, over = evaluate_full(ctx, ",".join(args[1:]), promote="functions")
        if isinstance(val, float) and math.isnan(val) and ctx.dtype(args[0]) != "REAL":
            over = True
        _finish(ctx, args[0], val, vt, over)
    return bool(rung)
