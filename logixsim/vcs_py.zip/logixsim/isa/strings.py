"""ASCII string and string conversion instructions (RM: p.833-865).

STRING values are held as Python text (LEN = number of characters, at most 82).
"""
from __future__ import annotations

import re
import struct

from .core import InstructionError
from .spec import INT, NUM, Operand, instruction
from ..model import string_max
from .values import f32, num, store_convert

MAX = 82
_S = ("STRING",)
_LEN_NOTES = ("A result longer than the destination (82 characters) is truncated and raises "
              "minor fault Type 4 Code 52 (output string larger than destination) (confirmed "
              "for MID, DELETE and RTOS: Logix Designer help, Middle String (MID); String "
              "Delete (DELETE); REAL to String (RTOS)). CONCAT uses Code 51 instead (confirmed: "
              "Logix Designer help, String Concatenate (CONCAT)). UNVERIFIED: the code for "
              "INSERT, DTOS, UPPER and LOWER. Help text is silent on this.",)
_START_NOTE = ("Start / Quantity outside the source string: minor fault Type 4 Code 56 "
               "(confirmed: Logix Designer help, String Delete (DELETE); Find String (FIND); "
               "Insert String (INSERT); Middle String (MID)). UNVERIFIED: Dest unchanged. Help "
               "text is silent on this.",)


def _text(ctx, operand) -> str:
    v = ctx.read(operand)
    if not isinstance(v, str):
        raise InstructionError(f"'{operand}' is not a STRING")
    return v


def _out(ctx, dest, text, code=52):
    try:
        mx = string_max(ctx.dtype(dest))      # STRING 82; user string types their own size
    except Exception:
        mx = MAX
    if len(text) > mx:
        ctx.minor_fault(4, code, f"String result longer than {mx} characters")
        text = text[:mx]
    ctx.write(dest, text)


def _bad_start(ctx, msg):
    ctx.minor_fault(4, 56, msg)


def _box(*labels):
    rows = []
    for i, lab in enumerate(labels):
        rows.append([lab, i])
    return {"rows": rows}


@instruction("CONCAT", "String Concatenate", "ASCII String", "action",
             [Operand("Source A", "src", _S), Operand("Source B", "src", _S),
              Operand("Dest", "dest", _S)], page=842,
             display=_box("Source A", "Source B", "Dest"),
             notes=("Dest = Source A followed by Source B.",) + _LEN_NOTES)
def concat(ctx, args, rung=True):
    if rung:
        _out(ctx, args[2], _text(ctx, args[0]) + _text(ctx, args[1]), code=51)
    return bool(rung)


@instruction("DELETE", "String Delete", "ASCII String", "action",
             [Operand("Source", "src", _S), Operand("Quantity", "src", INT),
              Operand("Start", "src", INT), Operand("Dest", "dest", _S)], page=846,
             display=_box("Source", "Quantity", "Start", "Dest"),
             notes=("Dest = Source with Quantity characters removed starting at Start "
                    "(1 = first character).",) + _START_NOTE)
def delete(ctx, args, rung=True):
    if rung:
        s = _text(ctx, args[0])
        qty, start = int(num(ctx.read(args[1]))), int(num(ctx.read(args[2])))
        if start < 1 or qty < 0 or start - 1 + qty > len(s):
            _bad_start(ctx, f"DELETE start {start} / quantity {qty} outside '{s}'")
        else:
            _out(ctx, args[3], s[:start - 1] + s[start - 1 + qty:])
    return bool(rung)


@instruction("FIND", "Find String", "ASCII String", "action",
             [Operand("Source", "src", _S), Operand("Search", "src", _S),
              Operand("Start", "src", INT), Operand("Result", "dest", INT)], page=834,
             display=_box("Source", "Search", "Start", "Result"),
             notes=("Result = position (1-based) of Search in Source, searching from Start; "
                    "0 when not found.",) + _START_NOTE)
def find(ctx, args, rung=True):
    if rung:
        s, sub = _text(ctx, args[0]), _text(ctx, args[1])
        start = int(num(ctx.read(args[2])))
        if start < 1 or start > max(len(s), 1):
            _bad_start(ctx, f"FIND start {start} outside '{s}'")
        else:
            ctx.store(args[3], s.find(sub, start - 1) + 1, "DINT", flags=False)
    return bool(rung)


@instruction("INSERT", "Insert String", "ASCII String", "action",
             [Operand("Source A", "src", _S), Operand("Source B", "src", _S),
              Operand("Start", "src", INT), Operand("Dest", "dest", _S)], page=836,
             display=_box("Source A", "Source B", "Start", "Dest"),
             notes=("Dest = Source A with Source B inserted so that it begins at position "
                    "Start.",) + _START_NOTE + _LEN_NOTES)
def insert(ctx, args, rung=True):
    if rung:
        a, b = _text(ctx, args[0]), _text(ctx, args[1])
        start = int(num(ctx.read(args[2])))
        if start < 1 or start > len(a) + 1:
            _bad_start(ctx, f"INSERT start {start} outside '{a}'")
        else:
            _out(ctx, args[3], a[:start - 1] + b + a[start - 1:])
    return bool(rung)


@instruction("MID", "Middle String", "ASCII String", "action",
             [Operand("Source", "src", _S), Operand("Quantity", "src", INT),
              Operand("Start", "src", INT), Operand("Dest", "dest", _S)], page=839,
             display=_box("Source", "Quantity", "Start", "Dest"),
             notes=("Dest = Quantity characters of Source beginning at Start.",) + _START_NOTE)
def mid(ctx, args, rung=True):
    if rung:
        s = _text(ctx, args[0])
        qty, start = int(num(ctx.read(args[1]))), int(num(ctx.read(args[2])))
        if start < 1 or qty < 0 or start - 1 + qty > len(s):
            _bad_start(ctx, f"MID start {start} / quantity {qty} outside '{s}'")
        else:
            _out(ctx, args[3], s[start - 1:start - 1 + qty])
    return bool(rung)


@instruction("UPPER", "Upper Case", "ASCII Conversion", "action",
             [Operand("Source", "src", _S), Operand("Dest", "dest", _S)], page=863,
             display=_box("Source", "Dest"), notes=("Letters a-z become A-Z.",))
def upper(ctx, args, rung=True):
    if rung:
        _out(ctx, args[1], "".join(c.upper() if "a" <= c <= "z" else c
                                   for c in _text(ctx, args[0])))
    return bool(rung)


@instruction("LOWER", "Lower Case", "ASCII Conversion", "action",
             [Operand("Source", "src", _S), Operand("Dest", "dest", _S)], page=853,
             display=_box("Source", "Dest"), notes=("Letters A-Z become a-z.",))
def lower(ctx, args, rung=True):
    if rung:
        _out(ctx, args[1], "".join(c.lower() if "A" <= c <= "Z" else c
                                   for c in _text(ctx, args[0])))
    return bool(rung)


@instruction("DTOS", "DINT to String", "ASCII Conversion", "action",
             [Operand("Source", "src", INT), Operand("Dest", "dest", _S)], page=851,
             display=_box("Source", "Dest"), notes=("Dest = decimal text of Source.",))
def dtos(ctx, args, rung=True):
    if rung:
        _out(ctx, args[1], str(int(num(ctx.read(args[0])))))
    return bool(rung)


def _real_text(x: float) -> str:
    """Shortest text that reads back as the same REAL."""
    for digits in range(1, 10):
        t = f"{x:.{digits}g}"
        if struct.unpack("<f", struct.pack("<f", float(t)))[0] == x:
            return t
    return f"{x:.9g}"


@instruction("RTOS", "REAL to String", "ASCII Conversion", "action",
             [Operand("Source", "src", NUM), Operand("Dest", "dest", _S)], page=856,
             display=_box("Source", "Dest"),
             notes=("Dest = text of the REAL value. UNVERIFIED: the controller's exact number "
                    "format (VirtualControlStudio writes the shortest text that reads back exactly, e.g. "
                    "'1.5', '1e+20'). Help text is silent on this.",))
def rtos(ctx, args, rung=True):
    if rung:
        _out(ctx, args[1], _real_text(f32(num(ctx.read(args[0])))))
    return bool(rung)


_INT_FIRST = re.compile(r"-?\d+")
_REAL_FIRST = re.compile(r"-?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?")


def _store_number(ctx, dest, value, vtype):
    """Write a converted number; out of range for Dest is minor fault Type 4 Code 53."""
    out, over = store_convert(value, vtype, ctx.dtype(dest))
    ctx.write(dest, out)
    ctx.set_flags(out)
    if over:
        ctx.status.V = True
        ctx.minor_fault(4, 53, f"Converted number does not fit {ctx.dtype(dest)}")


@instruction("STOD", "String to DINT", "ASCII Conversion", "action",
             [Operand("Source", "src", _S), Operand("Dest", "dest", INT)], page=858,
             display=_box("Source", "Dest"),
             notes=("Skips leading control and non-numeric characters (a minus sign directly "
                    "before the digits is kept) and converts the first group of digits only; "
                    "no digits gives 0. A value outside the Dest range raises minor fault "
                    "Type 4 Code 53 (confirmed: Logix Designer help, String to DINT (STOD)).",
                    "UNVERIFIED: the value then written (VirtualControlStudio keeps the low "
                    "bits and sets S:V). Help text is silent on this."))
def stod(ctx, args, rung=True):
    if rung:
        m = _INT_FIRST.search(_text(ctx, args[0]))
        _store_number(ctx, args[1], int(m.group()) if m else 0, "LINT")
    return bool(rung)


@instruction("STOR", "String to REAL", "ASCII Conversion", "action",
             [Operand("Source", "src", _S), Operand("Dest", "dest", ("REAL",))], page=861,
             display=_box("Source", "Dest"),
             notes=("Skips leading control and non-numeric characters (a minus sign directly "
                    "before the number is kept) and converts the first group of digits with its "
                    "decimal point; no number gives 0.0. A value outside the REAL range raises "
                    "minor fault Type 4 Code 53 (confirmed: Logix Designer help, String to REAL "
                    "(STOR)).",
                    "UNVERIFIED: exponent notation (VirtualControlStudio accepts e.g. '1.5e3'). "
                    "Help text is silent on this."))
def stor(ctx, args, rung=True):
    if rung:
        m = _REAL_FIRST.search(_text(ctx, args[0]))
        _store_number(ctx, args[1], float(m.group()) if m else 0.0, "REAL")
    return bool(rung)
