"""Compare instructions (RM: Compare Instructions, p.348-426)."""
from __future__ import annotations

from .core import InstructionError
from .expr import evaluate_full
from .spec import INT, NUM, Operand, instruction
from .values import f32, math_type, num


def _pair(ctx, a, b):
    (va, ta), (vb, tb) = ctx.value(a), ctx.value(b)
    if isinstance(va, str) or isinstance(vb, str):
        return va, vb
    t = math_type(ta, tb)
    va, vb = num(va), num(vb)
    if t == "REAL":
        return f32(va), f32(vb)
    return va, vb


_CMP_NOTES = ("If either operand is REAL the comparison is done in REAL (the integer is "
              "converted); otherwise as integers (SINT/INT promoted to DINT).",)


def _compare(mn, title, page, fn, alias):
    @instruction(mn, title, "Compare", "condition",
                 [Operand("Source A", "src", NUM + ("STRING",)),
                  Operand("Source B", "src", NUM + ("STRING",))],
                 page=page, notes=_CMP_NOTES + (f"Shown as {alias} in recent manuals.",),
                 languages=("LD",), aliases=(alias,),
                 display={"rows": [["Source A", 0], ["Source B", 1]]})
    def run(ctx, args):
        a, b = _pair(ctx, args[0], args[1])
        try:
            return bool(fn(a, b))
        except TypeError:
            raise InstructionError(f"{mn}: cannot compare {a!r} and {b!r}")
    run.__name__ = mn.lower()
    return run


_compare("EQU", "Equal To", 349, lambda a, b: a == b, "EQ")
_compare("NEQ", "Not Equal To", 416, lambda a, b: a != b, "NE")
_compare("LES", "Less Than", 382, lambda a, b: a < b, "LT")
_compare("LEQ", "Less Than or Equal To", 390, lambda a, b: a <= b, "LE")
_compare("GRT", "Greater Than", 361, lambda a, b: a > b, "GT")
_compare("GEQ", "Greater Than or Equal To", 370, lambda a, b: a >= b, "GE")


@instruction("LIM", "Limit", "Compare", "condition",
             [Operand("Low Limit", "src", NUM), Operand("Test", "src", NUM),
              Operand("High Limit", "src", NUM)], page=399, languages=("LD",), aliases=("LIMIT",),
             display={"rows": [["Low Limit", 0], ["Test", 1],
                               ["High Limit", 2]]},
             notes=("Low <= High: true when Low <= Test <= High.",
                    "Low > High: true when Test >= Low or Test <= High (outside-band test).",))
def lim(ctx, args):
    vals = [ctx.value(a) for a in args[:3]]
    t = math_type(*(tp for _, tp in vals))
    lo, test, hi = (f32(num(v)) if t == "REAL" else num(v) for v, _ in vals)
    if lo <= hi:
        return lo <= test <= hi
    return test >= lo or test <= hi


@instruction("MEQ", "Mask Equal To", "Compare", "condition",
             [Operand("Source", "src", INT), Operand("Mask", "src", INT),
              Operand("Compare", "src", INT)], page=408, languages=("LD",),
             display={"rows": [["Source", 0], ["Mask", 1],
                               ["Compare", 2]]},
             notes=("True when (Source AND Mask) = (Compare AND Mask).",))
def meq(ctx, args):
    src, mask, cmp_ = (int(num(ctx.read(a))) for a in args[:3])
    return (src & mask) == (cmp_ & mask)


@instruction("CMP", "Compare", "Compare", "condition",
             [Operand("Expression", "expr")], page=357, languages=("LD",),
             display={"rows": [["Expression", 0]]},
             notes=("Evaluates the expression; rung-out is true when the result is non-zero "
                    "(e.g. 'A + 2 > B * 3').",
                    "Operators: + - * / MOD ** AND OR XOR NOT = <> < <= > >= and the CPT "
                    "functions.",
                    "Precedence (highest first): ( ), functions, **, negate/NOT, * / MOD, + -, "
                    "AND, XOR, OR, then all six comparisons on one lowest level; equal levels "
                    "run left to right, so 'A > 1 AND B > 2' means A > (1 AND B) > 2 - use "
                    "parentheses. Structured Text keeps its own order (confirmed: Logix "
                    "Designer help, Compare (CMP); Determine the order of execution).",
                    "If any operand is REAL, or the expression uses SIN, COS, TAN, ASN, ACS, "
                    "ATN, LN, LOG, DEG or RAD, every operand is converted to REAL before the "
                    "calculation (confirmed: Logix Designer help, Compare (CMP)).",
                    "Does not affect the math status flags and raises no overflow minor fault "
                    "(5580 behaviour; confirmed: Logix Designer help, Compare (CMP))."))
def cmp_(ctx, args):
    val, _, _ = evaluate_full(ctx, ",".join(args), promote="operands")
    return bool(val)
