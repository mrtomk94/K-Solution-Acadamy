"""Controller data model and the typed tag database (single source of truth).

The TagDB is shared by the scan engine, the CIP server, and the web bridge.
Addressing supports dotted UDT members and array subscripts, e.g.
``Motor.Run``, ``Line[2].Spd``, ``Zone[1].Valve[3].Cmd``.
"""
from __future__ import annotations

import re

from dataclasses import dataclass, field
from typing import Any

# Atomic base types -> (python type, default, bit width)
ATOMIC = {
    "BOOL": (bool, False, 1),
    "SINT": (int, 0, 8),
    "INT": (int, 0, 16),
    "DINT": (int, 0, 32),
    "LINT": (int, 0, 64),
    "REAL": (float, 0.0, 32),
    # unsigned integers and LREAL (5380/5580 controllers, v32+)
    "USINT": (int, 0, 8),
    "UINT": (int, 0, 16),
    "UDINT": (int, 0, 32),
    "ULINT": (int, 0, 64),
    "LREAL": (float, 0.0, 64),
}
_INT_TYPES = {"SINT": 8, "INT": 16, "DINT": 32, "LINT": 64}
_UINT_TYPES = {"USINT": 8, "UINT": 16, "UDINT": 32, "ULINT": 64}


def _wrap_int(value: int, bits: int) -> int:
    """Two's-complement wrap into the signed range for ``bits`` width."""
    value &= (1 << bits) - 1
    if value >= (1 << (bits - 1)):
        value -= 1 << bits
    return value


def _f32(x) -> float:
    import struct
    try:
        return struct.unpack("<f", struct.pack("<f", float(x)))[0]
    except OverflowError:
        return float("inf") if float(x) > 0 else float("-inf")


def coerce(data_type: str, value: Any) -> Any:
    """Coerce a python value into the representation of an atomic type.
    REAL is held at IEEE single precision; a REAL written to an integer is
    rounded to nearest (ties to even), as the controller converts."""
    if data_type == "BOOL":
        return bool(value)
    if data_type == "REAL":
        return _f32(value)
    if data_type == "LREAL":
        return float(value)
    if data_type in _UINT_TYPES:
        if isinstance(value, float):
            value = 0 if (value != value or value in (float("inf"), float("-inf"))) else round(value)
        return int(value) & ((1 << _UINT_TYPES[data_type]) - 1)
    if data_type in _INT_TYPES:
        if isinstance(value, float):
            if value != value or value in (float("inf"), float("-inf")):
                value = 0
            else:
                value = round(value)
        return _wrap_int(int(value), _INT_TYPES[data_type])
    raise TypeError(f"not an atomic type: {data_type}")


@dataclass
class Member:
    name: str
    data_type: str
    dim: int = 0  # 0 = scalar, >0 = array length
    description: str = ""
    external_access: str = "Read/Write"      # UDT member setting (Read/Write | Read Only | None)


@dataclass
class DataType:
    """A UDT definition (ordered members). ``defaults`` holds member default
    values (used for Add-On Instruction parameters and local tags)."""
    name: str
    members: list[Member] = field(default_factory=list)
    defaults: dict | None = None
    family: str = ""              # "StringFamily" for user string types (STRING_20, ...)


@dataclass
class Tag:
    """A declared tag. ``dim`` is the total number of elements (0 = scalar);
    ``dims`` is the declared shape, e.g. (2, 3) for ``DINT[2,3]``. Arrays of any
    rank are stored flat, in row-major order (Logix memory order)."""
    name: str
    data_type: str
    dim: int = 0
    scope: str = "controller"  # or a program name
    init: Any = None           # initial value from the L5X <Data> (None = zeros)
    description: str = ""
    dims: tuple = ()
    external_access: str = "Read/Write"   # Read/Write | Read Only | None
    constant: bool = False
    radix: str = ""            # display style (L5X Radix): Decimal, Hex, Binary, Octal, ASCII, Float, Exponential
    tag_type: str = "Base"     # L5X TagType: Base, Produced, Consumed (aliases are kept apart)

    def __post_init__(self):
        self.dims = tuple(int(d) for d in (self.dims or ()))
        if self.dims:
            total = 1
            for d in self.dims:
                total *= d
            self.dim = total
        elif self.dim:
            self.dims = (int(self.dim),)

    def type_text(self) -> str:
        """``DINT``, ``DINT[10]`` or ``DINT[2,3]``."""
        return f"{self.data_type}[{','.join(map(str, self.dims))}]" if self.dims else self.data_type


@dataclass
class Routine:
    name: str
    rtype: str  # "RLL", "ST", or not simulated: "FBD", "SFC"
    rungs: list[str] = field(default_factory=list)   # RLL rung text, in order
    text: str = ""                                   # ST source
    comments: dict[int, str] = field(default_factory=dict)   # rung index -> comment
    description: str = ""
    pending_edits: list = field(default_factory=list)        # [(rung index, L5X rung Type)]
    version: int = 0                                         # bumped by every applied edit
    modified: bool = False                                   # edited since import


@dataclass
class Program:
    name: str
    main: str = ""                                   # main routine name
    routines: dict[str, Routine] = field(default_factory=dict)
    tags: list[Tag] = field(default_factory=list)
    description: str = ""
    disabled: bool = False                           # Program Disabled="true": not executed


@dataclass
class AOIParam:
    """An Add-On Instruction parameter or local tag."""
    name: str
    data_type: str
    usage: str = "Input"          # Input | Output | InOut | Local
    required: bool = False
    visible: bool = False
    dim: int = 0
    default: Any = None
    description: str = ""
    external_access: str = "Read/Write"
    constant: bool = False        # InOut only: the AOI may not write it


@dataclass
class AOIDef:
    name: str
    params: list[Member] = field(default_factory=list)       # all parameters (name/type)
    routines: dict[str, Routine] = field(default_factory=dict)
    main: str = "Logic"
    parameters: list[AOIParam] = field(default_factory=list)  # with usage/required/default
    local_tags: list[AOIParam] = field(default_factory=list)
    execute_prescan: bool = False
    execute_postscan: bool = False
    execute_enableinfalse: bool = False
    revision: str = ""
    description: str = ""

    def call_params(self) -> list[AOIParam]:
        """Parameters that take an argument in a call, in order (required Input/
        Output and every InOut)."""
        return [p for p in self.parameters
                if p.name not in ("EnableIn", "EnableOut") and (p.required or p.usage == "InOut")]

    def data_type(self) -> "DataType":
        """The instance data type: parameters (except InOut) then local tags."""
        members, defaults = [], {}
        for p in self.parameters + self.local_tags:
            if p.usage == "InOut":
                continue
            members.append(Member(p.name, p.data_type, p.dim, description=p.description,
                                  external_access=p.external_access))
            if p.default is not None:
                defaults[p.name] = p.default
        if not any(m.name == "EnableIn" for m in members):
            members.insert(0, Member("EnableIn", "BOOL", external_access="Read Only"))
        defaults.setdefault("EnableIn", True)          # EnableIn defaults to 1
        if not any(m.name == "EnableOut" for m in members):
            members.insert(1, Member("EnableOut", "BOOL", external_access="Read Only"))
        return DataType(self.name, members, defaults or None)


@dataclass
class Controller:
    name: str = "controller"
    data_types: dict[str, DataType] = field(default_factory=dict)
    aois: dict[str, AOIDef] = field(default_factory=dict)
    tags: list[Tag] = field(default_factory=list)
    programs: dict[str, Program] = field(default_factory=dict)
    task_order: list[str] = field(default_factory=list)  # program run order
    tasks: list[dict] = field(default_factory=list)      # [{name, type, rate_ms, programs}]
    modules: list[dict] = field(default_factory=list)    # I/O modules and their tags
    aliases: dict[str, str] = field(default_factory=dict)  # alias tag -> target address
    alias_descriptions: dict[str, str] = field(default_factory=dict)  # alias tag -> description
    description: str = ""
    processor: str = ""
    revision: str = ""
    report_overflow: bool = True       # controller option "Report Overflow Faults"
    module_names: list[str] = field(default_factory=list)   # every module in I/O config


PREDEFINED: dict[str, "DataType"] = {
    "TIMER": DataType("TIMER", [
        Member("PRE", "DINT"), Member("ACC", "DINT"),
        Member("EN", "BOOL"), Member("TT", "BOOL"), Member("DN", "BOOL"),
    ]),
    "COUNTER": DataType("COUNTER", [
        Member("PRE", "DINT"), Member("ACC", "DINT"),
        Member("CU", "BOOL"), Member("CD", "BOOL"), Member("DN", "BOOL"),
        Member("OV", "BOOL"), Member("UN", "BOOL"),
    ]),
    "CONTROL": DataType("CONTROL", [
        Member("LEN", "DINT"), Member("POS", "DINT"),
        Member("EN", "BOOL"), Member("EU", "BOOL"), Member("DN", "BOOL"),
        Member("EM", "BOOL"), Member("ER", "BOOL"), Member("UL", "BOOL"),
        Member("IN", "BOOL"), Member("FD", "BOOL"),
    ]),
    # PID control structure (members a program normally reads or writes; the PID
    # instruction itself is a simulation boundary, so nothing computes OUT)
    "PID": DataType("PID", [
        Member("CTL", "DINT"), Member("SP", "REAL"), Member("KP", "REAL"), Member("KI", "REAL"),
        Member("KD", "REAL"), Member("BIAS", "REAL"), Member("MAXS", "REAL"), Member("MINS", "REAL"),
        Member("DB", "REAL"), Member("SO", "REAL"), Member("MAXO", "REAL"), Member("MINO", "REAL"),
        Member("UPD", "REAL"), Member("PV", "REAL"), Member("ERR", "REAL"), Member("OUT", "REAL"),
        Member("PVH", "REAL"), Member("PVL", "REAL"), Member("DVP", "REAL"), Member("DVN", "REAL"),
        Member("PVDB", "REAL"), Member("DVDB", "REAL"), Member("MAXI", "REAL"), Member("MINI", "REAL"),
        Member("TIE", "REAL"), Member("MAXCV", "REAL"), Member("MINCV", "REAL"),
        Member("MINTIE", "REAL"), Member("MAXTIE", "REAL"),
        Member("EN", "BOOL"), Member("CT", "BOOL"), Member("CL", "BOOL"), Member("PVT", "BOOL"),
        Member("DOE", "BOOL"), Member("SWM", "BOOL"), Member("CA", "BOOL"), Member("MO", "BOOL"),
        Member("PE", "BOOL"), Member("NDF", "BOOL"), Member("NOBC", "BOOL"), Member("NOZC", "BOOL"),
        Member("INI", "BOOL"), Member("SPOR", "BOOL"), Member("OLL", "BOOL"), Member("OLH", "BOOL"),
        Member("EWD", "BOOL"), Member("DVNA", "BOOL"), Member("DVPA", "BOOL"), Member("PVLA", "BOOL"),
        Member("PVHA", "BOOL"),
    ]),
    # MSG control structure (members a program normally uses; no communication behind it)
    "MESSAGE": DataType("MESSAGE", [
        Member("Flags", "INT"), Member("EW", "BOOL"), Member("ER", "BOOL"), Member("DN", "BOOL"),
        Member("ST", "BOOL"), Member("EN", "BOOL"), Member("TO", "BOOL"), Member("EN_CC", "BOOL"),
        Member("ERR", "INT"), Member("EXERR", "DINT"), Member("ERR_SRC", "SINT"),
        Member("DN_LEN", "INT"), Member("REQ_LEN", "INT"), Member("DestinationLink", "INT"),
        Member("DestinationNode", "INT"), Member("SourceLink", "INT"), Member("Class", "INT"),
        Member("Attribute", "INT"), Member("Instance", "DINT"), Member("LocalIndex", "DINT"),
        Member("Channel", "SINT"), Member("Rack", "SINT"), Member("Group", "SINT"),
        Member("Slot", "SINT"), Member("Path", "STRING"), Member("RemoteIndex", "DINT"),
        Member("RemoteElement", "STRING"), Member("UnconnectedTimeout", "DINT"),
        Member("ConnectionRate", "DINT"), Member("TimeoutMultiplier", "SINT"),
    ]),
    # function-block forms used from Structured Text / FBD
    "FBD_TIMER": DataType("FBD_TIMER", [
        Member("EnableIn", "BOOL"), Member("TimerEnable", "BOOL"), Member("PRE", "DINT"),
        Member("Reset", "BOOL"), Member("EnableOut", "BOOL"), Member("ACC", "DINT"),
        Member("EN", "BOOL"), Member("TT", "BOOL"), Member("DN", "BOOL"),
        Member("Status", "DINT"), Member("InstructFault", "BOOL"), Member("PresetInv", "BOOL"),
    ], {"EnableIn": True}),
    "FBD_COUNTER": DataType("FBD_COUNTER", [
        Member("EnableIn", "BOOL"), Member("CUEnable", "BOOL"), Member("CDEnable", "BOOL"),
        Member("PRE", "DINT"), Member("Reset", "BOOL"), Member("EnableOut", "BOOL"),
        Member("ACC", "DINT"), Member("CU", "BOOL"), Member("CD", "BOOL"), Member("DN", "BOOL"),
        Member("OV", "BOOL"), Member("UN", "BOOL"),
    ], {"EnableIn": True}),
    "FBD_ONESHOT": DataType("FBD_ONESHOT", [
        Member("EnableIn", "BOOL"), Member("InputBit", "BOOL"), Member("EnableOut", "BOOL"),
        Member("OutputBit", "BOOL"),
    ], {"EnableIn": True}),
}


# Logix STRING-family types are modelled as plain Python strings. User string
# types (Family="StringFamily", e.g. STR0016 with DATA SINT[16]) are registered
# when a project is loaded; STRING_LEN holds each type's maximum length.
STRING_TYPES = {"STRING"}
STRING_LEN = {"STRING": 82}


def string_max(dtype: str) -> int:
    """Maximum number of characters of a string type (STRING: 82)."""
    return STRING_LEN.get(dtype, 82)


def register_string_type(dt: "DataType") -> bool:
    """Register a user string type (LEN DINT + DATA SINT[n]); True if it is one."""
    if getattr(dt, "family", "") != "StringFamily":
        return False
    data = next((m for m in dt.members if m.name.upper() == "DATA"), None)
    STRING_TYPES.add(dt.name)
    STRING_LEN[dt.name] = int(data.dim) if data is not None and data.dim else 82
    return True


class TagError(KeyError):
    pass


class BitIndexError(IndexError):
    """A bit number beyond the width of the integer (major fault 4/83 in logic)."""


# External Access, most open first; the more restrictive setting wins along a path
ACCESS_CODES = {"Read/Write": "rw", "Read Only": "ro", "None": "none"}
_ACCESS_RANK = {"rw": 0, "ro": 1, "none": 2}


def access_code(text: str | None) -> str:
    return ACCESS_CODES.get(text or "Read/Write", "rw")


def stricter(a: str, b: str) -> str:
    return a if _ACCESS_RANK.get(a, 0) >= _ACCESS_RANK.get(b, 0) else b


# display styles a data type allows (Tag Editor "Style" column)
STYLES_INT = ("Decimal", "Hex", "Binary", "Octal", "ASCII")
STYLES_REAL = ("Float", "Exponential")


def styles_for(data_type: str) -> tuple:
    t = (data_type or "").upper()
    if t in ("SINT", "INT", "DINT", "LINT", "USINT", "UINT", "UDINT", "ULINT"):
        return STYLES_INT
    if t in ("REAL", "LREAL"):
        return STYLES_REAL
    if t == "BOOL":
        return ("Decimal",)
    return ()


_ROOT_RE = re.compile(r"(Program:[^.]+\.)?[^.\[]+")


class _VDict(dict):
    """A dict that tells its owner when it changes (alias table: cached lookups
    must be dropped when an alias is added, removed or retargeted)."""
    __slots__ = ("_on_change",)

    def __init__(self, data=(), on_change=None):
        super().__init__(data)
        self._on_change = on_change

    def _chg(self):
        if self._on_change is not None:
            self._on_change()

    def __setitem__(self, k, v):
        super().__setitem__(k, v); self._chg()

    def __delitem__(self, k):
        super().__delitem__(k); self._chg()

    def pop(self, *a):
        r = super().pop(*a); self._chg(); return r

    def clear(self):
        super().clear(); self._chg()

    def update(self, *a, **kw):
        super().update(*a, **kw); self._chg()

    def setdefault(self, k, v=None):
        r = super().setdefault(k, v); self._chg(); return r


class TagDB:
    """Typed, nested, array-aware tag store built from a Controller model."""

    def __init__(self, controller: Controller | None = None):
        self._types: dict[str, DataType] = dict(PREDEFINED)
        self._store: dict[str, Any] = {}
        self._decl: dict[str, Tag] = {}
        self._alias_tab = _VDict(on_change=self.invalidate)
        self._dims: dict[str, tuple] = {}      # multi-dimensional base tags -> shape
        self._ci: dict[str, str] = {}          # lower-case name -> declared name
        self._ci_n = -1
        # address caches (pure functions of the tag/type/alias structure); dropped by
        # invalidate() whenever that structure changes
        self._c_dealias: dict[str, str] = {}
        self._c_dtype: dict[str, str] = {}
        self._c_plan: dict[str, tuple] = {}
        self._c_alias_ci: dict[str, str] | None = None
        if controller is not None:
            self.build(controller)

    @property
    def _aliases(self) -> dict[str, str]:
        return self._alias_tab

    @_aliases.setter
    def _aliases(self, value) -> None:
        self._alias_tab = _VDict(value, on_change=self.invalidate)
        self.invalidate()

    def invalidate(self) -> None:
        """Drop cached address lookups (tags, types or aliases changed)."""
        if hasattr(self, "_c_plan"):
            self._c_dealias.clear()
            self._c_dtype.clear()
            self._c_plan.clear()
            self._c_alias_ci = None

    # ---- construction -------------------------------------------------
    def build(self, controller: Controller) -> None:
        for dt in controller.data_types.values():
            register_string_type(dt)
        self._types = {**PREDEFINED, **controller.data_types}
        for aoi in controller.aois.values():
            self._types.setdefault(aoi.name, aoi.data_type())
        self._aliases = dict(controller.aliases)
        for tag in controller.tags:
            self._declare(tag.name, tag)
        for prog in controller.programs.values():
            for tag in prog.tags:
                self._declare(f"Program:{prog.name}.{tag.name}", tag)

    def _overlay(self, cur: Any, init: Any, data_type: str) -> Any:
        """Apply an L5X initial value onto the default value (shape-checked)."""
        if init is None:
            return cur
        if isinstance(cur, list) and isinstance(init, list):
            return [self._overlay(c, i, data_type) for c, i in zip(cur, init)] + cur[len(init):]
        if isinstance(cur, dict) and isinstance(init, dict):
            members = {m.name: m for m in self._types[data_type].members} \
                if data_type in self._types else {}
            out = dict(cur)
            for k, v in init.items():
                if k in out:
                    m = members.get(k)
                    out[k] = self._overlay(out[k], v, m.data_type if m else "")
            return out
        if isinstance(cur, (list, dict)) or isinstance(init, (list, dict)):
            return cur
        if isinstance(cur, str):
            return str(init)
        try:
            return coerce(data_type, init) if data_type in ATOMIC else \
                (type(cur)(init) if not isinstance(cur, bool) else bool(init))
        except (TypeError, ValueError):
            return cur

    # ---- names: Logix tag names are not case sensitive -------------------------
    def find_root(self, name: str) -> str | None:
        """The declared spelling of a base tag name, or None (case-insensitive)."""
        if name in self._store:
            return name
        if self._ci_n != len(self._store):
            self._ci = {k.lower(): k for k in self._store}
            self._ci_n = len(self._store)
        return self._ci.get(name.lower())

    def alias_key(self, name: str) -> str | None:
        """The declared spelling of an alias tag name, or None (case-insensitive)."""
        if name in self._alias_tab:
            return name
        ci = self._c_alias_ci
        if ci is None:
            ci = self._c_alias_ci = {k.lower(): k for k in self._alias_tab}
        return ci.get(name.lower())

    def is_alias(self, name: str) -> bool:
        return self.find_root(name) is None and self.alias_key(name) is not None

    def dealias(self, address: str) -> str:
        """Replace an alias tag name with the address it points to. Aliases of
        aliases are followed (a chain); a program-scope alias points at the
        program's own tag when one of that name exists."""
        if not self._alias_tab:
            return address
        hit = self._c_dealias.get(address)
        if hit is not None:
            return hit
        out = self._dealias(address)
        if len(self._c_dealias) < 200_000:
            self._c_dealias[address] = out
        return out

    def _dealias(self, address: str) -> str:
        for _ in range(16):
            m = _ROOT_RE.match(address)
            if not m:
                return address
            root = m.group()
            if root in self._store:
                return address
            key = self.alias_key(root)
            if key is None:
                return address
            target = self._aliases[key]
            if key.startswith("Program:") and not target.startswith("Program:"):
                prefix = key[:key.index(".") + 1]
                troot = _ROOT_RE.match(target)
                cand = prefix + (troot.group() if troot else target)
                if self.find_root(cand) is not None or self.alias_key(cand) is not None:
                    target = prefix + target
            address = target + address[m.end():]
        return address

    def canonical(self, address: str) -> str:
        """``address`` with aliases resolved and every tag/member name in its
        declared spelling (used as the key for forces and properties)."""
        address = self.dealias(address)
        m = _ROOT_RE.match(address)
        if not m:
            return address
        root = self.find_root(m.group())
        if root is None:
            return address
        out, rest = [root], address[m.end():]
        try:
            dtype = self._decl[root].data_type
        except KeyError:
            return root + rest
        for seg in re.findall(r"\.[^.\[]+|\[[^\]]*\]", rest):
            if seg.startswith(".") and not seg[1:].isdigit():
                try:
                    mem = self._member(dtype, seg[1:])
                    out.append("." + mem.name)
                    dtype = mem.data_type
                    continue
                except TagError:
                    pass
            out.append(seg)
        return "".join(out)

    def declaration_of(self, address: str):
        """(base tag name, Tag) for any address of a tag, or (None, None)."""
        m = _ROOT_RE.match(self.dealias(address))
        root = self.find_root(m.group()) if m else None
        return (root, self._decl.get(root)) if root else (None, None)

    def is_constant(self, address: str) -> bool:
        _, decl = self.declaration_of(address)
        return bool(decl is not None and getattr(decl, "constant", False))

    def ext_access(self, address: str) -> str:
        """External Access of an address from the declarations: the tag's setting,
        made more restrictive by any UDT member setting ('rw' | 'ro' | 'none')."""
        _, decl = self.declaration_of(address)
        if decl is None:
            return "rw"
        return stricter(access_code(getattr(decl, "external_access", None)), self.member_access(address))

    def member_access(self, address: str) -> str:
        """The most restrictive UDT member External Access along an address."""
        address = self.canonical(address)
        root, decl = self.declaration_of(address)
        acc = "rw"
        if decl is None:
            return acc
        dtype = decl.data_type
        for seg in re.findall(r"\.[^.\[]+", address[len(root):]):
            if seg[1:].isdigit():
                break
            try:
                mem = self._member(dtype, seg[1:])
            except TagError:
                break
            acc = stricter(acc, access_code(mem.external_access))
            dtype = mem.data_type
        return acc

    def _default(self, data_type: str, dim: int) -> Any:
        if dim and dim > 0:
            return [self._default(data_type, 0) for _ in range(dim)]
        if data_type in ATOMIC:
            return ATOMIC[data_type][1]
        if data_type in STRING_TYPES:                  # held as a Python str
            return ""
        if data_type in self._types:
            dt = self._types[data_type]
            out = {m.name: self._default(m.data_type, m.dim) for m in dt.members}
            if dt.defaults:
                for k, v in dt.defaults.items():
                    if k in out:
                        m = next(mm for mm in dt.members if mm.name == k)
                        out[k] = self._overlay(out[k], v, m.data_type)
            return out
        # unknown type -> treat as opaque DINT-like 0
        return 0

    def _declare(self, name: str, tag: Tag) -> None:
        self.invalidate()
        self._decl[name] = tag
        if len(getattr(tag, "dims", ()) or ()) > 1:
            self._dims[name] = tuple(tag.dims)
        else:
            self._dims.pop(name, None)
        value = self._default(tag.data_type, tag.dim)
        if getattr(tag, "init", None) is not None:
            value = self._overlay(value, tag.init, tag.data_type)
        self._store[name] = value

    # ---- runtime changes (generic emulator) ------------------------------
    def known_type(self, data_type: str) -> bool:
        return data_type in ATOMIC or data_type in STRING_TYPES or data_type in self._types

    def add_type(self, dtype: "DataType") -> None:
        self.invalidate()
        self._types[dtype.name] = dtype

    def types(self) -> dict[str, "DataType"]:
        return dict(self._types)

    def declare(self, tag: "Tag", name: str | None = None) -> None:
        self._declare(name or tag.name, tag)

    def remove(self, name: str) -> None:
        self.invalidate()
        self._ci_n = -1
        del self._store[name]
        del self._decl[name]
        self._dims.pop(name, None)

    def rename(self, old: str, new: str) -> None:
        self.invalidate()
        self._ci_n = -1
        self._store[new] = self._store.pop(old)
        if old in self._dims:
            self._dims[new] = self._dims.pop(old)
        tag = self._decl.pop(old)
        tag.name = new.split(".")[-1] if new.startswith("Program:") else new
        self._decl[new] = tag

    def declaration(self, name: str) -> "Tag":
        return self._decl[name]

    def declarations(self) -> dict[str, "Tag"]:
        return dict(self._decl)

    # ---- address parsing ---------------------------------------------
    _PARSE_CACHE: dict = {}

    @classmethod
    def _parse(cls, address: str) -> list[tuple[str, int | None]]:
        hit = cls._PARSE_CACHE.get(address)
        if hit is None:
            hit = cls._parse_uncached(address)
            if len(cls._PARSE_CACHE) < 100_000:
                cls._PARSE_CACHE[address] = hit
        return hit

    @staticmethod
    def _parse_uncached(address: str) -> list[tuple[str, int | None]]:
        """'Line[2].Spd' -> [('Line',2),('Spd',None)]  (program prefix kept)."""
        addr = address
        prefix = ""
        if addr.startswith("Program:"):
            # keep 'Program:Name' glued to the first segment
            head, _, rest = addr.partition(".")
            prefix = head + "."
            addr = rest
        parts: list = []
        for seg in addr.split("."):
            if "[" in seg:
                base, idx = seg[:-1].split("[")
                if "," in idx:                   # Grid[1,2] -> ('Grid', (1, 2))
                    parts.append((base, tuple(int(x) for x in idx.split(","))))
                else:
                    parts.append((base, int(idx)))
            else:
                parts.append((seg, None))
        if prefix and parts:
            name, idx = parts[0]
            parts[0] = (prefix + name, idx)
        return parts

    def _resolve(self, address: str):
        """Return (container, key, data_type) such that container[key] is the leaf."""
        parts = self._parse(address)
        root_name, root_idx = parts[0]
        if root_name not in self._store:
            root_name = self.find_root(root_name)
            if root_name is None:
                raise TagError(address)
        dtype = self._decl[root_name].data_type
        container: Any = self._store
        key: Any = root_name
        keys = [root_name]
        if root_idx is not None:            # subscripted root: descend into list
            container = self._store[root_name]
            if type(root_idx) is int and root_idx >= 0 and root_name not in self._dims:
                key = root_idx                 # fast path: one-dimensional array
            else:
                key = self.flat_index(root_name, root_idx)
            keys.append(key)
        for name, idx in parts[1:]:
            parent = container[key]
            if not isinstance(parent, dict):
                raise TagError(address)
            if name not in parent:                # other spelling of the member name
                name = self._member(dtype, name).name
            dtype = self._member(dtype, name).data_type
            container, key = parent, name
            keys.append(name)
            if idx is not None:             # member is an array (1-D): descend into list
                if isinstance(idx, tuple):
                    raise TagError(address)
                if idx < 0:
                    raise IndexError(idx)
                container = parent[name]
                key = idx
                keys.append(idx)
        self._last_keys = keys
        return container, key, dtype

    def _walk(self, keys) -> tuple:
        """(container, key) for a cached key path."""
        c = self._store
        for k in keys[:-1]:
            c = c[k]
        return c, keys[-1]

    def flat_index(self, name: str, idx) -> int:
        """Row-major element number of ``name[idx]``. Every subscript is range
        checked (IndexError, a major fault 4/20 in logic); the number of subscripts
        must match the declaration (TagError otherwise)."""
        dims = self._dims.get(name)
        if dims is None:
            if isinstance(idx, tuple):
                raise TagError(f"{name}: {len(idx)} subscripts for a one-dimensional array")
            if idx < 0:
                raise IndexError(idx)
            return idx
        if not isinstance(idx, tuple) or len(idx) != len(dims):
            n = len(idx) if isinstance(idx, tuple) else 1
            raise TagError(f"{name} has {len(dims)} dimensions but {n} subscript(s) were given")
        flat = 0
        for i, d in zip(idx, dims):
            if i < 0 or i >= d:
                raise IndexError(idx)
            flat = flat * d + i
        return flat

    def elem_address(self, addr: str, i: int) -> str:
        """Address of element ``i`` (flat, row-major) of the array at ``addr``."""
        return addr + (self.index_text(addr, i) if addr in self._dims else f"[{i}]")

    def dims_of(self, name: str) -> tuple:
        """Declared shape of a base tag: () scalar, (n,) or (a, b[, c])."""
        if name in self._dims:
            return self._dims[name]
        decl = self._decl.get(name)
        return (decl.dim,) if decl is not None and decl.dim else ()

    def index_text(self, name: str, flat: int) -> str:
        """Subscript text for element ``flat`` of base tag ``name``: '[4]' or '[1,1]'."""
        dims = self._dims.get(name)
        if not dims:
            return f"[{flat}]"
        out = []
        for d in reversed(dims):
            out.append(flat % d)
            flat //= d
        return "[" + ",".join(str(x) for x in reversed(out)) + "]"

    def _member(self, dtype: str, name: str) -> Member:
        if dtype in self._types:
            members = self._types[dtype].members
            for m in members:
                if m.name == name:
                    return m
            low = name.lower()
            for m in members:                       # member names are not case sensitive
                if m.name.lower() == low:
                    return m
        raise TagError(f"{dtype}.{name}")

    # ---- public API ---------------------------------------------------
    def has_tag(self, name: str) -> bool:
        """True if ``name`` is a declared base tag (e.g. 'Program:P.Local'); not case sensitive."""
        return name in self._store or self.find_root(name) is not None

    def names(self) -> list[str]:
        return list(self._store.keys())

    _BIT = re.compile(r"^(.*)\.(\d+)$")
    _INT_BITS = {"SINT": 8, "INT": 16, "DINT": 32, "LINT": 64,
                 "USINT": 8, "UINT": 16, "UDINT": 32, "ULINT": 64}

    def _bit(self, address: str):
        """'Word.3' on an integer tag -> (container, key, dtype, bit), else None."""
        m = self._BIT.match(address)
        if not m:
            return None
        container, key, dtype = self._resolve(m.group(1))
        bits = self._INT_BITS.get(dtype)
        if bits is None:
            raise TagError(address)
        if int(m.group(2)) >= bits:
            raise BitIndexError(f"bit {m.group(2)} of {dtype} {m.group(1)} (0..{bits - 1})")
        return container, key, dtype, int(m.group(2))

    _STR = re.compile(r"^(.*)\.(LEN|DATA\[(\d+)\])$", re.I)

    def _string_member(self, address: str):
        """'Msg.LEN' / 'Msg.DATA[3]' on a STRING (held as text) -> (container, key, index|None)."""
        m = self._STR.match(address)
        if not m:
            return None
        try:
            container, key, dtype = self._resolve(m.group(1))
        except Exception:
            return None
        if dtype not in STRING_TYPES:
            return None
        return container, key, (int(m.group(3)) if m.group(3) is not None else None), \
            string_max(dtype)

    def _plan(self, address: str) -> tuple:
        """How to reach an (alias-free) address: ('s', base, idx|None, max) for a
        STRING member, ('b', base, bit, dtype) for an integer bit, ('p',) otherwise.
        Cached; raises (and caches nothing) when the address is invalid."""
        hit = self._c_plan.get(address)
        if hit is not None:
            return hit
        plan = None
        if address[-1:] in "]NnAa":
            sm = self._string_member(address)
            if sm:
                m = self._STR.match(address)
                plan = ("s", m.group(1), sm[2], sm[3])
        if plan is None and address[-1:].isdigit():
            bit = self._bit(address)
            if bit:
                plan = ("b", address[:address.rindex(".")], bit[3], bit[2])
        if plan is None:
            dtype = self._resolve(address)[2]
            plan = ("p", dtype, tuple(self._last_keys))
            try:
                self._walk(plan[2])[0][plan[2][-1]]
            except (IndexError, KeyError):            # out of range: do not remember
                return plan
        if len(self._c_plan) < 200_000:
            self._c_plan[address] = plan
        return plan

    def data_type(self, address: str) -> str:
        address = self.dealias(address)
        hit = self._c_dtype.get(address)
        if hit is not None:
            return hit
        plan = self._plan(address)
        out = ("DINT" if plan[2] is None else "SINT") if plan[0] == "s" else \
            "BOOL" if plan[0] == "b" else plan[1]
        if len(self._c_dtype) < 200_000:
            self._c_dtype[address] = out
        return out

    def get(self, address: str) -> Any:
        address = self.dealias(address)
        plan = self._plan(address)
        kind = plan[0]
        if kind == "p":
            c = self._store
            for k in plan[2]:
                c = c[k]
            return c
        container, key, _ = self._resolve(plan[1])
        if kind == "b":
            return bool((int(container[key]) >> plan[2]) & 1)
        text, idx = container[key], plan[2]
        if idx is None:
            return len(text)
        if idx >= plan[3]:
            raise IndexError(idx)
        c = ord(text[idx]) if idx < len(text) else 0
        return c - 256 if c > 127 else c

    def set(self, address: str, value: Any) -> None:
        address = self.dealias(address)
        plan = self._plan(address)
        kind = plan[0]
        if kind == "s":
            container, key, _ = self._resolve(plan[1])
            idx, mx = plan[2], plan[3]
            text = container[key]
            if idx is None:                      # LEN: truncate, or extend with NULs
                n = max(0, min(int(value), mx))
                container[key] = text[:n].ljust(n, "\x00")
            elif idx >= mx:
                raise IndexError(idx)
            elif idx < len(text):                # characters beyond LEN are not kept
                container[key] = text[:idx] + chr(int(value) & 0xFF) + text[idx + 1:]
            return
        if kind == "b":
            container, key, dtype = self._resolve(plan[1])
            n = plan[2]
            word = int(container[key])
            word = word | (1 << n) if value else word & ~(1 << n)
            container[key] = coerce(dtype, word)
            return
        container, key = self._walk(plan[2])
        dtype = plan[1]
        if dtype in STRING_TYPES and isinstance(value, str):
            value = value[:string_max(dtype)]
        if dtype in ATOMIC:
            value = coerce(dtype, value)
        container[key] = value

    # convenience for engine internals (whole-tag snapshot)
    def snapshot(self) -> dict[str, Any]:
        import copy
        return copy.deepcopy(self._store)
