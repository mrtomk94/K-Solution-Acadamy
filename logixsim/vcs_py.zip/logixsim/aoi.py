"""Add-On Instruction execution (1756-PM010, "Logix 5000 Controllers Add-On
Instructions").

Documented behaviour implemented here:

* Input parameters are passed *by value*: the argument values are copied into
  the instance before the logic runs. Output parameters are copied out to their
  arguments after it runs. InOut parameters are passed *by reference*: the logic
  reads and writes the argument tag directly.
* EnableIn is the rung condition (always true in Structured Text); EnableOut is
  the rung-condition-out.
* EnableIn false with no EnableInFalse routine: no logic executes and no outputs
  are written. With an enabled EnableInFalse routine it runs in place of the
  logic, with inputs and outputs passed.
* Prescan (Program -> Run): inputs are passed, the logic routine is prescanned,
  the Prescan routine (if enabled) executes normally, outputs are passed back.
* Arguments in a ladder or ST call: the instance tag, then one argument for each
  required parameter and each InOut parameter, in definition order.

Inside the AOI only its parameters and local tags are visible; they live in the
instance tag (``Instance.Param``). Each instance keeps its own timers, one-shots
and other instruction state because their addresses are inside the instance.

UNVERIFIED: EnableOut is preset to true before the logic runs (the logic may
clear it).
"""
from __future__ import annotations

from types import SimpleNamespace

from .instructions import ExecContext, InstructionError
from .isa.core import Frame
from .ld_interp import instructions


class AOIContext(ExecContext):
    def __init__(self, parent: ExecContext, aoi, instance: str, inout: dict[str, str]):
        super().__init__(parent.db, now=parent.now, engine=parent.engine, program=None,
                         first_scan=parent.first_scan)
        self.status = parent.status
        self.prescan = parent.prescan
        self.aoi = aoi
        self.instance = instance
        self.inout = inout
        self.members = {p.name.upper(): p.name for p in aoi.parameters + aoi.local_tags
                        if p.usage != "InOut"}
        self.members.setdefault("ENABLEIN", "EnableIn")
        self.members.setdefault("ENABLEOUT", "EnableOut")
        self.program = SimpleNamespace(name=f"AOI:{aoi.name}", routines=aoi.routines)
        self.frames = [Frame()]
        if parent.engine is not None:
            key = ("aoi", aoi.name, instance, tuple(sorted(inout.items())))
            self._cache = parent.engine.resolve_cache.setdefault(key, {})

    def _scope(self, name: str) -> str:
        up = name.upper()
        if up in self.inout:
            return self.inout[up]
        if up in self.members:
            return f"{self.instance}.{self.members[up]}"
        return name


def _bind(aoi, args: list[str]):
    if not args:
        raise InstructionError(f"{aoi.name}: the first operand must be the instance tag")
    params = aoi.call_params()
    if len(args) - 1 != len(params):
        raise InstructionError(
            f"{aoi.name}: expected {len(params)} argument(s) after the instance tag "
            f"({', '.join(p.name for p in params) or 'none'}), got {len(args) - 1}")
    return args[0], list(zip(params, args[1:]))


def _copy_in(ctx, inst, bound):
    for p, arg in bound:
        if p.usage == "Input":
            v, t = ctx.value(arg)
            ctx.store(f"{inst}.{p.name}", v, t, flags=False)


def _copy_out(ctx, inst, bound):
    for p, arg in bound:
        if p.usage == "Output":
            v = ctx.db.get(f"{inst}.{p.name}")
            ctx.store(arg, v, p.data_type, flags=False)


def _check_instance(ctx, aoi, inst):
    try:
        t = ctx.db.data_type(inst)
    except Exception:
        raise InstructionError(f"{aoi.name}: instance tag '{inst}' does not exist")
    if t.upper() != aoi.name.upper():
        raise InstructionError(f"{aoi.name}: instance tag '{inst}' is a {t}, not a {aoi.name}")


def execute(engine, ctx: ExecContext, aoi, args: list[str], rung: bool):
    """Run one AOI call. Returns (rung-condition-out, highlight)."""
    inst, bound = _bind(aoi, args)
    _check_instance(ctx, aoi, inst)
    inout = {p.name.upper(): arg for p, arg in bound if p.usage == "InOut"}
    sub = AOIContext(ctx, aoi, inst, inout)
    db = ctx.db
    if rung:
        _copy_in(ctx, inst, bound)
        db.set(f"{inst}.EnableIn", True)
        db.set(f"{inst}.EnableOut", True)
        _run(engine, sub, aoi, aoi.main or "Logic", ctx)
        _copy_out(ctx, inst, bound)
        out = bool(db.get(f"{inst}.EnableOut"))
        return out, out
    db.set(f"{inst}.EnableIn", False)
    db.set(f"{inst}.EnableOut", False)
    if aoi.execute_enableinfalse and "EnableInFalse" in aoi.routines:
        _copy_in(ctx, inst, bound)
        _run(engine, sub, aoi, "EnableInFalse", ctx)
        db.set(f"{inst}.EnableOut", False)
        _copy_out(ctx, inst, bound)
    return False, False


def _run(engine, sub, aoi, routine, parent):
    saved = parent.location
    try:
        engine.run_routine(sub.program, routine, sub)
    finally:
        parent.location = saved


def prescan_call(engine, ctx: ExecContext, name: str, args: list[str]) -> None:
    """Prescan of one AOI call (see module docstring)."""
    aoi = _lookup(engine, name)
    if aoi is None:
        return
    resolved = [ctx.resolve(a) for a in args]
    inst, bound = _bind(aoi, resolved)
    inout = {p.name.upper(): arg for p, arg in bound if p.usage == "InOut"}
    sub = AOIContext(ctx, aoi, inst, inout)
    sub.prescan = True
    _copy_in(ctx, inst, bound)
    logic = aoi.routines.get(aoi.main or "Logic")
    if logic is not None and logic.rtype == "RLL":
        for rung in logic.rungs:
            try:
                items = instructions(rung)
            except Exception:
                continue
            for n, a in items:
                engine._prescan_instr(sub, n, a)
    if aoi.execute_prescan and "Prescan" in aoi.routines:
        sub.prescan = False
        engine.run_routine(sub.program, "Prescan", sub)
    _copy_out(ctx, inst, bound)


def _lookup(engine, name):
    aois = engine.controller.aois
    if name in aois:
        return aois[name]
    for n, a in aois.items():
        if n.upper() == name.upper():
            return a
    return None
