"""Command line (``python -m vcs`` or ``python -m logixsim``).

    python -m logixsim run program.L5X [--slot N] [--web-port 8800]
                                       [--cip-port 44818] [--no-cip] [--autostart]
    python -m logixsim chassis rack.json [--web-port 8800] [--cip-port 44818]
                                         [--no-cip] [--autostart]

    python -m logixsim studio [program.L5X] [--opcua] [--run]   Studio-style UI
    python -m logixsim instructions [--markdown]                instruction catalog
    python -m logixsim verify program.L5X                       what can be executed
    python -m logixsim new  project.json [--name "Line 1"]
    python -m logixsim serve project.json [--host] [--web-port 8800] [--opcua-port 4840]
                                          [--no-opcua] [--cip] [--cip-port] [--run]

``new``/``serve`` run the generic emulator: tags from a project file, no PLC
program required, OPC UA + web API (+ optional EtherNet/IP) connectors.
``chassis`` loads a virtual 1756 chassis (several controllers by slot) from a
JSON config; see logixsim/chassis.py for the format.
"""
from __future__ import annotations

import argparse
import sys

from .chassis import Chassis, ChassisError, load_chassis_config
from .cip_server import CIPServer
from .engine import Engine
from .l5x_loader import load_file
from .web_bridge import create_app

_LOOPBACK = ("127.0.0.1", "localhost", "::1")


def _add_server_args(p) -> None:
    p.add_argument("--web-port", type=int, default=8800)
    p.add_argument("--cip-port", type=int, default=44818)
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--no-cip", action="store_true")
    p.add_argument("--autostart", action="store_true",
                   help="start every controller (chassis: also honours per-slot autostart)")


def _serve(chassis: Chassis, args, autostart_all: bool) -> int:
    if args.host not in _LOOPBACK:
        print(f"WARNING: binding to {args.host} exposes UNAUTHENTICATED tag "
              f"write access (web + EtherNet/IP) to the network. Use a trusted "
              f"network only.")
    print(f"chassis {chassis.name}:")
    for row in chassis.describe()["slots"]:
        eng = chassis.get(row["slot"])
        print(f"  slot {row['slot']}: {row['controller']}  "
              f"[{row['product_name']} rev {row['revision']}]  "
              f"{len(eng.db.names())} tags, {len(eng.controller.programs)} program(s)")

    cip = None
    if not args.no_cip:
        cip = CIPServer(chassis, host=args.host, port=args.cip_port)
        port = cip.start()
        print(f"EtherNet/IP server listening on {args.host}:{port} "
              f"(pycomm3: LogixDriver('<ip>/<slot>'))")

    if autostart_all:
        chassis.start_all()
    else:
        chassis.start_all(only_autostart=True)
    for s in chassis.slots():
        if chassis.get(s).running:
            print(f"  slot {s}: RUNNING")

    try:
        import uvicorn
        print(f"studio: http://{args.host}:{args.web_port}/studio   control panel: http://{args.host}:{args.web_port}/panel")
        uvicorn.run(create_app(chassis), host=args.host,
                    port=args.web_port, log_level="warning")
    finally:
        chassis.stop_all()
        if cip:
            cip.stop()
    return 0


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    from . import APP_NAME, __version__
    ap = argparse.ArgumentParser(
        prog="vcs", description=f"{APP_NAME} {__version__}: PLC programming and simulation "
        "(python -m vcs or python -m logixsim)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    run_p = sub.add_parser("run", help="run one L5X program")
    run_p.add_argument("l5x")
    run_p.add_argument("--slot", type=int, default=0, help="chassis slot (default 0)")
    _add_server_args(run_p)

    ch_p = sub.add_parser("chassis", help="run a virtual chassis from a JSON config")
    ch_p.add_argument("config")
    _add_server_args(ch_p)

    new_p = sub.add_parser("new", help="create a project: NAME.vcsproj = empty Studio project "
                                       "(MainTask/MainProgram/MainRoutine); NAME.json = generic "
                                       "emulator project with example tags")
    new_p.add_argument("project")
    new_p.add_argument("--name", default="My Emulator")

    sv_p = sub.add_parser("serve", help="run the generic emulator from a project file")
    sv_p.add_argument("project")
    sv_p.add_argument("--host", default="127.0.0.1")
    sv_p.add_argument("--web-port", type=int, default=8800)
    sv_p.add_argument("--opcua-port", type=int, default=None)
    sv_p.add_argument("--no-opcua", action="store_true")
    sv_p.add_argument("--cip", action="store_true", help="also serve EtherNet/IP (slot 0)")
    sv_p.add_argument("--cip-port", type=int, default=44818)
    sv_p.add_argument("--run", action="store_true", help="start the scan clock (RUN)")
    sv_p.add_argument("--allow-origin", action="append", default=[],
                      help="web page origin allowed to use the WebSocket API "
                           "(repeatable; 'null' = pages opened from disk, '*' = any)")

    st_p = sub.add_parser("studio", help="Studio-style engineering UI (import an L5X, run, monitor)")
    st_p.add_argument("file", nargs="?", help=".L5X or .vcsproj to open (optional; you can also "
                                              "open or import from the UI)")
    st_p.add_argument("--host", default="127.0.0.1")
    st_p.add_argument("--web-port", type=int, default=8800)
    st_p.add_argument("--opcua", action="store_true", help="also serve the tags over OPC UA")
    st_p.add_argument("--opcua-port", type=int, default=4840)
    st_p.add_argument("--run", action="store_true")
    st_p.add_argument("--tab", action="store_true",
                      help="with --open: use a normal browser tab instead of an app window")
    st_p.add_argument("--open", action="store_true",
                      help="open the Studio page in the default browser; if Studio is already "
                           "running on this port, hand the file to it instead of starting another")

    vf_p = sub.add_parser("verify", help="report what VirtualControlStudio can execute in an .L5X")
    vf_p.add_argument("file")

    in_p = sub.add_parser("instructions", help="list the instruction catalog (what VirtualControlStudio executes)")
    in_p.add_argument("--markdown", action="store_true",
                      help="print the full reference / traceability matrix as Markdown")

    hp = sub.add_parser("hash-password", help="hash an OPC UA password for the project file")
    hp.add_argument("password", nargs="?", help="omit to be prompted")

    args = ap.parse_args(argv)
    if args.cmd == "new":
        return _new(args)
    if args.cmd == "serve":
        return _serve_project(args)
    if args.cmd == "studio":
        return _studio(args)
    if args.cmd == "instructions":
        from .isa.docgen import markdown, text
        print(markdown() if args.markdown else text())
        return 0
    if args.cmd == "verify":
        return _verify(args)
    if args.cmd == "hash-password":
        import getpass
        from .connectors.opcua import hash_password
        pw = args.password if args.password is not None else getpass.getpass("password: ")
        print(hash_password(pw))
        return 0

    if args.cmd == "run":
        try:
            chassis = Chassis.single(Engine(load_file(args.l5x)), slot=args.slot)
        except ChassisError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        except Exception as exc:                  # unreadable / invalid L5X
            print(f"error: cannot load {args.l5x}: {exc}", file=sys.stderr)
            return 2
        return _serve(chassis, args, autostart_all=args.autostart)

    try:
        chassis = load_chassis_config(args.config)
    except ChassisError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    return _serve(chassis, args, autostart_all=args.autostart)




# ---- generic emulator -----------------------------------------------------------------
def _new(args) -> int:
    import json
    import os
    if os.path.exists(args.project):
        print(f"error: {args.project} already exists", file=sys.stderr)
        return 2
    if args.project.lower().endswith(".vcsproj"):           # a new Studio project
        from .project import new_studio_project
        from .project_ops import ProjectOpError
        name = args.name if args.name != "My Emulator" else \
            os.path.splitext(os.path.basename(args.project))[0]
        try:
            new_studio_project(args.project, name)
        except ProjectOpError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        print(f"created {args.project}: {name} with MainTask / MainProgram / MainRoutine")
        print(f"next: python -m vcs studio {args.project} --open")
        return 0
    data = {
        "format": "logixsim-project", "version": 1, "name": args.name,
        "types": {"Motor_t": [{"name": "Run", "type": "BOOL"},
                              {"name": "Running", "type": "BOOL"},
                              {"name": "Speed", "type": "REAL"}]},
        "tags": [
            {"name": "Start", "type": "BOOL", "description": "Start push button", "group": "Operator"},
            {"name": "Stop", "type": "BOOL", "description": "Stop push button", "group": "Operator"},
            {"name": "Conveyor", "type": "Motor_t", "description": "Main conveyor", "group": "Line"},
            {"name": "Tank_Level", "type": "REAL", "value": 40.0, "units": "%", "min": 0, "max": 100,
             "group": "Process"},
            {"name": "Sensors", "type": "BOOL", "dim": 8, "description": "Photo eyes", "group": "Line"},
        ],
        "engine": {"scan_ms": 20, "publish_ms": 50},
        "connectors": {"opcua": {"enabled": True, "port": 4840},
                       "cip": {"enabled": False, "port": 44818}},
    }
    with open(args.project, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    print(f"created {args.project} with {len(data['tags'])} example tags")
    print(f"next: python -m logixsim serve {args.project}")
    return 0


def _serve_project(args) -> int:
    from .connectors import create
    from .project import ProjectError, load_project
    try:
        emu = load_project(args.project)
    except ProjectError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    emu.project_path = args.project
    emu.settings.setdefault("web", {})["bind_host"] = args.host
    if args.allow_origin:
        web = emu.settings.setdefault("web", {})
        web["allowed_origins"] = list(web.get("allowed_origins") or []) + args.allow_origin
    conf = {k: dict(v or {}) for k, v in (emu.settings.get("connectors") or {}).items()}
    opc = conf.setdefault("opcua", {"enabled": True})
    if args.no_opcua:
        opc["enabled"] = False
    if args.opcua_port is not None:
        opc["port"] = args.opcua_port
    if args.cip:
        conf["cip"] = {**conf.get("cip", {}), "enabled": True, "port": args.cip_port}
    for name, settings in conf.items():
        if settings.get("enabled", True):
            settings.setdefault("host", args.host)
        try:
            con = create(name, emu, settings)
        except (ValueError, TypeError) as exc:
            print(f"error: connector {name}: {exc}", file=sys.stderr)
            return 2
        if con is not None:
            emu.add_connector(con)

    if args.host not in _LOOPBACK:
        print(f"WARNING: binding to {args.host} exposes tag write access (web, OPC UA "
              f"anonymous, EtherNet/IP) to the network. Use a trusted network only.")
    try:
        emu.start(run=args.run)
    except RuntimeError as exc:
        emu.stop()
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print(f"project {emu.name}: {len(emu.store.definitions())} tags"
          f"{' + logic ' + emu.logic_file if emu.logic_file else ''}"
          f" -- {'RUNNING' if emu.engine.running else 'STOPPED'}")
    for st in emu.connector_status():
        print(f"  {st['name']}: {st.get('endpoint', '')}")
    try:
        import uvicorn
        print(f"studio: http://{args.host}:{args.web_port}/studio   panel: http://{args.host}:{args.web_port}/panel   "
              f"API: ws://{args.host}:{args.web_port}/api/v1/ws")
        uvicorn.run(create_app(emu), host=args.host, port=args.web_port, log_level="warning")
    finally:
        emu.stop()
    return 0


# ---- studio / verify ---------------------------------------------------------------------
def _verify(args) -> int:
    from .verify import format_report, verify
    try:
        ctrl = load_file(args.file)
    except Exception as exc:
        print(f"error: cannot load {args.file}: {exc}", file=sys.stderr)
        return 2
    r = verify(ctrl)
    print(format_report(r))
    clean = not (r["unsupported"] or r["routines_not_simulated"] or r["parse_errors"] or r["missing_tags"])
    return 0 if clean else 1


def _running_studio(host: str, port: int):
    """The version string of a VirtualControlStudio already answering on host:port
    ("unknown" for builds without one), or None when nothing answers."""
    import json
    import urllib.request
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    h = "127.0.0.1" if host in ("0.0.0.0", "::") else host
    try:
        with opener.open(f"http://{h}:{port}/api/studio/project", timeout=1.5) as r:
            if r.status != 200:
                return None
            data = json.loads(r.read())
            return data.get("version") or "unknown" if "controller" in data else None
    except Exception:
        return None


def open_app_window(url: str, tab: bool = False) -> None:
    """Open Studio in its own browser *app window* (Edge or Chrome with --app) when
    one is installed, so it behaves like a desktop program and browser tab
    shortcuts such as Ctrl+T are not intercepted by the browser's tab strip.
    Falls back to the default browser."""
    import os
    import shutil
    import subprocess
    import webbrowser
    if not tab:
        cands = []
        for env in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
            base = os.environ.get(env)
            if base:
                cands += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                          os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
        cands += [shutil.which(n) for n in ("msedge", "google-chrome", "chromium", "chrome")]
        for exe in cands:
            if exe and os.path.exists(exe):
                try:
                    subprocess.Popen([exe, f"--app={url}"])
                    return
                except OSError:
                    continue
    webbrowser.open(url)


def _hand_over(args, url: str) -> int:
    """Studio is already running: import the file into it and bring up the page."""
    import os
    import urllib.request
    if args.file:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with open(args.file, "rb") as fh:
            body = fh.read()
        target = "/api/studio/project/upload" if args.file.lower().endswith(".vcsproj") \
            else "/api/studio/import"
        req = urllib.request.Request(url.replace("/studio", target), data=body,
                                     method="POST",
                                     headers={"content-type": "application/xml",
                                              "x-filename": os.path.basename(args.file)})
        try:
            with opener.open(req, timeout=60) as r:
                r.read()
            print(f"Loaded {args.file} into the running VirtualControlStudio.")
        except Exception as exc:
            print(f"error: the running Studio refused {args.file}: {exc}", file=sys.stderr)
            return 2
    else:
        print("VirtualControlStudio is already running.")
    open_app_window(url, getattr(args, "tab", False))
    return 0


def _studio(args) -> int:
    import os
    from .emulator import Emulator
    url_host = "127.0.0.1" if args.host in ("0.0.0.0", "::") else args.host
    url = f"http://{url_host}:{args.web_port}/studio"
    if getattr(args, "open", False):
        from . import __version__
        running = _running_studio(args.host, args.web_port)
        if running == __version__:
            return _hand_over(args, url)
        if running is not None:
            print(f"An older VirtualControlStudio (or LogixSim Studio, version {running}) is still running on port "
                  f"{args.web_port}, so this version ({__version__}) cannot start.\n"
                  "Close the other black console window (or end python.exe in Task Manager) "
                  "and start again.", file=sys.stderr)
            return 3
    from .verify import format_report, verify
    emu = Emulator(name="VirtualControlStudio")
    emu.settings.setdefault("web", {})["bind_host"] = args.host
    if args.file and args.file.lower().endswith(".vcsproj"):
        from .project import ProjectError, load_project
        try:
            load_project(args.file, emu)
        except ProjectError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        print(format_report(verify(emu.engine.controller)))
    elif args.file:
        try:
            ctrl = load_file(args.file)
        except Exception as exc:
            print(f"error: cannot load {args.file}: {exc}", file=sys.stderr)
            return 2
        with open(args.file, "rb") as fh:
            source = fh.read()
        emu.load_controller(ctrl, logic_file=os.path.basename(args.file), source=source)
        print(format_report(verify(ctrl)))
    emu.settings.setdefault("web", {})["port"] = args.web_port
    if args.opcua and not any(c["kind"] == "opcua" for c in emu.connections.list()):
        emu.connections.add({"preset": "opcua", "name": "OPC UA server", "params": {
            "port": args.opcua_port,
            "bind": "local" if args.host in _LOOPBACK else ("lan" if args.host in ("0.0.0.0", "::")
                                                           else args.host)}})
    if args.host not in _LOOPBACK:
        print(f"WARNING: binding to {args.host} exposes tag write access to the network. "
              f"Use a trusted network only.")
    try:
        emu.start(run=args.run)
    except RuntimeError as exc:
        emu.stop()
        print(f"error: {exc}", file=sys.stderr)
        return 2
    for st in emu.connector_status():
        print(f"  {st['name']}: {st.get('endpoint', '')}")
    try:
        import uvicorn
        print(f"VirtualControlStudio: {url}")
        if getattr(args, "open", False):
            import threading
            threading.Timer(1.5, open_app_window, args=(url, getattr(args, "tab", False))).start()
            print("Opening your browser. Keep this window open; close it to stop VirtualControlStudio.")
        uvicorn.run(create_app(emu), host=args.host, port=args.web_port, log_level="warning")
    finally:
        emu.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
