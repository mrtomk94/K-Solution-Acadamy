"""VirtualControlStudio: a PLC programming and simulation workbench with a
Logix-style soft PLC (the Python package keeps its original name ``logixsim``)."""
APP_NAME = "VirtualControlStudio"
APP_SHORT = "VCS"
__version__ = "1.0.0"
APP_EDITION = "Studio Edition"
TRADEMARK_NOTICE = (
    "Studio 5000, Logix Designer, RSLogix, ControlLogix, CompactLogix, GuardLogix, "
    "FactoryTalk and Logix Echo are trademarks of Rockwell Automation, Inc. "
    "VirtualControlStudio is an independent project and is not affiliated with, "
    "endorsed by or sponsored by Rockwell Automation.")
