"""Write the project (the controller model) as an L5X file that Studio 5000
Logix Designer can import.

* With the imported L5X as ``source``, everything that was not changed in
  VirtualControlStudio is copied from the source unchanged (data types,
  modules, Add-On Instructions, untouched tags, routines, programs and tasks,
  and every controller setting this program does not model), so a round trip
  through VirtualControlStudio keeps the project as it was.
* Changed or new items (tags, routines, programs, tasks) are written from the
  model: rungs as ``Type="N"`` with their comments, Structured Text as lines,
  tags with ``L5K`` and ``Decorated`` data where the format is known.
* Without a source (a project started in VirtualControlStudio) the whole file
  is generated, using the controller and export header of a Studio 5000 v30
  ``1756-L71`` project.

Renamed items keep their original node (``src_name``), so a rename does not
lose attributes this program does not know about.
"""
from __future__ import annotations

import copy
import math
import time

from lxml import etree

from .l5x_loader import _SAFE_PARSER
from .isa.values import nice_real
from .model import ATOMIC, STRING_TYPES

_EXPORT_OPTIONS = "NoRawData L5KData DecoratedData ForceProtectedEncoding AllProjDocTrans"
_RADIX = {"BOOL": "Decimal", "SINT": "Decimal", "INT": "Decimal", "DINT": "Decimal",
          "LINT": "Decimal", "USINT": "Decimal", "UINT": "Decimal", "UDINT": "Decimal",
          "ULINT": "Decimal", "REAL": "Float", "LREAL": "Float"}
# control word bit layout of the predefined structures (first L5K element)
_CTRL_BITS = {"TIMER": ("EN", "TT", "DN"),
              "COUNTER": ("CU", "CD", "DN", "OV", "UN"),
              "CONTROL": ("EN", "EU", "DN", "EM", "ER", "UL", "IN", "FD")}
_CTRL_VALUES = {"TIMER": ("PRE", "ACC"), "COUNTER": ("PRE", "ACC"), "CONTROL": ("LEN", "POS")}


def _cdata(parent, tag, text, **attrs):
    el = etree.SubElement(parent, tag, **attrs)
    el.text = etree.CDATA(text)
    return el


def _desc(parent, text):
    if text:
        _cdata(parent, "Description", text)


def _date() -> str:
    return time.strftime("%a %b %d %H:%M:%S %Y")


# ---- tag data ---------------------------------------------------------------------------
def _num_text(v, dtype: str) -> str:
    if dtype == "BOOL":
        return "1" if v else "0"
    if dtype in ("REAL", "LREAL"):
        f = float(v or 0.0)
        if not math.isfinite(f):
            return "1.#QNAN" if f != f else ("1.#INF" if f > 0 else "-1.#INF")
        return repr(float(nice_real(f))) if dtype == "REAL" else repr(f)
    return str(int(v or 0))


def _l5k_real(v) -> str:
    """REAL in L5K form, e.g. 2.50000000e+000."""
    f = float(v or 0.0)
    mant, exp = f"{f:.8e}".split("e")
    e = int(exp)
    return f"{mant}e{'+' if e >= 0 else '-'}{abs(e):03d}"


def _l5k_atomic(v, dtype: str) -> str:
    if dtype in ("REAL", "LREAL"):
        return _l5k_real(v)
    if dtype == "BOOL":
        return "1" if v else "0"
    return str(int(v or 0))


def _finite(value) -> bool:
    if isinstance(value, float):
        return math.isfinite(value)
    if isinstance(value, dict):
        return all(_finite(v) for v in value.values())
    if isinstance(value, list):
        return all(_finite(v) for v in value)
    return True


def _l5k(value, dtype: str, dims: tuple) -> str | None:
    """L5K data text, or None when this program does not write the L5K form
    (structures other than TIMER/COUNTER/CONTROL, BOOL arrays, which Logix packs
    into words, and non-finite REALs)."""
    if not _finite(value) or (dtype == "BOOL" and dims):
        return None
    if dtype in ATOMIC:
        if dims:
            return "[" + ",".join(_l5k_atomic(x, dtype) for x in value) + "]"
        return _l5k_atomic(value, dtype)
    if dtype in _CTRL_BITS and not dims and isinstance(value, dict):
        word = 0
        for n, name in enumerate(_CTRL_BITS[dtype]):
            if value.get(name):
                word |= 1 << (31 - n)
        if word >= 1 << 31:
            word -= 1 << 32
        a, b = _CTRL_VALUES[dtype]
        return f"[{word},{int(value.get(a, 0))},{int(value.get(b, 0))}]"
    return None


def _decorated(parent, value, dtype: str, dims: tuple, types: dict):
    if dims:
        arr = etree.SubElement(parent, "Array", DataType=dtype,
                               Dimensions=",".join(str(d) for d in dims))
        if dtype in _RADIX:
            arr.set("Radix", _RADIX[dtype])
        for i, v in enumerate(value):
            idx = _index(i, dims)
            if dtype in ATOMIC:
                etree.SubElement(arr, "Element", Index=idx, Value=_num_text(v, dtype))
            else:
                el = etree.SubElement(arr, "Element", Index=idx)
                _struct(el, "Structure", None, v, dtype, types)
        return arr
    if dtype in ATOMIC:
        attrs = {"DataType": dtype, "Radix": _RADIX[dtype]}
        attrs["Value"] = _num_text(value, dtype)
        return etree.SubElement(parent, "DataValue", **attrs)
    return _struct(parent, "Structure", None, value, dtype, types)


def _index(i: int, dims: tuple) -> str:
    out = []
    for d in reversed(dims):
        out.append(i % d)
        i //= d
    return "[" + ",".join(str(x) for x in reversed(out)) + "]"


def escape_string(text: str) -> str:
    """Logix string literal escapes for $ ' and control characters ($hh)."""
    out = []
    for ch in text:
        if ch == "$":
            out.append("$$")
        elif ch == "'":
            out.append("$'")
        elif ord(ch) < 32 or ord(ch) == 127:
            out.append(f"${ord(ch):02X}")
        else:
            out.append(ch)
    return "".join(out)


def _string(parent, tag, name, text, dtype="STRING"):
    attrs = {"Name": name} if name else {}
    s = etree.SubElement(parent, tag, **attrs, DataType=dtype)
    etree.SubElement(s, "DataValueMember", Name="LEN", DataType="DINT", Radix="Decimal",
                     Value=str(len(text or "")))
    q = "'" + escape_string(text or "") + "'"
    _cdata(s, "DataValueMember", q, Name="DATA", DataType="STRING", Radix="ASCII")
    return s


def _struct(parent, tag, name, value, dtype: str, types: dict):
    if dtype in STRING_TYPES:
        return _string(parent, tag, name, value, dtype)
    attrs = {"Name": name} if name else {}
    s = etree.SubElement(parent, tag, **attrs, DataType=dtype)
    members = types[dtype].members if dtype in types else []
    for m in members:
        v = (value or {}).get(m.name)
        if m.dim:
            am = etree.SubElement(s, "ArrayMember", Name=m.name, DataType=m.data_type,
                                  Dimensions=str(m.dim))
            if m.data_type in _RADIX:
                am.set("Radix", _RADIX[m.data_type])
            for i, x in enumerate(v or []):
                if m.data_type in ATOMIC:
                    etree.SubElement(am, "Element", Index=f"[{i}]", Value=_num_text(x, m.data_type))
                else:
                    el = etree.SubElement(am, "Element", Index=f"[{i}]")
                    _struct(el, "Structure", None, x, m.data_type, types)
        elif m.data_type in ATOMIC:
            a = {"Name": m.name, "DataType": m.data_type}
            if m.data_type != "BOOL":
                a["Radix"] = _RADIX[m.data_type]
            a["Value"] = _num_text(v, m.data_type)
            etree.SubElement(s, "DataValueMember", **a)
        elif m.data_type in STRING_TYPES:
            _string(s, "StructureMember", m.name, v, m.data_type)
        else:
            _struct(s, "StructureMember", m.name, v, m.data_type, types)
    return s


def tag_node(tag, types: dict, db=None) -> etree._Element:
    """A <Tag> element for a base tag of the model."""
    dims = tuple(getattr(tag, "dims", ()) or ())
    t = etree.Element("Tag", Name=tag.name, TagType="Base", DataType=tag.data_type)
    if dims:
        t.set("Dimensions", " ".join(str(d) for d in dims))
    if tag.data_type in _RADIX:
        from .model import styles_for
        r = getattr(tag, "radix", "") or ""
        t.set("Radix", r if r in styles_for(tag.data_type) else _RADIX[tag.data_type])
    t.set("Constant", "true" if getattr(tag, "constant", False) else "false")
    t.set("ExternalAccess", getattr(tag, "external_access", "") or "Read/Write")
    _desc(t, tag.description)
    value = tag.init
    if value is None:
        return t                                    # all zero: Studio 5000 uses the defaults
    l5k = _l5k(value, tag.data_type, dims)
    if l5k is not None:
        d = etree.SubElement(t, "Data", Format="L5K")
        d.text = etree.CDATA(l5k)
    if tag.data_type in STRING_TYPES and not dims:
        d = etree.SubElement(t, "Data", Format="Decorated")
        _string(d, "Structure", None, value, tag.data_type)
        return t
    d = etree.SubElement(t, "Data", Format="Decorated")
    _decorated(d, value, tag.data_type, dims, types)
    return t


def alias_node(name: str, target: str, description: str = "") -> etree._Element:
    t = etree.Element("Tag", Name=name, TagType="Alias", AliasFor=target,
                      ExternalAccess="Read/Write")
    _desc(t, description)
    return t


# ---- routines ---------------------------------------------------------------------------
def routine_node(rt) -> etree._Element:
    r = etree.Element("Routine", Name=rt.name, Type=rt.rtype)
    _desc(r, rt.description)
    if rt.rtype == "RLL":
        if rt.rungs:
            rll = etree.SubElement(r, "RLLContent")
            for n, text in enumerate(rt.rungs):
                rung = etree.SubElement(rll, "Rung", Number=str(n), Type="N")
                if n in rt.comments:
                    _cdata(rung, "Comment", rt.comments[n])
                _cdata(rung, "Text", text if text.strip() else ";")
    elif rt.rtype == "ST":
        st = etree.SubElement(r, "STContent")
        for n, line in enumerate(rt.text.split("\n")):
            _cdata(st, "Line", line, Number=str(n))
    return r


def _replace_content(rnode, rt) -> None:
    """Rewrite the logic of a routine node in place (keeps its other children)."""
    fresh = routine_node(rt)
    for child in list(rnode):
        if child.tag in ("RLLContent", "STContent", "Description"):
            rnode.remove(child)
    for i, child in enumerate(fresh):
        rnode.insert(i, child)
    rnode.set("Name", rt.name)


# ---- whole project ----------------------------------------------------------------------
def _src(obj):
    return getattr(obj, "src_name", None) or obj.name


def _tags_section(old, model_tags, aliases: dict, types, db, skip=()):
    """Rebuild a <Tags> element: source order first (reused where unchanged), then new."""
    new = etree.Element("Tags")
    by_src = {}
    for t in model_tags:
        if t.name not in skip:
            by_src.setdefault(_src(t), t)
    done_tags, done_alias = set(), set()
    for node in (old.findall("Tag") if old is not None else []):
        name = node.get("Name")
        if node.get("TagType") == "Alias":
            if name in aliases:                        # kept; the target may have been renamed
                n2 = copy.deepcopy(node)
                n2.set("AliasFor", aliases[name][0])
                old_desc = (n2.findtext("Description") or "").strip()
                if old_desc != (aliases[name][1] or ""):
                    for ch in n2.findall("Description"):
                        n2.remove(ch)
                    if aliases[name][1]:
                        d = etree.Element("Description")
                        d.text = etree.CDATA(aliases[name][1])
                        n2.insert(0, d)
                new.append(n2)
                done_alias.add(name)
            continue
        t = by_src.get(name)
        if t is None:
            continue                                   # deleted in VirtualControlStudio
        done_tags.add(id(t))
        if getattr(t, "dirty", False):
            new.append(tag_node(t, types, db))
        else:
            n2 = copy.deepcopy(node)
            n2.set("Name", t.name)
            new.append(n2)
    for t in model_tags:
        if t.name in skip or id(t) in done_tags:
            continue
        new.append(tag_node(t, types, db))
    for name, (target, desc) in aliases.items():
        if name not in done_alias:
            new.append(alias_node(name, target, desc))
    return new


def _aliases_for(c, prefix: str, alias_desc: dict) -> dict:
    out = {}
    for full, target in c.aliases.items():
        if prefix:
            if not full.startswith(prefix):
                continue
            name = full[len(prefix):]
        else:
            if full.startswith("Program:"):
                continue
            name = full
        out[name] = (target, alias_desc.get(full, ""))
    return out


def _program_node(old, prog, c, types, db, alias_desc) -> etree._Element:
    if old is not None:
        p = copy.deepcopy(old)
        for ch in list(p):
            if ch.tag in ("Description", "Tags", "Routines"):
                p.remove(ch)
    else:
        p = etree.Element("Program", Name=prog.name, TestEdits="false",
                          MainRoutineName=prog.main or "", Disabled="false", UseAsFolder="false")
    p.set("Name", prog.name)
    if prog.main:
        p.set("MainRoutineName", prog.main)
    elif "MainRoutineName" in p.attrib:
        del p.attrib["MainRoutineName"]
    p.set("Disabled", "true" if prog.disabled else "false")
    pos = 0
    if prog.description:
        d = etree.Element("Description")
        d.text = etree.CDATA(prog.description)
        p.insert(pos, d)
        pos += 1
    old_tags = old.find("Tags") if old is not None else None
    p.insert(pos, _tags_section(old_tags, prog.tags,
                                _aliases_for(c, f"Program:{prog.name}.", alias_desc), types, db))
    pos += 1
    routines = etree.Element("Routines")
    old_r = {r.get("Name"): r for r in (old.findall("Routines/Routine") if old is not None else [])}
    used = set()
    for name in [r.get("Name") for r in (old.findall("Routines/Routine") if old is not None else [])]:
        rt = next((r for r in prog.routines.values() if _src(r) == name), None)
        if rt is None:
            continue
        used.add(id(rt))
        node = copy.deepcopy(old_r[name])
        if getattr(rt, "modified", False) and rt.rtype in ("RLL", "ST"):
            _replace_content(node, rt)
        else:
            node.set("Name", rt.name)
            if getattr(rt, "description_changed", False):
                for ch in node.findall("Description"):
                    node.remove(ch)
                if rt.description:
                    d = etree.Element("Description")
                    d.text = etree.CDATA(rt.description)
                    node.insert(0, d)
        routines.append(node)
    for rt in prog.routines.values():
        if id(rt) not in used:
            routines.append(routine_node(rt))
    p.insert(pos, routines)
    return p


def _task_node(old, t) -> etree._Element:
    if old is not None:
        n = copy.deepcopy(old)
        for ch in list(n):
            if ch.tag in ("ScheduledPrograms", "Description"):
                n.remove(ch)
    else:
        n = etree.Element("Task", Name=t["name"], Type=t["type"])
    attrs = dict(n.attrib)
    n.attrib.clear()
    n.set("Name", t["name"])
    n.set("Type", t["type"])
    if t["type"] == "PERIODIC":
        n.set("Rate", _fmt(t.get("rate_ms") or 10))
    n.set("Priority", str(int(t.get("priority") or 10)))
    n.set("Watchdog", _fmt(t.get("watchdog_ms") or 500))
    n.set("DisableUpdateOutputs", attrs.get("DisableUpdateOutputs", "false"))
    n.set("InhibitTask", "true" if t.get("inhibited") else "false")
    for k, v in attrs.items():
        if k not in n.attrib and k != "Rate":
            n.set(k, v)
    pos = 0
    if t.get("description"):
        d = etree.Element("Description")
        d.text = etree.CDATA(t["description"])
        n.insert(0, d)
        pos = 1
    if t.get("type") != "EVENT" or t["programs"]:
        sp = etree.Element("ScheduledPrograms")
        for prog in t["programs"]:
            etree.SubElement(sp, "ScheduledProgram", Name=prog)
        n.insert(pos, sp)
    return n


def _fmt(v) -> str:
    f = float(v)
    return str(int(f)) if f.is_integer() else repr(f)


def _same_task(old, t) -> bool:
    if old is None:
        return False
    progs = [s.get("Name") for s in old.findall("ScheduledPrograms/ScheduledProgram")]
    rate = old.get("Rate")
    return (old.get("Name") == t["name"] and (old.get("Type") or "").upper() == t["type"]
            and progs == t["programs"]
            and (t["type"] != "PERIODIC" or (rate is not None and float(rate) == float(t.get("rate_ms") or 0)))
            and int(old.get("Priority") or 10) == int(t.get("priority") or 10)
            and float(old.get("Watchdog") or 500) == float(t.get("watchdog_ms") or 500)
            and (old.get("InhibitTask") == "true") == bool(t.get("inhibited"))
            and (old.findtext("Description") or "").strip() == (t.get("description") or ""))


def _new_document(c) -> etree._Element:
    """The skeleton of a new project, like a Studio 5000 v30 export."""
    from .project_ops import NEW_MAJOR, NEW_MINOR, NEW_PROCESSOR, NEW_SOFTWARE
    now = _date()
    major, _, minor = (c.revision or f"{NEW_MAJOR}.{NEW_MINOR}").partition(".")
    root = etree.Element("RSLogix5000Content", SchemaRevision="1.0", SoftwareRevision=NEW_SOFTWARE,
                         TargetName=c.name, TargetType="Controller", ContainsContext="false",
                         ExportDate=now, ExportOptions=_EXPORT_OPTIONS)
    proc = c.processor or NEW_PROCESSOR
    cn = etree.SubElement(root, "Controller", Use="Target", Name=c.name, ProcessorType=proc,
                          MajorRev=major or str(NEW_MAJOR), MinorRev=minor or str(NEW_MINOR),
                          TimeSlice="20", ShareUnusedTimeSlice="1", ProjectCreationDate=now,
                          LastModifiedDate=now, SFCExecutionControl="CurrentActive",
                          SFCRestartPosition="MostRecent", SFCLastScan="DontScan",
                          MatchProjectToController="false", CanUseRPIFromProducer="false",
                          InhibitAutomaticFirmwareUpdate="0",
                          PassThroughConfiguration="EnabledWithAppend",
                          DownloadProjectDocumentationAndExtendedProperties="true",
                          DownloadProjectCustomProperties="true", ReportMinorOverflow="false")
    if c.description:
        _cdata(cn, "Description", c.description)
    etree.SubElement(cn, "RedundancyInfo", Enabled="false", KeepTestEditsOnSwitchOver="false",
                     IOMemoryPadPercentage="90", DataTablePadPercentage="50")
    etree.SubElement(cn, "Security", Code="0", ChangesToDetect="16#ffff_ffff_ffff_ffff")
    etree.SubElement(cn, "SafetyInfo")
    etree.SubElement(cn, "DataTypes")
    mods = etree.SubElement(cn, "Modules")
    if proc == NEW_PROCESSOR:
        m = etree.SubElement(mods, "Module", Name="Local", CatalogNumber=proc, Vendor="1",
                             ProductType="14", ProductCode="92", Major=major or str(NEW_MAJOR),
                             Minor=minor or str(NEW_MINOR), ParentModule="Local",
                             ParentModPortId="1", Inhibited="false", MajorFault="true")
        etree.SubElement(m, "EKey", State="ExactMatch")
        ports = etree.SubElement(m, "Ports")
        port = etree.SubElement(ports, "Port", Id="1", Address="0", Type="ICP", Upstream="false")
        etree.SubElement(port, "Bus", Size="10")
    etree.SubElement(cn, "AddOnInstructionDefinitions")
    etree.SubElement(cn, "Tags")
    etree.SubElement(cn, "Programs")
    etree.SubElement(cn, "Tasks")
    etree.SubElement(cn, "CST", MasterID="0")
    etree.SubElement(cn, "WallClockTime", LocalTimeAdjustment="0", TimeZone="0")
    etree.SubElement(cn, "Trends")
    etree.SubElement(cn, "DataLogs")
    etree.SubElement(cn, "TimeSynchronize", Priority1="128", Priority2="128", PTPEnable="false")
    return root


def write_l5x(controller, source: bytes | None = None, db=None) -> bytes:
    """The whole project as L5X bytes (see the module docstring)."""
    c = controller
    alias_desc = c.alias_descriptions
    if source:
        root = etree.fromstring(source, parser=_SAFE_PARSER)
        cnode = root if root.tag == "Controller" else root.find(".//Controller")
        if cnode is None:
            raise ValueError("the stored L5X has no <Controller>")
    else:
        root = _new_document(c)
        cnode = root.find("Controller")
    if root.tag == "RSLogix5000Content":
        root.set("TargetName", c.name)
    cnode.set("Name", c.name)
    types = {**_types(c), **(db._types if db is not None else {})}
    module_tags = {m["tag"] for m in c.modules}

    # controller tags
    old = cnode.find("Tags")
    new = _tags_section(old, c.tags, _aliases_for(c, "", alias_desc), types, db,
                        skip=module_tags)
    if old is not None:
        cnode.replace(old, new)
    else:
        _insert_before(cnode, new, ("Programs", "Tasks"))

    # programs
    old_p = cnode.find("Programs")
    progs = etree.Element("Programs")
    old_nodes = {p.get("Name"): p for p in (old_p.findall("Program") if old_p is not None else [])}
    done = set()
    for name in list(old_nodes):
        prog = next((p for p in c.programs.values() if _src(p) == name), None)
        if prog is None:
            continue
        done.add(id(prog))
        progs.append(_program_node(old_nodes[name], prog, c, types, db, alias_desc))
    for prog in c.programs.values():
        if id(prog) not in done:
            progs.append(_program_node(None, prog, c, types, db, alias_desc))
    if old_p is not None:
        cnode.replace(old_p, progs)
    else:
        _insert_before(cnode, progs, ("Tasks",))

    # tasks
    old_t = cnode.find("Tasks")
    tasks = etree.Element("Tasks")
    old_tasks = [t for t in (old_t.findall("Task") if old_t is not None else [])]
    by_name = {t.get("Name"): t for t in old_tasks}
    emitted = set()
    for node in old_tasks:
        t = next((x for x in c.tasks if x.get("src_name", x["name"]) == node.get("Name")), None)
        if t is None:
            continue
        emitted.add(id(t))
        tasks.append(copy.deepcopy(node) if _same_task(node, t) else _task_node(node, t))
    for t in c.tasks:
        if id(t) not in emitted:
            tasks.append(_task_node(by_name.get(t.get("src_name", t["name"])), t))
    if old_t is not None:
        cnode.replace(old_t, tasks)
    else:
        _insert_before(cnode, tasks, ("CST", "WallClockTime", "Trends", "DataLogs"))
    if source and getattr(c, "description_changed", False):
        for ch in cnode.findall("Description"):
            cnode.remove(ch)
        if c.description:
            d = etree.Element("Description")
            d.text = etree.CDATA(c.description)
            cnode.insert(0, d)
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)


def _types(c) -> dict:
    from .model import PREDEFINED
    out = dict(PREDEFINED)
    out.update(c.data_types)
    for a in c.aois.values():
        out.setdefault(a.name, a.data_type())
    return out


def _insert_before(cnode, node, names) -> None:
    for i, ch in enumerate(cnode):
        if ch.tag in names:
            cnode.insert(i, node)
            return
    cnode.append(node)


def export_l5x(controller, source: bytes) -> bytes:
    """Kept for callers of the first editing milestone: same as write_l5x."""
    return write_l5x(controller, source)
