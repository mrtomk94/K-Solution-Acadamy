"""Connection Manager: the project's connections to Node-RED, Ignition, C-more,
simulators and other programs.

Each connection = {id, name, kind, preset, enabled, params, mapping}. ``kind``
picks a connector class from the registry (``connectors/``); ``preset`` only
fills in defaults and the "other side" help for a platform.

* Connections start, stop, restart and change one at a time; the controller and
  the other connections keep running. A connection that fails to start is marked
  ``error`` with a plain-language message; it never stops the rest.
* Status is the same for every connection (state, light, endpoint, clients,
  counters, error) and is pushed to the UI as a ``connection`` bus event.
* Every connection keeps an activity log (the last 200 events).
* ``test(config)`` runs checks (port free, reachable, handshake) without changing
  a running connection.
* Saved in the project (``connections``); an old ``connectors`` dict is converted.
"""
from __future__ import annotations

import collections
import copy
import itertools
import logging
import threading
import time

from .connectors.base import REGISTRY, ParamError, _load_builtins, validate_params
from .connectors.errors import explain, local_ips

log = logging.getLogger(__name__)

# platform presets: wizard tile -> connector kind + defaults
PRESETS = {
    "node-red": {"title": "Node-RED", "kind": "ws_server", "icon": "NR",
                 "summary": "WebSocket with Node-RED's built-in nodes; import the generated flow",
                 "params": {"port": 8810}},
    "ignition": {"title": "Ignition", "kind": "opcua", "icon": "IG",
                 "summary": "OPC UA server; add it as an OPC UA connection in the gateway",
                 "params": {"port": 4840}},
    "cmore-cip": {"title": "C-more HMI (EtherNet/IP)", "kind": "cip", "icon": "CM",
                  "summary": "Allen-Bradley EtherNet/IP 'Tag Based' protocol, tag names as-is",
                  "params": {"port": 44818, "slot": 0}},
    "cmore-modbus": {"title": "C-more HMI (Modbus TCP)", "kind": "modbus_tcp", "icon": "CM",
                     "summary": "Modbus TCP/IP with a generated register map",
                     "params": {"port": 502}},
    "ws-sim-in": {"title": "Simulator → VCS (WebSocket)", "kind": "ws_server", "icon": "WS",
                  "summary": "Your simulator connects to VirtualControlStudio",
                  "params": {"port": 8811}},
    "ws-sim-out": {"title": "VCS → Simulator (WebSocket)", "kind": "ws_client", "icon": "WS",
                   "summary": "VirtualControlStudio connects to your simulator's WebSocket server",
                   "params": {"url": "ws://127.0.0.1:9000/"}},
    "modbus-device": {"title": "Modbus TCP device", "kind": "modbus_client", "icon": "MD",
                      "summary": "Read I/O, sensors, IO-Link masters, drives and meters over Modbus TCP",
                      "params": {"port": 502}},
    "opcua": {"title": "OPC UA client app", "kind": "opcua", "icon": "UA",
              "summary": "Kepware, UaExpert, SCADA and other OPC UA clients", "params": {}},
    "modbus": {"title": "Modbus TCP device / HMI", "kind": "modbus_tcp", "icon": "MB",
               "summary": "Any Modbus TCP client", "params": {"port": 5020}},
    "custom": {"title": "Custom", "kind": None, "icon": "…",
               "summary": "Choose the connector and every setting yourself", "params": {}},
}

MAPPED = ("ws_client", "modbus_client")          # kinds with a mapping table

LIGHT = {"off": "grey", "starting": "blue", "listening": "amber", "serving": "green",
         "connected": "green", "connecting": "blue", "reconnecting": "amber", "error": "red"}


class ConnectionError_(Exception):
    def __init__(self, message: str, status: int = 400, field: str | None = None):
        super().__init__(message)
        self.status = status
        self.field = field


class _Conn:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.connector = None
        self.error: dict | None = None
        self.state = "off"
        self.log = collections.deque(maxlen=200)
        self.started_at = None


class ConnectionManager:
    def __init__(self, emu):
        self.emu = emu
        self._conns: "collections.OrderedDict[str, _Conn]" = collections.OrderedDict()
        self._lock = threading.RLock()
        self._ids = itertools.count(1)
        self.active = False                       # start() was called (the app is serving)

    # ---- kinds / presets ----------------------------------------------------------------
    @staticmethod
    def kinds() -> dict:
        _load_builtins()
        out = {}
        for k, cls in REGISTRY.items():
            out[k] = {"kind": k, "title": getattr(cls, "title", k), "role": getattr(cls, "role", "server"),
                      "summary": getattr(cls, "summary", ""), "schema": getattr(cls, "schema", [])}
        return out

    # ---- configuration ----------------------------------------------------------------------
    def list(self) -> list[dict]:
        with self._lock:
            return [self._describe(c) for c in self._conns.values()]

    def get(self, cid: str) -> dict:
        return self._describe(self._get(cid))

    def _get(self, cid: str) -> _Conn:
        c = self._conns.get(cid)
        if c is None:
            raise ConnectionError_(f"no connection {cid!r}", 404)
        return c

    def _clean(self, cfg: dict, existing_id: str | None = None) -> dict:
        _load_builtins()
        preset = cfg.get("preset") or "custom"
        p = PRESETS.get(preset, PRESETS["custom"])
        kind = cfg.get("kind") or p["kind"]
        if kind not in REGISTRY:
            raise ConnectionError_(f"unknown connection type {kind!r}", field="kind")
        cls = REGISTRY[kind]
        name = str(cfg.get("name") or "").strip()[:60]
        if not name:                                # default: the platform name, numbered
            taken = {o.cfg["name"].lower() for o in self._conns.values()
                     if o.cfg["id"] != existing_id}
            name, n = p["title"], 2
            while name.lower() in taken:
                name, n = f"{p['title']} {n}", n + 1
        for other in self._conns.values():
            if other.cfg["id"] != existing_id and other.cfg["name"].lower() == name.lower():
                raise ConnectionError_(f"a connection named {name!r} already exists", 409, "name")
        params = {**p["params"], **(cfg.get("params") or {})}
        try:
            params = validate_params(getattr(cls, "schema", []), params)
        except ParamError as exc:
            raise ConnectionError_(str(exc), field=exc.field) from None
        if kind == "opcua":
            params["users"] = _hash_users(params.get("users") or {},
                                          self._conns[existing_id].cfg["params"].get("users")
                                          if existing_id in self._conns else {})
        mapping = cfg.get("mapping") or []
        if kind in ("ws_client", "modbus_client"):
            if kind == "ws_client":
                from .connectors.ws_client import _row
                rows = lambda ms: [_row(m) for m in ms]               # noqa: E731
            else:
                from .connectors.modbus_client import points as rows
            try:
                mapping = rows(mapping)
            except ParamError as exc:
                raise ConnectionError_(str(exc), field="mapping") from None
        out = {"id": existing_id or cfg.get("id") or f"c{next(self._ids)}", "name": name,
               "kind": kind, "preset": preset, "enabled": bool(cfg.get("enabled", True)),
               "params": params, "mapping": mapping}
        self._check_ports(out)
        return out

    def _check_ports(self, cfg: dict) -> None:
        port = (cfg["params"] or {}).get("port")
        if not port or REGISTRY[cfg["kind"]].role != "server":
            return
        for other in self._conns.values():
            o = other.cfg
            if o["id"] != cfg["id"] and o["enabled"] and cfg["enabled"] and \
                    REGISTRY[o["kind"]].role == "server" and o["params"].get("port") == port:
                raise ConnectionError_(f"port {port} is already used by the connection "
                                       f"'{o['name']}'", 409, "port")
        web = self.emu.settings.get("web") or {}
        if web.get("port") == port:
            raise ConnectionError_(f"port {port} is the VirtualControlStudio UI port", 409, "port")

    def add(self, cfg: dict) -> dict:
        with self._lock:
            clean = self._clean(cfg)
            while clean["id"] in self._conns:
                clean["id"] = f"c{next(self._ids)}"
            c = _Conn(clean)
            self._conns[clean["id"]] = c
            self._note(c, "info", "connection created")
            self._project_changed()
            self._changed()
            if self.active and clean["enabled"]:
                self._start(c)
            return self._describe(c)

    def update(self, cid: str, cfg: dict) -> dict:
        with self._lock:
            c = self._get(cid)
            merged = {**c.cfg, **{k: v for k, v in cfg.items() if k != "id"}}
            if "params" in cfg:
                merged["params"] = {**c.cfg["params"], **(cfg.get("params") or {})}
            clean = self._clean(merged, existing_id=cid)
            self._stop(c)                          # only this connection restarts
            c.cfg, c.error = clean, None
            self._project_changed()
            self._note(c, "info", "settings changed" if set(cfg) - {"enabled"} else
                       ("turned on" if clean["enabled"] else "turned off"))
            if self.active and clean["enabled"]:
                self._start(c)
            self._changed()
            return self._describe(c)

    def remove(self, cid: str) -> None:
        with self._lock:
            c = self._get(cid)
            self._stop(c)
            del self._conns[cid]
            self._project_changed()
            self._changed()

    def set_enabled(self, cid: str, enabled: bool) -> dict:
        return self.update(cid, {"enabled": bool(enabled)})

    def restart(self, cid: str) -> dict:
        with self._lock:
            c = self._get(cid)
            self._stop(c)
            if c.cfg["enabled"]:
                self._start(c)
            return self._describe(c)

    # ---- lifecycle ------------------------------------------------------------------------
    def start(self) -> None:
        """Start every enabled connection (failures are recorded, never raised)."""
        with self._lock:
            self.active = True
            for c in self._conns.values():
                if c.cfg["enabled"] and c.connector is None:
                    self._start(c)

    def stop(self) -> None:
        with self._lock:
            self.active = False
            for c in reversed(list(self._conns.values())):
                self._stop(c)

    def reload(self) -> None:
        """A new program was loaded: restart running connections so they see the new tags."""
        with self._lock:
            for c in self._conns.values():
                if c.connector is not None:
                    self._stop(c)
                    self._start(c)

    def _start(self, c: _Conn) -> None:
        cls = REGISTRY[c.cfg["kind"]]
        c.state, c.error = "starting", None
        try:
            settings = dict(c.cfg["params"])
            if c.cfg["kind"] in MAPPED:
                settings["mapping"] = c.cfg["mapping"]
            settings["_name"] = c.cfg["name"]
            con = cls(self.emu, **settings)
            con._log = lambda level, msg, _c=c: self._note(_c, level, msg)
            con.start()
            c.connector = con
            c.started_at = time.time()
            c.state = "running"
            persist = getattr(con, "persist", None)
            if persist:
                c.cfg["params"].update(persist())
        except Exception as exc:
            c.connector = None
            p = c.cfg["params"]
            e = explain(exc.__cause__ or exc, port=p.get("port"), host=p.get("bind"),
                        kind=c.cfg["kind"], local_ips=local_ips())
            if e["code"] == "error":
                e["message"] = str(exc)
            c.error, c.state = e, "error"
            self._note(c, "error", f"{e['message']} {e['hint']}".strip())
        self._changed()

    def _stop(self, c: _Conn) -> None:
        con, c.connector = c.connector, None
        if con is not None:
            try:
                con.stop()
            except Exception as exc:                 # never let one stop block the others
                log.exception("connection %s failed to stop", c.cfg["name"])
                self._note(c, "warn", f"stop: {exc}")
            self._note(c, "info", "stopped")
        c.state = "off"
        c.started_at = None

    # ---- status -----------------------------------------------------------------------------
    def _describe(self, c: _Conn) -> dict:
        cfg = copy.deepcopy(c.cfg)
        for u in (cfg["params"].get("users") or {}):        # never send password hashes
            cfg["params"]["users"][u] = "••••"
        if cfg["params"].get("token"):
            cfg["params"]["token_set"] = True
        st = {}
        if c.connector is not None:
            try:
                st = c.connector.status()
            except Exception as exc:
                st = {"error": {"code": "error", "message": str(exc), "hint": ""}}
        cfg["status"] = self._summary(c, st)
        return cfg

    def _summary(self, c: _Conn, st: dict) -> dict:
        role = REGISTRY[c.cfg["kind"]].role
        if not c.cfg["enabled"]:
            state, text = "off", "Off"
        elif c.error:
            state, text = "error", f"Error — {c.error['message']}"
        elif c.connector is None:
            state, text = ("off", "Not started") if not self.active else ("error", "Not running")
        elif role == "client":
            state = st.get("state", "connecting")
            text = {"connected": "Connected", "connecting": "Connecting…",
                    "reconnecting": f"Reconnecting — attempt {st.get('attempt', 1)}, "
                                    f"next in {st.get('next_in', 0):g} s"}.get(state, state)
            if st.get("error") and state != "connected":
                text += f" ({st['error']['message']})"
        else:
            n = st.get("client_count", 0)
            state = "serving" if n else "listening"
            text = (f"Listening — {n} client{'s' if n != 1 else ''} connected" if n else
                    "Listening — no clients yet")
        return {"state": state, "light": LIGHT.get(state, "grey"), "text": text,
                "endpoint": st.get("endpoint", ""), "since": c.started_at,
                "error": c.error or (st.get("error") if state != "connected" else None),
                "details": {k: v for k, v in st.items() if k not in ("name", "endpoint", "error")}}

    def summary(self) -> dict:
        """The worst state over all enabled connections (for the toolbar light)."""
        items = [c for c in self.list() if c["enabled"]]
        order = ["red", "amber", "blue", "green", "grey"]
        worst = min((c["status"]["light"] for c in items), key=order.index, default="grey")
        return {"light": worst, "count": len(items),
                "items": [{"id": c["id"], "name": c["name"], "light": c["status"]["light"],
                           "text": c["status"]["text"]} for c in items]}

    def log(self, cid: str) -> list[dict]:
        return list(self._get(cid).log)

    def _note(self, c: _Conn, level: str, message: str) -> None:
        c.log.append({"time": time.time(), "level": level, "message": message})

    def _project_changed(self) -> None:
        eng = self.emu.engine
        eng.change_count = getattr(eng, "change_count", 0) + 1

    def _changed(self) -> None:
        try:
            self.emu.bus.emit("connection", {"summary": self.summary()})
        except Exception:
            pass

    # ---- test / other side ---------------------------------------------------------------
    def test(self, cfg: dict, cid: str | None = None) -> list[dict]:
        """Checks for a configuration (saved or not). The running connection (if any)
        is used read-only."""
        with self._lock:
            base = self._get(cid).cfg if cid else {}
            merged = {**base, **cfg, "params": {**base.get("params", {}), **(cfg.get("params") or {})}}
            try:
                clean = self._clean({**merged, "name": merged.get("name") or "test"},
                                    existing_id=cid or "__test__")
            except ConnectionError_ as exc:
                return [{"ok": False, "label": str(exc), "hint": ""}]
            running = self._conns[cid].connector if cid and cid in self._conns else None
            if running is not None and clean["params"] != self._conns[cid].cfg["params"]:
                running = None                     # testing changed settings: not the live one
        cls = REGISTRY[clean["kind"]]
        try:
            if clean["kind"] == "modbus_client":
                return cls.test(self.emu, clean["params"], running=running, mapping=clean["mapping"])
            return cls.test(self.emu, clean["params"], running=running)
        except Exception as exc:
            e = explain(exc)
            return [{"ok": False, "label": e["message"], "hint": e["hint"]}]

    def other_side(self, cid: str) -> dict:
        c = self._get(cid)
        if c.connector is not None:
            out = c.connector.other_side()
        else:
            cls = REGISTRY[c.cfg["kind"]]
            try:
                settings = dict(c.cfg["params"])
                if c.cfg["kind"] in MAPPED:
                    settings["mapping"] = c.cfg["mapping"]
                out = cls(self.emu, **settings).other_side()
            except Exception as exc:
                out = {"values": {}, "steps": [f"Fix the settings first: {exc}"], "examples": {}}
        out["preset"] = c.cfg["preset"]
        out["running"] = c.connector is not None
        return out

    def connector(self, cid: str):
        return self._get(cid).connector

    # ---- persistence ------------------------------------------------------------------------
    def to_project(self) -> list[dict]:
        return [copy.deepcopy(c.cfg) for c in self._conns.values()]

    def load(self, items: list | None, legacy: dict | None = None) -> None:
        """Replace all connections (stops the old ones). ``legacy`` = old
        ``connectors`` dict ({"opcua": {"enabled":.., "port":..}, "cip": {...}})."""
        with self._lock:
            for c in list(self._conns.values()):
                self._stop(c)
            self._conns.clear()
            items = list(items or [])
            if not items and legacy:
                items = migrate(legacy)
            for cfg in items:
                try:
                    clean = self._clean(cfg, existing_id=cfg.get("id"))
                except ConnectionError_ as exc:
                    log.warning("connection %r skipped: %s", cfg.get("name"), exc)
                    continue
                self._conns[clean["id"]] = _Conn(clean)
            n = max([int(i[1:]) for i in self._conns if i[1:].isdigit()] or [0])
            self._ids = itertools.count(n + 1)
            if self.active:
                for c in self._conns.values():
                    if c.cfg["enabled"]:
                        self._start(c)
            self._changed()


def migrate(legacy: dict) -> list[dict]:
    """Old project ``connectors`` dict -> connections."""
    out = []
    names = {"opcua": ("OPC UA server", "opcua"), "cip": ("EtherNet/IP server", "cmore-cip")}
    for kind, settings in (legacy or {}).items():
        settings = dict(settings or {})
        enabled = settings.pop("enabled", True)
        host = settings.pop("host", None)
        if host and "bind" not in settings:
            settings["bind"] = "local" if host in ("127.0.0.1", "localhost") else \
                ("lan" if host == "0.0.0.0" else host)
        title, preset = names.get(kind, (kind, "custom"))
        out.append({"name": title, "kind": kind, "preset": preset, "enabled": enabled,
                    "params": settings})
    return out


def _hash_users(users: dict, old: dict | None) -> dict:
    from .connectors.opcua import hash_password
    out = {}
    for name, pw in (users or {}).items():
        name = str(name).strip()
        if not name:
            continue
        if pw in ("••••", "", None) and old and name in old:
            out[name] = old[name]                    # unchanged (the UI shows a placeholder)
        elif isinstance(pw, str) and pw.startswith("pbkdf2:sha256:"):
            out[name] = pw
        elif pw:
            out[name] = hash_password(str(pw))
    return out
