"""Project-edit service: create, change, rename and delete tags, routines,
programs and tasks in the controller model the engine executes.

The same rules as editing.py (rung / Structured Text edits) apply:

* Each change is validated here (never trust the UI), then applied while
  holding the engine's scan lock, so it lands between two scans. The
  controller keeps running and tag values are kept.
* Changes are serialized with the rung editor (one shared edit lock).
* ``project_version`` gives optimistic concurrency for structure changes; a
  change based on an older version is refused (409).
* Every change can be undone (``undo``), most recent first.
* Deleting something the logic still uses is refused unless ``force`` is set;
  the refusal lists every reference (rung / line), so the UI can ask first.
* Renaming a tag, routine or program rewrites the references in the logic
  (token-aware: comments, strings, members, instruction names, labels and
  routine operands are never touched).

Name rules follow Logix: 1-40 characters, letters, digits and underscores,
starting with a letter or underscore, no two underscores in a row and no
trailing underscore. Names are compared without regard to case.
"""
from __future__ import annotations

import copy
import math
import re
import time

from .editing import _EDIT_LOCK, EditError
from .model import ATOMIC, PREDEFINED, STRING_TYPES, Controller, Program, Routine

NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,39}$")
TASK_TYPES = ("CONTINUOUS", "PERIODIC", "EVENT")
ACCESS = {"Read/Write": "rw", "Read Only": "ro", "None": "none"}
MAX_UNDO = 50

# the controller a new project starts with (matches a Studio 5000 v30 export of a
# 1756-L71; change the controller type in Studio 5000 after importing if needed)
NEW_PROCESSOR, NEW_MAJOR, NEW_MINOR, NEW_SOFTWARE = "1756-L71", 30, 14, "30.02"


class ProjectOpError(EditError):
    def __init__(self, message: str, status: int = 400, references: list | None = None):
        super().__init__(message, status)
        self.references = references or []


# ---- helpers --------------------------------------------------------------------------
def check_name(name, what: str = "name") -> str:
    if not isinstance(name, str) or not NAME_RE.match(name):
        raise ProjectOpError(f"invalid {what} {name!r}: 1-40 letters, digits or underscores, "
                             "starting with a letter or underscore")
    if "__" in name or name.endswith("_"):
        raise ProjectOpError(f"invalid {what} {name!r}: no two underscores in a row and no "
                             "underscore at the end")
    return name


def _same(a: str, b: str) -> bool:
    return a.lower() == b.lower()


def _find(names, name):
    return next((n for n in names if _same(n, name)), None)


def _bump(engine) -> None:
    engine.project_version = getattr(engine, "project_version", 0) + 1
    engine.change_count = getattr(engine, "change_count", 0) + 1


def _check_pv(engine, pv) -> None:
    if pv is not None and int(pv) != getattr(engine, "project_version", 0):
        raise ProjectOpError("the project was changed by another edit; reload and try again", 409)


def _push_undo(engine, label: str, fn) -> None:
    stack = engine.__dict__.setdefault("project_undo", [])
    stack.append((label, fn))
    del stack[:-MAX_UNDO]


def _log(engine, op: str, **detail) -> dict:
    entry = {"time": time.time(), "op": op, "project_version": engine.project_version,
             "effective_scan": engine.scan_count + 1, "mode": engine.mode, **detail}
    engine.edit_log.append(entry)
    del engine.edit_log[:-200]
    return entry


def _invalidate(engine) -> None:
    engine.resolve_cache.clear()
    getattr(engine.db, "invalidate", lambda: None)()
    engine._labels.clear()


def _program(engine, name: str) -> Program:
    p = engine.controller.programs.get(name)
    if p is None:
        raise ProjectOpError(f"no program {name!r}", 404)
    return p


def _task(engine, name: str) -> dict:
    t = next((t for t in engine.controller.tasks if t["name"] == name), None)
    if t is None:
        raise ProjectOpError(f"no task {name!r}", 404)
    return t


def sync_order(c: Controller) -> None:
    """``task_order`` (used when a project has no tasks) follows the tasks:
    continuous task first, then the others, then unscheduled programs."""
    order = []
    tasks = [t for t in c.tasks if t["type"] == "CONTINUOUS"] + \
            [t for t in c.tasks if t["type"] != "CONTINUOUS"]
    for t in tasks:
        order += [p for p in t["programs"] if p in c.programs and p not in order]
    order += [p for p in c.programs if p not in order]
    c.task_order = order


def _watchdog(engine) -> None:
    wd = [t.get("watchdog_ms") for t in engine.controller.tasks if t.get("watchdog_ms")]
    engine.watchdog_s = (max(wd) / 1000.0) if wd else 0.5


# ---- token-aware scanning of logic ----------------------------------------------------
_SKIP_KINDS = ("routine", "label", "name")


_ROUTINE_FIRST = ("JSR", "SFR", "SFP")


def _arg_kind(mnemonic: str, index: int) -> str:
    """What an operand of ``mnemonic`` is: 'tag', 'routine', 'label', 'name' (an
    object, class or attribute name such as GSV's), 'expr', 'imm', ..."""
    from .isa.spec import get
    up = mnemonic.upper()
    if up in _ROUTINE_FIRST and index == 0:
        return "routine"
    if up in _NAME_OPERANDS and index < _NAME_OPERANDS[up]:
        return "name"
    sp = get(up)
    if sp is None:
        return "tag"                       # AOI call or unknown: operands are tags
    if index < len(sp.operands):
        return sp.operands[index].kind
    return sp.operands[-1].kind if sp.operands and sp.operands[-1].repeat else "tag"


# instructions whose first operands are names, not tags (GSV/SSV: class, instance, attribute)
_NAME_OPERANDS = {"GSV": 3, "SSV": 3}


def scan_refs(text: str, st: bool = False, ctx: bool = False):
    """Yield (start, end, kind, value) for every tag reference root in ``text``.
    kind 'tag': value is the root identifier; kind 'full': value is
    (program, tag) for an explicit ``Program:P.T``; kind 'routine': the routine
    operand of JSR/SFR/SFP. Comments (ST), strings, numbers, members after '.',
    instruction / function names and label / name operands are skipped."""
    i, n = 0, len(text)
    stack: list[list] = []      # [mnemonic, arg index, paren depth, bracket depth] per call
    ordinal = -1                # instruction number (left to right) of the outermost call
    def out(a, b, kind, value):
        if not ctx:
            return (a, b, kind, value)
        top = stack[0] if stack else None
        return (a, b, kind, value, top[0] if top else None, top[1] if top else None, ordinal)
    while i < n:
        ch = text[i]
        if st and text.startswith("//", i):
            j = text.find("\n", i)
            i = n if j < 0 else j
            continue
        if st and (text.startswith("(*", i) or text.startswith("/*", i)):
            close = "*)" if ch == "(" else "*/"
            j = text.find(close, i + 2)
            i = n if j < 0 else j + 2
            continue
        if ch in "'\"":
            j = i + 1
            while j < n:
                if text[j] == ch:
                    if j + 1 < n and text[j + 1] == ch:      # doubled quote inside a string
                        j += 2
                        continue
                    break
                if text[j] == "$":
                    j += 1
                j += 1
            i = j + 1
            continue
        if ch.isdigit():
            j = i
            while j < n and (text[j].isalnum() or text[j] in "_#."):
                if text[j] in "eE" and j + 1 < n and text[j + 1] in "+-":
                    j += 1
                j += 1
            i = j
            continue
        if ch in "([" and stack:
            stack[-1][2 if ch == "(" else 3] += 1
            i += 1
            continue
        if ch == "]" and stack:
            stack[-1][3] = max(0, stack[-1][3] - 1)
            i += 1
            continue
        if ch == ")":
            if stack:
                if stack[-1][2]:
                    stack[-1][2] -= 1
                else:
                    stack.pop()
            i += 1
            continue
        if ch == "," and stack and not stack[-1][2] and not stack[-1][3]:
            stack[-1][1] += 1
            i += 1
            continue
        if ch.isalpha() or ch == "_":
            j = i
            while j < n and (text[j].isalnum() or text[j] == "_"):
                j += 1
            word = text[i:j]
            k = j
            while k < n and text[k] in " \t":
                k += 1
            p = i - 1
            while p >= 0 and text[p] in " \t":
                p -= 1
            if p >= 0 and text[p] == ".":             # a member: never a tag root
                i = j
                continue
            if k < n and text[k] == "(":              # instruction / function / AOI call
                if not stack:
                    ordinal += 1
                stack.append([word, 0, 0, 0])
                i = k + 1
                continue
            m = _FULL.match(text, i) if word.upper() == "PROGRAM" and j < n and text[j] == ":" else None
            in_sub = bool(stack and stack[-1][3])     # inside [..]: always a tag (index)
            kind = "tag" if in_sub or not stack else _arg_kind(stack[-1][0], stack[-1][1])
            if m:
                yield out(i, m.end(), "full", (m.group(1), m.group(2)))
                i = m.end()
                continue
            if kind == "routine" and stack and not stack[-1][2]:
                yield out(i, j, "routine", word)
            elif kind not in _SKIP_KINDS:
                if not (st and word.upper() in _ST_WORDS):
                    yield out(i, j, "tag", word)
            i = j
            continue
        i += 1


_FULL = re.compile(r"Program:([A-Za-z_]\w*)\.([A-Za-z_]\w*)", re.I)


_ST_WORDS = {"IF", "THEN", "ELSIF", "ELSE", "END_IF", "CASE", "OF", "END_CASE", "FOR", "TO",
             "BY", "DO", "END_FOR", "WHILE", "END_WHILE", "REPEAT", "UNTIL", "END_REPEAT",
             "EXIT", "RETURN", "AND", "OR", "XOR", "NOT", "MOD", "TRUE", "FALSE"}


def _rewrite(text: str, st: bool, fn) -> str:
    """Replace each reference for which fn(kind, value) returns new text."""
    out, last = [], 0
    for a, b, kind, value in scan_refs(text, st):
        new = fn(kind, value)
        if new is not None:
            out.append(text[last:a])
            out.append(new)
            last = b
    out.append(text[last:])
    return "".join(out)


def _locations(rt: Routine):
    """(location dict, text, is_st) for each rung / ST line of a routine."""
    if rt.rtype == "RLL":
        for i, t in enumerate(rt.rungs):
            yield {"rung": i}, t, False
    elif rt.rtype == "ST":
        yield {"line": None}, rt.text, True


def _tag_matcher(engine, address: str):
    """fn(program, kind, value) -> True if that reference is the tag ``address``."""
    c = engine.controller
    if address.startswith("Program:"):
        owner, _, base = address[len("Program:"):].partition(".")

        def match(pname, kind, value):
            if kind == "full":
                return _same(value[0], owner) and _same(value[1], base)
            return kind == "tag" and pname == owner and _same(value, base)
        return match

    def local(pname, word):
        p = c.programs.get(pname)
        if p is None:
            return False
        return any(_same(t.name, word) for t in p.tags) or \
            any(_same(k, f"Program:{pname}.{word}") for k in c.aliases)

    def match(pname, kind, value):
        return kind == "tag" and _same(value, address) and not local(pname, value)
    return match


def references(engine, address: str) -> list[dict]:
    """Every rung / ST line that uses the tag (aliases pointing at it too)."""
    match = _tag_matcher(engine, address)
    out = []
    for pname, prog in engine.controller.programs.items():
        for rname, rt in prog.routines.items():
            for loc, text, st in _locations(rt):
                hits = [(a, b) for a, b, k, v in scan_refs(text, st) if match(pname, k, v)]
                if not hits:
                    continue
                if st:
                    for a, _ in hits:
                        line = text.count("\n", 0, a) + 1
                        row = {"program": pname, "routine": rname, "line": line,
                               "text": text.split("\n")[line - 1].strip()}
                        if row not in out:
                            out.append(row)
                else:
                    out.append({"program": pname, "routine": rname, **loc, "text": text})
    for alias, target in engine.controller.aliases.items():
        root = re.match(r"(Program:[^.]+\.)?[^.\[]+", target).group()
        if _same(root, address):
            out.append({"alias": alias, "text": f"{alias} is an alias for {target}"})
    return out


_ONE_SHOTS = {"ONS", "OSR", "OSF"}
_ST_ASSIGN = re.compile(r"(?:\s*(?:\.\s*[A-Za-z_]\w*|\[[^\]]*\]))*\s*:=")


def _destructive(engine, mnemonic, index, text, end, st) -> bool:
    """Does this reference write the tag? (Cross Reference 'Destructive')."""
    if mnemonic is None:
        return bool(st and _ST_ASSIGN.match(text, end))
    from .isa.spec import get
    up = mnemonic.upper()
    sp = get(up)
    if sp is None:
        aoi = engine.controller.aois.get(mnemonic) or next(
            (a for n, a in engine.controller.aois.items() if n.upper() == up), None)
        if aoi is None:
            return False
        if index == 0:
            return True                        # the instance tag holds the AOI's data
        call = [p for p in aoi.parameters if p.required and p.name not in ("EnableIn", "EnableOut")]
        par = call[index - 1] if 0 < index <= len(call) else None
        return bool(par and par.usage in ("Output", "InOut"))
    ops = sp.operands
    if not ops:
        return False
    op = ops[index] if index < len(ops) else (ops[-1] if ops[-1].repeat else None)
    if op is None:
        return False
    if op.kind == "dest":
        return True
    if op.kind == "tag":
        return (not sp.input_like) or up in _ONE_SHOTS
    return False


def xref(engine, address: str) -> list[dict]:
    """Cross reference of a tag: every instruction operand / ST use, with the
    instruction, operand number and whether it writes the tag (destructive)."""
    match = _tag_matcher(engine, address)
    out = []
    c = engine.controller
    progs = list(c.programs.items())
    for pname, prog in progs:
        for rname, rt in prog.routines.items():
            for loc, text, st in _locations(rt):
                for a, b, k, v, mn, idx, ordinal in scan_refs(text, st, ctx=True):
                    if not match(pname, k, v):
                        continue
                    row = {"program": pname, "routine": rname, "instruction": mn, "operand": idx,
                           "destructive": _destructive(engine, mn, idx or 0, text, b, st),
                           "start": a, "end": b}
                    if st:
                        line = text.count("\n", 0, a) + 1
                        row.update(line=line, text=text.split("\n")[line - 1].strip())
                    else:
                        row.update(rung=loc["rung"], index=ordinal, text=text)
                    out.append(row)
    aliases = []
    for alias, target in c.aliases.items():
        root = re.match(r"(Program:[^.]+\.)?[^.\[]+", target).group()
        if _same(root, address):
            aliases.append({"alias": alias, "target": target})
    return out + [{"alias": x["alias"], "target": x["target"], "text": f"{x['alias']} is an alias for {x['target']}"}
                  for x in aliases]


def _routine_refs(engine, program: str, routine: str) -> list[dict]:
    out = []
    prog = _program(engine, program)
    for rname, rt in prog.routines.items():
        for loc, text, st in _locations(rt):
            for a, _, kind, value in scan_refs(text, st):
                if kind == "routine" and _same(value, routine):
                    row = {"program": program, "routine": rname, **loc, "text": text}
                    if st:
                        line = text.count("\n", 0, a) + 1
                        row.update(line=line, text=text.split("\n")[line - 1].strip())
                    out.append(row)
    return out


# ---- logic snapshots (undo) -----------------------------------------------------------
def _apply_rewrite(engine, programs, fn, dry_run: bool) -> list[dict]:
    """fn(pname, kind, value) -> replacement text or None. Returns the changes.
    The routines' rung-undo history is rewritten the same way, so undoing an
    earlier rung edit never brings back a name that no longer exists."""
    changes = []
    for pname in programs:
        prog = engine.controller.programs[pname]
        for rname, rt in prog.routines.items():
            def rw(text, st, _p=pname):
                return _rewrite(text, st, lambda k, v: fn(_p, k, v))
            if rt.rtype == "RLL":
                new_rungs = []
                for i, t in enumerate(rt.rungs):
                    nt = rw(t, False)
                    if nt != t:
                        changes.append({"program": pname, "routine": rname, "rung": i,
                                        "before": t, "after": nt})
                    new_rungs.append(nt)
                changed = new_rungs != rt.rungs
                if not dry_run and changed:
                    rt.rungs = new_rungs
            elif rt.rtype == "ST":
                nt = rw(rt.text, True)
                changed = nt != rt.text
                if changed:
                    old_lines, new_lines = rt.text.split("\n"), nt.split("\n")
                    for i, (a, b) in enumerate(zip(old_lines, new_lines)):
                        if a != b:
                            changes.append({"program": pname, "routine": rname, "line": i + 1,
                                            "before": a, "after": b})
                    if not dry_run:
                        rt.text = nt
            else:
                continue
            if dry_run:
                continue
            for snap in (engine.edit_history.get((pname, rname), [])
                         + getattr(engine, "redo_history", {}).get((pname, rname), [])):
                snap["rungs"] = [rw(t, False) for t in snap["rungs"]]
                snap["text"] = rw(snap["text"], True)
            if changed:
                rt.version += 1
                rt.modified = True
                engine.trace.pop((pname, rname), None)
    return changes


def _move_keys(engine, old: tuple, new: tuple) -> None:
    """Rung-undo history, trace and errors follow a renamed routine or program.
    ``old``/``new`` are (program, routine) or (program, None) for every routine."""
    for d in (engine.edit_history, getattr(engine, "redo_history", {}), engine.trace, engine.instr_errors):
        for key in [k for k in d if isinstance(k, tuple) and k[0] == old[0]
                    and (old[1] is None or k[1] == old[1])]:
            d[(new[0], new[1] if old[1] is not None else key[1])] = d.pop(key)


# ---- tags ---------------------------------------------------------------------------------
def _scope_names(engine, scope: str) -> list[str]:
    c = engine.controller
    if scope == "controller":
        names = [n for n in engine.db.declarations() if not n.startswith("Program:")]
        names += [a for a in c.aliases if not a.startswith("Program:")]
    else:
        pre = f"Program:{scope}."
        names = [n[len(pre):] for n in engine.db.declarations() if n.startswith(pre)]
        names += [a[len(pre):] for a in c.aliases if a.startswith(pre)]
    return names


def _full(scope: str, name: str) -> str:
    return name if scope in (None, "", "controller") else f"Program:{scope}.{name}"


def _split(address: str) -> tuple[str, str]:
    if address.startswith("Program:"):
        p, _, n = address[len("Program:"):].partition(".")
        return p, n
    return "controller", address


def known_types(engine) -> dict:
    c = engine.controller
    module = sorted(n for n in c.data_types if ":" in n)
    first = ("BOOL", "SINT", "INT", "DINT", "LINT", "REAL")
    return {"atomic": [t for t in first if t in ATOMIC] + sorted(t for t in ATOMIC if t not in first),
            "string": sorted(STRING_TYPES),
            "predefined": sorted(n for n in PREDEFINED if not n.startswith("FBD_"))
            + sorted(n for n in PREDEFINED if n.startswith("FBD_")),
            "user": sorted(n for n in c.data_types if ":" not in n),
            "aoi": sorted(c.aois), "module": module}


def create_tag(engine, name: str, data_type: str | None = None, scope: str = "controller",
               dims=(), description: str = "", external_access: str = "Read/Write",
               constant: bool = False, alias_for: str | None = None, value=None,
               project_version=None) -> dict:
    from .tagstore import TagMeta, TagStoreError
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        scope = scope or "controller"
        check_name(name, "tag name")
        if scope != "controller":
            _program(engine, scope)
        clash = _find(_scope_names(engine, scope), name)
        if clash:
            raise ProjectOpError(f"a tag named {clash!r} already exists in "
                                 f"{'the controller' if scope == 'controller' else scope}", 409)
        if external_access not in ACCESS:
            raise ProjectOpError(f"external access must be one of {list(ACCESS)}")
        full = _full(scope, name)
        c = engine.controller
        if alias_for:
            target = alias_for.strip()
            try:
                engine.db.data_type(target)
            except Exception:
                raise ProjectOpError(f"alias target {target!r} is not a tag") from None
            with engine.scan_lock:
                c.aliases[full] = target
                engine.db._aliases[full] = target
                if description:
                    c.alias_descriptions[full] = description
                engine.store._notify("define", full)
                _invalidate(engine)
                _bump(engine)
                _push_undo(engine, f"create alias {full}", lambda: _drop_alias(engine, full))
                entry = _log(engine, "create_alias", address=full, alias_for=target)
            return {"ok": True, "address": full, "entry": entry}
        if not data_type:
            raise ProjectOpError("a data type is required")
        m = re.fullmatch(r"\s*([A-Za-z_][\w:]*)\s*\[\s*([\d\s,]+)\]\s*", data_type)
        if m:                                    # "DINT[10]" / "Station_t[2,3]", as typed in Studio
            if dims:
                raise ProjectOpError("give the array size either in the data type or in Dimensions, not both")
            data_type, dims = m.group(1), [int(x) for x in m.group(2).split(",") if x.strip()]
        dt = _resolve_type(engine, data_type)
        dims = _norm_dims(dims, dt)
        _check_finite(value)
        meta = TagMeta(description=description or "", access=ACCESS[external_access])
        try:
            with engine.scan_lock:
                engine.store.define(full, dt, value=value, meta=meta, dims=dims,
                                    external_access=external_access, constant=constant)
                _invalidate(engine)
                _bump(engine)
                _push_undo(engine, f"create tag {full}", lambda: _drop_tag(engine, full))
                entry = _log(engine, "create_tag", address=full, data_type=dt, dims=list(dims))
        except TagStoreError as exc:
            raise ProjectOpError(str(exc), 409 if exc.code == "exists" else 400) from None
        return {"ok": True, "address": full, "entry": entry}


_REAL_MAX = 3.4028234663852886e38


def _check_finite(value) -> None:
    """Initial values must be finite and fit a REAL (Logix cannot store INF/NaN
    as an initial value; it would also make the L5X export unreadable)."""
    if isinstance(value, dict):
        for v in value.values():
            _check_finite(v)
    elif isinstance(value, (list, tuple)):
        for v in value:
            _check_finite(v)
    elif isinstance(value, float) and (not math.isfinite(value) or abs(value) > _REAL_MAX):
        raise ProjectOpError(f"{value!r} is not a valid initial value (finite REAL only)")


def _resolve_type(engine, data_type) -> str:
    if not isinstance(data_type, str) or not data_type.strip():
        raise ProjectOpError("a data type is required")
    dt = _find(list(engine.db.types()) + list(ATOMIC) + list(STRING_TYPES), data_type.strip())
    if dt is None:
        raise ProjectOpError(f"unknown data type {data_type!r}")
    return dt


def _norm_dims(dims, data_type: str = "") -> tuple:
    """Array dimensions as a tuple of 0-3 whole numbers above 0. Accepts a list or
    tuple of ints (or digit strings); anything else is refused."""
    if dims is None or dims == () or dims == []:
        return ()
    if not isinstance(dims, (list, tuple)):
        raise ProjectOpError("array dimensions must be a list of whole numbers, e.g. [10] or [2, 3]")
    out = []
    for d in dims:
        if isinstance(d, bool) or not (isinstance(d, int) or (isinstance(d, str) and d.strip().isdigit())):
            raise ProjectOpError(f"array dimension {d!r} is not a whole number")
        out.append(int(d))
    if len(out) > 3 or any(d <= 0 for d in out):
        raise ProjectOpError(f"array dimensions must be 1 to 3 sizes, each above 0 (got {out})")
    if data_type == "BOOL" and out and (len(out) != 1 or out[0] % 32):
        raise ProjectOpError("a BOOL array has one dimension, a multiple of 32 (32, 64, ...)")
    return tuple(out)


def _drop_alias(engine, full):
    with engine.scan_lock:
        engine.controller.aliases.pop(full, None)
        engine.db._aliases.pop(full, None)
        engine.store._notify("delete", full)
        _invalidate(engine)


def _drop_tag(engine, full):
    with engine.scan_lock:
        engine.store.delete(full)
        _invalidate(engine)


def _tag_state(engine, full):
    """Everything needed to re-create a tag (undo of delete / retype)."""
    decl = engine.db.declaration(full)
    scope, _ = _split(full)
    lst = engine.controller.tags if scope == "controller" else engine.controller.programs[scope].tags
    return {"decl": copy.deepcopy(decl), "value": copy.deepcopy(engine.db.get(full)),
            "meta": copy.deepcopy(engine.store.meta(full)),
            "index": next((i for i, t in enumerate(lst) if t is decl), None),
            "forces": {k: v for k, v in engine.store.forces().items()
                       if k == full or k.startswith(full + ".") or k.startswith(full + "[")}}


def _recreate(engine, full, state):
    """Put a tag back exactly as ``state`` recorded it (type, value, attributes,
    forces, place in the tag list)."""
    d = state["decl"]
    with engine.scan_lock:
        if engine.store._has(full):
            engine.store.delete(full)
        engine.store.define(full, d.data_type, dims=d.dims, meta=copy.deepcopy(state["meta"]),
                            external_access=d.external_access, constant=d.constant)
        engine.db._store[full] = copy.deepcopy(state["value"])
        new = engine.db.declaration(full)
        for attr in ("init", "description", "radix"):
            setattr(new, attr, copy.deepcopy(getattr(d, attr)))
        for attr in ("src_name", "dirty"):
            if hasattr(d, attr):
                setattr(new, attr, getattr(d, attr))
            elif attr in new.__dict__:
                delattr(new, attr)
        _place(engine, full, state.get("index"))
        for k, v in state["forces"].items():
            engine.store.force(k, v, source="project")
        _invalidate(engine)


def _place(engine, full, index) -> None:
    """Move the model Tag of ``full`` to position ``index`` of its tag list."""
    if index is None:
        return
    scope, _ = _split(full)
    decl = engine.db.declaration(full)
    lst = engine.controller.tags if scope == "controller" else engine.controller.programs[scope].tags
    if decl in lst:
        lst.remove(decl)
        lst.insert(min(index, len(lst)), decl)


def set_tag_style(engine, address: str, style: str, project_version=None) -> dict:
    """Display style (radix) of a base tag; saved in the project and the L5X."""
    from .model import styles_for
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        if not engine.db.has_tag(address):
            raise ProjectOpError(f"no tag {address!r}", 404)
        decl = engine.db.declaration(address)
        allowed = styles_for(decl.data_type)
        if style not in allowed:
            raise ProjectOpError(f"{decl.data_type} tags can use the style(s): {', '.join(allowed) or 'none'}")
        old = getattr(decl, "radix", "") or ""
        if old == style:
            return {"ok": True, "unchanged": True}
        with engine.scan_lock:
            decl.radix = style
            decl.dirty = True
            _bump(engine)
            _push_undo(engine, f"style of {address}", lambda: setattr(decl, "radix", old))
            entry = _log(engine, "set_style", address=address, style=style)
        return {"ok": True, "entry": entry}


def update_tag(engine, address: str, description=None, external_access=None, constant=None,
               data_type=None, dims=None, project_version=None) -> dict:
    """Change a tag. Every field is checked before anything changes; fields equal
    to the current value are ignored (nothing is marked changed). A new data
    type or new dimensions re-create the tag (its value starts from zero)."""
    from .tagstore import TagStoreError
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        if address in c.aliases:
            if data_type or dims:
                raise ProjectOpError("an alias tag takes its data type from its target")
            old = c.alias_descriptions.get(address, "")
            if description is None or description == old:
                return {"ok": True, "unchanged": True}
            with engine.scan_lock:
                c.alias_descriptions[address] = description
                _bump(engine)
                _push_undo(engine, f"change alias {address}",
                           lambda: c.alias_descriptions.__setitem__(address, old))
                entry = _log(engine, "update_alias", address=address)
            return {"ok": True, "entry": entry}
        if not engine.db.has_tag(address):
            raise ProjectOpError(f"no tag {address!r}", 404)
        decl = engine.db.declaration(address)
        # ---- check everything first
        new_type = _resolve_type(engine, data_type) if data_type not in (None, "") else decl.data_type
        new_dims = _norm_dims(dims, new_type) if dims is not None else tuple(decl.dims)
        if new_type != decl.data_type and dims is None:
            new_dims = _norm_dims(new_dims, new_type)
        if external_access is not None and external_access not in ACCESS:
            raise ProjectOpError(f"external access must be one of {list(ACCESS)}")
        retype = new_type != decl.data_type or new_dims != tuple(decl.dims)
        changes = {}
        if description is not None and description != (decl.description or ""):
            changes["description"] = description
        if external_access is not None and external_access != decl.external_access:
            changes["external_access"] = external_access
        if constant is not None and bool(constant) != bool(decl.constant):
            changes["constant"] = bool(constant)
        if not retype and not changes:
            return {"ok": True, "unchanged": True}
        state = _tag_state(engine, address)
        old_fields = {"description": decl.description, "external_access": decl.external_access,
                      "constant": decl.constant, "dirty": getattr(decl, "dirty", False),
                      "meta": copy.deepcopy(engine.store.meta(address))}
        with engine.scan_lock:
            if retype:
                try:
                    engine.store.delete(address)
                    engine.store.define(address, new_type, dims=new_dims,
                                        meta=copy.deepcopy(old_fields["meta"]),
                                        external_access=decl.external_access,
                                        constant=decl.constant)
                except TagStoreError as exc:
                    _recreate(engine, address, state)
                    raise ProjectOpError(str(exc)) from None
                new = engine.db.declaration(address)
                new.description = decl.description
                if getattr(decl, "src_name", None):
                    new.src_name = decl.src_name
                _place(engine, address, state["index"])
                decl = new
            if "description" in changes:
                decl.description = changes["description"]
                engine.store.set_meta(address, description=changes["description"])
            if "external_access" in changes:
                decl.external_access = changes["external_access"]
                engine.store.set_meta(address, access=ACCESS[changes["external_access"]])
            if "constant" in changes:
                decl.constant = changes["constant"]
            decl.dirty = True                 # written from the model at export
            _invalidate(engine)
            _bump(engine)

            def undo():
                if retype:
                    _recreate(engine, address, state)
                    return
                with engine.scan_lock:
                    d = engine.db.declaration(address)
                    d.description = old_fields["description"]
                    d.external_access = old_fields["external_access"]
                    d.constant = old_fields["constant"]
                    d.dirty = old_fields["dirty"]
                    engine.store._meta[address] = old_fields["meta"]
            _push_undo(engine, f"change tag {address}", undo)
            entry = _log(engine, "update_tag", address=address,
                         changed=sorted(changes) + (["data_type"] if retype else []))
        return {"ok": True, "entry": entry}


def delete_tag(engine, address: str, force: bool = False, project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        is_alias = address in c.aliases
        if not is_alias and not engine.db.has_tag(address):
            raise ProjectOpError(f"no tag {address!r}", 404)
        refs = references(engine, address)
        if refs and not force:
            raise ProjectOpError(f"{address} is used in {len(refs)} place(s); delete anyway?",
                                 409, refs)
        if refs and engine.mode == "RUN":
            # the rungs using it would stop executing and their outputs would freeze
            raise ProjectOpError(f"{address} is used by the running logic. Put the controller in "
                                 "Program mode first, or remove those references.", 409)
        if is_alias:
            target = c.aliases[address]
            desc = c.alias_descriptions.get(address)
            _drop_alias(engine, address)

            def undo():
                with engine.scan_lock:
                    c.aliases[address] = target
                    engine.db._aliases[address] = target
                    if desc is not None:
                        c.alias_descriptions[address] = desc
                    _invalidate(engine)
        else:
            state = _tag_state(engine, address)
            _drop_tag(engine, address)

            def undo():
                _recreate(engine, address, state)
        _bump(engine)
        _push_undo(engine, f"delete tag {address}", undo)
        return {"ok": True, "references": refs, "entry": _log(engine, "delete_tag", address=address)}


def rename_tag(engine, address: str, new_name: str, dry_run: bool = False,
               project_version=None) -> dict:
    """Rename a tag and every reference to it in the logic and in aliases.
    Refused (409) when the new name is taken in the tag's scope, or when a
    reference would end up meaning a different tag (a program tag of the new
    name, or for a program tag, a controller tag its program already uses)."""
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        is_alias = address in c.aliases
        if not is_alias and not engine.db.has_tag(address):
            raise ProjectOpError(f"no tag {address!r}", 404)
        check_name(new_name, "tag name")
        scope, old = _split(address)
        clash = _find([n for n in _scope_names(engine, scope) if not _same(n, old)], new_name)
        if clash:
            raise ProjectOpError(f"a tag named {clash!r} already exists", 409)
        match = _tag_matcher(engine, address)
        users = {r["program"] for r in references(engine, address) if "program" in r}
        if scope == "controller":
            captured = sorted(p for p in users
                              if _find(_scope_names(engine, p), new_name))
            if captured:
                raise ProjectOpError(
                    f"program(s) {', '.join(captured)} have their own tag named {new_name!r}: "
                    "the references there would point to that tag instead", 409)
        else:
            uses_ctrl = _tag_matcher(engine, new_name)
            hit = any(uses_ctrl(scope, k, v) for rt in c.programs[scope].routines.values()
                      for _, text, st in _locations(rt) for _, _, k, v in scan_refs(text, st)) \
                if _find(_scope_names(engine, "controller"), new_name) else False
            if hit:
                raise ProjectOpError(
                    f"program {scope} uses the controller tag {new_name!r}; renaming its own tag "
                    "to that name would change what that logic refers to", 409)
        changes, alias_changes = _rename_tag_core(engine, address, new_name, match, dry_run=True)
        if dry_run:
            return {"ok": True, "dry_run": True, "changes": changes,
                    "aliases": [{"alias": a, "after": t} for a, t in alias_changes]}
        new_full = _full(scope, new_name)
        with engine.scan_lock:
            _rename_tag_core(engine, address, new_name, match, dry_run=False)
            _invalidate(engine)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    _rename_tag_core(engine, new_full, old, _tag_matcher(engine, new_full),
                                     dry_run=False)
                    _invalidate(engine)
            _push_undo(engine, f"rename tag {address} -> {new_full}", undo)
            entry = _log(engine, "rename_tag", address=address, new_address=new_full,
                         changes=len(changes))
        return {"ok": True, "address": new_full, "changes": changes, "entry": entry}


def _rename_tag_core(engine, address, new_name, match, dry_run):
    """Rewrite the references, the alias targets and the tag itself."""
    c = engine.controller
    scope, old = _split(address)
    new_full = _full(scope, new_name)

    def fn(pname, kind, value):
        if not match(pname, kind, value):
            return None
        return f"Program:{value[0]}.{new_name}" if kind == "full" else new_name
    changes = _apply_rewrite(engine, list(c.programs), fn, dry_run)
    alias_changes = []
    for alias, target in c.aliases.items():
        m = re.match(r"(Program:[^.]+\.)?[^.\[]+", target)
        if _same(m.group(), address):
            alias_changes.append((alias, new_full + target[m.end():]))
    if dry_run:
        return changes, alias_changes
    for alias, target in alias_changes:
        c.aliases[alias] = target
    if address in c.aliases:
        c.aliases[new_full] = c.aliases.pop(address)
        if address in c.alias_descriptions:
            c.alias_descriptions[new_full] = c.alias_descriptions.pop(address)
    else:
        decl = engine.db.declaration(address)
        if not getattr(decl, "src_name", None):
            decl.src_name = old
        engine.store.rename(address, new_full)
    engine.db._aliases = dict(c.aliases)
    return changes, alias_changes


# ---- routines ----------------------------------------------------------------------------
def create_routine(engine, program: str, name: str, rtype: str = "RLL", description: str = "",
                   project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        prog = _program(engine, program)
        check_name(name, "routine name")
        rtype = (rtype or "RLL").upper()
        if rtype not in ("RLL", "ST"):
            raise ProjectOpError("new routines can be ladder (RLL) or Structured Text (ST)")
        clash = _find(prog.routines, name)
        if clash:
            raise ProjectOpError(f"program {program} already has a routine {clash!r}", 409)
        with engine.scan_lock:
            prog.routines[name] = Routine(name, rtype, description=description or "", modified=True)
            for d in (engine.edit_history, getattr(engine, "redo_history", {}), engine.trace, engine.instr_errors):
                d.pop((program, name), None)          # nothing left over from an older routine
            was_main = prog.main
            if not prog.main:
                prog.main = name
            _invalidate(engine)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    prog.routines.pop(name, None)
                    prog.main = was_main
            _push_undo(engine, f"create routine {program}/{name}", undo)
            entry = _log(engine, "create_routine", program=program, routine=name, type=rtype)
        return {"ok": True, "entry": entry}


def update_routine(engine, program: str, name: str, new_name: str | None = None,
                   description: str | None = None, main: bool | None = None,
                   project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        prog = _program(engine, program)
        rt = prog.routines.get(name)
        if rt is None:
            raise ProjectOpError(f"no routine {program}/{name}", 404)
        renaming = new_name is not None and new_name != name
        if renaming:
            check_name(new_name, "routine name")
            clash = _find([r for r in prog.routines if r != name], new_name)
            if clash:
                raise ProjectOpError(f"program {program} already has a routine {clash!r}", 409)
        before = {"main": prog.main, "description": rt.description,
                  "description_changed": getattr(rt, "description_changed", False)}
        with engine.scan_lock:
            if renaming:
                _rename_routine(engine, program, name, new_name)
            if description is not None and description != rt.description:
                rt.description = description
                rt.description_changed = True
            if main:
                prog.main = rt.name
            _invalidate(engine)
            _bump(engine)
            current = rt.name

            def undo():
                with engine.scan_lock:
                    if renaming:
                        _rename_routine(engine, program, current, name)
                    prog.main = before["main"]
                    rt.description = before["description"]
                    rt.description_changed = before["description_changed"]
                    _invalidate(engine)
            _push_undo(engine, f"change routine {program}/{name}", undo)
            entry = _log(engine, "update_routine", program=program, routine=name,
                         new_name=rt.name)
        return {"ok": True, "entry": entry}


def _rename_routine(engine, program: str, old: str, new: str) -> None:
    """Rename a routine: its JSR/SFR/SFP calls, the main routine name and the
    rung-undo history follow."""
    prog = engine.controller.programs[program]
    rt = prog.routines[old]

    def fn(pname, kind, value):
        return new if kind == "routine" and _same(value, old) else None
    _apply_rewrite(engine, [program], fn, dry_run=False)
    prog.routines = {(new if k == old else k): v for k, v in prog.routines.items()}
    if not getattr(rt, "src_name", None):
        rt.src_name = old
    rt.name = new
    if prog.main == old:
        prog.main = new
    _move_keys(engine, (program, old), (program, new))


def delete_routine(engine, program: str, name: str, force: bool = False,
                   project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        prog = _program(engine, program)
        if name not in prog.routines:
            raise ProjectOpError(f"no routine {program}/{name}", 404)
        if prog.main == name:
            raise ProjectOpError(f"{name} is the main routine of {program}; make another routine "
                                 "the main routine first", 409)
        refs = _routine_refs(engine, program, name)
        if refs and not force:
            raise ProjectOpError(f"{name} is called from {len(refs)} place(s); delete anyway?",
                                 409, refs)
        with engine.scan_lock:
            before = dict(prog.routines)
            prog.routines.pop(name)
            _invalidate(engine)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    prog.routines = before
                    _invalidate(engine)
            _push_undo(engine, f"delete routine {program}/{name}", undo)
            entry = _log(engine, "delete_routine", program=program, routine=name)
        return {"ok": True, "references": refs, "entry": entry}


# ---- programs ----------------------------------------------------------------------------
def create_program(engine, name: str, task: str | None = None, main_routine: str | None = None,
                   description: str = "", project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        check_name(name, "program name")
        clash = _find(c.programs, name)
        if clash:
            raise ProjectOpError(f"a program named {clash!r} already exists", 409)
        t = _task(engine, task) if task else None
        if main_routine:
            check_name(main_routine, "routine name")
        with engine.scan_lock:
            prog = Program(name, main_routine or "", description=description or "")
            if main_routine:
                prog.routines[main_routine] = Routine(main_routine, "RLL", modified=True)
            c.programs[name] = prog
            if t is not None:
                t["programs"].append(name)
            sync_order(c)
            _invalidate(engine)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    c.programs.pop(name, None)
                    for tk in c.tasks:
                        if name in tk["programs"]:
                            tk["programs"].remove(name)
                    sync_order(c)
            _push_undo(engine, f"create program {name}", undo)
            entry = _log(engine, "create_program", program=name, task=task)
        return {"ok": True, "entry": entry}


def update_program(engine, name: str, new_name: str | None = None, description: str | None = None,
                   disabled: bool | None = None, project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        prog = _program(engine, name)
        renaming = new_name is not None and new_name != name
        if renaming:
            check_name(new_name, "program name")
            clash = _find([p for p in c.programs if p != name], new_name)
            if clash:
                raise ProjectOpError(f"a program named {clash!r} already exists", 409)
        before = {"desc": prog.description, "disabled": prog.disabled}
        with engine.scan_lock:
            if renaming:
                _rename_program(engine, name, new_name)
            if description is not None:
                prog.description = description
            if disabled is not None:
                prog.disabled = bool(disabled)
            _invalidate(engine)
            _bump(engine)
            current = prog.name

            def undo():
                with engine.scan_lock:
                    prog.description, prog.disabled = before["desc"], before["disabled"]
                    if renaming:
                        _rename_program(engine, current, name)
                    _invalidate(engine)
            _push_undo(engine, f"change program {name}", undo)
            entry = _log(engine, "update_program", program=name, new_name=prog.name)
        return {"ok": True, "entry": entry}


def _rename_program(engine, old: str, new: str) -> None:
    """Rename a program everywhere: its tags (Program:Old.X), explicit references
    in logic, alias names, targets and descriptions, task lists, rung-undo history."""
    c = engine.controller
    prog = c.programs[old]

    def fn(pname, kind, value):
        if kind == "full" and _same(value[0], old):
            return f"Program:{new}.{value[1]}"
        return None
    _apply_rewrite(engine, list(c.programs), fn, dry_run=False)
    pre_old, pre_new = f"Program:{old}.", f"Program:{new}."
    for addr in [a for a in engine.db.declarations() if a.startswith(pre_old)]:
        engine.store.rename(addr, pre_new + addr[len(pre_old):])
    fix = (lambda s: pre_new + s[len(pre_old):] if s.startswith(pre_old) else s)
    for d in (c.aliases, c.alias_descriptions):
        moved = {fix(k): (fix(v) if d is c.aliases else v) for k, v in d.items()}
        d.clear()
        d.update(moved)
    engine.db._aliases = dict(c.aliases)
    c.programs = {(new if k == old else k): v for k, v in c.programs.items()}
    if not getattr(prog, "src_name", None):
        prog.src_name = old
    prog.name = new
    for t in c.tasks:
        t["programs"] = [new if p == old else p for p in t["programs"]]
    _move_keys(engine, (old, None), (new, None))
    sync_order(c)


def delete_program(engine, name: str, force: bool = False, project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        prog = _program(engine, name)
        refs = []
        for pname, p in c.programs.items():
            if pname == name:
                continue
            for rname, rt in p.routines.items():
                for loc, text, st in _locations(rt):
                    if any(k == "full" and _same(v[0], name) for _, _, k, v in scan_refs(text, st)):
                        refs.append({"program": pname, "routine": rname, **loc, "text": text})
        if refs and not force:
            raise ProjectOpError(f"other programs use tags of {name} ({len(refs)} place(s)); "
                                 "delete anyway?", 409, refs)
        with engine.scan_lock:
            states = {a: _tag_state(engine, a) for a in engine.db.declarations()
                      if a.startswith(f"Program:{name}.")}
            tasks_before = {t["name"]: list(t["programs"]) for t in c.tasks}
            programs_before = dict(c.programs)
            aliases_before = dict(c.aliases)
            alias_desc_before = dict(c.alias_descriptions)
            for a in states:
                engine.store.delete(a)
            for k in [k for k in c.aliases if k.startswith(f"Program:{name}.")]:
                c.aliases.pop(k)
            engine.db._aliases = dict(c.aliases)
            c.programs.pop(name)
            for t in c.tasks:
                if name in t["programs"]:
                    t["programs"].remove(name)
            sync_order(c)
            _invalidate(engine)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    c.programs.clear()
                    c.programs.update(programs_before)
                    for t in c.tasks:
                        t["programs"] = tasks_before.get(t["name"], t["programs"])
                    c.aliases.clear()
                    c.aliases.update(aliases_before)
                    c.alias_descriptions.clear()
                    c.alias_descriptions.update(alias_desc_before)
                    engine.db._aliases = dict(c.aliases)
                    prog.tags = []
                    for a, st in states.items():
                        _recreate(engine, a, st)
                    sync_order(c)
                    _invalidate(engine)
            _push_undo(engine, f"delete program {name}", undo)
            entry = _log(engine, "delete_program", program=name)
        return {"ok": True, "references": refs, "entry": entry}


def schedule_program(engine, program: str, task: str | None, index: int | None = None,
                     project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        _program(engine, program)
        t = _task(engine, task) if task else None
        before = {tk["name"]: list(tk["programs"]) for tk in c.tasks}
        with engine.scan_lock:
            for tk in c.tasks:
                if program in tk["programs"]:
                    tk["programs"].remove(program)
            if t is not None:
                pos = len(t["programs"]) if index is None else max(0, min(int(index), len(t["programs"])))
                t["programs"].insert(pos, program)
            sync_order(c)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    for tk in c.tasks:
                        tk["programs"] = before.get(tk["name"], tk["programs"])
                    sync_order(c)
            _push_undo(engine, f"schedule {program}", undo)
            entry = _log(engine, "schedule_program", program=program, task=task)
        return {"ok": True, "entry": entry}


def _unique(existing, base: str) -> str:
    """A name not in ``existing`` (case-insensitive): base, base1, base2, ..."""
    if not _find(existing, base):
        return base
    i = 1
    while _find(existing, f"{base}{i}"):
        i += 1
    return f"{base}{i}"


def copy_routine(engine, program: str, name: str, to_program: str, new_name: str | None = None,
                 project_version=None) -> dict:
    """Copy a routine into a program (Ctrl+drag / Copy-Paste in the organizer). A copy in
    the same program, or a name already used in the target, gets a number added."""
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        src, dst = _program(engine, program), _program(engine, to_program)
        rt = src.routines.get(name)
        if rt is None:
            raise ProjectOpError(f"no routine {program}/{name}", 404)
        if program.startswith("AOI:"):
            raise ProjectOpError("Add-On Instruction routines cannot be copied here")
        target = new_name or _unique(dst.routines, name)
        check_name(target, "routine name")
        if _find(dst.routines, target):
            raise ProjectOpError(f"program {to_program} already has a routine {target!r}", 409)
        with engine.scan_lock:
            new = copy.deepcopy(rt)
            new.name, new.modified = target, True
            for attr in ("src_name",):
                if attr in new.__dict__:
                    delattr(new, attr)
            dst.routines[target] = new
            _invalidate(engine)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    dst.routines.pop(target, None)
                    _invalidate(engine)
            _push_undo(engine, f"copy routine {program}/{name} to {to_program}/{target}", undo)
            entry = _log(engine, "copy_routine", program=program, routine=name,
                         to_program=to_program, new_name=target)
        return {"ok": True, "name": target, "entry": entry}


def move_routine(engine, program: str, name: str, to_program: str, force: bool = False,
                 project_version=None) -> dict:
    """Move a routine to another program (drag in the organizer). JSR calls in the old
    program stop working, so they are listed first (409) unless ``force``."""
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        src, dst = _program(engine, program), _program(engine, to_program)
        if _same(program, to_program):
            raise ProjectOpError("the routine is already in that program")
        rt = src.routines.get(name)
        if rt is None:
            raise ProjectOpError(f"no routine {program}/{name}", 404)
        if src.main == name:
            raise ProjectOpError(f"{name} is the main routine of {program}; make another routine "
                                 "the main routine first", 409)
        refs = _routine_refs(engine, program, name)
        if refs and not force:
            raise ProjectOpError(f"{name} is called from {len(refs)} place(s) in {program}; move anyway?",
                                 409, refs)
        target = _unique(dst.routines, name)
        with engine.scan_lock:
            src_before, dst_before = dict(src.routines), dict(dst.routines)
            src.routines.pop(name)
            rt.name, rt.modified = target, True
            dst.routines[target] = rt
            _move_keys(engine, (program, name), (to_program, target))
            _invalidate(engine)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    rt.name = name
                    src.routines, dst.routines = src_before, dst_before
                    _move_keys(engine, (to_program, target), (program, name))
                    _invalidate(engine)
            _push_undo(engine, f"move routine {program}/{name} to {to_program}", undo)
            entry = _log(engine, "move_routine", program=program, routine=name, to_program=to_program,
                         new_name=target)
        return {"ok": True, "name": target, "references": refs, "entry": entry}


def copy_program(engine, name: str, task: str | None = None, index: int | None = None,
                 new_name: str | None = None, project_version=None) -> dict:
    """Copy a program with its routines, tags (with their current values) and program
    aliases; the copy is scheduled in ``task`` (or unscheduled)."""
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        prog = _program(engine, name)
        target = new_name or _unique(c.programs, name)
        check_name(target, "program name")
        if _find(c.programs, target):
            raise ProjectOpError(f"a program named {target!r} already exists", 409)
        t = _task(engine, task) if task else None
        pre_old, pre_new = f"Program:{name}.", f"Program:{target}."
        states = {a: _tag_state(engine, a) for a in engine.db.declarations() if a.startswith(pre_old)}
        with engine.scan_lock:
            new = copy.deepcopy(prog)
            new.name, new.tags = target, []
            for attr in ("src_name",):
                if attr in new.__dict__:
                    delattr(new, attr)
            for rt in new.routines.values():
                rt.modified = True
            c.programs[target] = new
            if t is not None:
                pos = len(t["programs"]) if index is None else max(0, min(int(index), len(t["programs"])))
                t["programs"].insert(pos, target)
            sync_order(c)
            for a, st in states.items():
                st = dict(st, forces={}, index=None)
                _recreate(engine, pre_new + a[len(pre_old):], st)
            fix = (lambda x: pre_new + x[len(pre_old):] if x.startswith(pre_old) else x)
            for k, v in list(c.aliases.items()):
                if k.startswith(pre_old):
                    c.aliases[fix(k)] = fix(v)
                    if k in c.alias_descriptions:
                        c.alias_descriptions[fix(k)] = c.alias_descriptions[k]
            engine.db._aliases = dict(c.aliases)
            _invalidate(engine)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    for a in [a for a in engine.db.declarations() if a.startswith(pre_new)]:
                        engine.store.delete(a)
                    for k in [k for k in c.aliases if k.startswith(pre_new)]:
                        c.aliases.pop(k)
                        c.alias_descriptions.pop(k, None)
                    engine.db._aliases = dict(c.aliases)
                    c.programs.pop(target, None)
                    for tk in c.tasks:
                        if target in tk["programs"]:
                            tk["programs"].remove(target)
                    sync_order(c)
                    _invalidate(engine)
            _push_undo(engine, f"copy program {name} to {target}", undo)
            entry = _log(engine, "copy_program", program=name, new_name=target, task=task)
        return {"ok": True, "name": target, "entry": entry}


# ---- tasks ---------------------------------------------------------------------------------
def _task_fields(t: dict, ttype=None, rate_ms=None, priority=None, watchdog_ms=None,
                 inhibited=None, description=None) -> None:
    if ttype is not None:
        ttype = str(ttype).upper()
        if ttype not in TASK_TYPES:
            raise ProjectOpError(f"task type must be one of {list(TASK_TYPES)}")
        if ttype == "EVENT" and t.get("type") != "EVENT":
            raise ProjectOpError("event tasks are not supported yet (they would not run); "
                                 "use a periodic task")
        t["type"] = ttype
    if rate_ms is not None:
        r = float(rate_ms)
        if not 0.1 <= r <= 2_000_000:
            raise ProjectOpError("period must be between 0.1 ms and 2000 s")
        t["rate_ms"] = r if not r.is_integer() else int(r)
    if priority is not None:
        p = int(priority)
        if not 1 <= p <= 15:
            raise ProjectOpError("priority must be 1 (highest) to 15 (lowest)")
        t["priority"] = p
    if watchdog_ms is not None:
        w = float(watchdog_ms)
        if not 1 <= w <= 2_000_000:
            raise ProjectOpError("watchdog must be between 1 ms and 2000 s")
        t["watchdog_ms"] = w if not w.is_integer() else int(w)
    if inhibited is not None:
        t["inhibited"] = bool(inhibited)
    if description is not None:
        t["description"] = description
    if t["type"] == "PERIODIC" and not t.get("rate_ms"):
        t["rate_ms"] = 10
    if t["type"] != "PERIODIC":
        t["rate_ms"] = t.get("rate_ms") if t["type"] == "EVENT" else None


def create_task(engine, name: str, type: str = "PERIODIC", rate_ms=None, priority=10,
                watchdog_ms=500, inhibited=False, description: str = "",
                project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        check_name(name, "task name")
        clash = _find([t["name"] for t in c.tasks], name)
        if clash:
            raise ProjectOpError(f"a task named {clash!r} already exists", 409)
        t = {"name": name, "type": "PERIODIC", "rate_ms": None, "priority": 10,
             "watchdog_ms": 500, "inhibited": False, "programs": []}
        _task_fields(t, type, rate_ms, priority, watchdog_ms, inhibited, description or None)
        if t["type"] == "CONTINUOUS" and any(x["type"] == "CONTINUOUS" for x in c.tasks):
            raise ProjectOpError("a controller has only one continuous task", 409)
        with engine.scan_lock:
            c.tasks.append(t)
            sync_order(c)
            _watchdog(engine)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    c.tasks.remove(t)
                    sync_order(c)
                    _watchdog(engine)
            _push_undo(engine, f"create task {name}", undo)
            entry = _log(engine, "create_task", task=name, type=t["type"])
        return {"ok": True, "entry": entry}


def update_task(engine, name: str, new_name: str | None = None, type=None, rate_ms=None,
                priority=None, watchdog_ms=None, inhibited=None, description=None,
                programs=None, project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        t = _task(engine, name)
        before = copy.deepcopy(t)
        trial = copy.deepcopy(t)
        _task_fields(trial, type, rate_ms, priority, watchdog_ms, inhibited, description)
        if trial["type"] == "CONTINUOUS" and any(x is not t and x["type"] == "CONTINUOUS"
                                                 for x in c.tasks):
            raise ProjectOpError("a controller has only one continuous task", 409)
        if new_name is not None and new_name != name:
            check_name(new_name, "task name")
            clash = _find([x["name"] for x in c.tasks if x is not t], new_name)
            if clash:
                raise ProjectOpError(f"a task named {clash!r} already exists", 409)
            trial["name"] = new_name
            trial.setdefault("src_name", name)
        if programs is not None:                   # new execution order of the scheduled programs
            order = [str(p) for p in programs]
            if sorted(order) != sorted(t["programs"]):
                raise ProjectOpError("the program order must list exactly the programs scheduled in the task")
            trial["programs"] = order
        with engine.scan_lock:
            t.clear()
            t.update(trial)
            if t["name"] != name and name in engine.task_stats:
                engine.task_stats[t["name"]] = engine.task_stats.pop(name)
            if before.get("rate_ms") != t.get("rate_ms") and t["name"] in engine.task_stats:
                engine.task_stats[t["name"]]["next"] = None
            sync_order(c)
            _watchdog(engine)
            _bump(engine)
            current = t["name"]

            def undo():
                with engine.scan_lock:
                    if current != name and current in engine.task_stats:
                        engine.task_stats[name] = engine.task_stats.pop(current)
                    t.clear()
                    t.update(before)
                    sync_order(c)
                    _watchdog(engine)
            _push_undo(engine, f"change task {name}", undo)
            entry = _log(engine, "update_task", task=name, new_name=t["name"])
        return {"ok": True, "entry": entry}


def delete_task(engine, name: str, project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        t = _task(engine, name)
        with engine.scan_lock:
            pos = c.tasks.index(t)
            c.tasks.remove(t)
            engine.task_stats.pop(name, None)
            sync_order(c)
            _watchdog(engine)
            _bump(engine)

            def undo():
                with engine.scan_lock:
                    c.tasks.insert(pos, t)
                    sync_order(c)
                    _watchdog(engine)
            _push_undo(engine, f"delete task {name}", undo)
            entry = _log(engine, "delete_task", task=name, unscheduled=list(t["programs"]))
        return {"ok": True, "unscheduled": list(t["programs"]), "entry": entry}


# ---- controller ----------------------------------------------------------------------------
def update_controller(engine, name: str | None = None, description: str | None = None,
                      project_version=None) -> dict:
    with _EDIT_LOCK:
        _check_pv(engine, project_version)
        c = engine.controller
        if name is not None:
            check_name(name, "controller name")
        before = (c.name, c.description)
        with engine.scan_lock:
            if name is not None:
                c.name = name
            if description is not None:
                c.description = description
                c.description_changed = True
            _bump(engine)

            def undo():
                c.name, c.description = before
            _push_undo(engine, "change controller", undo)
            entry = _log(engine, "update_controller", name=c.name)
        return {"ok": True, "entry": entry}


def undo(engine) -> dict:
    with _EDIT_LOCK:
        stack = engine.__dict__.get("project_undo") or []
        if not stack:
            raise ProjectOpError("nothing to undo", 409)
        label, fn = stack.pop()
        fn()
        _bump(engine)
        return {"ok": True, "undone": label, "entry": _log(engine, "undo", undone=label)}


def new_controller(name: str) -> Controller:
    """An empty project: MainTask (continuous) -> MainProgram -> MainRoutine (ladder)."""
    check_name(name, "controller name")
    c = Controller(name=name, processor=NEW_PROCESSOR, revision=f"{NEW_MAJOR}.{NEW_MINOR}")
    prog = Program("MainProgram", "MainRoutine")
    prog.routines["MainRoutine"] = Routine("MainRoutine", "RLL")
    c.programs["MainProgram"] = prog
    c.tasks.append({"name": "MainTask", "type": "CONTINUOUS", "rate_ms": None, "priority": 10,
                    "watchdog_ms": 500, "inhibited": False, "programs": ["MainProgram"]})
    sync_order(c)
    return c
