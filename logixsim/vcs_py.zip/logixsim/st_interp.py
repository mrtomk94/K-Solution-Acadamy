"""A small IEC-61131-3 Structured Text interpreter (Phase-1 subset).

Supports: ``:=`` assignment; IF/ELSIF/ELSE/END_IF; CASE/END_CASE;
FOR/END_FOR; WHILE/END_WHILE; REPEAT/UNTIL/END_REPEAT; the usual arithmetic,
comparison and boolean operators (``&`` = AND); nested/array tag references;
string literals with ``$`` escapes; based numbers (``16#FF_FF``, ``2#1010``);
``//``, ``(* *)`` and ``/* */`` comments; ``#region``/``#endregion`` markers; and
calling any instruction from the shared REGISTRY as a statement.
"""
from __future__ import annotations

import math
import re

from .instructions import SPECS, UnsupportedInstruction
from .isa.expr import _Eval
from .isa.values import f32, value_type

_TOKEN = re.compile(r"""
    \s+
  | (?P<lcomment>//[^\n]*)
  | (?P<bcomment>\(\*.*?\*\)|/\*.*?\*/)
  | (?P<pragma>\#(?:end)?region\b[^\n]*)
  | (?P<str>'(?:\$.|[^'$])*'|"(?:\$.|[^"$])*")
  | (?P<nrassign>\[\s*:=\s*\])
  | (?P<assign>:=)
  | (?P<pow>\*\*)
  | (?P<le><=) | (?P<ge>>=) | (?P<ne><>)
  | (?P<based>(?:2|8|16)\#[0-9A-Fa-f_]+)
  | (?P<num>\d[\d_]*\.\d[\d_]*(?:[eE][-+]?\d+)?|\d[\d_]*[eE][-+]?\d+|\d[\d_]*)
  | (?P<id>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<amp>&)
  | (?P<op>[-+*/()\[\].,;:<>=])
""", re.VERBOSE | re.DOTALL | re.IGNORECASE)

_KEYWORDS = {
    "IF", "THEN", "ELSIF", "ELSE", "END_IF", "CASE", "OF", "END_CASE",
    "FOR", "TO", "BY", "DO", "END_FOR", "WHILE", "END_WHILE",
    "REPEAT", "UNTIL", "END_REPEAT", "AND", "OR", "XOR", "NOT", "MOD",
    "TRUE", "FALSE", "EXIT",
}

# IEC/Logix string escapes: $$ $' $" $L $N $P $R $T and $hh (hex byte)
_ESC = {"$": "$", "'": "'", '"': '"', "L": "\n", "N": "\n", "P": "\f",
        "R": "\r", "T": "\t"}


def _unescape(body: str) -> str:
    out, i = [], 0
    while i < len(body):
        c = body[i]
        if c != "$" or i + 1 >= len(body):
            out.append(c)
            i += 1
            continue
        nxt = body[i + 1]
        if re.fullmatch(r"[0-9A-Fa-f]{2}", body[i + 1:i + 3]):
            out.append(chr(int(body[i + 1:i + 3], 16)))
            i += 3
        else:
            out.append(_ESC.get(nxt.upper(), nxt))
            i += 2
    return "".join(out)


def _number(text: str):
    text = text.replace("_", "")
    if "#" in text:
        base, digits = text.split("#", 1)
        return int(digits, int(base))
    if "." in text or "e" in text.lower():
        return float(text)
    return int(text)


class STSyntaxError(SyntaxError):
    """Syntax error with a character offset into the source (for line/column)."""

    def __init__(self, msg: str, offset: int):
        super().__init__(msg)
        self.offset_ = offset


def tokenize(src: str, positions: list | None = None):
    """Tokens as (kind, value). If ``positions`` is given, the start offset of
    each token is appended to it (the editor uses it for line/column)."""
    toks, i = [], 0
    while i < len(src):
        m = _TOKEN.match(src, i)
        if not m:
            raise STSyntaxError(f"unexpected character {src[i]!r}", i)
        start = i
        i = m.end()
        kind, val = m.lastgroup, m.group()
        if kind in (None, "lcomment", "bcomment", "pragma"):   # whitespace/comments
            continue
        if positions is not None:
            positions.append(start)
        if kind == "id" and val.upper() in _KEYWORDS and not (toks and toks[-1] == ("op", ".")):
            toks.append(("kw", val.upper()))      # (after a '.', a keyword is a member: x.To)
        elif kind == "id":
            toks.append(("id", val))
        elif kind in ("num", "based"):
            toks.append(("num", _number(val)))
        elif kind == "str":
            toks.append(("str", _unescape(val[1:-1])))
        elif kind == "amp":
            toks.append(("kw", "AND"))
        elif kind in ("assign", "le", "ge", "ne", "pow", "nrassign"):
            toks.append(("op", {"assign": ":=", "le": "<=", "ge": ">=", "ne": "<>",
                                "pow": "**", "nrassign": "[:=]"}[kind]))
        else:
            toks.append(("op", val))
    toks.append(("eof", None))
    if positions is not None:
        positions.append(len(src))
    return toks


def _desc(tok) -> str:
    k, v = tok
    if k == "eof":
        return "the end of the routine"
    if k == "str":
        return "a string"
    return f"'{v}'"


class _Parser:
    def __init__(self, toks):
        self.toks = toks
        self.p = 0
        self.max_p = 0          # furthest token reached (error location)

    def peek(self):
        return self.toks[self.p]

    def next(self):
        t = self.toks[self.p]
        self.p += 1
        self.max_p = max(self.max_p, self.p)
        return t

    def accept(self, kind, val=None):
        k, v = self.peek()
        if k == kind and (val is None or v == val):
            return self.next()
        return None

    def expect(self, kind, val=None):
        t = self.accept(kind, val)
        if t is None:
            want = {"id": "a tag name", "num": "a number"}.get(kind, val or kind) if val is None \
                else f"'{val}'"
            raise SyntaxError(f"expected {want} but found {_desc(self.peek())}")
        return t

    # --- statements ---------------------------------------------------
    def block(self, *terminators):
        stmts = []
        while True:
            k, v = self.peek()
            if k == "eof" or (k == "kw" and v in terminators):
                break
            stmts.append(self.statement())
        return stmts

    def statement(self):
        k, v = self.peek()
        if k == "kw":
            if v == "IF":
                return self._if()
            if v == "CASE":
                return self._case()
            if v == "FOR":
                return self._for()
            if v == "WHILE":
                return self._while()
            if v == "REPEAT":
                return self._repeat()
            if v == "EXIT":
                self.next()
                self.accept("op", ";")
                return ("exit",)
        if k == "op" and v == ";":            # empty statement
            self.next()
            return ("nop",)
        # assignment or call
        start = self.p
        name = self.expect("id")[1]
        kk, vv = self.peek()
        if kk == "op" and vv == "(":          # instruction call statement
            args = self._call_args()
            self.accept("op", ";")
            return ("call", name, args, start)
        self.p = start                         # rewind, parse lvalue
        target = self._lvalue()
        if self.accept("op", "[:=]"):
            expr = self._expr()
            self.accept("op", ";")
            return ("assign", target, expr, True)
        self.expect("op", ":=")
        expr = self._expr()
        self.accept("op", ";")
        return ("assign", target, expr, False)

    def _call_args(self):
        self.expect("op", "(")
        args = []
        if not (self.peek() == ("op", ")")):
            args.append(self._arg())
            while self.accept("op", ","):
                args.append(self._arg())
        self.expect("op", ")")
        return args

    def _arg(self):
        # an argument is a raw operand expression captured as text for the
        # instruction layer (tag name or literal); evaluate numbers/exprs lazily
        return self._expr()

    def _if(self):
        self.expect("kw", "IF")
        cond = self._expr()
        self.expect("kw", "THEN")
        body = self.block("ELSIF", "ELSE", "END_IF")
        branches = [(cond, body)]
        while self.accept("kw", "ELSIF"):
            c = self._expr()
            self.expect("kw", "THEN")
            branches.append((c, self.block("ELSIF", "ELSE", "END_IF")))
        els = None
        if self.accept("kw", "ELSE"):
            els = self.block("END_IF")
        self.expect("kw", "END_IF")
        self.accept("op", ";")
        return ("if", branches, els)

    def _at_case_label(self) -> bool:
        """Lookahead: does the cursor begin ``label (',' label)* ':'`` where a
        label is ``[-]num`` or ``[-]num..[-]num`` ?"""
        i = self.p

        def num(i):
            if self.toks[i] == ("op", "-"):
                i += 1
            return i + 1 if self.toks[i][0] == "num" else None

        def label(i):
            i = num(i)
            if i is None:
                return None
            if self.toks[i] == ("op", ".") and self.toks[i + 1] == ("op", "."):
                return num(i + 2)
            return i

        i = label(i)
        if i is None:
            return False
        while self.toks[i] == ("op", ","):
            i = label(i + 1)
            if i is None:
                return False
        return self.toks[i] == ("op", ":")

    def _case_body(self):
        stmts = []
        while True:
            k, v = self.peek()
            if k == "eof" or (k == "kw" and v in ("END_CASE", "ELSE")):
                break
            if self._at_case_label():
                break
            stmts.append(self.statement())
        return stmts

    def _case(self):
        self.expect("kw", "CASE")
        sel = self._expr()
        self.expect("kw", "OF")
        cases = []
        els = None
        while not (self.peek() == ("kw", "END_CASE")):
            if self.accept("kw", "ELSE"):
                els = self._case_body()
                break
            labels = [self._case_label()]
            while self.accept("op", ","):
                labels.append(self._case_label())
            self.expect("op", ":")
            cases.append((labels, self._case_body()))
        self.expect("kw", "END_CASE")
        self.accept("op", ";")
        return ("case", sel, cases, els)

    def _case_label(self):
        lo = self._expr()
        if self.peek() == ("op", ".") and self.toks[self.p + 1] == ("op", "."):
            self.p += 2
            return ("range", lo, self._expr())
        return lo

    def _for(self):
        self.expect("kw", "FOR")
        var = self._lvalue()
        self.expect("op", ":=")
        lo = self._expr()
        self.expect("kw", "TO")
        hi = self._expr()
        step = ("num", 1)
        if self.accept("kw", "BY"):
            step = self._expr()
        self.expect("kw", "DO")
        body = self.block("END_FOR")
        self.expect("kw", "END_FOR")
        self.accept("op", ";")
        return ("for", var, lo, hi, step, body)

    def _while(self):
        self.expect("kw", "WHILE")
        cond = self._expr()
        self.expect("kw", "DO")
        body = self.block("END_WHILE")
        self.expect("kw", "END_WHILE")
        self.accept("op", ";")
        return ("while", cond, body)

    def _repeat(self):
        self.expect("kw", "REPEAT")
        body = self.block("UNTIL")
        self.expect("kw", "UNTIL")
        cond = self._expr()
        self.expect("kw", "END_REPEAT")
        self.accept("op", ";")
        return ("repeat", body, cond)

    # --- lvalue / tag path --------------------------------------------
    def _lvalue(self):
        start = self.p
        parts = [("name", self.expect("id")[1])]
        while True:
            if self.accept("op", "."):
                if self.peek()[0] == "num":            # bit of a word: Tag.3
                    parts.append(("name", str(self.next()[1])))
                elif self.accept("op", "["):            # indirect bit: Tag.[Index]
                    parts.append(("bit", self._expr()))
                    self.expect("op", "]")
                else:
                    parts.append(("name", self.expect("id")[1]))
            elif self.accept("op", "["):
                idx = [self._expr()]
                while self.accept("op", ","):          # Grid[i,j]: multi-dimensional
                    idx.append(self._expr())
                self.expect("op", "]")
                parts.append(("idx", idx[0]) if len(idx) == 1 else ("idxn", idx))
            else:
                break
        return ("path", parts, start)

    # --- expressions (precedence climbing, 1756-PM007 order) ----------
    # () functions > ** > - NOT > * / MOD > + - > < <= > >= > = <> > AND & > XOR > OR
    def _expr(self):
        return self._or()

    def _bin_level(self, sub, ops):
        node = sub()
        while True:
            k, v = self.peek()
            if (k in ("op", "kw")) and v in ops:
                self.next()
                node = ("bin", v, node, sub())
            else:
                return node

    def _or(self):
        return self._bin_level(self._xor, ("OR",))

    def _xor(self):
        return self._bin_level(self._and, ("XOR",))

    def _and(self):
        return self._bin_level(self._eq, ("AND",))

    def _eq(self):
        return self._bin_level(self._rel, ("=", "<>"))

    def _rel(self):
        return self._bin_level(self._add, ("<", "<=", ">", ">="))

    def _add(self):
        return self._bin_level(self._mul, ("+", "-"))

    def _mul(self):
        return self._bin_level(self._unary, ("*", "/", "MOD"))

    def _unary(self):
        if self.accept("op", "-"):
            return ("neg", self._unary())
        if self.accept("op", "+"):
            return self._unary()
        if self.accept("kw", "NOT"):
            return ("not", self._unary())
        return self._power()

    def _power(self):
        node = self._primary()
        while self.accept("op", "**"):
            rhs = ("neg", self._primary()) if self.accept("op", "-") else self._primary()
            node = ("bin", "**", node, rhs)
        return node

    def _primary(self):
        k, v = self.peek()
        if k == "num":
            self.next()
            return ("num", v)
        if k == "str":
            self.next()
            return ("str", v)
        if k == "kw" and v in ("TRUE", "FALSE"):
            self.next()
            return ("bool", v == "TRUE")
        if self.accept("op", "("):
            e = self._expr()
            self.expect("op", ")")
            return e
        if k == "id" and self.toks[self.p + 1] == ("op", "(") and v.upper() in ST_FUNCTIONS:
            self.next()
            self.expect("op", "(")
            args = [self._expr()]
            while self.accept("op", ","):
                args.append(self._expr())
            self.expect("op", ")")
            return ("fn", v.upper(), args)
        if k == "id":
            return self._lvalue()
        raise SyntaxError(f"unexpected {_desc(self.peek())} in an expression")


ST_FUNCTIONS = {"ABS", "SQRT", "LN", "LOG", "SIN", "COS", "TAN", "ASIN", "ACOS", "ATAN",
                "TRUNC", "DEG", "RAD", "ATAN2"}


class _Exit(Exception):
    """EXIT statement: leave the innermost loop."""


class _Stop(Exception):
    """RET / TND executed: leave the routine."""


class Interpreter:
    MAX_LOOP = 100_000

    def __init__(self):
        self._ast: dict[str, list] = {}

    def parse(self, text: str):
        ast = self._ast.get(text)
        if ast is None:
            ast = _Parser(tokenize(text)).block()
            if len(self._ast) < 2000:
                self._ast[text] = ast
        return ast

    def exec_text(self, ctx, text: str):
        if not text.strip():
            return
        try:
            for stmt in self.parse(text):
                self._exec(ctx, stmt)
        except _Stop:
            pass

    # --- prescan: [:=] targets reset to zero, instruction prescan ----------
    def prescan(self, ctx, text: str):
        if not text.strip():
            return
        self._prescan_block(ctx, self.parse(text))

    def _prescan_block(self, ctx, body):
        for node in body:
            kind = node[0]
            if kind == "assign" and node[3]:
                try:
                    addr = self._addr(ctx, node[1])
                    t = ctx.dtype(addr)
                    ctx.write(addr, False if t == "BOOL" else (0.0 if t == "REAL" else 0))
                except Exception:
                    pass
            elif kind == "call":
                operands = []
                try:
                    operands = [self._operand(ctx, a) for a in node[2]]
                except Exception:
                    pass
                if ctx.engine is not None:
                    ctx.engine._prescan_instr(ctx, node[1], operands)
            elif kind == "if":
                for _, b in node[1]:
                    self._prescan_block(ctx, b)
                if node[2]:
                    self._prescan_block(ctx, node[2])
            elif kind == "case":
                for _, b in node[2]:
                    self._prescan_block(ctx, b)
                if node[3]:
                    self._prescan_block(ctx, node[3])
            elif kind in ("for",):
                self._prescan_block(ctx, node[5])
            elif kind in ("while",):
                self._prescan_block(ctx, node[2])
            elif kind in ("repeat",):
                self._prescan_block(ctx, node[1])

    # --- statement execution ------------------------------------------
    def _exec(self, ctx, node):
        kind = node[0]
        if kind == "assign":
            target, expr = node[1], node[2]
            val = self._eval(ctx, expr)
            addr = self._addr(ctx, target)
            ctx.store(addr, val, value_type(val), flags=False)
        elif kind == "call":
            name, args = node[1], node[2]
            operands = [ctx.resolve(self._operand(ctx, a)) for a in args]
            spec = SPECS.get(name.upper())
            if spec is not None:
                spec.fn(ctx, operands) if spec.kind == "condition" else spec.fn(ctx, operands, rung=True)
            else:
                aoi = _find_aoi(ctx, name)
                if aoi is None:
                    raise UnsupportedInstruction(name)
                ctx.engine.call_aoi(ctx, aoi, operands, True)
            if ctx.frame.stop:
                raise _Stop()
        elif kind == "if":
            _, branches, els = node
            for cond, body in branches:
                if self._truth(self._eval(ctx, cond)):
                    self._run(ctx, body)
                    return
            if els:
                self._run(ctx, els)
        elif kind == "case":
            _, sel, cases, els = node
            val = self._eval(ctx, sel)
            for labels, body in cases:
                if any(self._match(ctx, lb, val) for lb in labels):
                    self._run(ctx, body)
                    return
            if els:
                self._run(ctx, els)
        elif kind == "for":
            _, var, lo, hi, step, body = node
            addr = self._addr(ctx, var)
            i = self._eval(ctx, lo)
            hi_v = self._eval(ctx, hi)
            st = self._eval(ctx, step)
            if st == 0:
                raise RuntimeError("FOR loop with BY 0")
            n = 0
            ctx.store(addr, i, value_type(i), flags=False)
            while True:
                i = ctx.read(addr)
                if not ((st > 0 and i <= hi_v) or (st < 0 and i >= hi_v)):
                    break                      # the index keeps the value that failed the test
                try:
                    self._run(ctx, body)
                except _Exit:
                    break
                ctx.store(addr, ctx.read(addr) + st, value_type(i), flags=False)
                n += 1
                if n > self.MAX_LOOP:
                    raise RuntimeError("FOR loop exceeded iteration guard")
                if n % 1024 == 0 and ctx.engine is not None:
                    ctx.engine._watchdog()
        elif kind == "while":
            _, cond, body = node
            n = 0
            while self._truth(self._eval(ctx, cond)):
                try:
                    self._run(ctx, body)
                except _Exit:
                    break
                n += 1
                if n > self.MAX_LOOP:
                    raise RuntimeError("WHILE loop exceeded iteration guard")
                if n % 1024 == 0 and ctx.engine is not None:
                    ctx.engine._watchdog()
        elif kind == "repeat":
            _, body, cond = node
            n = 0
            while True:
                try:
                    self._run(ctx, body)
                except _Exit:
                    break
                n += 1
                if self._truth(self._eval(ctx, cond)) or n > self.MAX_LOOP:
                    break
        elif kind == "exit":
            raise _Exit()
        elif kind == "nop":
            pass
        else:
            raise RuntimeError(f"unknown statement {kind}")

    def _match(self, ctx, label, val):
        if label[0] == "range":
            return self._eval(ctx, label[1]) <= val <= self._eval(ctx, label[2])
        return self._eval(ctx, label) == val

    def _run(self, ctx, body):
        for s in body:
            self._exec(ctx, s)

    # --- expression evaluation (typed, Logix rules) -----------------------
    def _eval(self, ctx, node):
        kind = node[0]
        if kind == "num":
            return node[1]
        if kind in ("bool", "str"):
            return node[1]
        if kind == "path":
            return ctx.read(self._addr(ctx, node))
        if kind == "neg":
            v = self._eval(ctx, node[1])
            ev = _Eval(ctx)
            out, _ = ev.fn("NEG", _n(v), _t(v))
            self._flag(ctx, ev)
            return out
        if kind == "not":
            v = self._eval(ctx, node[1])
            if isinstance(v, bool):
                return not v
            if isinstance(v, float):
                raise RuntimeError("NOT needs a BOOL or integer operand")
            return ~v
        if kind == "bin":
            return self._binop(ctx, node[1], node[2], node[3])
        if kind == "fn":
            return self._fn(ctx, node[1], [self._eval(ctx, a) for a in node[2]])
        raise RuntimeError(f"cannot eval {kind}")

    @staticmethod
    def _flag(ctx, ev):
        if ev.overflow:
            ctx.overflow()

    def _binop(self, ctx, o, left, right):
        a = self._eval(ctx, left)
        b = self._eval(ctx, right)
        if o in ("AND", "OR", "XOR"):
            if isinstance(a, bool) and isinstance(b, bool):
                return {"AND": a and b, "OR": a or b, "XOR": a != b}[o]
            if isinstance(a, float) or isinstance(b, float):
                raise RuntimeError(f"{o} needs BOOL or integer operands")
            a, b = int(a), int(b)                  # bitwise on integers (1756-PM007)
            return {"AND": a & b, "OR": a | b, "XOR": a ^ b}[o]
        if isinstance(a, str) or isinstance(b, str):
            if o == "=":
                return a == b
            if o == "<>":
                return a != b
            raise RuntimeError("strings can only be compared with = or <>")
        ev = _Eval(ctx)
        out, _ = ev.bin(o, (_n(a), _t(a)), (_n(b), _t(b)))
        self._flag(ctx, ev)
        if o in ("=", "<>", "<", "<=", ">", ">="):
            return bool(out)
        return out

    def _fn(self, ctx, name, args):
        if name == "ATAN2":
            if len(args) != 2:
                raise RuntimeError("ATAN2 needs 2 arguments")
            return f32(math.atan2(_n(args[0]), _n(args[1])))
        if len(args) != 1:
            raise RuntimeError(f"{name} needs 1 argument")
        v = args[0]
        ev = _Eval(ctx)
        out, _ = ev.fn(name, _n(v), _t(v))
        self._flag(ctx, ev)
        return out

    @staticmethod
    def _truth(v):
        return bool(v)

    def _addr(self, ctx, path_node) -> str:
        """Render a ('path', parts) node to a TagDB address string."""
        parts = path_node[1]
        out = ""
        for i, (tag, val) in enumerate(parts):
            if tag == "name":
                out += ("." if i and out else "") + val
            elif tag == "bit":                        # Tag.[Index]: indirect bit number
                b = self._eval(ctx, val)
                b = int(b)
                if b < 0:
                    from .isa.core import MajorFault
                    raise MajorFault(4, 83, f"Bit index out of range: {out}.[{b}]")
                out += f".{b}"
            else:  # idx / idxn — evaluate the subscript expression(s) to integers
                subs = []
                for e in (val if tag == "idxn" else [val]):
                    idx = self._eval(ctx, e)
                    if isinstance(idx, float):
                        idx = int(idx)
                    if idx < 0:
                        from .isa.core import MajorFault
                        raise MajorFault(4, 20, f"Array subscript negative: {out}[{idx}]")
                    subs.append(str(int(idx)))
                out += "[" + ",".join(subs) + "]"
        return out

    def _operand(self, ctx, expr) -> str:
        """Turn a call argument AST into an operand string for an instruction."""
        if expr[0] == "path":
            return self._addr(ctx, expr)
        if expr[0] == "num":
            return repr(expr[1]) if isinstance(expr[1], float) else str(expr[1])
        if expr[0] == "bool":
            return "1" if expr[1] else "0"
        if expr[0] == "neg" and expr[1][0] == "num":
            return "-" + self._operand(ctx, expr[1])
        if expr[0] == "str":
            return "'" + expr[1].replace("'", "''") + "'"
        # fall back: evaluate and pass as a literal
        v = self._eval(ctx, expr)
        if isinstance(v, bool):
            return "1" if v else "0"
        return repr(v) if isinstance(v, float) else str(v)


def _n(v):
    return int(v) if isinstance(v, bool) else v


def _t(v):
    t = value_type(v)
    return "DINT" if t == "BOOL" else t


def _find_aoi(ctx, name):
    eng = getattr(ctx, "engine", None)
    if eng is None:
        return None
    for n, a in eng.controller.aois.items():
        if n.upper() == name.upper():
            return a
    return None
