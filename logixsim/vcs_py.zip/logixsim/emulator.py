"""Emulator: one running instance — engine + tag store + event bus + connectors.

    emu = Emulator(name="Line 1")            # no PLC program needed
    emu.store.define("Start", "BOOL")
    emu.add_connector(OpcUaConnector(emu, port=4840))
    emu.start(run=True)

``settings`` holds the project's engine/connector settings and is saved with
the project file.
"""
from __future__ import annotations

import logging
from typing import Any

from .engine import Engine
from .events import EventBus
from .model import Controller

log = logging.getLogger(__name__)


class Emulator:
    def __init__(self, name: str = "Project", engine: Engine | None = None,
                 publish_interval: float = 0.05):
        self.name = name
        self.engine = engine or Engine(Controller(name=name))
        self.store = self.engine.store
        self.bus = EventBus(self.store, interval=publish_interval)
        self.connectors: list = []
        self.settings: dict[str, Any] = {"connectors": {}}
        self.logic_file: str | None = None
        self.project_path: str | None = None
        self.l5x_source: bytes | None = None      # imported L5X, for exporting edits
        self.saved_change: int | None = 0         # engine.change_count when last saved/opened (None: never)
        from .connections import ConnectionManager
        self.connections = ConnectionManager(self)  # Node-RED, Ignition, C-more, simulators...

    # ---- connectors --------------------------------------------------------------
    def add_connector(self, connector) -> None:
        self.connectors.append(connector)

    def connector_status(self) -> list[dict]:
        out = []
        for c in self.connectors:
            try:
                out.append(c.status())
            except Exception as exc:
                out.append({"name": getattr(c, "name", "?"), "running": False, "error": str(exc)})
        for c in self.connections.list():
            st = c["status"]
            out.append({"name": c["name"], "kind": c["kind"], "running": st["state"] not in ("off", "error"),
                        "endpoint": st["endpoint"], "state": st["state"], "text": st["text"]})
        return out

    def load_controller(self, controller, logic_file: str | None = None,
                        source: bytes | None = None) -> None:
        """Import a new PLC program (parsed L5X) into this running emulator."""
        self.l5x_source = source
        running = [c for c in self.connectors]
        for c in running:
            try:
                c.stop()
            except Exception:
                log.exception("connector %s failed to stop", getattr(c, "name", c))
        self.engine.load(controller)
        self.connections.reload()                 # they now serve the new tags
        self.engine.authoring = True              # a Studio project: tags created at runtime
        self.name = controller.name               # become part of the project
        self.logic_file = logic_file
        self.project_path = None
        self.saved_change = self.engine.change_count
        self._l5x_tags = set(self.engine.db.declarations())
        for c in running:
            try:
                c.start()
            except Exception:
                log.exception("connector %s failed to restart", getattr(c, "name", c))
        self.bus.emit("state", self.state())

    def new_project(self, name: str) -> None:
        """Start an empty project: MainTask -> MainProgram -> MainRoutine (ladder)."""
        from .project_ops import new_controller
        self.load_controller(new_controller(name))
        self.saved_change = None                  # never saved: dirty until the first Save

    @property
    def dirty(self) -> bool:
        return self.saved_change is None or self.saved_change != self.engine.change_count

    # ---- run control ---------------------------------------------------------------
    def run(self) -> None:
        self.engine.start()
        self.bus.emit("state", self.state())

    def halt(self) -> None:
        self.engine.stop()
        self.bus.emit("state", self.state())

    def pause(self) -> None:
        self.engine.pause()
        self.bus.emit("state", self.state())

    def reset(self) -> None:
        self.engine.reset()
        self.bus.emit("state", self.state())

    def step(self) -> None:
        if self.engine.running:
            raise RuntimeError("single step is only possible while stopped")
        self.engine.step()
        self.bus.emit("state", self.state())

    def state(self) -> dict:
        st = self.engine.state()
        st["project"] = self.name
        st["forces"] = len(self.store.forces())
        st["dirty"] = self.dirty
        st["project_version"] = getattr(self.engine, "project_version", 0)
        st["project_file"] = self.project_path and __import__("os").path.basename(self.project_path)
        return st

    # ---- lifecycle -------------------------------------------------------------------
    def start(self, run: bool = False) -> None:
        self.bus.start()
        for c in self.connectors:
            try:
                c.start()
            except Exception:
                log.exception("connector %s failed to start", getattr(c, "name", c))
                raise
        self.connections.start()                  # failures are shown per connection
        if run:
            self.run()

    def stop(self) -> None:
        self.connections.stop()
        for c in reversed(self.connectors):
            try:
                c.stop()
            except Exception:
                log.exception("connector %s failed to stop", getattr(c, "name", c))
        self.engine.stop()
        self.bus.stop()
