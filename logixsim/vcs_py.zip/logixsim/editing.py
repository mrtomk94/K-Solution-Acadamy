"""Edit / finalize service: applies validated rung and Structured Text changes to
the *same* Routine objects the engine executes.

Safety rules
* Every change is validated again here (the editor's earlier result is not
  trusted: tags or routines may have changed since).
* Changes are applied while holding the engine's scan lock. A running engine
  holds that lock for a whole scan, so an edit always lands *between* two
  scans (a scan boundary) - never in the middle of one. The scan number at
  which the change takes effect is reported.
* The routine is replaced atomically (a new list / text is assigned in one
  step); if anything fails, the previous rungs stay in place.
* Tag values are not reset and the controller is not restarted. Instructions
  added by an edit start from the current tag values (no prescan), like an
  online edit on a controller. Removed instructions simply stop executing.
* ``version`` gives optimistic concurrency: an edit based on an old version of
  the routine is refused (another edit was applied in between).
* Add-On Instruction logic cannot be edited online (as in Studio 5000).
"""
from __future__ import annotations

import threading
import time
from functools import wraps

from .validation import RungSyntaxError, flatten, parse_rung_strict, validate_rung, validate_st

MAX_UNDO = 50


_EDIT_LOCK = threading.RLock()


def _serialized(fn):
    """One edit at a time (validate + apply as a unit)."""
    @wraps(fn)
    def inner(*a, **kw):
        with _EDIT_LOCK:
            return fn(*a, **kw)
    return inner


class EditError(Exception):
    def __init__(self, message: str, status: int = 400, issues: list | None = None):
        super().__init__(message)
        self.status = status
        self.issues = issues or []


def _routine(engine, program: str, routine: str):
    if program.startswith("AOI:"):
        raise EditError("Add-On Instruction logic cannot be edited while online; edit the AOI "
                        "definition in Studio 5000 and import the project again", 409)
    prog = engine.controller.programs.get(program)
    rt = prog.routines.get(routine) if prog else None
    if rt is None:
        raise EditError(f"no routine {program}/{routine}", 404)
    return rt


def _check_version(rt, version):
    if version is not None and int(version) != rt.version:
        raise EditError(f"the routine was changed by another edit (version {rt.version}, "
                        f"your edit is based on {version}); reload it and edit again", 409)


def _normalize(text: str) -> str:
    t = text.strip()
    if t and not t.endswith(";"):
        t += ";"
    return t


def _state(rt) -> dict:
    return {"rungs": list(rt.rungs), "comments": dict(rt.comments), "text": rt.text,
            "version": rt.version}


def _redo_stack(engine) -> dict:
    if not hasattr(engine, "redo_history"):
        engine.redo_history = {}
    return engine.redo_history


def _snapshot(engine, program, routine, rt):
    if getattr(engine, "_edit_group", None) is not None:
        return                               # a batch keeps one snapshot for all its steps
    hist = engine.edit_history.setdefault((program, routine), [])
    hist.append(_state(rt))
    del hist[:-MAX_UNDO]
    if not getattr(engine, "_redoing", False):
        _redo_stack(engine).pop((program, routine), None)   # a new edit ends the redo chain


def _commit(engine, program, routine, rt, op, detail, rungs=None, comments=None, text=None):
    """Swap in the new routine content under the scan lock."""
    with engine.scan_lock:
        _snapshot(engine, program, routine, rt)
        if rungs is not None:
            rt.rungs = rungs
        if comments is not None:
            rt.comments = comments
        if text is not None:
            rt.text = text
        rt.version += 1
        rt.modified = True
        engine.change_count = getattr(engine, "change_count", 0) + 1
        engine._labels.clear()
        engine.trace.pop((program, routine), None)
        engine.instr_errors.pop((program, routine), None)
        entry = {"time": time.time(), "op": op, "program": program, "routine": routine,
                 "version": rt.version, "effective_scan": engine.scan_count + 1,
                 "mode": engine.mode, **detail}
        engine.edit_log.append(entry)
        del engine.edit_log[:-200]
    _forget_faults(engine, program, routine)
    return entry


def _forget_faults(engine, program, routine):
    """Drop 'unsupported instruction' log lines of the edited routine so the
    fault list reflects the new logic (they are re-reported if still there)."""
    tag = f"{program}/{routine}"
    engine.faults[:] = [f for f in engine.faults if tag not in f]


def _shift_comments(comments: dict, at: int, delta: int) -> dict:
    out = {}
    for k, v in comments.items():
        if k >= at:
            if delta < 0 and k == at:
                continue                     # the deleted rung's comment goes with it
            out[k + delta] = v
        else:
            out[k] = v
    return out


def _labels_of(text):
    try:
        items = flatten(parse_rung_strict(text))
    except RungSyntaxError:
        return set()
    return {a[0].strip().upper() for _, n, a, _ in items if n.upper() == "LBL" and a}


def _jumps(rt, skip=None):
    out = set()
    for n, text in enumerate(rt.rungs):
        if n == skip:
            continue
        try:
            items = flatten(parse_rung_strict(text))
        except RungSyntaxError:
            continue
        out |= {a[0].strip().upper() for _, nm, a, _ in items if nm.upper() == "JMP" and a}
    return out


@_serialized
def apply_rung_edit(engine, program: str, routine: str, op: str, index: int,
                    text: str | None = None, comment: str | None = None,
                    to: int | None = None, version=None) -> dict:
    """op: 'replace' | 'insert' | 'delete' | 'move' | 'comment'."""
    rt = _routine(engine, program, routine)
    if rt.rtype != "RLL":
        raise EditError(f"{program}/{routine} is a {rt.rtype} routine, not ladder")
    _check_version(rt, version)
    n = len(rt.rungs)
    if op in ("replace", "delete", "move", "comment") and not 0 <= index < n:
        raise EditError(f"rung {index} does not exist (routine has {n} rungs)", 404)
    if op == "insert" and not 0 <= index <= n:
        raise EditError(f"cannot insert at {index} (routine has {n} rungs)")

    if op in ("replace", "insert"):
        if text is None:
            raise EditError("rung text is required")
        result = validate_rung(engine, program, routine, text, index, inserting=(op == "insert"))
        if not result["ok"]:
            raise EditError("the rung has errors; it was not applied", 422, result["issues"])
        new = _normalize(result["text"])
        rungs = list(rt.rungs)
        if op == "replace":
            removed = _labels_of(rt.rungs[index]) - _labels_of(new)
            used = removed & _jumps(rt, skip=index)
            if used:
                raise EditError(f"label(s) {', '.join(sorted(used))} are still used by JMP "
                                "elsewhere in the routine", 422)
            rungs[index] = new
            comments = dict(rt.comments)
        else:
            rungs.insert(index, new)
            comments = _shift_comments(rt.comments, index, +1)
        if comment is not None:
            if comment.strip():
                comments[index] = comment.rstrip()
            else:
                comments.pop(index, None)
        entry = _commit(engine, program, routine, rt, op, {"index": index, "text": new},
                        rungs=rungs, comments=comments)
        return {"ok": True, "issues": result["issues"], "entry": entry, "version": rt.version}

    if op == "delete":
        used = _labels_of(rt.rungs[index]) & _jumps(rt, skip=index)
        if used:
            raise EditError(f"rung {index} holds label(s) {', '.join(sorted(used))} used by JMP; "
                            "remove those jumps first", 422)
        rungs = list(rt.rungs)
        old = rungs.pop(index)
        comments = _shift_comments(rt.comments, index, -1)
        entry = _commit(engine, program, routine, rt, op, {"index": index, "text": old},
                        rungs=rungs, comments=comments)
        return {"ok": True, "issues": [], "entry": entry, "version": rt.version}

    if op == "move":
        if to is None or not 0 <= to < n:
            raise EditError(f"cannot move rung {index} to {to}")
        rungs = list(rt.rungs)
        order = list(range(n))
        order.insert(to, order.pop(index))
        rungs = [rt.rungs[i] for i in order]
        comments = {order.index(k): v for k, v in rt.comments.items()}
        entry = _commit(engine, program, routine, rt, op, {"index": index, "to": to},
                        rungs=rungs, comments=comments)
        return {"ok": True, "issues": [], "entry": entry, "version": rt.version}

    if op == "comment":
        comments = dict(rt.comments)
        if comment and comment.strip():
            comments[index] = comment.rstrip()
        else:
            comments.pop(index, None)
        entry = _commit(engine, program, routine, rt, op, {"index": index}, comments=comments)
        return {"ok": True, "issues": [], "entry": entry, "version": rt.version}

    raise EditError(f"unknown edit operation {op!r}")


@_serialized
def apply_st_edit(engine, program: str, routine: str, text: str, version=None) -> dict:
    rt = _routine(engine, program, routine)
    if rt.rtype != "ST":
        raise EditError(f"{program}/{routine} is a {rt.rtype} routine, not Structured Text")
    _check_version(rt, version)
    result = validate_st(engine, program, text)
    if not result["ok"]:
        raise EditError("the routine has errors; it was not applied", 422, result["issues"])
    entry = _commit(engine, program, routine, rt, "st", {"lines": text.count("\n") + 1},
                    text=text)
    return {"ok": True, "issues": result["issues"], "entry": entry, "version": rt.version}


@_serialized
def apply_rung_batch(engine, program: str, routine: str, ops: list, version=None) -> dict:
    """Several rung operations (paste, multi-delete, drag-move) applied as ONE edit:
    every step is validated, all or nothing, and one undo step restores them all.
    Each op is {op, index, text?, comment?, to?} as for apply_rung_edit, applied in
    order (indexes refer to the routine as it is after the previous steps)."""
    rt = _routine(engine, program, routine)
    _check_version(rt, version)
    if not ops:
        raise EditError("nothing to do")
    before = _state(rt)
    entries, issues = [], []
    engine._edit_group = True
    try:
        for o in ops:
            res = apply_rung_edit(engine, program, routine, o.get("op"), int(o.get("index", 0)),
                                  o.get("text"), o.get("comment"), o.get("to"), None)
            entries.append(res["entry"])
            issues += res.get("issues", [])
    except EditError:
        with engine.scan_lock:
            rt.rungs, rt.comments, rt.text = before["rungs"], before["comments"], before["text"]
            rt.version += 1
            engine._labels.clear()
        raise
    finally:
        engine._edit_group = None
    hist = engine.edit_history.setdefault((program, routine), [])
    hist.append(before)
    del hist[:-MAX_UNDO]
    _redo_stack(engine).pop((program, routine), None)
    return {"ok": True, "issues": issues, "entry": entries[-1], "entries": entries,
            "version": rt.version}


def _restore(engine, program, routine, rt, snap, op):
    with engine.scan_lock:
        rt.rungs, rt.comments, rt.text = snap["rungs"], snap["comments"], snap["text"]
        rt.version += 1
        rt.modified = True
        engine.change_count = getattr(engine, "change_count", 0) + 1
        engine._labels.clear()
        engine.trace.pop((program, routine), None)
        engine.instr_errors.pop((program, routine), None)
        entry = {"time": time.time(), "op": op, "program": program, "routine": routine,
                 "version": rt.version, "effective_scan": engine.scan_count + 1,
                 "mode": engine.mode}
        engine.edit_log.append(entry)
    _forget_faults(engine, program, routine)
    return {"ok": True, "entry": entry, "version": rt.version}


@_serialized
def redo(engine, program: str, routine: str, version=None) -> dict:
    """Apply again the edit that the last undo removed."""
    rt = _routine(engine, program, routine)
    _check_version(rt, version)
    stack = _redo_stack(engine).get((program, routine)) or []
    if not stack:
        raise EditError("nothing to redo for this routine", 409)
    snap = stack.pop()
    hist = engine.edit_history.setdefault((program, routine), [])
    hist.append(_state(rt))
    del hist[:-MAX_UNDO]
    return _restore(engine, program, routine, rt, snap, "redo")


@_serialized
def undo(engine, program: str, routine: str, version=None) -> dict:
    """Restore the routine as it was before its last applied edit."""
    rt = _routine(engine, program, routine)
    _check_version(rt, version)
    hist = engine.edit_history.get((program, routine)) or []
    if not hist:
        raise EditError("nothing to undo for this routine", 409)
    snap = hist.pop()
    stack = _redo_stack(engine).setdefault((program, routine), [])
    stack.append(_state(rt))
    del stack[:-MAX_UNDO]
    with engine.scan_lock:
        rt.rungs, rt.comments, rt.text = snap["rungs"], snap["comments"], snap["text"]
        rt.version += 1
        engine.change_count = getattr(engine, "change_count", 0) + 1
        engine._labels.clear()
        engine.trace.pop((program, routine), None)
        engine.instr_errors.pop((program, routine), None)
        entry = {"time": time.time(), "op": "undo", "program": program, "routine": routine,
                 "version": rt.version, "effective_scan": engine.scan_count + 1,
                 "mode": engine.mode}
        engine.edit_log.append(entry)
    _forget_faults(engine, program, routine)
    return {"ok": True, "entry": entry, "version": rt.version}


def edit_log(engine) -> list[dict]:
    return list(engine.edit_log)
