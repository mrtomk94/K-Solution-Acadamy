"""Parse a Studio 5000 ``.L5X`` export into a :class:`Controller` model.

Reads: data types (BIT members of UDTs become BOOL), controller/program tags with
their initial values from ``<Data Format="Decorated">`` (timer/counter presets,
arrays, structures), alias tags, I/O module input/output tags (``Local:1:I``),
programs, routines (RLL text + rung comments, ST text; FBD/SFC are recorded but
not simulated), AOI definitions, tasks and descriptions.

Tolerant of missing optional elements so exports from different Logix versions
still load. AOI definitions keep their parameters (usage, required, defaults),
local tags and routines so the engine can execute them.
"""
from __future__ import annotations

from lxml import etree

from .model import (STRING_TYPES, AOIDef, AOIParam, Controller, DataType, Member, Program,
                    Routine, Tag, register_string_type)


def _dim(elem, *names: str) -> int:
    for n in names:
        v = elem.get(n)
        if v:
            try:
                return int(str(v).split()[0])
            except ValueError:
                return 0
    return 0


def _dims(elem, *names: str) -> tuple:
    """Declared shape: Dimensions="2 3" -> (2, 3); "10" -> (10,); none -> ()."""
    for n in names:
        v = elem.get(n)
        if v:
            try:
                dims = tuple(int(x) for x in str(v).replace(",", " ").split())
            except ValueError:
                return ()
            return dims if all(d > 0 for d in dims) else ()
    return ()


_ATOMIC_L5K = {"BOOL", "SINT", "INT", "DINT", "LINT", "USINT", "UINT", "UDINT", "ULINT",
               "REAL", "LREAL"}


def _l5k_atomic(tag_elem):
    """Initial value from <Data Format="L5K"> for atomic scalars and arrays (used
    when the export has no Decorated data). Structures are not decoded from L5K:
    their text includes hidden members."""
    dtype = tag_elem.get("DataType", "")
    if dtype not in _ATOMIC_L5K:
        return None
    for d in tag_elem.findall("Data"):
        if d.get("Format") != "L5K":
            continue
        raw = (d.text or "").strip()
        if not raw:
            return None
        flat = raw.replace("[", " ").replace("]", " ").replace(",", " ").split()
        vals = [_number(x, dtype) for x in flat]
        return vals if raw.startswith("[") else (vals[0] if vals else None)
    return None


def _members(parent) -> list[Member]:
    out = []
    mp = parent.find("Members")
    if mp is None:
        return out
    for m in mp.findall("Member"):
        if m.get("Hidden") == "true":
            continue
        dtype = m.get("DataType")
        if dtype == "BIT":                       # BOOL packed into a hidden SINT
            dtype = "BOOL"
        out.append(Member(m.get("Name"), dtype, _dim(m, "Dimension"), description=_text(m),
                          external_access=m.get("ExternalAccess") or "Read/Write"))
    return out


def _text(elem, child: str = "Description") -> str:
    node = elem.find(child) if elem is not None else None
    return (node.text or "").strip() if node is not None else ""


# ---- <Data Format="Decorated"> initial values ---------------------------------------
def _number(raw: str | None, dtype: str = ""):
    if raw is None:
        return None
    s = raw.strip()
    if dtype == "BOOL":
        return s in ("1", "true", "True")
    if dtype in ("REAL", "LREAL"):
        try:
            return float(s)
        except ValueError:
            return 0.0                           # 1.#QNAN etc.
    if s.startswith("'") and s.endswith("'"):    # ASCII radix
        body = s[1:-1]
        return ord(body[0]) if len(body) == 1 else 0
    s = s.replace("_", "")
    try:
        if "#" in s:
            base, digits = s.split("#", 1)
            return int(digits, int(base))
        return int(s)
    except ValueError:
        try:
            return int(float(s))
        except ValueError:
            return 0


_ESC = {"$": "$", "'": "'", '"': '"', "L": "\n", "N": "\n", "P": "\f", "R": "\r", "T": "\t"}


def unescape_string(text: str) -> str:
    """Logix string literal escapes: $$ $' $N $L $R $T $P and $hh (hex)."""
    out, i = [], 0
    while i < len(text):
        ch = text[i]
        if ch == "$" and i + 1 < len(text):
            nxt = text[i + 1]
            if nxt.upper() in _ESC:
                out.append(_ESC[nxt.upper()])
                i += 2
                continue
            if i + 2 < len(text) and all(c in "0123456789abcdefABCDEF" for c in text[i + 1:i + 3]):
                out.append(chr(int(text[i + 1:i + 3], 16)))
                i += 3
                continue
        out.append(ch)
        i += 1
    return "".join(out)


def _decorated(node, dtype: str = ""):
    """Decorated data element -> python value (dict / list / scalar)."""
    tag = node.tag
    if tag == "DataValue":
        return _number(node.get("Value"), node.get("DataType") or dtype)
    if tag in ("Structure", "StructureMember"):
        sdt = node.get("DataType") or dtype
        out = {}
        for m in node:
            if not isinstance(m.tag, str) or not m.get("Name"):
                continue
            out[m.get("Name")] = _decorated(m, m.get("DataType", ""))
        if sdt and (sdt in STRING_TYPES or "STRING" in sdt.upper()) and "DATA" in out:
            data = node.find("DataValueMember[@Name='DATA']")
            raw = data.get("Value") if data is not None else ""
            raw = ((raw or data.text or "") if data is not None else "").strip()
            text = unescape_string(raw[1:-1] if raw.startswith("'") and raw.endswith("'") else raw)
            n = out.get("LEN")
            return text[:n] if isinstance(n, int) and 0 <= n <= len(text) else text
        return out
    if tag in ("Array", "ArrayMember"):
        adt = node.get("DataType") or dtype
        out = []
        for e in node.findall("Element"):
            if e.get("Value") is not None:
                out.append(_number(e.get("Value"), adt))
            else:
                child = next((c for c in e if isinstance(c.tag, str)), None)
                out.append(_decorated(child, adt) if child is not None else None)
        return out
    if tag == "DataValueMember":
        return _number(node.get("Value"), node.get("DataType") or dtype)
    return None


def _initial(tag_elem):
    for d in tag_elem.findall("Data"):
        if d.get("Format") == "Decorated":
            child = next((c for c in d if isinstance(c.tag, str)), None)
            if child is not None:
                return _decorated(child, tag_elem.get("DataType", ""))
        if d.get("Format") == "String":
            raw = (d.text or "").strip()
            return unescape_string(raw[1:-1] if raw.startswith("'") and raw.endswith("'") else raw)
    return None


def _struct_type(node, name: str, types: dict) -> None:
    """Create a DataType from a decorated module Structure (e.g. AB:1756_DI:I:0)."""
    if name in types:
        return
    members = []
    for m in node:
        if not isinstance(m.tag, str) or not m.get("Name"):
            continue
        mt = m.get("DataType") or "DINT"
        if m.tag == "StructureMember":
            _struct_type(m, mt, types)
            members.append(Member(m.get("Name"), mt, 0))
        elif m.tag == "ArrayMember":
            members.append(Member(m.get("Name"), mt, len(m.findall("Element"))))
        else:
            members.append(Member(m.get("Name"), "BOOL" if mt == "BIT" else mt, 0))
    types[name] = DataType(name, members)


def _routines(parent) -> dict[str, Routine]:
    routines: dict[str, Routine] = {}
    rp = parent.find("Routines")
    if rp is None:
        return routines
    for r in rp.findall("Routine"):
        name = r.get("Name")
        rtype = (r.get("Type") or "RLL").upper()
        routine = Routine(name, rtype if rtype in ("ST", "FBD", "SFC") else "RLL",
                          description=_text(r))
        if routine.rtype == "RLL":
            rll = r.find("RLLContent")
            if rll is not None:
                for rung in rll.findall("Rung"):
                    # empty rungs are kept so rung numbers match Studio 5000
                    txt = (rung.findtext("Text") or "").strip()
                    comment = _text(rung, "Comment")
                    if comment:
                        routine.comments[len(routine.rungs)] = comment
                    rtype = (rung.get("Type") or "N")
                    if rtype not in ("N", "n"):
                        routine.pending_edits.append((len(routine.rungs), rtype))
                    routine.rungs.append(txt)
        else:
            st = r.find("STContent")
            if st is not None:
                lines = [_st_line(ln.text) for ln in st.findall("Line")]
                routine.text = "\n".join(lines)
        routines[name] = routine
    return routines


def _st_line(text: str | None) -> str:
    """One <Line> of Structured Text. Exports put the CDATA on its own line inside the
    element (<Line>CRLF<![CDATA[...]]>CRLF</Line>); that layout whitespace is not part of
    the code line, which never contains a line break itself."""
    t = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    if "\n" not in t:
        return t
    parts = t.split("\n")
    while len(parts) > 1 and not parts[0].strip():
        parts.pop(0)
    while len(parts) > 1 and not parts[-1].strip():
        parts.pop()
    return " ".join(p for p in parts) if len(parts) > 1 else parts[0]


def _flag(elem, name: str, default: bool = False) -> bool:
    v = elem.get(name)
    return default if v is None else v.strip().lower() == "true"


def _default_data(elem, dtype: str):
    for d in elem.findall("DefaultData"):
        if d.get("Format") == "Decorated":
            child = next((c for c in d if isinstance(c.tag, str)), None)
            if child is not None:
                return _decorated(child, dtype)
    return None


def _aoi(a) -> AOIDef:
    params, members = [], []
    for p in a.findall("Parameters/Parameter"):
        dtype = p.get("DataType") or "DINT"
        usage = p.get("Usage") or "Input"
        params.append(AOIParam(
            p.get("Name"), "BOOL" if dtype == "BIT" else dtype, usage,
            required=_flag(p, "Required"), visible=_flag(p, "Visible"),
            dim=_dim(p, "Dimensions", "Dimension"),
            default=_default_data(p, dtype), description=_text(p),
            # import defaults when the attribute is missing (1756-PM004, Imported Tag Behavior)
            external_access=p.get("ExternalAccess") or (
                "Read Only" if usage == "Output" or p.get("Name") in ("EnableIn", "EnableOut")
                else "Read/Write"),
            constant=usage == "InOut" and _flag(p, "Constant")))
        members.append(Member(p.get("Name"), dtype, _dim(p, "Dimensions", "Dimension")))
    local = []
    for t in a.findall("LocalTags/LocalTag"):
        dtype = t.get("DataType") or "DINT"
        local.append(AOIParam(t.get("Name"), "BOOL" if dtype == "BIT" else dtype, "Local",
                              dim=_dim(t, "Dimensions", "Dimension"),
                              default=_default_data(t, dtype), description=_text(t),
                              external_access=t.get("ExternalAccess") or "Read/Write"))
    return AOIDef(a.get("Name"), members, _routines(a), "Logic",
                  parameters=params, local_tags=local,
                  execute_prescan=_flag(a, "ExecutePrescan"),
                  execute_postscan=_flag(a, "ExecutePostscan"),
                  execute_enableinfalse=_flag(a, "ExecuteEnableInFalse"),
                  revision=a.get("Revision", ""), description=_text(a))


def _tags(parent, scope: str, aliases: dict | None = None, prefix: str = "",
          alias_desc: dict | None = None) -> list[Tag]:
    out = []
    tp = parent.find("Tags")
    if tp is None:
        return out
    for t in tp.findall("Tag"):
        if t.get("TagType") == "Alias":
            if aliases is not None and t.get("AliasFor"):
                aliases[prefix + t.get("Name")] = t.get("AliasFor")
                if alias_desc is not None and _text(t):
                    alias_desc[prefix + t.get("Name")] = _text(t)
            continue
        init = _initial(t)
        if init is None:
            init = _l5k_atomic(t)
        out.append(Tag(t.get("Name"), t.get("DataType"), 0, scope,
                       init=init, description=_text(t),
                       dims=_dims(t, "Dimensions", "Dimension"),
                       external_access=t.get("ExternalAccess") or "Read/Write",
                       constant=_flag(t, "Constant"), radix=t.get("Radix") or "",
                       tag_type=t.get("TagType") or "Base"))
    return out


def _modules(cnode, ctrl: Controller) -> None:
    """I/O module connection tags -> tags named like Studio 5000 (Local:1:I, Rack:3:O, Enet:I)."""
    mods = cnode.find("Modules")
    if mods is None:
        return
    by_name = {m.get("Name"): m for m in mods.findall("Module")}
    ctrl.module_names = list(by_name)
    controller_name = None
    for m in by_name.values():
        if m.get("ParentModule") == m.get("Name"):       # the controller itself (Local)
            controller_name = m.get("Name")

    def slot_of(m):
        for p in m.findall("Ports/Port"):
            if p.get("Upstream") == "true":
                return p.get("Address"), (p.get("Type") or "")
        return None, ""

    for name, m in by_name.items():
        if name == controller_name:
            continue
        parent = m.get("ParentModule")
        addr, ptype = slot_of(m)
        backplane = ptype.upper() in ("ICP", "COMPACT", "POINTIO", "FLEX", "CNET") \
            or (addr is not None and addr.isdigit() and ptype.upper() != "ETHERNET")
        if parent == controller_name and backplane:
            base = f"Local:{addr}"
        elif parent and parent in by_name and parent != controller_name and backplane:
            base = f"{parent}:{addr}"
        else:
            base = name
        cfg = m.find("Communications/ConfigTag")       # Location:Slot:C (configuration data)
        if cfg is not None:
            data = next((d for d in cfg.findall("Data") if d.get("Format") == "Decorated"), None)
            struct = data.find("Structure") if data is not None else None
            if struct is not None:
                dtype = struct.get("DataType") or f"{name}:C"
                _struct_type(struct, dtype, ctrl.data_types)
                tag_name = f"{base}:C"
                if not any(t.name == tag_name for t in ctrl.tags):
                    ctrl.tags.append(Tag(tag_name, dtype, 0, "controller",
                                         init=_decorated(struct, dtype), description=_text(m)))
                    ctrl.modules.append({"tag": tag_name, "module": name,
                                         "catalog": m.get("CatalogNumber", ""), "parent": parent,
                                         "slot": addr, "description": _text(m)})
        for conn in m.findall("Communications/Connections/Connection"):
            for kind, letter in (("InputTag", "I"), ("OutputTag", "O")):
                tnode = conn.find(kind)
                if tnode is None:
                    continue
                data = next((d for d in tnode.findall("Data") if d.get("Format") == "Decorated"), None)
                struct = data.find("Structure") if data is not None else None
                if struct is None:
                    continue
                dtype = struct.get("DataType") or f"{name}:{letter}"
                _struct_type(struct, dtype, ctrl.data_types)
                tag_name = f"{base}:{letter}"
                if any(t.name == tag_name for t in ctrl.tags):
                    continue
                ctrl.tags.append(Tag(tag_name, dtype, 0, "controller",
                                     init=_decorated(struct, dtype),
                                     description=_text(m)))
                ctrl.modules.append({"tag": tag_name, "module": name,
                                     "catalog": m.get("CatalogNumber", ""),
                                     "parent": parent, "slot": addr,
                                     "description": _text(m)})


# Hardened parser: no entity expansion, no network, no huge trees. L5X files
# can come from customers, so the input is not always trusted.
_SAFE_PARSER = etree.XMLParser(
    resolve_entities=False, no_network=True, huge_tree=False,
    dtd_validation=False, load_dtd=False,
)


def load_string(xml: str | bytes) -> Controller:
    if isinstance(xml, str):
        xml = xml.encode("utf-8")
    root = etree.fromstring(xml, parser=_SAFE_PARSER)
    cnode = root if root.tag == "Controller" else root.find(".//Controller")
    if cnode is None:
        raise ValueError("no <Controller> element found in L5X")

    ctrl = Controller(name=cnode.get("Name", "controller"), description=_text(cnode),
                      report_overflow=(cnode.get("ReportMinorOverflow") or "true").lower() != "false",
                      processor=cnode.get("ProcessorType", ""),
                      revision=f"{cnode.get('MajorRev', '')}.{cnode.get('MinorRev', '')}".strip("."))

    dts = cnode.find("DataTypes")
    if dts is not None:
        for dt in dts.findall("DataType"):
            d = DataType(dt.get("Name"), _members(dt), family=dt.get("Family") or "")
            register_string_type(d)                  # user string types are strings
            ctrl.data_types[dt.get("Name")] = d

    aoip = cnode.find("AddOnInstructionDefinitions")
    if aoip is not None:
        for a in aoip.findall("AddOnInstructionDefinition"):
            ctrl.aois[a.get("Name")] = _aoi(a)

    ctrl.tags = _tags(cnode, "controller", ctrl.aliases, "", ctrl.alias_descriptions)
    _modules(cnode, ctrl)

    progs = cnode.find("Programs")
    if progs is not None:
        for p in progs.findall("Program"):
            prog = Program(p.get("Name"), p.get("MainRoutineName") or "",
                           description=_text(p), disabled=_flag(p, "Disabled"))
            prog.routines = _routines(p)
            prog.tags = _tags(p, prog.name, ctrl.aliases, f"Program:{prog.name}.",
                              ctrl.alias_descriptions)
            ctrl.programs[prog.name] = prog

    # task scheduling order (continuous task first, then declaration order)
    order: list[str] = []
    tasks = cnode.find("Tasks")
    if tasks is not None:
        cont = [t for t in tasks.findall("Task")
                if (t.get("Type") or "").upper() == "CONTINUOUS"]
        rest = [t for t in tasks.findall("Task")
                if (t.get("Type") or "").upper() != "CONTINUOUS"]
        for t in tasks.findall("Task"):
            ctrl.tasks.append({"name": t.get("Name"), "type": (t.get("Type") or "").upper(),
                               "rate_ms": float(t.get("Rate") or 0) or None,
                               "priority": int(t.get("Priority") or 10),
                               "watchdog_ms": float(t.get("Watchdog") or 500),
                               "inhibited": _flag(t, "InhibitTask"),
                               "description": _text(t),
                               "programs": [s.get("Name") for s in t.findall("ScheduledPrograms/ScheduledProgram")]})
        for t in cont + rest:
            sp = t.find("ScheduledPrograms")
            if sp is not None:
                for s in sp.findall("ScheduledProgram"):
                    if s.get("Name") in ctrl.programs:
                        order.append(s.get("Name"))
    for name in ctrl.programs:
        if name not in order:
            order.append(name)
    ctrl.task_order = order
    return ctrl


def load_file(path: str) -> Controller:
    with open(path, "rb") as fh:
        return load_string(fh.read())
