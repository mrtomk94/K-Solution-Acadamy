"""Project files (``project.json``) and tag import/export.

Format (version 1)::

    {"format": "logixsim-project", "version": 1, "name": "Line 1",
     "types": {"Motor_t": [{"name": "Run", "type": "BOOL"}, {"name": "Speed", "type": "REAL"}]},
     "tags": [{"name": "Level", "type": "REAL", "dim": 0, "value": 40.0,
               "description": "", "units": "%", "min": 0, "max": 100,
               "access": "rw", "group": "Tank", "retain": false}],
     "forces": {"Running": false},
     "logic": {"l5x": "program.L5X"},             # optional PLC program
     "engine": {"scan_ms": 20, "publish_ms": 50},
     "connectors": {"opcua": {"enabled": true, "port": 4840}}}

Tags from an optional L5X keep coming from that file; ``tags`` saved in the
project are the ones defined in the emulator (plus their current values).
"""
from __future__ import annotations

import csv
import json
import os
import time
from dataclasses import asdict

from .emulator import Emulator
from .engine import Engine
from .l5x_loader import load_file
from .model import ATOMIC, STRING_TYPES
from .tagstore import META_FIELDS, TagMeta, TagStoreError

FORMAT, VERSION = "logixsim-project", 1
STUDIO_FORMAT, STUDIO_VERSION = "virtualcontrolstudio-project", 2
STUDIO_EXT = ".vcsproj"


class ProjectError(ValueError):
    pass


def _meta_from(d: dict) -> TagMeta:
    kw = {k: d[k] for k in META_FIELDS if k in d and d[k] is not None and d[k] != ""}
    return TagMeta(**kw)


def save_project(emu: Emulator, path: str) -> None:
    """Save the project. Studio projects (and any ``.vcsproj`` path) use format 2:
    the whole project as an embedded L5X plus values, forces and settings."""
    if path.lower().endswith(STUDIO_EXT) or getattr(emu.engine, "authoring", False):
        return save_studio_project(emu, path)
    st = emu.store
    l5x_names = set(emu._l5x_tags) if hasattr(emu, "_l5x_tags") else set()
    tags, l5x_meta = [], {}
    default_meta = asdict(TagMeta())
    for d in st.definitions():
        if d["name"] in l5x_names:
            m = {k: d[k] for k in META_FIELDS if d.get(k) != default_meta[k]}
            if m:
                l5x_meta[d["name"]] = m
            continue
        d = dict(d)
        d["value"] = st.read(d["name"])
        tags.append(d)
    data = {"format": FORMAT, "version": VERSION, "name": emu.name,
            "types": {n: t for n, t in st.types().items()
                      if n not in emu.engine.controller.data_types
                      and n not in emu.engine.controller.aois},
            "tags": tags, "forces": st.forces(),
            "engine": {"scan_ms": round(emu.engine.target_period * 1000),
                       "timing": emu.engine.timing,
                       "publish_ms": round(emu.bus.interval * 1000)},
            "connectors": emu.settings.get("connectors", {}),
            "web": {k: v for k, v in (emu.settings.get("web") or {}).items() if k != "bind_host"}}
    if emu.connections.list():
        data["connections"] = emu.connections.to_project()
    if emu.logic_file:
        data["logic"] = {"l5x": emu.logic_file}
        if l5x_meta:
            data["l5x_meta"] = l5x_meta
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    os.replace(tmp, path)


def load_project(path: str, emu: Emulator | None = None) -> Emulator:
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError) as exc:
        raise ProjectError(f"cannot read project {path}: {exc}") from exc
    if isinstance(data, dict) and data.get("format") == STUDIO_FORMAT:
        return load_studio_project(path, emu, data)
    if not isinstance(data, dict) or data.get("format") != FORMAT:
        raise ProjectError(f"{path} is not a VirtualControlStudio project (format must be "
                           f"{STUDIO_FORMAT!r} or {FORMAT!r})")
    if data.get("version") != VERSION:
        raise ProjectError(f"unsupported project version {data.get('version')!r} (expected {VERSION})")
    base = os.path.dirname(os.path.abspath(path))
    name = str(data.get("name") or "Project")

    engine = None
    logic = (data.get("logic") or {}).get("l5x")
    l5x_tags: set[str] = set()
    if logic:
        lp = logic if os.path.isabs(logic) else os.path.join(base, logic)
        try:
            engine = Engine(load_file(lp))
        except Exception as exc:
            raise ProjectError(f"cannot load logic {lp}: {exc}") from exc
        l5x_tags = set(engine.db.declarations())
    emu = Emulator(name=name, engine=engine)
    emu.logic_file = logic
    emu._l5x_tags = l5x_tags
    eng_cfg = data.get("engine") or {}
    if "scan_ms" in eng_cfg:
        emu.engine.target_period = max(1, int(eng_cfg["scan_ms"])) / 1000.0
    if eng_cfg.get("timing") in ("realtime", "exact"):
        emu.engine.timing = eng_cfg["timing"]
    if "publish_ms" in eng_cfg:
        emu.bus.interval = max(10, int(eng_cfg["publish_ms"])) / 1000.0
    emu.settings["connectors"] = data.get("connectors") or {}
    emu.settings["web"] = data.get("web") or {}
    emu.connections.load(data.get("connections"))

    st = emu.store
    try:
        for tname, members in (data.get("types") or {}).items():
            if tname in emu.engine.controller.data_types or tname in emu.engine.controller.aois:
                continue                          # comes from the L5X
            st.define_type(tname, members)
        for i, t in enumerate(data.get("tags") or []):
            if not isinstance(t, dict) or "name" not in t or "type" not in t:
                raise ProjectError(f"tag #{i + 1}: needs at least 'name' and 'type'")
            st.define(t["name"], t["type"], dim=t.get("dim", 0),
                      dims=t.get("dims") if len(t.get("dims") or ()) > 1 else None,
                      value=t.get("value"), meta=_meta_from(t))
        for tname, m in (data.get("l5x_meta") or {}).items():
            if tname in l5x_tags:
                st.set_meta(tname, **{k: v for k, v in m.items() if k in META_FIELDS})
        for addr, v in (data.get("forces") or {}).items():
            st.force(addr, v, source="project")
    except TagStoreError as exc:
        raise ProjectError(f"{path}: {exc}") from exc
    return emu


# ---- Studio projects (format 2, .vcsproj) -----------------------------------------------
def projects_dir() -> str:
    """Where Open / Save look: $VCS_PROJECTS_DIR, else Documents/VirtualControlStudio."""
    env = os.environ.get("VCS_PROJECTS_DIR")
    if env:
        return os.path.abspath(env)
    home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    docs = os.path.join(home, "Documents")
    return os.path.join(docs if os.path.isdir(docs) else home, "VirtualControlStudio")


_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
             *(f"LPT{i}" for i in range(1, 10))}
_BAD_NAME = set('<>:"/\\|?*')


def project_file(name: str, exts=(STUDIO_EXT,), default_ext: str | None = STUDIO_EXT) -> str:
    """A file name inside the projects folder (no folders, no '..', no drive).
    Raises ProjectError for anything else."""
    if not isinstance(name, str) or not name.strip():
        raise ProjectError("a file name is required")
    name = name.strip()
    if any(ch in _BAD_NAME or ord(ch) < 32 for ch in name) or name in (".", "..") \
            or name.startswith(".") or name.endswith((".", " ")) or len(name) > 120:
        raise ProjectError(f"{name!r} is not a plain file name in the projects folder")
    base, ext = os.path.splitext(name)
    if base.split(".")[0].strip().upper() in _RESERVED:
        raise ProjectError(f"{name!r} is a reserved device name on Windows; choose another name")
    if not ext and default_ext:
        name, ext = name + default_ext, default_ext
    if ext.lower() not in tuple(e.lower() for e in exts):
        raise ProjectError(f"{name!r}: expected a {' or '.join(exts)} file")
    folder = projects_dir()
    path = os.path.abspath(os.path.join(folder, name))
    if os.path.dirname(path) != folder:
        raise ProjectError(f"{name!r} is outside the projects folder")
    if os.path.islink(path) or (os.path.exists(path) and
                                os.path.dirname(os.path.realpath(path)) != os.path.realpath(folder)):
        raise ProjectError(f"{name!r} is a link to another place; links are not followed")
    return path


def save_studio_project(emu: Emulator, path: str, watch: list | None = None) -> str:
    from . import __version__
    from .l5x_writer import write_l5x
    eng, st = emu.engine, emu.store
    with eng.scan_lock:
        l5x = write_l5x(eng.controller, emu.l5x_source, eng.db)
        values = json.loads(json.dumps(eng.db._store, default=str))
        default_meta = asdict(TagMeta())
        meta = {}
        for d in st.definitions():
            m = {k: d[k] for k in META_FIELDS if k != "description" and d.get(k) != default_meta[k]}
            if m:
                meta[d["name"]] = m
        forces = st.forces()
    if watch is not None:
        emu.settings["watch"] = list(watch)
    data = {"format": STUDIO_FORMAT, "version": STUDIO_VERSION, "name": eng.controller.name,
            "app_version": __version__, "saved": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "source_file": emu.logic_file,
            "l5x": l5x.decode("utf-8"),
            "values": values, "forces": forces, "meta": meta,
            "forces_enabled": bool(getattr(st, "forces_enabled", True)),
            "watch": emu.settings.get("watch", []),
            "engine": {"scan_ms": round(eng.target_period * 1000), "timing": eng.timing,
                       "publish_ms": round(emu.bus.interval * 1000)},
            "connectors": emu.settings.get("connectors", {}),
            "connections": emu.connections.to_project(),
            "web": {k: v for k, v in (emu.settings.get("web") or {}).items() if k != "bind_host"}}
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=1)
    os.replace(tmp, path)
    emu.project_path = path
    with eng.scan_lock:
        emu.l5x_source = l5x                  # the saved project is the new export base,
        mark_clean(eng.controller)            # so nothing is "changed" relative to it now
    emu.saved_change = eng.change_count
    return path


def mark_clean(c) -> None:
    """After a save the export base is the saved L5X: every item now matches its
    node there under its current name (see l5x_writer: src_name, dirty, modified)."""
    for t in list(c.tags) + [t for p in c.programs.values() for t in p.tags]:
        t.__dict__.pop("src_name", None)
        t.__dict__.pop("dirty", None)
    for p in c.programs.values():
        p.__dict__.pop("src_name", None)
        for r in p.routines.values():
            r.__dict__.pop("src_name", None)
            r.__dict__.pop("description_changed", None)
            r.modified = False
    for t in c.tasks:
        t.pop("src_name", None)
    c.__dict__.pop("description_changed", None)


def load_studio_project(path: str, emu: Emulator | None = None, data: dict | None = None) -> Emulator:
    from .l5x_loader import load_string
    if data is None:
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError) as exc:
            raise ProjectError(f"cannot read project {path}: {exc}") from exc
    if data.get("version") != STUDIO_VERSION or not isinstance(data.get("l5x"), str):
        raise ProjectError(f"{path}: unsupported project version {data.get('version')!r}")
    raw = data["l5x"].encode("utf-8")
    try:
        ctrl = load_string(raw)
    except Exception as exc:
        raise ProjectError(f"{path}: the project's L5X cannot be read: {exc}") from exc
    if emu is None:
        emu = Emulator(name=ctrl.name)
    emu.load_controller(ctrl, logic_file=data.get("source_file"), source=raw)
    eng, st = emu.engine, emu.store
    with eng.scan_lock:
        for name, v in (data.get("values") or {}).items():
            if eng.db.has_tag(name):
                decl = eng.db.declaration(name)
                eng.db._store[name] = eng.db._overlay(eng.db._store[name], v, decl.data_type)
    for name, m in (data.get("meta") or {}).items():
        if st._has(name):
            try:
                st.set_meta(name, **{k: v for k, v in m.items() if k in META_FIELDS})
            except TagStoreError:
                pass
    if hasattr(st, "set_forces_enabled"):
        st.set_forces_enabled(data.get("forces_enabled", True))
    for addr, v in (data.get("forces") or {}).items():
        try:
            st.force(addr, v, source="project")
        except TagStoreError:
            pass
    emu.settings["watch"] = list(data.get("watch") or [])
    emu.settings["connectors"] = {}
    emu.connections.load(data.get("connections"), legacy=data.get("connectors"))
    emu.settings["web"] = {**(emu.settings.get("web") or {}), **(data.get("web") or {})}
    eng_cfg = data.get("engine") or {}
    if "scan_ms" in eng_cfg:
        eng.target_period = max(1, int(eng_cfg["scan_ms"])) / 1000.0
    if eng_cfg.get("timing") in ("realtime", "exact"):
        eng.timing = eng_cfg["timing"]
    emu.project_path = path
    emu.saved_change = eng.change_count
    return emu


def new_studio_project(path: str, name: str) -> str:
    """Write an empty Studio project file (MainTask / MainProgram / MainRoutine)."""
    emu = Emulator(name=name)
    emu.new_project(name)
    try:
        return save_studio_project(emu, path)
    finally:
        emu.stop()


# ---- CSV ----------------------------------------------------------------------------
CSV_COLUMNS = ["name", "type", "dim", "value", "description", "units", "min", "max",
               "access", "group", "retain"]


def export_csv(store, path: str) -> int:
    """Atomic and STRING tags (and their arrays) as CSV. Returns the row count."""
    rows = 0
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=CSV_COLUMNS)
        w.writeheader()
        for d in store.definitions():
            if d["type"] not in ATOMIC and d["type"] not in STRING_TYPES:
                continue                       # structures need their type: use the project file
            row = {k: d.get(k) for k in CSV_COLUMNS if k != "value"}
            row["value"] = json.dumps(store.read(d["name"]))
            row = {k: ("" if v is None else v) for k, v in row.items()}
            w.writerow(row)
            rows += 1
    return rows


def _num(x: str):
    if x is None or str(x).strip() == "":
        return None
    f = float(x)
    return int(f) if f.is_integer() else f


def import_csv(store, path: str) -> int:
    """Columns: name,type[,dim,value,description,units,min,max,access,group,retain]."""
    n = 0
    with open(path, newline="", encoding="utf-8-sig") as fh:
        for line, row in enumerate(csv.DictReader(fh), start=2):
            try:
                value = row.get("value")
                if value not in (None, ""):
                    try:
                        value = json.loads(value)
                    except ValueError:
                        pass                       # plain text, e.g. for STRING
                else:
                    value = None
                meta = TagMeta(description=row.get("description") or "",
                               units=row.get("units") or "",
                               min=_num(row.get("min")), max=_num(row.get("max")),
                               access=(row.get("access") or "rw").strip(),
                               group=row.get("group") or "",
                               retain=str(row.get("retain") or "").lower() in ("1", "true", "yes"))
                store.define((row.get("name") or "").strip(), (row.get("type") or "").strip(),
                             dim=int(_num(row.get("dim")) or 0), value=value, meta=meta)
                n += 1
            except (TagStoreError, ValueError, TypeError) as exc:
                raise ProjectError(f"{path} line {line}: {exc}") from exc
    return n


def import_l5x_tags(store, path: str) -> int:
    """Create the controller-scope tags and data types of an L5X (no logic)."""
    try:
        ctrl = load_file(path)
    except Exception as exc:
        raise ProjectError(f"cannot load {path}: {exc}") from exc
    for dt in ctrl.data_types.values():
        if dt.name not in store.types():
            store.define_type(dt.name, [{"name": m.name, "type": m.data_type, "dim": m.dim}
                                        for m in dt.members])
    n = 0
    for tag in ctrl.tags:
        try:
            store.define(tag.name, tag.data_type, dim=tag.dim)
            n += 1
        except TagStoreError as exc:
            if exc.code != "exists":
                raise ProjectError(f"{path}: tag {tag.name}: {exc}") from exc
    return n
