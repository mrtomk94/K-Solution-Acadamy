"""TagStore: the emulator's single source of truth for tags.

Wraps the typed TagDB with what a generic emulator needs:
  * tags and structure types created, renamed and deleted at runtime
  * metadata per base tag (description, units, min/max, access, group, retain)
  * forces (hold a value against every other writer, including logic)
  * write arbitration: force > read-only check > range check > last write wins
  * who wrote each tag last, and when
  * change detection over flattened leaf addresses (for the EventBus)

Write timing: while the engine is RUNNING writes are queued and applied at the
next scan boundary; while STOPPED they apply immediately.
"""
from __future__ import annotations

import re
import threading
import time
from dataclasses import asdict, dataclass
from typing import Any, Callable

from .model import (ATOMIC, STRING_TYPES, DataType, Member, Tag, TagDB, access_code,
                    coerce)
from .isa.values import nice_real

# Logix tag names: letters, digits and _, start with a letter or _, at most 40
# characters, no two underscores in a row and no underscore at the end; names are
# not case sensitive (1756-PM004, Guidelines for Tags)
NAME_RE = re.compile(r"^(?!.*__)(?!.*_$)[A-Za-z_][A-Za-z0-9_]{0,39}$")
INTERNAL_SOURCES = ("ui", "logic", "sequence", "internal", "force", "project")
NUMERIC = {"SINT", "INT", "DINT", "LINT", "REAL", "USINT", "UINT", "UDINT", "ULINT", "LREAL"}
INT_RANGE = {t: (-(1 << (b - 1)), (1 << (b - 1)) - 1)
             for t, b in (("SINT", 8), ("INT", 16), ("DINT", 32), ("LINT", 64))}
INT_RANGE.update({t: (0, (1 << b) - 1) for t, b in (("USINT", 8), ("UINT", 16), ("UDINT", 32), ("ULINT", 64))})


def _check_int_range(addr: str, dtype: str, value) -> None:
    """Client values must fit the type; logic arithmetic still wraps like a PLC."""
    if isinstance(value, bool):
        return
    try:
        num = float(value) if isinstance(value, str) else value
    except ValueError:
        return                                   # _strict reports the bad text
    if isinstance(num, (int, float)):
        lo, hi = INT_RANGE[dtype]
        if num < lo or num > hi:
            raise TagStoreError("range", f"{addr}={value} does not fit {dtype} ({lo}..{hi})")


class TagStoreError(ValueError):
    """code: name | type | exists | unknown | value | range | readonly | forced | limit"""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


@dataclass
class TagMeta:
    description: str = ""
    units: str = ""
    min: float | None = None
    max: float | None = None
    access: str = "rw"            # External Access: "rw", "ro" or "none" (connectors / API)
    group: str = ""
    retain: bool = False
    state0: str = ""              # BOOL extended properties (display text)
    state1: str = ""

    def validate(self) -> None:
        for f in ("min", "max"):
            v = getattr(self, f)
            if v is None or v == "":
                setattr(self, f, None)
                continue
            if isinstance(v, bool):
                raise TagStoreError("value", f"{f} must be a number, got {v!r}")
            try:
                num = float(v)
            except (TypeError, ValueError):
                raise TagStoreError("value", f"{f} must be a number, got {v!r}") from None
            setattr(self, f, int(num) if num.is_integer() else num)
        if self.access not in ("rw", "ro", "none"):
            raise TagStoreError("value", f"access must be 'rw', 'ro' or 'none', got {self.access!r}")
        if self.min is not None and self.max is not None and self.min > self.max:
            raise TagStoreError("value", "min is greater than max")


META_FIELDS = tuple(TagMeta.__dataclass_fields__)


def _display(v: Any) -> Any:
    """REAL values as their shortest decimal text (1.2, not 1.2000000476837158)."""
    if isinstance(v, float):
        return nice_real(v)
    if isinstance(v, list):
        return [_display(x) for x in v]
    if isinstance(v, dict):
        return {k: _display(x) for k, x in v.items()}
    return v


def root_of(addr: str) -> str:
    """Base tag of an address: 'M[1].Run' -> 'M', 'Program:P.T.X' -> 'Program:P.T'."""
    if addr.startswith("Program:"):
        head, _, rest = addr.partition(".")
        m = re.match(r"[^.\[]+", rest)
        return head + "." + (m.group() if m else rest)
    m = re.match(r"[^.\[]+", addr)
    return m.group() if m else addr


def _strict(dtype: str, value: Any) -> Any:
    """Coerce a client value, refusing things that are clearly not that type."""
    if dtype == "BOOL":
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)) and value in (0, 1):
            return bool(value)
        if isinstance(value, str) and value.strip().lower() in ("true", "false", "1", "0"):
            return value.strip().lower() in ("true", "1")
        raise TagStoreError("value", f"expected BOOL (true/false/0/1), got {value!r}")
    if dtype in STRING_TYPES:
        if not isinstance(value, str):
            raise TagStoreError("value", f"expected text, got {value!r}")
        return value
    if isinstance(value, bool) or value is None:
        raise TagStoreError("value", f"expected {dtype}, got {value!r}")
    try:
        if isinstance(value, str):
            value = float(value) if dtype in ("REAL", "LREAL") else int(float(value))
        if dtype not in ("REAL", "LREAL") and isinstance(value, float):
            if not value.is_integer():
                raise TagStoreError("value", f"expected a whole number for {dtype}, got {value!r}")
            value = int(value)
        return coerce(dtype, value)
    except (TypeError, ValueError) as exc:
        raise TagStoreError("value", f"expected {dtype}, got {value!r}") from exc


class TagStore:
    def __init__(self, db: TagDB | None = None, engine=None):
        self.db = db if db is not None else TagDB()
        self.engine = engine
        self.lock = threading.RLock()
        self._meta: dict[str, TagMeta] = {}
        self._forces: dict[str, Any] = {}
        self._writers: dict[str, tuple[str, float]] = {}
        self._prev: dict[str, Any] = {}
        self._structure_listeners: list[Callable] = []
        # guard against runaway tag creation by clients; counts every value in the project
        # (imported tags included), so it must sit well above real controller projects
        self.max_leaves = 2_000_000
        self._leaf_total: int | None = None
        self.forces_enabled = True          # I/O forces enabled at the controller level
        self.controller_log: list[dict] = []   # changes to constant tag values (last 200)

    def replace_db(self, db) -> None:
        """A new program was loaded: new tag database, all runtime state cleared."""
        with self.lock:
            self.db = db
            self._meta.clear()
            self._forces.clear()
            self._writers.clear()
            self._prev = {}
            self._leaf_total = None
        self._notify("reload", None)

    # ---- structure ------------------------------------------------------------
    def on_structure(self, fn: Callable[[str, Any], None]) -> None:
        self._structure_listeners.append(fn)

    def _notify(self, kind: str, name) -> None:
        cache = getattr(self.engine, "resolve_cache", None)
        if cache is not None:
            cache.clear()                        # scoping may change with new/removed tags
        inv = getattr(getattr(self.engine, "db", None), "invalidate", None)
        if inv is not None:
            inv()
        for fn in list(self._structure_listeners):
            try:
                fn(kind, name)
            except Exception:
                pass

    def _has(self, name: str) -> bool:
        has = getattr(self.db, "has_tag", None)
        return bool(has and has(name))

    def define_type(self, name: str, members: list[dict]) -> None:
        if not NAME_RE.match(name or ""):
            raise TagStoreError("name", f"invalid type name {name!r}")
        if self.db.known_type(name):
            raise TagStoreError("exists", f"data type {name!r} already exists")
        mlist = []
        for m in members:
            mname, mtype, mdim = m.get("name"), m.get("type"), int(m.get("dim", 0) or 0)
            if not NAME_RE.match(mname or ""):
                raise TagStoreError("name", f"invalid member name {mname!r} in {name}")
            if mtype != name and not self.db.known_type(mtype):
                raise TagStoreError("type", f"unknown member type {mtype!r} in {name}")
            mlist.append(Member(mname, mtype, mdim))
        with self.lock:
            self.db.add_type(DataType(name, mlist))

    def types(self) -> dict[str, list[dict]]:
        """User structure types (built-ins like TIMER excluded)."""
        from .model import PREDEFINED
        return {n: [{"name": m.name, "type": m.data_type, "dim": m.dim} for m in t.members]
                for n, t in self.db.types().items() if n not in PREDEFINED}

    def define(self, name: str, data_type: str, dim: int = 0, value: Any = None,
               meta: TagMeta | None = None, dims=None, external_access: str | None = None,
               constant: bool = False) -> None:
        """Create a tag. ``dims`` (e.g. (2, 3)) gives a multi-dimensional shape.
        In a Studio project (``engine.authoring``) the tag is also added to the
        controller model, so it is part of the project and of the L5X export."""
        if not isinstance(name, str) or not (NAME_RE.match(name) or self._program_name(name)):
            raise TagStoreError("name", f"invalid tag name {name!r} (letters, digits and _; start with a letter or _; max 40; no __ and no _ at the end)")
        if not self.db.known_type(data_type):
            raise TagStoreError("type", f"unknown data type {data_type!r}")
        try:
            dims = tuple(int(d) for d in dims) if dims else ()
            dim = int(dim or 0)
        except (TypeError, ValueError):
            raise TagStoreError("value", f"bad array size {dims or dim!r}") from None
        if len(dims) > 3 or any(d <= 0 for d in dims):
            raise TagStoreError("value", f"bad array dimensions {list(dims)} (1 to 3 sizes, each > 0)")
        if dims:
            dim = 1
            for d in dims:
                dim *= d
        if dim < 0 or dim > 100000:
            raise TagStoreError("value", f"bad array size {dim}")
        meta = meta or TagMeta()
        meta.validate()
        with self.lock:
            if self._has(name):
                raise TagStoreError("exists", f"tag {name!r} already exists")
            scope = name.split(".", 1)[0][len("Program:"):] if name.startswith("Program:") else "controller"
            base = name.split(".", 1)[1] if name.startswith("Program:") else name
            authoring = bool(getattr(self.engine, "authoring", False))
            if authoring and scope != "controller" and scope not in self.engine.controller.programs:
                raise TagStoreError("unknown", f"no program {scope!r}")
            tag = Tag(base if authoring else name, data_type, dim, scope, dims=dims,
                      description=meta.description,
                      external_access=external_access or
                      {"ro": "Read Only", "none": "None"}.get(meta.access, "Read/Write"),
                      constant=bool(constant))
            before = self._leaves_total()
            self.db.declare(tag, name)
            total = before + self._count(self.db.get(name))
            if total > self.max_leaves:
                self.db.remove(name)
                raise TagStoreError("limit", f"tag {name!r} would take the project to {total} values, "
                                             f"above the limit of {self.max_leaves}")
            self._leaf_total = total
            self._meta[name] = meta
            if value is not None:
                try:
                    for leaf, v in self._partial_leaves(name, value):
                        self.db.set(leaf, v)
                except TagStoreError:
                    self._leaf_total -= self._count(self.db.get(name))
                    self.db.remove(name)
                    del self._meta[name]
                    raise
            if authoring:
                import copy
                tag.init = copy.deepcopy(self.db.get(name)) if value is not None else None
                tag.dirty = True                  # new: written from the model at export
                self._model_add(scope, tag)
                self._changed()
        self._notify("define", name)

    def _partial_leaves(self, addr: str, value: Any) -> list[tuple[str, Any]]:
        """Like _leaves, but a structure value may give only some members
        (e.g. {"PRE": 1500} for a TIMER)."""
        try:
            cur = self.db.get(addr)
        except Exception:
            raise TagStoreError("unknown", f"no tag {addr!r}") from None
        if isinstance(cur, dict) and isinstance(value, dict):
            unknown = set(value) - set(cur)
            if unknown:
                raise TagStoreError("value", f"{addr} has no member(s) {sorted(unknown)}")
            out = []
            for k, v in value.items():
                out += self._partial_leaves(f"{addr}.{k}", v)
            return out
        return self._leaves(addr, value)

    # ---- the controller model (Studio projects) ---------------------------------------
    def _changed(self) -> None:
        """The project changed (unsaved changes; structure version for the UI)."""
        eng = self.engine
        eng.change_count = getattr(eng, "change_count", 0) + 1
        eng.project_version = getattr(eng, "project_version", 0) + 1

    def _model_add(self, scope: str, tag: Tag) -> None:
        c = self.engine.controller
        (c.tags if scope == "controller" else c.programs[scope].tags).append(tag)

    def _model_remove(self, name: str) -> None:
        c = getattr(self.engine, "controller", None)
        if c is None:
            return
        if name.startswith("Program:"):
            pname, _, base = name[len("Program:"):].partition(".")
            prog = c.programs.get(pname)
            if prog is not None:
                prog.tags = [t for t in prog.tags if t.name != base]
        else:
            c.tags = [t for t in c.tags if t.name != name]

    @staticmethod
    def _count(value) -> int:
        if isinstance(value, dict):
            return sum(TagStore._count(v) for v in value.values())
        if isinstance(value, list):
            return sum(TagStore._count(v) for v in value)
        return 1

    def _leaves_total(self) -> int:
        if self._leaf_total is None:
            self._leaf_total = sum(self._count(v) for v in getattr(self.db, "_store", {}).values())
        return self._leaf_total

    @staticmethod
    def _program_name(name: str) -> bool:
        m = re.match(r"^Program:([A-Za-z_]\w*)\.([A-Za-z_]\w*)$", name)
        return bool(m) and bool(NAME_RE.match(m.group(2)))

    def delete(self, name: str) -> None:
        with self.lock:
            if not self._has(name):
                raise TagStoreError("unknown", f"no tag {name!r}")
            if self._leaf_total is not None:
                self._leaf_total -= self._count(self.db.get(name))
            self.db.remove(name)
            self._meta.pop(name, None)
            for d in (self._forces, self._writers, self._prev):
                for k in [k for k in d if root_of(k) == name]:
                    del d[k]
            if getattr(self.engine, "authoring", False):
                self._model_remove(name)
                self._changed()
        self._notify("delete", name)

    def rename(self, old: str, new: str) -> None:
        if not (NAME_RE.match(new or "") or self._program_name(new or "")):
            raise TagStoreError("name", f"invalid tag name {new!r}")
        with self.lock:
            if not self._has(old):
                raise TagStoreError("unknown", f"no tag {old!r}")
            if self._has(new):
                raise TagStoreError("exists", f"tag {new!r} already exists")
            self.db.rename(old, new)
            self._meta[new] = self._meta.pop(old, TagMeta())

            def move(d):
                for k in [k for k in d if root_of(k) == old]:
                    d[new + k[len(old):]] = d.pop(k)
            move(self._forces)
            move(self._writers)
            for k in [k for k in self._prev if root_of(k) == old]:
                del self._prev[k]
        self._notify("rename", (old, new))

    def _root_key(self, name: str) -> str:
        """Declared base tag of any address (aliases resolved, any letter case)."""
        decl_of = getattr(self.db, "declaration_of", None)
        if decl_of is not None:
            root, _ = decl_of(name)
            if root:
                return root
        return root_of(name)

    def meta(self, name: str) -> TagMeta:
        key = self._root_key(name)
        m = self._meta.get(key)
        if m is not None:
            return m
        decl = getattr(self.db, "_decl", {}).get(key)
        if decl is not None:                       # imported tag: its External Access
            return TagMeta(description=getattr(decl, "description", "") or "",
                           access=access_code(getattr(decl, "external_access", None)))
        return TagMeta()

    def set_meta(self, name: str, **fields) -> None:
        with self.lock:
            if not self._has(name):
                raise TagStoreError("unknown", f"no tag {name!r}")
            key = self._root_key(name)
            m = TagMeta(**{**asdict(self.meta(key)), **fields})
            m.validate()
            self._meta[key] = m

    def access(self, addr: str) -> str:
        """External Access of an address for HMIs, other controllers and the
        integration connections: 'rw', 'ro' or 'none'. The tag's setting, made more
        restrictive by UDT member settings; an alias has its target's setting.
        The programming application (the Studio UI) always has full access."""
        from .model import stricter
        acc = self.meta(addr).access
        member = getattr(self.db, "member_access", None)
        if member is not None:
            try:
                acc = stricter(acc, member(addr))
            except Exception:
                pass
        return acc

    def read_external(self, addr: str) -> Any:
        """Read for an external client: refused for External Access None."""
        if self.access(addr) == "none":
            raise TagStoreError("noaccess", f"{addr}: External Access is None")
        return self.read(addr)

    # ---- extended properties (Min, Max, Engineering Unit, State0/1) -------------
    def extended(self, addr: str, prop: str):
        """Configured @Min/@Max for an address (the array/structure tag's value
        applies to its elements), or None when not configured."""
        m = self.meta(addr)
        v = getattr(m, prop.lower(), None)
        return None if v in ("", None) else v

    def definition(self, name: str) -> dict:
        with self.lock:
            if not self._has(name):
                raise TagStoreError("unknown", f"no tag {name!r}")
            tag = self.db.declaration(name)
            return {"name": name, "type": tag.data_type, "dim": tag.dim,
                    "dims": list(getattr(tag, "dims", ()) or ((tag.dim,) if tag.dim else ())),
                    **asdict(self.meta(name))}

    def definitions(self) -> list[dict]:
        with self.lock:
            names = list(self.db.declarations()) if hasattr(self.db, "declarations") else []
        return [self.definition(n) for n in names]

    # ---- reading ----------------------------------------------------------------
    def read(self, addr: str) -> Any:
        try:
            return _display(self.db.get(addr))
        except Exception:
            raise TagStoreError("unknown", f"no tag {addr!r}") from None

    def data_type(self, addr: str) -> str:
        try:
            return self.db.data_type(addr)
        except Exception:
            raise TagStoreError("unknown", f"no tag {addr!r}") from None

    def flat(self) -> dict[str, Any]:
        """Every leaf (atomic or string) as {address: value}."""
        out: dict[str, Any] = {}
        elem = getattr(self.db, "elem_address", lambda a, i: f"{a}[{i}]")

        def walk(prefix, v):
            if isinstance(v, dict):
                for k, x in v.items():
                    walk(f"{prefix}.{k}", x)
            elif isinstance(v, list):
                for i, x in enumerate(v):
                    walk(elem(prefix, i), x)
            else:
                out[prefix] = nice_real(v) if isinstance(v, float) else v
        scan_lock = getattr(self.engine, "scan_lock", None)
        if scan_lock is not None:
            with scan_lock, self.lock:            # never mid-scan
                for name, value in list(getattr(self.db, "_store", {}).items()):
                    walk(name, value)
        else:
            with self.lock:
                for name, value in list(getattr(self.db, "_store", {}).items()):
                    walk(name, value)
        return out

    def read_many(self, patterns: list[str]) -> dict[str, Any]:
        from .events import compile_pattern
        matchers = [compile_pattern(p) for p in patterns]
        return {a: v for a, v in self.flat().items() if any(m(a) for m in matchers)}

    def collect_changes(self) -> dict[str, Any]:
        """Leaves whose value differs from the previous call (first call: all)."""
        now = self.flat()
        with self.lock:
            changed = {a: v for a, v in now.items()
                       if a not in self._prev or self._prev[a] != v
                       or type(self._prev[a]) is not type(v)}
            self._prev = now
        return changed

    # ---- writing ----------------------------------------------------------------
    def _leaves(self, addr: str, value: Any) -> list[tuple[str, Any]]:
        """Expand a (possibly whole array / structure) write into validated leaf writes."""
        try:
            cur = self.db.get(addr)
        except Exception:
            raise TagStoreError("unknown", f"no tag {addr!r}") from None
        if isinstance(cur, list):
            if not isinstance(value, (list, tuple)) or len(value) != len(cur):
                raise TagStoreError("value", f"{addr} needs a list of {len(cur)} values")
            out = []
            elem = getattr(self.db, "elem_address", lambda a, k: f"{a}[{k}]")
            for i, v in enumerate(value):
                out += self._leaves(elem(addr, i), v)
            return out
        if isinstance(cur, dict):
            if not isinstance(value, dict) or set(value) - set(cur):
                raise TagStoreError("value", f"{addr} needs an object with members {sorted(cur)}")
            out = []
            for k, v in value.items():
                out += self._leaves(f"{addr}.{k}", v)
            return out
        dtype = self.db.data_type(addr)
        if dtype not in ATOMIC and dtype not in STRING_TYPES and not isinstance(cur, str):
            raise TagStoreError("type", f"{addr} has type {dtype} and cannot take a single value")
        if dtype in INT_RANGE and not isinstance(cur, str):
            _check_int_range(addr, dtype, value)
        v = _strict("STRING" if isinstance(cur, str) else dtype, value)
        m = self.meta(addr)
        if dtype in NUMERIC and ((m.min is not None and v < m.min) or (m.max is not None and v > m.max)):
            raise TagStoreError("range", f"{addr}={v} outside {m.min}..{m.max}")
        return [(addr, v)]

    def _running(self) -> bool:
        return bool(self.engine is not None and self.engine.running)

    def _canon(self, addr: str) -> str:
        canon = getattr(self.db, "canonical", None)
        try:
            return canon(addr) if canon is not None else addr
        except Exception:
            return addr

    def is_forced(self, addr: str) -> bool:
        """A force is installed on ``addr`` (or on a part containing it)."""
        if not self._forces:
            return False
        if addr not in self._forces:
            addr = self._canon(addr)
        if addr in self._forces:
            return True
        return any(addr.startswith(f) and addr[len(f):len(f) + 1] in (".", "[")
                   for f in self._forces)

    def is_force_active(self, addr: str) -> bool:
        """Installed and in effect (forces enabled)."""
        return self.forces_enabled and self.is_forced(addr)

    def set_forces_enabled(self, enabled: bool) -> None:
        """Enable or disable all I/O forces (controller level). Disabled forces
        stay installed but do not override logic or writes."""
        with self.lock:
            self.forces_enabled = bool(enabled)
            if self.forces_enabled:
                for leaf, v in self._forces.items():
                    try:
                        self.db.set(leaf, v)
                    except Exception:
                        pass
        self._notify("forces", None)

    def force_status(self) -> int:
        """GSV MODULE ForceStatus: bit 0 = forces installed, bit 1 = forces enabled."""
        return (1 if self._forces else 0) | (2 if self.forces_enabled else 0)

    def check(self, addr: str, value: Any, source: str = "api") -> list[tuple[str, Any]]:
        """Run every write check without writing; returns the validated leaf writes."""
        from .engine import BitMask
        external = not source.split(":")[0] in INTERNAL_SOURCES
        root = root_of(addr)
        if not self._has(root) and not addr.startswith("S:"):
            # SLC data tables etc. have no declarations: fall back to existence check
            try:
                self.db.get(addr)
            except Exception:
                raise TagStoreError("unknown", f"no tag {addr!r}") from None
        if external and self.access(addr) in ("ro", "none"):
            raise TagStoreError("readonly", f"{addr} is read-only (External Access "
                                            f"{'None' if self.access(addr) == 'none' else 'Read Only'})")
        caddr = self._canon(addr) if self._forces else addr
        with self.lock:
            forced = [a for a in self._forces if a == caddr or caddr.startswith(a + ".")
                      or caddr.startswith(a + "[") or a.startswith(caddr + ".")
                      or a.startswith(caddr + "[")] if self.forces_enabled else []
        if forced and source != "force":
            raise TagStoreError("forced", f"{addr} is forced ({forced[0]})")
        if isinstance(value, BitMask):
            return [(addr, value)]
        return self._leaves(addr, value)

    def write(self, addr: str, value: Any, source: str = "api") -> None:
        from .engine import BitMask
        leaves = self.check(addr, value, source)
        is_const = getattr(self.db, "is_constant", None)
        if is_const is not None and is_const(addr):     # recorded, like the controller log
            try:
                old = _display(self.db.get(addr))
            except Exception:
                old = None
            self.controller_log.append({"time": time.time(), "tag": addr, "old": old,
                                        "new": value, "source": source})
            del self.controller_log[:-200]
        stamp = (source, time.time())
        if self._running():
            for leaf, v in leaves:
                self.engine.queue_write(leaf, v)
        else:
            with self.lock:
                for leaf, v in leaves:
                    if isinstance(v, BitMask):
                        v = v.apply(self.db.get(leaf))
                    self.db.set(leaf, v)
        with self.lock:
            self._writers[addr] = stamp

    def write_many(self, values: dict[str, Any], source: str = "api") -> dict[str, str]:
        errors = {}
        for addr, v in values.items():
            try:
                self.write(addr, v, source=source)
            except TagStoreError as exc:
                errors[addr] = str(exc)
        return errors

    def last_write(self, addr: str) -> tuple[str, float] | None:
        return self._writers.get(addr)

    def can_fast_write(self, root: str) -> bool:
        """True when a tag has no forces and is read/write (CIP array fast path)."""
        return self.meta(root).access == "rw" and not any(
            root_of(a) == root for a in self._forces)

    # ---- forces -----------------------------------------------------------------
    def force(self, addr: str, value: Any, source: str = "ui") -> None:
        """Install a force. An alias forces its base tag; configuration data of an
        I/O module (Location:Slot:C) cannot be forced."""
        addr = self._canon(addr)
        if re.match(r"^[^.\[]*:C(?=$|[.\[])", addr):
            raise TagStoreError("value", f"{addr}: I/O configuration data cannot be forced")
        leaves = self._leaves(addr, value)
        with self.lock:
            # a force replaces any force on a part of the same address
            for k in [k for k in self._forces if k.startswith(addr + ".") or k.startswith(addr + "[")]:
                del self._forces[k]
            for leaf, v in leaves:
                self._forces[leaf] = v
                if self.forces_enabled:
                    self.db.set(leaf, v)
            self._writers[addr] = (f"force:{source}", time.time())

    def unforce(self, addr: str) -> None:
        addr = self._canon(addr)                 # removing an alias's force removes the base's
        with self.lock:
            for k in [k for k in self._forces if k == addr or k.startswith(addr + ".")
                      or k.startswith(addr + "[")]:
                del self._forces[k]

    def unforce_all(self) -> None:
        with self.lock:
            self._forces.clear()

    def forces(self) -> dict[str, Any]:
        return dict(self._forces)

    def apply_forces(self) -> None:
        if not self._forces or not self.forces_enabled:
            return
        with self.lock:
            for leaf, v in self._forces.items():
                try:
                    self.db.set(leaf, v)
                except Exception:
                    pass
