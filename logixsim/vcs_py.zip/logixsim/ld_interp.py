"""Parse and evaluate Logix ladder rung text.

Rung text is a series of instructions, e.g. ``XIC(Start)OTE(Run)``. Parallel
branches are ``[leg1,leg2,...]`` and OR together; each leg is itself a series
starting from the branch's incoming rung condition. Branches may nest.
Operand brackets (``arr[2]``) live inside parentheses and never collide with
branch brackets.
"""
from __future__ import annotations

import re

from .instructions import SPECS, UnsupportedInstruction
from .isa.core import MajorFault

_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
# instructions drawn on the input (left) side and highlighted by their own result
INPUT_INSTRUCTIONS = frozenset(n for n, s in SPECS.items() if s.input_like)
# instructions that use their operands when the rung is false (transitional ones,
# outputs that reset, timers/counters and CONTROL-based file instructions)
FALSE_RUNG_ACCESS = {"OTE", "ONS", "OSR", "OSF", "CTU", "CTD", "TON", "TOF", "RTO", "BSL", "BSR",
                     "FFL", "FFU", "LFL", "LFU", "SQO", "SQI", "SQL", "FAL", "FSC", "AVE",
                     "STD", "SRT", "CPS"}
_NO_RESOLVE = {"expr", "label", "routine", "imm", "elem"}   # elem: resolved per element


# --- parsing ----------------------------------------------------------
def parse_rung(text: str):
    """Return a series: list of ('instr', name, [args]) | ('branch', [series...])."""
    text = text.strip().rstrip(";").strip()
    pos = 0

    def parse_series(i):
        items = []
        while i < len(text):
            ch = text[i]
            if ch in "],":
                break
            if ch == "[":
                branch, i = parse_branch(i)
                items.append(branch)
            elif ch.isspace():
                i += 1
            else:
                instr, i = parse_instr(i)
                items.append(instr)
        return items, i

    def parse_branch(i):
        assert text[i] == "["
        i += 1
        legs = []
        while True:
            leg, i = parse_series(i)
            legs.append(leg)
            if i < len(text) and text[i] == ",":
                i += 1
                continue
            break
        if i < len(text) and text[i] == "]":
            i += 1
        return ("branch", legs), i

    def parse_instr(i):
        m = _NAME.match(text, i)
        if not m:
            raise SyntaxError(f"expected instruction at {text[i:i+12]!r}")
        name = m.group()                     # case kept (AOI names); matched case-insensitively
        i = m.end()
        args = []
        if i < len(text) and text[i] == "(":
            depth, start = 0, i + 1
            while i < len(text):
                c = text[i]
                if c == "(":
                    depth += 1
                elif c == ")":
                    depth -= 1
                    if depth == 0:
                        break
                i += 1
            raw = text[start:i]
            i += 1  # consume ')'
            args = _split_args(raw)
        return ("instr", name, args), i

    series, _ = parse_series(pos)
    return series


def _split_args(raw: str):
    args, depth, cur = [], 0, ""
    for c in raw:
        if c == "[":
            depth += 1
            cur += c
        elif c == "]":
            depth -= 1
            cur += c
        elif c == "," and depth == 0:
            args.append(cur.strip())
            cur = ""
        else:
            cur += c
    if cur.strip():
        args.append(cur.strip())
    return args


_PARSED: dict[str, list] = {}


def parsed(text: str):
    """parse_rung with a cache (rung text does not change while running)."""
    tree = _PARSED.get(text)
    if tree is None:
        tree = parse_rung(text)
        if len(_PARSED) < 20000:
            _PARSED[text] = tree
    return tree


def rung_tree(text: str) -> list[dict]:
    """JSON-friendly rung structure with instruction ids in evaluation order
    (the same order as the execution trace)."""
    counter = [0]

    def conv(series):
        out = []
        for item in series:
            if item[0] == "branch":
                out.append({"kind": "branch", "legs": [conv(leg) for leg in item[1]]})
            else:
                out.append({"kind": "instr", "id": counter[0], "name": item[1],
                            "args": list(item[2]), "input": item[1].upper() in INPUT_INSTRUCTIONS})
                counter[0] += 1
        return out
    return conv(parse_rung(text))


def instructions(text: str) -> list[tuple[str, list[str]]]:
    """Flat list of (name, args) in evaluation order."""
    out = []

    def walk(series):
        for item in series:
            if item[0] == "branch":
                for leg in item[1]:
                    walk(leg)
            else:
                out.append((item[1], item[2]))
    walk(parsed(text))
    return out


# --- evaluation -------------------------------------------------------
class LadderInterpreter:
    def eval_rung(self, ctx, text: str, trace: list | None = None, rung_in: bool = True) -> bool:
        """Evaluate one rung. Every instruction executes, whatever its
        rung-condition-in (1756-PM008). ``trace`` (optional) receives one highlight
        flag per instruction in evaluation order: for input instructions their own
        result (as Studio 5000 highlights an XIC whose bit is on), for outputs the
        rung condition that reached them. ``rung_in`` is false inside a disabled
        MCR zone."""
        return self._eval_series(ctx, parsed(text), rung_in, trace)

    def _eval_series(self, ctx, series, rung: bool, trace=None) -> bool:
        for item in series:
            if item[0] == "branch":
                legs = item[1]
                # evaluate every leg (side effects) then OR their outputs
                rung = any([self._eval_series(ctx, leg, rung, trace) for leg in legs])
            else:
                rung = self._eval_instr(ctx, item, rung, trace)
        return rung

    _PLAN: dict = {}

    @classmethod
    def _plan(cls, name: str, nargs: int):
        """(spec, per-operand 'resolve now' flags) for an instruction name/arity."""
        key = (name, nargs)
        plan = cls._PLAN.get(key)
        if plan is None:
            spec = SPECS.get(name.upper())
            if spec is None:
                flags = (True,) * nargs
            else:
                ops = spec.operands
                flags = tuple((ops[min(i, len(ops) - 1)].kind if ops else "src") not in _NO_RESOLVE
                              for i in range(nargs))
            plan = cls._PLAN[key] = (spec, flags)
        return plan

    def _eval_instr(self, ctx, item, rung: bool, trace=None) -> bool:
        _, orig, args = item
        spec, flags = self._plan(orig, len(args))
        if spec is None:
            aoi = _find_aoi(ctx, orig)
            if aoi is None:
                if trace is not None:
                    trace.append(False)
                raise UnsupportedInstruction(orig)
            out, hl = ctx.engine.call_aoi(ctx, aoi, [ctx.resolve(a) for a in args], rung)
        elif not rung and spec.mnemonic not in FALSE_RUNG_ACCESS:
            # On a false rung most instructions do nothing with their operands, so an
            # out-of-range subscript there is not a fault; transitional instructions
            # and those that act on a false rung still check (1756-PM004, Array
            # Subscript Out of Range)
            try:
                res = [ctx.resolve(a) if f else a for a, f in zip(args, flags)]
                out, hl = spec.run(ctx, res, rung)
            except MajorFault as exc:
                if exc.code not in (20, 83):
                    raise
                out, hl = False, False
        else:
            res = [ctx.resolve(a) if f else a for a, f in zip(args, flags)]
            out, hl = spec.run(ctx, res, rung)
        if trace is not None:
            trace.append(hl)
        return out


def _find_aoi(ctx, name: str):
    eng = getattr(ctx, "engine", None)
    if eng is None:
        return None
    aois = eng.controller.aois
    if name in aois:
        return aois[name]
    up = name.upper()
    for n, a in aois.items():
        if n.upper() == up:
            return a
    return None
