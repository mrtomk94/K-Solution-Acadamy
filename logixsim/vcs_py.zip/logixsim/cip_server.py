"""EtherNet/IP (CIP) server for a virtual 1756 chassis.

Encapsulation layer:
  Register/Unregister Session (0x65/0x66), List Identity (0x63),
  List Services (0x04), SendRRData (0x6F, unconnected), SendUnitData (0x70,
  connected Class 3).

Connection Manager (class 0x06, instance 1), as a 1756-EN2T would route it:
  Unconnected Send (0x52)  -> backplane port 1, link = slot -> that controller
  Forward Open (0x54) / Large Forward Open (0x5B) -> Class 3 connection
  Forward Close (0x4E)

Everything that reaches a controller is answered by its MessageRouter
(cip_router.py). Requests sent without a route (Phase 1 style) go to the
lowest occupied slot so older clients keep working.
"""
from __future__ import annotations

import os
import re
import socket
import struct
import threading
from dataclasses import dataclass

from .chassis import Chassis
from .cip_router import (
    CLS_IDENTITY, SVC_GET_ALL, PACK, TYPE_CODE, CIPError, MessageRouter, OK, NOT_SUPPORTED, NOT_ENOUGH_DATA,
    PATH_SEG_ERR, PATH_UNKNOWN, decode_path, reply,
)

REGISTER, UNREGISTER, LISTID, SENDRR = 0x0065, 0x0066, 0x0063, 0x006F
SENDUNIT, LISTSERVICES = 0x0070, 0x0004

ENCAP_OK, ENCAP_BAD_COMMAND, ENCAP_BAD_DATA, ENCAP_BAD_SESSION = 0x0, 0x1, 0x3, 0x64

CLS_CONN_MGR = 0x06
SVC_UNCONNECTED_SEND, SVC_FWD_OPEN, SVC_LARGE_FWD_OPEN, SVC_FWD_CLOSE = 0x52, 0x54, 0x5B, 0x4E
CONN_FAILURE = 0x01
EXT_OUT_OF_CONNECTIONS, EXT_CONN_NOT_FOUND, EXT_LINK_INVALID = 0x0113, 0x0107, 0x0312
UNCONNECTED_SIZE = 504
MAX_CONNECTIONS = 128               # whole chassis
MAX_CONNECTIONS_PER_SESSION = 32    # one client can't lock the others out

# client-helper type table (type code -> struct format), kept for tests / scripts
_PACK = {TYPE_CODE[t]: fmt for t, fmt in PACK.items()}


def _enc_header(command, length, session, ctx, status=0):
    return struct.pack("<HHII8sI", command, length, session, status, ctx, 0)


@dataclass
class Connection:
    slot: int
    o_t_id: int            # ours: client puts it in SendUnitData address item
    t_o_id: int            # client's: we put it in our replies
    size: int
    key: tuple             # (connection serial, vendor id, originator serial)
    session: int


def _parse_cpf(body: bytes) -> dict[int, bytes]:
    """Common Packet Format -> {item type: data} (after iface handle + timeout)."""
    off = 6
    count = struct.unpack_from("<H", body, off)[0]
    off += 2
    items = {}
    for _ in range(count):
        tid, ilen = struct.unpack_from("<HH", body, off)
        off += 4
        items[tid] = body[off:off + ilen]
        off += ilen
    return items


def split_route(path: bytes) -> tuple[list[tuple[int, bytes]], bytes]:
    """Strip leading port segments: returns ([(port, link bytes)], remaining path).

    Only backplane hops (port 1, one-byte link = slot) matter for a chassis;
    extended links (e.g. an IP string for port 2) are returned raw.
    """
    hops, i = [], 0
    while i < len(path) and (path[i] & 0xE0) == 0:
        seg = path[i]
        if seg & 0x10:                          # extended link address
            ln = path[i + 1]
            hops.append((seg & 0x0F, path[i + 2:i + 2 + ln]))
            i += 2 + ln + (ln & 1)
        else:
            hops.append((seg & 0x0F, path[i + 1:i + 2]))
            i += 2
    return hops, path[i:]


class CIPServer:
    def __init__(self, target, host="127.0.0.1", port=44818,
                 max_connections: int = MAX_CONNECTIONS):
        self.chassis = target if isinstance(target, Chassis) else Chassis.single(target)
        default = self.chassis.default_slot()
        self.engine = self.chassis.get(default) if default is not None else None
        self.routers = {s: MessageRouter(self.chassis.get(s), self.chassis.identity(s))
                        for s in self.chassis.slots()}
        self.host, self.port = host, port
        self.max_connections = max_connections
        self.connections: dict[int, Connection] = {}
        self._sessions: set[int] = set()
        self._lock = threading.Lock()
        self._sock: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._session = 0

    # ---- lifecycle ---------------------------------------------------
    def start(self) -> int:
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.host, self.port))
        self.port = self._sock.getsockname()[1]
        self._sock.listen(16)
        self._sock.settimeout(0.3)
        self._stop.clear()
        self._thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._thread.start()
        return self.port

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=1.0)
        if self._sock:
            self._sock.close()

    def _accept_loop(self) -> None:
        while not self._stop.is_set():
            try:
                conn, _ = self._sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._serve, args=(conn,), daemon=True).start()

    # ---- per-socket handling -----------------------------------------
    def _serve(self, conn: socket.socket) -> None:
        conn.settimeout(0.5)
        owned: set[int] = set()
        local_ip = conn.getsockname()[0]
        try:
            with conn:
                while not self._stop.is_set():
                    header = self._recv_exact(conn, 24)
                    if header is None:
                        return
                    command, length, session, _st, ctx, _opts = \
                        struct.unpack("<HHII8sI", header)
                    body = self._recv_exact(conn, length) if length else b""
                    if body is None:
                        return
                    reply_bytes = self._dispatch(command, session, ctx, body, local_ip, owned)
                    if reply_bytes:
                        conn.sendall(reply_bytes)
        except OSError:
            pass
        finally:
            with self._lock:
                for sid in owned:
                    self._sessions.discard(sid)
                for cid in [c for c, v in self.connections.items() if v.session in owned]:
                    del self.connections[cid]

    def _recv_exact(self, conn, n):
        """Read n bytes; None when the peer closes or the server stops."""
        buf = b""
        while len(buf) < n:
            try:
                chunk = conn.recv(n - len(buf))
            except socket.timeout:
                if self._stop.is_set():
                    return None
                continue
            if not chunk:
                return None
            buf += chunk
        return buf

    def _dispatch(self, command, session, ctx, body, local_ip="0.0.0.0", owned=None) -> bytes:
        if command == REGISTER:
            with self._lock:
                self._session += 1
                sid = self._session
                self._sessions.add(sid)
            if owned is not None:
                owned.add(sid)
            data = struct.pack("<HH", 1, 0)
            return _enc_header(REGISTER, len(data), sid, ctx) + data
        if command == UNREGISTER:
            with self._lock:
                self._sessions.discard(session)
                for cid in [c for c, v in self.connections.items() if v.session == session]:
                    del self.connections[cid]
            return b""
        if command == LISTID:
            return self._list_identity(ctx, local_ip)
        if command == LISTSERVICES:
            item = struct.pack("<HH", 1, 0x0120) + b"Communications\x00\x00"
            data = struct.pack("<HHH", 1, 0x0100, len(item)) + item
            return _enc_header(LISTSERVICES, len(data), 0, ctx) + data
        if command in (SENDRR, SENDUNIT):
            if session not in self._sessions:
                return _enc_header(command, 0, session, ctx, status=ENCAP_BAD_SESSION)
            try:
                items = _parse_cpf(body)
            except struct.error:
                return _enc_header(command, 0, session, ctx, status=ENCAP_BAD_DATA)
            if command == SENDRR:
                resp = self._unconnected(items.get(0x00B2, b""), session)
                cpf = (struct.pack("<IHH", 0, 0, 2) + struct.pack("<HH", 0x0000, 0)
                       + struct.pack("<HH", 0x00B2, len(resp)) + resp)
                return _enc_header(SENDRR, len(cpf), session, ctx) + cpf
            return self._send_unit(items, session, ctx)
        return _enc_header(command, 0, session, ctx, status=ENCAP_BAD_COMMAND)

    # ---- identity ------------------------------------------------------
    def _comms_identity_bytes(self) -> bytes:
        """Identity attributes of the chassis' Ethernet module (1756-EN2T)."""
        return self.chassis.comms_identity.encode(b"\x30\x00")

    def _list_identity(self, ctx, local_ip) -> bytes:
        try:
            ip = socket.inet_aton(local_ip)
        except OSError:
            ip = b"\x00\x00\x00\x00"
        item = (struct.pack("<H", 1)                                  # encap version
                + struct.pack(">hH4s8x", 2, self.port, ip)            # socket address
                + self._comms_identity_bytes() + b"\x03")            # state: operational
        payload = struct.pack("<HHH", 1, 0x000C, len(item)) + item
        return _enc_header(LISTID, len(payload), 0, ctx) + payload

    # ---- unconnected (UCMM) --------------------------------------------
    def _unconnected(self, cip: bytes, session: int) -> bytes:
        if len(cip) < 2:
            return reply(cip[0] if cip else 0, PATH_SEG_ERR)
        service, plen = cip[0], cip[1] * 2
        path, data = cip[2:2 + plen], cip[2 + plen:]
        try:
            segs = decode_path(path)
        except CIPError:
            segs = []
        if segs[:2] == [("class", CLS_CONN_MGR), ("instance", 1)]:
            try:
                if service == SVC_UNCONNECTED_SEND:
                    return self._unconnected_send(data)
                if service in (SVC_FWD_OPEN, SVC_LARGE_FWD_OPEN):
                    return self._forward_open(service, data, session)
                if service == SVC_FWD_CLOSE:
                    return self._forward_close(data)
            except (struct.error, IndexError):
                return reply(service, NOT_ENOUGH_DATA)
            return reply(service, NOT_SUPPORTED)
        if segs[:2] == [("class", CLS_IDENTITY), ("instance", 1)] and service == SVC_GET_ALL:
            return reply(service, OK, self._comms_identity_bytes())   # the EN2T itself
        slot = self.chassis.default_slot()
        if slot is None:
            return reply(service, PATH_UNKNOWN)
        return self.routers[slot].handle(cip, UNCONNECTED_SIZE)

    def _slot_from_route(self, route: bytes) -> tuple[int | None, bytes]:
        hops, rest = split_route(route)
        for port, link in hops:
            if port == 1 and len(link) == 1:
                return link[0], rest
        return (self.chassis.default_slot() if not hops else None), rest

    def _unconnected_send(self, data: bytes) -> bytes:
        msg_len = struct.unpack_from("<H", data, 2)[0]
        msg = data[4:4 + msg_len]
        off = 4 + msg_len + (msg_len & 1)
        route_words = data[off]
        route = data[off + 2:off + 2 + route_words * 2]
        slot, _ = self._slot_from_route(route)
        if slot not in self.routers:
            return reply(SVC_UNCONNECTED_SEND, CONN_FAILURE, ext=EXT_LINK_INVALID)
        return self.routers[slot].handle(msg, UNCONNECTED_SIZE)

    def _forward_open(self, service: int, data: bytes, session: int) -> bytes:
        large = service == SVC_LARGE_FWD_OPEN
        p = 2
        _o_t_id, t_o_id, serial, vendor, orig = struct.unpack_from("<IIHHI", data, p)
        p += 16 + 4                                   # ids/serials + multiplier/reserved
        pfmt, psize = ("<I", 4) if large else ("<H", 2)
        o_t_rpi = struct.unpack_from("<I", data, p)[0]
        o_t_params = struct.unpack_from(pfmt, data, p + 4)[0]
        p += 4 + psize
        t_o_rpi = struct.unpack_from("<I", data, p)[0]
        p += 4 + psize + 1                            # T->O RPI + params + transport
        path_words = data[p]
        route = data[p + 1:p + 1 + path_words * 2]
        slot, rest = self._slot_from_route(route)
        if slot not in self.routers:
            return reply(service, CONN_FAILURE, ext=EXT_LINK_INVALID)
        size = o_t_params & (0xFFFF if large else 0x01FF)
        key = (serial, vendor, orig)
        with self._lock:
            for cid, c in list(self.connections.items()):
                if c.key == key:                      # duplicate FO: replace
                    del self.connections[cid]
            mine = sum(1 for c in self.connections.values() if c.session == session)
            if (len(self.connections) >= self.max_connections
                    or mine >= MAX_CONNECTIONS_PER_SESSION):
                return reply(service, CONN_FAILURE, ext=EXT_OUT_OF_CONNECTIONS)
            o_t_id = struct.unpack("<I", os.urandom(4))[0] or 1
            while o_t_id in self.connections:
                o_t_id = (o_t_id + 1) & 0xFFFFFFFF or 1
            self.connections[o_t_id] = Connection(slot, o_t_id, t_o_id, size, key, session)
        body = struct.pack("<IIHHIIIBB", o_t_id, t_o_id, serial, vendor, orig,
                           o_t_rpi, t_o_rpi, 0, 0)
        return reply(service, OK, body)

    def _forward_close(self, data: bytes) -> bytes:
        serial, vendor, orig = struct.unpack_from("<HHI", data, 2)
        key = (serial, vendor, orig)
        with self._lock:
            found = [cid for cid, c in self.connections.items() if c.key == key]
            for cid in found:
                del self.connections[cid]
        if not found:
            return reply(SVC_FWD_CLOSE, CONN_FAILURE, ext=EXT_CONN_NOT_FOUND)
        return reply(SVC_FWD_CLOSE, OK, struct.pack("<HHIBB", serial, vendor, orig, 0, 0))

    # ---- connected (Class 3) -----------------------------------------------
    def _send_unit(self, items: dict, session: int, ctx: bytes) -> bytes:
        addr, data = items.get(0x00A1, b""), items.get(0x00B1, b"")
        if len(addr) != 4 or len(data) < 2:
            return _enc_header(SENDUNIT, 0, session, ctx, status=ENCAP_BAD_DATA)
        conn = self.connections.get(struct.unpack("<I", addr)[0])
        if conn is None or conn.session != session:
            return _enc_header(SENDUNIT, 0, session, ctx, status=ENCAP_BAD_DATA)
        seq, cip = data[:2], data[2:]
        resp = seq + self.routers[conn.slot].handle(cip, conn.size)
        cpf = (struct.pack("<IHH", 0, 0, 2) + struct.pack("<HHI", 0x00A1, 4, conn.t_o_id)
               + struct.pack("<HH", 0x00B1, len(resp)) + resp)
        return _enc_header(SENDUNIT, len(cpf), session, ctx) + cpf


# --- client-side helpers used by tests (craft raw frames) -------------
def register_session(sock) -> int:
    data = struct.pack("<HH", 1, 0)
    sock.sendall(_enc_header(REGISTER, len(data), 0, b"\x00" * 8) + data)
    hdr = sock.recv(24)
    _, length, session, *_ = struct.unpack("<HHII8sI", hdr)
    sock.recv(length)
    return session


def _symbolic_path(addr: str) -> bytes:
    path = b""
    for tok in re.findall(r"[A-Za-z_][A-Za-z0-9_]*|\[\d+\]", addr):
        if tok.startswith("["):
            idx = int(tok[1:-1])
            path += struct.pack("<BB", 0x28, idx) if idx < 256 \
                else struct.pack("<BBH", 0x29, 0, idx)
        else:
            b = tok.encode("ascii")
            path += struct.pack("<BB", 0x91, len(b)) + b
            if len(b) & 1:
                path += b"\x00"
    return path


def _sendrr(sock, cip: bytes, session: int) -> bytes:
    cpf = (struct.pack("<H", 2)
           + struct.pack("<HH", 0x0000, 0)
           + struct.pack("<HH", 0x00B2, len(cip)) + cip)
    data = struct.pack("<IH", 0, 0) + cpf
    sock.sendall(_enc_header(SENDRR, len(data), session, b"\x00" * 8) + data)
    hdr = sock.recv(24)
    _, length, *_ = struct.unpack("<HHII8sI", hdr)
    body = b""
    while len(body) < length:
        body += sock.recv(length - len(body))
    return _parse_cpf(body).get(0x00B2, b"")


def read_tag(sock, addr: str, session: int):
    path = _symbolic_path(addr)
    cip = struct.pack("<BB", 0x4C, len(path) // 2) + path + struct.pack("<H", 1)
    resp = _sendrr(sock, cip, session)
    status = resp[2]
    if status != 0:
        raise IOError(f"read status {status}")
    code = struct.unpack_from("<H", resp, 4)[0]
    return struct.unpack_from(_PACK[code], resp, 6)[0]


def write_tag(sock, addr: str, type_name: str, value, session: int):
    path = _symbolic_path(addr)
    code = TYPE_CODE[type_name]
    payload = struct.pack("<H", code) + struct.pack("<H", 1) + \
        struct.pack(_PACK[code], value)
    cip = struct.pack("<BB", 0x4D, len(path) // 2) + path + payload
    resp = _sendrr(sock, cip, session)
    return resp[2] == 0
