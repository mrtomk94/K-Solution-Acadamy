"""Virtual 1756 chassis: soft controllers in numbered slots behind one IP.

Like FactoryTalk Logix Echo's virtual chassis, a client reaches a controller
with a CIP route path (backplane port 1, link = slot). Each slot answers with
its own ControlLogix-style identity.

JSON config::

    {"name": "Line1",
     "slots": [
       {"slot": 0, "l5x": "Line1.L5X", "autostart": true},
       {"slot": 2, "l5x": "AGV.L5X", "product_name": "1756-L83E/B",
        "revision": "32.012", "serial": "00c0ffee"}]}

Relative ``l5x`` paths resolve against the config file's folder.
"""
from __future__ import annotations

import json
import os
import struct
import zlib
from dataclasses import dataclass

from .engine import Engine
from .l5x_loader import load_file

MAX_SLOT = 16

# Defaults are typical values, not verified against a physical module.
L85E_PRODUCT_CODE = 168
EN2T_PRODUCT_CODE = 166


class ChassisError(ValueError):
    pass


@dataclass
class SlotIdentity:
    """CIP Identity object (class 0x01) attributes reported for a module."""
    vendor: int = 1                       # Rockwell Automation/Allen-Bradley
    product_type: int = 0x0E              # Programmable Logic Controller
    product_code: int = L85E_PRODUCT_CODE
    revision: tuple[int, int] = (33, 11)
    serial: int = 0x00C0FF00
    product_name: str = "1756-L85E/B"

    def validate(self) -> None:
        major, minor = self.revision
        if not (0 <= major <= 255 and 0 <= minor <= 255):
            raise ChassisError(f"revision {major}.{minor} out of range (0-255 each)")
        if not 0 <= self.product_code <= 0xFFFF:
            raise ChassisError(f"product_code {self.product_code} out of range")
        if not 0 <= self.serial <= 0xFFFFFFFF:
            raise ChassisError(f"serial 0x{self.serial:x} out of range (32-bit)")
        if not self.product_name.isascii() or len(self.product_name) > 32:
            raise ChassisError("product_name must be ASCII, at most 32 characters")

    def encode(self, status: bytes) -> bytes:
        """Identity Get Attributes All layout (also used inside List Identity)."""
        name = self.product_name.encode("ascii")
        return (struct.pack("<HHHBB", self.vendor, self.product_type,
                            self.product_code, *self.revision)
                + status + struct.pack("<I", self.serial) + bytes([len(name)]) + name)


def _serial_for(chassis_name: str, slot: int) -> int:
    return zlib.crc32(f"{chassis_name}/{slot}".encode()) & 0xFFFFFFFF


def _parse_revision(text) -> tuple[int, int]:
    major, _, minor = str(text).partition(".")
    return int(major), int(minor or 0)


class Chassis:
    def __init__(self, name: str = "VirtualControlStudio"):
        self.name = name
        self._slots: dict[int, Engine] = {}
        self._ident: dict[int, SlotIdentity] = {}
        self.autostart: dict[int, bool] = {}
        self.comms_identity = SlotIdentity(
            product_type=0x0C, product_code=EN2T_PRODUCT_CODE,
            revision=(11, 1), serial=_serial_for(name, 99),
            product_name="1756-EN2T/D")

    @classmethod
    def single(cls, engine: Engine, slot: int = 0) -> "Chassis":
        ch = cls()
        ch.add(slot, engine)
        return ch

    def add(self, slot: int, engine: Engine, identity: SlotIdentity | None = None,
            autostart: bool = False) -> None:
        if not isinstance(slot, int) or not 0 <= slot <= MAX_SLOT:
            raise ChassisError(f"slot must be 0..{MAX_SLOT}, got {slot!r}")
        if slot in self._slots:
            raise ChassisError(f"slot {slot} already occupied")
        self._slots[slot] = engine
        self._ident[slot] = identity or SlotIdentity(serial=_serial_for(self.name, slot))
        self.autostart[slot] = autostart

    def get(self, slot: int) -> Engine | None:
        return self._slots.get(slot)

    def identity(self, slot: int) -> SlotIdentity:
        return self._ident[slot]

    def slots(self) -> list[int]:
        return sorted(self._slots)

    def default_slot(self) -> int | None:
        s = self.slots()
        return s[0] if s else None

    def start_all(self, only_autostart: bool = False) -> None:
        for slot, eng in self._slots.items():
            if not only_autostart or self.autostart.get(slot):
                eng.start()

    def stop_all(self) -> None:
        for eng in self._slots.values():
            eng.stop()

    def describe(self) -> dict:
        return {"name": self.name, "slots": [
            {"slot": s, "controller": self._slots[s].controller.name,
             "running": self._slots[s].running,
             "product_name": self._ident[s].product_name,
             "revision": "%d.%03d" % self._ident[s].revision}
            for s in self.slots()]}


def load_chassis_config(path: str) -> Chassis:
    try:
        with open(path, encoding="utf-8") as fh:
            cfg = json.load(fh)
    except (OSError, ValueError) as exc:
        raise ChassisError(f"cannot read chassis config {path}: {exc}") from exc
    base = os.path.dirname(os.path.abspath(path))
    ch = Chassis(name=str(cfg.get("name", "VirtualControlStudio")))
    for entry in cfg.get("slots", []):
        if not isinstance(entry, dict):
            raise ChassisError(f"slot entries must be objects, got {entry!r}")
        slot = entry.get("slot")
        try:
            _add_slot(ch, base, slot, entry)
        except ChassisError:
            raise
        except Exception as exc:              # bad values or an unreadable L5X
            raise ChassisError(f"slot {slot}: {exc}") from exc
    if not ch.slots():
        raise ChassisError("chassis config has no slots")
    return ch


def _add_slot(ch: Chassis, base: str, slot, entry: dict) -> None:
    l5x = entry.get("l5x")
    if not l5x:
        raise ChassisError(f"slot {slot}: missing 'l5x'")
    l5x_path = l5x if os.path.isabs(l5x) else os.path.join(base, l5x)
    if not os.path.isfile(l5x_path):
        raise ChassisError(f"slot {slot}: file not found: {l5x_path}")
    if slot in ch.slots():
        raise ChassisError(f"slot {slot} listed twice")
    ident = SlotIdentity(serial=_serial_for(ch.name, slot if isinstance(slot, int) else 0))
    if "product_name" in entry:
        ident.product_name = str(entry["product_name"])
    if "product_code" in entry:
        ident.product_code = int(entry["product_code"])
    if "revision" in entry:
        ident.revision = _parse_revision(entry["revision"])
    if "serial" in entry:
        ident.serial = int(str(entry["serial"]), 16)
    ident.validate()
    ch.add(slot, Engine(load_file(l5x_path)), ident,
           autostart=bool(entry.get("autostart", False)))
