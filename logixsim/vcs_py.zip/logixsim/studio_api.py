"""Studio API: what the Studio-style engineering UI needs on top of protocol v1.

    POST /api/studio/import            body = .L5X file -> replaces the running program
    GET  /api/studio/project           controller organizer (tasks/programs/routines, types, AOIs, I/O)
    GET  /api/studio/tags?scope=       controller or program tags with descriptions/aliases
    GET  /api/studio/routine?program=&routine=   rungs (text, comment, instruction tree) or ST text
    GET  /api/studio/trace?program=&routine=     per-instruction highlight flags from the last scan
    GET  /api/studio/verify            what VirtualControlStudio can / cannot execute in this project
    GET  /api/studio/datatype?name=    members of a data type
    GET  /api/studio/timers            all TIMER / COUNTER tags with PRE/ACC/status bits
    GET  /api/studio/faults            fault log, major fault, minor faults
    GET  /api/studio/instructions      instruction metadata (operands, display, notes) + catalog
    GET  /api/studio/diagnostics       task statistics, status flags, watchdog
Values themselves stream over the v1 WebSocket (/api/v1/ws).
A routine inside an Add-On Instruction is addressed as program ``AOI:<name>``.

Editing (validation service: validation.py, finalize service: editing.py):
    POST /api/studio/validate/rung     {program, routine, text, index?, inserting?}
    POST /api/studio/validate/st       {program, routine, text}
    POST /api/studio/edit/rung         {program, routine, op, index, text?, comment?, to?, version}
    POST /api/studio/edit/st           {program, routine, text, version}
    POST /api/studio/edit/undo         {program, routine, version}
    GET  /api/studio/edit/log          applied edits (with the scan they took effect)
    GET  /api/studio/tagnames?program= every tag/member address usable in that program
    GET  /api/studio/export            the imported L5X with edited routines written back
"""
from __future__ import annotations

import os
import re

from fastapi import APIRouter, FastAPI, Request
from fastapi.responses import JSONResponse

from .ld_interp import rung_tree
from .model import ATOMIC, PREDEFINED, STRING_TYPES
from .verify import format_report, verify

MAX_L5X = 50 * 1024 * 1024


_ACCESS_TEXT = {"rw": "Read/Write", "ro": "Read Only", "none": "None"}
_LIMITS = {"SINT": (-128, 127), "INT": (-32768, 32767), "DINT": (-2147483648, 2147483647),
           "LINT": (-9223372036854775808, 9223372036854775807), "REAL": (-3.402823e38, 3.402823e38),
           "USINT": (0, 255), "UINT": (0, 65535), "UDINT": (0, 4294967295), "ULINT": (0, 18446744073709551615),
           "LREAL": (-1.7976931348623157e308, 1.7976931348623157e308)}


def _not_found(msg: str) -> JSONResponse:
    return JSONResponse({"error": msg}, status_code=404)


def _projects_folder() -> str:
    from .project import projects_dir
    return projects_dir()


def mount_studio(app: FastAPI, emu) -> None:
    r = APIRouter(prefix="/api/studio")

    def ctrl():
        return emu.engine.controller

    def decl_description(name: str) -> str:
        meta = emu.store.meta(name)
        if meta.description:
            return meta.description
        try:
            return emu.engine.db.declaration(name).description or ""
        except Exception:
            return ""

    @r.post("/import")
    async def import_l5x(request: Request):
        from .l5x_loader import load_string
        raw = await request.body()
        if len(raw) > MAX_L5X:
            return JSONResponse({"error": f"file larger than {MAX_L5X // (1024 * 1024)} MB"},
                                status_code=413)
        try:
            controller = load_string(raw)
        except Exception as exc:
            return JSONResponse({"error": f"not a readable L5X: {exc}"}, status_code=400)
        name = request.headers.get("x-filename") or None
        emu.load_controller(controller, logic_file=name, source=raw)
        report = verify(controller)
        return {"ok": True, "controller": controller.name, "verify": report,
                "text": format_report(report)}

    @r.get("/project")
    def project():
        c = ctrl()
        scheduled = {p for t in c.tasks for p in t["programs"]}

        def prog_info(pname):
            p = c.programs[pname]
            return {"name": pname, "description": p.description, "main": p.main,
                    "disabled": p.disabled, "tags": len(p.tags),
                    "routines": [{"name": n, "type": rt.rtype, "main": n == p.main,
                                  "simulated": rt.rtype in ("RLL", "ST"),
                                  "rungs": len(rt.rungs) if rt.rtype == "RLL" else None}
                                 for n, rt in p.routines.items()]}
        tasks = [{"name": t["name"], "type": t["type"], "rate_ms": t["rate_ms"],
                  "priority": t.get("priority"), "watchdog_ms": t.get("watchdog_ms"),
                  "inhibited": bool(t.get("inhibited")),
                  "programs": [prog_info(p) for p in t["programs"] if p in c.programs]}
                 for t in c.tasks]
        if not tasks and c.programs:                       # projects without a <Tasks> section
            tasks = [{"name": "MainTask", "type": "CONTINUOUS", "rate_ms": None,
                      "programs": [prog_info(p) for p in c.task_order]}]
            scheduled = set(c.task_order)
        module_types = {m for m in c.data_types if ":" in m}
        from . import __version__
        from . import APP_EDITION
        return {
            "version": __version__,
            "edition": APP_EDITION,
            "project_version": getattr(emu.engine, "project_version", 0),
            "dirty": emu.dirty,
            "project_file": os.path.basename(emu.project_path) if emu.project_path else None,
            "projects_folder": _projects_folder(),
            "authoring": bool(getattr(emu.engine, "authoring", False)),
            "watch": list(emu.settings.get("watch") or []),
            # alias -> the address it stands for (chains and program scope resolved), so
            # the UI shows and forces an alias through its base tag
            "aliases": {a: emu.engine.db.canonical(a) for a in c.aliases},
            "controller": {"name": c.name, "processor": c.processor, "revision": c.revision,
                           "description": c.description, "file": emu.logic_file},
            "state": emu.state(),
            "tasks": tasks,
            "unscheduled": [prog_info(p) for p in c.programs if p not in scheduled],
            "data_types": {"user": sorted(n for n in c.data_types if n not in module_types
                                          and getattr(c.data_types[n], "family", None) != "StringFamily"),
                           "strings": sorted(n for n in c.data_types
                                             if getattr(c.data_types[n], "family", None) == "StringFamily"),
                           "module": sorted(module_types),
                           "predefined": sorted(PREDEFINED) + sorted(ATOMIC)
                                         + sorted(t for t in STRING_TYPES if t not in c.data_types),
                           "runtime": sorted(n for n in emu.store.types()
                                           if n not in c.data_types and n not in c.aois)},
            "aois": [{"name": a.name, "description": a.description, "revision": a.revision,
                      "params": [{"name": m.name, "type": m.data_type} for m in a.params],
                      "parameters": [{"name": p.name, "type": p.data_type, "usage": p.usage,
                                      "required": p.required, "visible": p.visible,
                                      "description": p.description} for p in a.parameters],
                      "call": [p.name for p in a.call_params()],
                      "local_tags": [{"name": p.name, "type": p.data_type} for p in a.local_tags],
                      "routines": [{"name": n, "type": rt.rtype,
                                    "simulated": rt.rtype in ("RLL", "ST"),
                                    "rungs": len(rt.rungs) if rt.rtype == "RLL" else None}
                                   for n, rt in a.routines.items()]}
                     for a in c.aois.values()],
            "modules": c.modules,
        }

    @r.get("/tags")
    def tags(scope: str = "controller"):
        db = emu.engine.db
        out = []
        prefix = f"Program:{scope}."
        for d in emu.store.definitions():
            addr = d["name"]
            if scope == "controller":
                if addr.startswith("Program:"):
                    continue
                name = addr
            else:
                if not addr.startswith(prefix):
                    continue
                name = addr[len(prefix):]
            try:
                decl = db.declaration(addr)
            except Exception:
                decl = None
            out.append({"name": name, "address": addr, "type": d["type"], "dim": d["dim"],
                        "dims": d.get("dims", []),
                        "description": decl_description(addr), "access": d["access"],
                        "external_access": _ACCESS_TEXT.get(d["access"], "Read/Write"),
                        "constant": bool(getattr(decl, "constant", False)),
                        "units": d["units"], "min": d.get("min"), "max": d.get("max"),
                        "state0": d.get("state0", ""), "state1": d.get("state1", ""),
                        "style": getattr(decl, "radix", "") or "",
                        "alias_for": None})
        for alias, target in sorted(ctrl().aliases.items()):
            in_scope = alias.startswith(prefix) if scope != "controller" else not alias.startswith("Program:")
            if not in_scope:
                continue
            try:
                atype = db.data_type(target)
            except Exception:
                atype = "?"
            try:                               # an alias has its target's access and constant
                acc = emu.engine.store.access(alias)
                const = db.is_constant(alias)
            except Exception:
                acc, const = "rw", False
            out.append({"name": alias[len(prefix):] if scope != "controller" else alias,
                        "address": alias, "type": atype, "dim": 0,
                        "description": ctrl().alias_descriptions.get(alias, ""),
                        "access": acc, "external_access": _ACCESS_TEXT.get(acc, "Read/Write"),
                        "constant": const, "units": "", "alias_for": target,
                        "alias_for_address": db.dealias(alias)})
        return {"scope": scope, "tags": out}

    def _routine(program: str, routine: str):
        if program.startswith("AOI:"):
            a = ctrl().aois.get(program[4:])
            return a.routines.get(routine) if a else None
        p = ctrl().programs.get(program)
        return p.routines.get(routine) if p else None

    @r.get("/routine")
    def routine(program: str, routine: str):
        rt = _routine(program, routine)
        if rt is None:
            return _not_found(f"no routine {program}/{routine}")
        base = {"program": program, "routine": routine, "type": rt.rtype,
                "simulated": rt.rtype in ("RLL", "ST"), "description": rt.description,
                "version": rt.version, "modified": rt.modified,
                "editable": not program.startswith("AOI:") and rt.rtype in ("RLL", "ST"),
                "undo": len(emu.engine.edit_history.get((program, routine), [])),
                "redo": len(getattr(emu.engine, "redo_history", {}).get((program, routine), []))}
        if rt.rtype == "RLL":
            rungs = []
            for n, text in enumerate(rt.rungs):
                try:
                    tree, err = rung_tree(text), None
                except Exception as exc:
                    tree, err = [], str(exc)
                rungs.append({"n": n, "text": text, "comment": rt.comments.get(n, ""),
                              "tree": tree, "error": err})
            base["rungs"] = rungs
        elif rt.rtype == "ST":
            base["text"] = rt.text
        return base

    @r.get("/routine/version")
    def routine_version(program: str, routine: str):
        """Cheap check for another window: the routine's edit version."""
        rt = _routine(program, routine)
        if rt is None:
            return _not_found(f"no routine {program}/{routine}")
        return {"program": program, "routine": routine, "version": rt.version, "modified": rt.modified}

    @r.get("/trace")
    def trace(program: str, routine: str):
        eng = emu.engine
        return {"program": program, "routine": routine, "scan_count": eng.scan_count,
                "mode": eng.mode, "rungs": eng.trace.get((program, routine), []),
                "errors": {str(k): v for k, v in
                           eng.instr_errors.get((program, routine), {}).items()}}

    @r.get("/verify")
    def verify_project():
        report = verify(ctrl(), store=emu.engine.store)
        report["text"] = format_report(report)
        return report

    @r.get("/datatype")
    def datatype(name: str):
        from .model import STRING_TYPES, string_max
        types = emu.engine.db.types()
        hit = name if name in types else next((n for n in types if n.lower() == name.lower()), None)
        if hit is None:
            st = next((n for n in STRING_TYPES if n.lower() == name.lower()), None)
            if st:                                   # string types: LEN + DATA[n]
                return {"name": st, "predefined": True, "string": True, "description": "",
                        "members": [{"name": "LEN", "type": "DINT", "dim": 0, "description": ""},
                                    {"name": "DATA", "type": "SINT", "dim": string_max(st), "description": ""}]}
            return _not_found(f"no data type {name}")
        t = types[hit]
        return {"name": hit, "predefined": hit in PREDEFINED, "description": getattr(t, "description", "") or "",
                "members": [{"name": m.name, "type": m.data_type, "dim": m.dim, "description": m.description or "",
                             "external_access": m.external_access}
                            for m in t.members if not m.name.startswith("ZZZZZZZZZZ")]}

    @r.post("/describe")
    def describe(body: dict):
        """Type and description of each address (tag, element, member or bit).
        A member without its own description shows its data type member's description;
        otherwise the base tag's description is passed through (as in the Tag Editor)."""
        db = emu.engine.db
        types = db.types()
        out = {}
        for a in list(body.get("addresses") or [])[:2000]:
            info = {"type": None, "description": "", "from": None}
            try:
                real = db.dealias(a) if hasattr(db, "dealias") else a
                info["type"] = db.data_type(real)
            except Exception:
                out[a] = info
                continue
            m = re.match(r"(Program:[^.]+\.)?[A-Za-z_]\w*", real)
            root = m.group() if m else real
            base = decl_description(root)
            try:
                cur = db.declaration(root).data_type
            except Exception:
                cur = None
            member_desc = ""
            for seg in re.findall(r"\.([A-Za-z_]\w*)", real[len(root):]):
                t = types.get(cur) if cur else None
                mem = next((x for x in t.members if x.name.lower() == seg.lower()), None) if t else None
                if mem is None:
                    break
                member_desc = mem.description or member_desc
                cur = mem.data_type
            if real == root and base:
                info.update(description=base, **{"from": "tag"})
            elif member_desc:
                info.update(description=member_desc, **{"from": "member"})
            elif base:
                info.update(description=base, **{"from": "base"})
            out[a] = info
        return {"items": out}

    @r.get("/timers")
    def timers():
        db = emu.engine.db
        items = []
        for name, tag in db.declarations().items():
            if tag.data_type not in ("TIMER", "COUNTER") or tag.dim:
                continue
            v = db.get(name)
            items.append({"address": name, "kind": tag.data_type, **v})
        return {"items": items}

    @r.get("/faults")
    def faults():
        eng = emu.engine
        return {"faults": list(eng.faults), "major": eng.major_fault,
                "minor": list(eng.minor_faults)}

    @r.get("/instructions")
    def instruction_set():
        from .isa import SPECS, catalog
        specs = {s.mnemonic: s for s in SPECS.values()}
        return {"instructions": [s.to_json() for s in specs.values()],
                "aliases": {a: s.mnemonic for a, s in SPECS.items() if a != s.mnemonic},
                "catalog": catalog()}

    @r.get("/diagnostics")
    def diagnostics():
        eng = emu.engine
        st = eng.status
        return {"state": emu.state(), "tasks": eng.task_stats,
                "flags": {"N": st.N, "Z": st.Z, "V": st.V, "C": st.C},
                "watchdog_ms": round(eng.watchdog_s * 1000), "report_overflow": eng.report_overflow,
                "major": eng.major_fault, "minor_count": len(eng.minor_faults),
                "scan_period_ms": round(eng.target_period * 1000, 3),
                "timing": eng.timing, "speed": eng.speed}

    # ---- editing ---------------------------------------------------------------------
    from .editing import (EditError, apply_rung_batch, apply_rung_edit, apply_st_edit, edit_log,
                          redo, undo)
    from .validation import validate_rung, validate_st

    def _edit_error(exc: EditError):
        return JSONResponse({"ok": False, "error": str(exc), "issues": exc.issues},
                            status_code=exc.status)

    def _need(body, *keys):
        missing = [k for k in keys if body.get(k) is None]
        if missing:
            raise EditError(f"missing field(s): {', '.join(missing)}")

    @r.post("/validate/rung")
    def v_rung(body: dict):
        try:
            _need(body, "program", "routine", "text")
        except EditError as exc:
            return _edit_error(exc)
        if body["program"].startswith("AOI:"):
            return {"ok": False, "issues": [{"severity": "error", "kind": "structure",
                    "message": "Add-On Instruction logic cannot be edited online"}]}
        return validate_rung(emu.engine, body["program"], body["routine"], body["text"],
                             body.get("index"), bool(body.get("inserting")))

    @r.post("/validate/st")
    def v_st(body: dict):
        try:
            _need(body, "program", "text")
        except EditError as exc:
            return _edit_error(exc)
        return validate_st(emu.engine, body["program"], body["text"])

    def _done(res):
        emu.bus.emit("state", emu.state())
        return res

    @r.post("/edit/rung")
    def e_rung(body: dict):
        try:
            _need(body, "program", "routine", "op", "index")
            return _done(apply_rung_edit(emu.engine, body["program"], body["routine"],
                                         body["op"], int(body["index"]), body.get("text"),
                                         body.get("comment"), body.get("to"),
                                         body.get("version")))
        except EditError as exc:
            return _edit_error(exc)

    @r.post("/edit/st")
    def e_st(body: dict):
        try:
            _need(body, "program", "routine", "text")
            return _done(apply_st_edit(emu.engine, body["program"], body["routine"],
                                       body["text"], body.get("version")))
        except EditError as exc:
            return _edit_error(exc)

    @r.post("/edit/batch")
    def e_batch(body: dict):
        try:
            _need(body, "program", "routine", "ops")
            return _done(apply_rung_batch(emu.engine, body["program"], body["routine"],
                                          list(body["ops"]), body.get("version")))
        except EditError as exc:
            return _edit_error(exc)

    @r.post("/edit/redo")
    def e_redo(body: dict):
        try:
            _need(body, "program", "routine")
            return _done(redo(emu.engine, body["program"], body["routine"], body.get("version")))
        except EditError as exc:
            return _edit_error(exc)

    @r.post("/edit/undo")
    def e_undo(body: dict):
        try:
            _need(body, "program", "routine")
            return _done(undo(emu.engine, body["program"], body["routine"], body.get("version")))
        except EditError as exc:
            return _edit_error(exc)

    @r.get("/edit/log")
    def e_log():
        return {"edits": edit_log(emu.engine)}

    @r.get("/tagnames")
    def tagnames(program: str = ""):
        db = emu.engine.db
        out = []
        prefix = f"Program:{program}." if program else None
        for addr in emu.store.flat():
            if addr.startswith("Program:"):
                if not prefix or not addr.startswith(prefix):
                    continue
                addr = addr[len(prefix):]
            out.append(addr)
        bases = set()
        for name, decl in db.declarations().items():
            if name.startswith("Program:"):
                if prefix and name.startswith(prefix):
                    bases.add(name[len(prefix):])
            else:
                bases.add(name)
        for alias in emu.engine.controller.aliases:
            if not alias.startswith("Program:"):
                bases.add(alias)
        return {"names": sorted(bases | set(out))}

    @r.get("/export")
    def export():
        from fastapi.responses import Response
        from .l5x_writer import write_l5x
        if not ctrl().programs and not emu.l5x_source:
            return JSONResponse({"error": "nothing to export: create or import a project first"},
                                status_code=409)
        with emu.engine.scan_lock:
            data = write_l5x(ctrl(), emu.l5x_source, emu.engine.db)
        name = (emu.logic_file or f"{ctrl().name}.L5X").rsplit(".", 1)[0]
        name = (name + "_edited" if emu.logic_file else name) + ".L5X"
        return Response(data, media_type="application/xml",
                        headers={"Content-Disposition": f'attachment; filename="{name}"'})

    # ---- project structure (project_ops.py) -----------------------------------------------
    from . import project_ops as ops
    from .project import (ProjectError, load_project, project_file, projects_dir,
                          save_studio_project)

    def _op(fn, *a, status=200, **kw):
        try:
            res = fn(emu.engine, *a, **kw)
        except ops.ProjectOpError as exc:
            return JSONResponse({"ok": False, "error": str(exc), "references": exc.references},
                                status_code=exc.status)
        except EditError as exc:
            return _edit_error(exc)
        except (TypeError, ValueError) as exc:
            return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)
        emu.bus.emit("state", emu.state())
        res["project_version"] = emu.engine.project_version
        return JSONResponse(res, status_code=status)

    def _flag(v) -> bool:
        return str(v).lower() in ("1", "true", "yes", "on")

    def _pick(body, *keys):
        return {k: body[k] for k in keys if k in body}

    @r.post("/project/new")
    def project_new(body: dict):
        name = (body or {}).get("name") or "NewProject"
        try:
            ops.check_name(name, "controller name")
        except ops.ProjectOpError as exc:
            return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)
        emu.new_project(name)
        emu.bus.emit("state", emu.state())
        return {"ok": True, "controller": name}

    @r.post("/project/save")
    def project_save(body: dict | None = None):
        body = body or {}
        try:
            if "name" in body:                       # Save As
                path = project_file(body["name"])
                if os.path.exists(path) and path != emu.project_path and not body.get("overwrite"):
                    return JSONResponse({"ok": False, "exists": True, "name": os.path.basename(path),
                                         "error": f"{os.path.basename(path)} already exists"},
                                        status_code=409)
            elif emu.project_path and emu.project_path.lower().endswith(".vcsproj"):
                path = emu.project_path
            else:
                path = project_file(ctrl().name)
            save_studio_project(emu, path, body.get("watch"))
        except ProjectError as exc:
            return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)
        except OSError as exc:
            return JSONResponse({"ok": False, "error": f"cannot save: {exc}"}, status_code=500)
        return {"ok": True, "path": path, "name": os.path.basename(path)}

    @r.get("/project/files")
    def project_files():
        folder = projects_dir()
        out = []
        if os.path.isdir(folder):
            for n in sorted(os.listdir(folder), key=str.lower):
                fp = os.path.join(folder, n)
                if os.path.isfile(fp) and n.lower().endswith((".vcsproj", ".l5x")):
                    st = os.stat(fp)
                    out.append({"name": n, "size": st.st_size, "modified": st.st_mtime,
                                "kind": "project" if n.lower().endswith(".vcsproj") else "l5x"})
        return {"folder": folder, "files": out}

    @r.post("/project/open")
    def project_open(body: dict):
        from .l5x_loader import load_file
        try:
            path = project_file((body or {}).get("name", ""), exts=(".vcsproj", ".L5X"),
                                default_ext=None)
            if not os.path.isfile(path):
                return JSONResponse({"ok": False, "error": f"{os.path.basename(path)} not found "
                                     f"in {projects_dir()}"}, status_code=404)
            if path.lower().endswith(".l5x"):
                controller = load_file(path)
                with open(path, "rb") as fh:
                    emu.load_controller(controller, logic_file=os.path.basename(path),
                                        source=fh.read())
            else:
                load_project(path, emu)
        except ProjectError as exc:
            return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)
        except Exception as exc:
            return JSONResponse({"ok": False, "error": f"cannot open: {exc}"}, status_code=400)
        emu.bus.emit("state", emu.state())
        return {"ok": True, "controller": ctrl().name, "name": os.path.basename(path)}

    @r.post("/project/upload")
    async def project_upload(request: Request):
        """Open a .vcsproj sent as the request body (used when a project file is
        dropped on the launcher while the app is already running)."""
        import json as _json
        from .project import load_studio_project
        raw = await request.body()
        if len(raw) > MAX_L5X:
            return JSONResponse({"error": "file too large"}, status_code=413)
        try:
            data = _json.loads(raw)
            if not isinstance(data, dict) or data.get("format") != "virtualcontrolstudio-project":
                raise ProjectError("not a VirtualControlStudio project file")
            load_studio_project("(uploaded)", emu, data)
        except (ValueError, ProjectError) as exc:
            return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)
        emu.project_path = None                   # Save goes to the projects folder
        emu.bus.emit("state", emu.state())
        return {"ok": True, "controller": ctrl().name}

    @r.get("/project/undo")
    def project_undo_peek():
        stack = emu.engine.__dict__.get("project_undo") or []
        return {"label": stack[-1][0] if stack else None, "depth": len(stack)}

    @r.post("/project/undo")
    def project_undo():
        return _op(ops.undo)

    @r.put("/timing")
    def timing_put(body: dict):
        """Controller clock while running: "realtime" (follows the PC clock; slow
        logic misses task periods) or "exact" (every task period runs; the
        controller runs slower than real time when the logic is heavy)."""
        mode = str(body.get("timing", "")).lower()
        if mode not in ("realtime", "exact"):
            return JSONResponse({"ok": False, "error": "timing must be 'realtime' or 'exact'"},
                                status_code=400)
        eng = emu.engine
        if eng.timing != mode:
            eng.timing = mode
            for st in eng.task_stats.values():      # start counting overlaps afresh
                st["overlaps"] = 0
                st["next"] = None
            eng.speed = 1.0
            eng.change_count += 1
        emu.bus.emit("state", emu.state())
        return {"ok": True, "timing": eng.timing}

    @r.put("/controller")
    def controller_put(body: dict):
        return _op(ops.update_controller, **_pick(body, "name", "description", "project_version"))

    @r.post("/tag")
    def tag_post(body: dict):
        if not body.get("name"):
            return JSONResponse({"ok": False, "error": "a tag name is required"}, status_code=400)
        return _op(ops.create_tag, body["name"], status=201,
                   **_pick(body, "data_type", "scope", "dims", "description", "external_access",
                           "constant", "alias_for", "value", "project_version"))

    @r.put("/tag")
    def tag_put(body: dict):
        if not body.get("address"):
            return JSONResponse({"ok": False, "error": "address is required"}, status_code=400)
        return _op(ops.update_tag, body["address"],
                   **_pick(body, "description", "external_access", "constant", "data_type",
                           "dims", "project_version"))

    @r.post("/types")
    def addr_types(body: dict):
        """Data type of each address (members and elements too), for the tag views."""
        db, out = emu.engine.db, {}
        for a in list(body.get("addresses") or [])[:5000]:
            try:
                out[a] = db.data_type(db.dealias(a) if hasattr(db, "dealias") else a)
            except Exception:
                out[a] = None
        return {"types": out}

    @r.put("/tag/style")
    def tag_style(body: dict):
        return _op(ops.set_tag_style, body.get("address", ""), body.get("style", ""),
                   **_pick(body, "project_version"))

    @r.put("/tag/extended")
    def tag_extended(body: dict):
        """Extended properties of a tag (1756-PM004): Engineering Unit, Min/Max for
        SINT/INT/DINT/LINT/REAL, State0/State1 for BOOL. Min/Max can be read in logic
        as Tag.@Min / Tag.@Max."""
        addr = body.get("address") or ""
        st = emu.engine.store
        db = emu.engine.db
        if db.is_alias(addr):
            return JSONResponse({"ok": False, "error": "extended properties of an alias are "
                                 "those of its base tag; change them there"}, status_code=400)
        if not st._has(addr):
            return JSONResponse({"ok": False, "error": f"no tag {addr!r}"}, status_code=404)
        decl = db.declaration(db.find_root(addr))
        dtype, is_array = decl.data_type, bool(decl.dim)
        allowed = {"units"} if is_array or dtype == "STRING" else \
            {"units", "state0", "state1"} if dtype == "BOOL" else \
            {"units", "min", "max"} if dtype in _LIMITS else set()
        fields = {k: body[k] for k in ("units", "min", "max", "state0", "state1") if k in body}
        bad = set(fields) - allowed
        if bad:
            return JSONResponse({"ok": False, "error": f"{', '.join(sorted(bad))} not available for "
                                 f"{dtype}{'[...]' if is_array else ''}"}, status_code=400)
        for k in ("min", "max"):
            if fields.get(k) not in (None, ""):
                try:
                    v = float(fields[k])
                except (TypeError, ValueError):
                    return JSONResponse({"ok": False, "error": f"{k} must be a number"}, status_code=400)
                lo, hi = _LIMITS[dtype]
                if not lo <= v <= hi:
                    return JSONResponse({"ok": False, "error": f"{k} {fields[k]} is outside the "
                                         f"{dtype} range {lo}..{hi}"}, status_code=400)
        from .tagstore import TagStoreError
        try:
            st.set_meta(addr, **fields)
        except TagStoreError as exc:
            return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)
        eng = emu.engine                       # a project change (saved with the project)
        eng.change_count = getattr(eng, "change_count", 0) + 1
        return {"ok": True, **{k: getattr(st.meta(addr), k) for k in ("units", "min", "max", "state0", "state1")}}

    @r.post("/passthrough")
    def passthrough(body: dict):
        """Pass-through descriptions (gray in the tag monitor) for member/element addresses."""
        from .descriptions import pass_through
        db = emu.engine.db
        out = {}
        for a in (body.get("addresses") or [])[:2000]:
            try:
                out[a] = pass_through(db, a)
            except Exception:
                out[a] = ""
        return {"descriptions": out}

    @r.delete("/tag")
    def tag_delete(address: str, force: str = "false", project_version: int | None = None):
        return _op(ops.delete_tag, address, force=_flag(force), project_version=project_version)

    @r.post("/tag/rename")
    def tag_rename(body: dict):
        if not body.get("address") or not body.get("new_name"):
            return JSONResponse({"ok": False, "error": "address and new_name are required"},
                                status_code=400)
        return _op(ops.rename_tag, body["address"], body["new_name"],
                   dry_run=bool(body.get("dry_run")), project_version=body.get("project_version"))

    @r.get("/xref")
    def cross_reference(address: str = "", routine: str = "", program: str = ""):
        """Cross reference: a tag (every use, destructive or not) or a routine (its callers)."""
        if routine:
            try:
                return {"routine": routine, "program": program,
                        "references": ops._routine_refs(emu.engine, program, routine)}
            except ops.ProjectOpError as exc:
                return JSONResponse({"ok": False, "error": str(exc)}, status_code=404)
        return {"address": address, "references": ops.xref(emu.engine, address)}

    @r.get("/search")
    def search(q: str, scope: str = "all", program: str = "", routine: str = "",
               within: str = "operands,mnemonics,comments", whole: bool = False, case: bool = False,
               wild: bool = False):
        """Find in logic (ladder operands / mnemonics / rung comments, ST text; wildcards
        * ? #; ST comments or statements only with within=stcomments / stcode)."""
        from .search import search_logic
        return {"q": q, "hits": search_logic(emu.engine, q, scope, program, routine,
                                             set(within.split(",")), whole, case, wild=wild)}

    @r.post("/replace")
    def replace_in_logic(body: dict):
        """Replace All in logic, applied as one edit per routine (each undoable)."""
        from .search import replace_logic
        try:
            res = replace_logic(emu.engine, body.get("q", ""), body.get("with", ""),
                                body.get("scope", "all"), body.get("program", ""),
                                body.get("routine", ""), set(body.get("within", "operands,comments").split(",")),
                                bool(body.get("whole")), bool(body.get("case")))
        except EditError as exc:
            return _edit_error(exc)
        emu.bus.emit("state", emu.state())
        return res

    @r.get("/tag/references")
    def tag_references(address: str):
        return {"address": address, "references": ops.references(emu.engine, address)}

    @r.post("/routine")
    def routine_post(body: dict):
        if not body.get("program") or not body.get("name"):
            return JSONResponse({"ok": False, "error": "program and name are required"},
                                status_code=400)
        return _op(ops.create_routine, body["program"], body["name"], body.get("type", "RLL"),
                   body.get("description", ""), body.get("project_version"), status=201)

    @r.put("/routine")
    def routine_put(body: dict):
        return _op(ops.update_routine, body.get("program", ""), body.get("name", ""),
                   **_pick(body, "new_name", "description", "main", "project_version"))

    @r.delete("/routine")
    def routine_delete(program: str, name: str, force: str = "false",
                       project_version: int | None = None):
        return _op(ops.delete_routine, program, name, force=_flag(force),
                   project_version=project_version)

    @r.post("/program")
    def program_post(body: dict):
        if not body.get("name"):
            return JSONResponse({"ok": False, "error": "a program name is required"},
                                status_code=400)
        return _op(ops.create_program, body["name"], status=201,
                   **_pick(body, "task", "main_routine", "description", "project_version"))

    @r.put("/program")
    def program_put(body: dict):
        return _op(ops.update_program, body.get("name", ""),
                   **_pick(body, "new_name", "description", "disabled", "project_version"))

    @r.delete("/program")
    def program_delete(name: str, force: str = "false", project_version: int | None = None):
        return _op(ops.delete_program, name, force=_flag(force), project_version=project_version)

    @r.post("/routine/copy")
    def routine_copy(body: dict):
        return _op(ops.copy_routine, body.get("program", ""), body.get("name", ""),
                   body.get("to_program", ""), **_pick(body, "new_name", "project_version"))

    @r.post("/routine/move")
    def routine_move(body: dict):
        return _op(ops.move_routine, body.get("program", ""), body.get("name", ""),
                   body.get("to_program", ""), **_pick(body, "force", "project_version"))

    @r.post("/program/copy")
    def program_copy(body: dict):
        return _op(ops.copy_program, body.get("name", ""),
                   **_pick(body, "task", "index", "new_name", "project_version"))

    @r.post("/program/schedule")
    def program_schedule(body: dict):
        return _op(ops.schedule_program, body.get("program", ""), body.get("task"),
                   **_pick(body, "index", "project_version"))

    @r.post("/task")
    def task_post(body: dict):
        if not body.get("name"):
            return JSONResponse({"ok": False, "error": "a task name is required"}, status_code=400)
        return _op(ops.create_task, body["name"], status=201,
                   **_pick(body, "type", "rate_ms", "priority", "watchdog_ms", "inhibited",
                           "description", "project_version"))

    @r.put("/task")
    def task_put(body: dict):
        return _op(ops.update_task, body.get("name", ""),
                   **_pick(body, "new_name", "type", "rate_ms", "priority", "watchdog_ms",
                           "inhibited", "description", "programs", "project_version"))

    @r.delete("/task")
    def task_delete(name: str, project_version: int | None = None):
        return _op(ops.delete_task, name, project_version=project_version)

    # ---- connections (connections.py) -------------------------------------------------------
    from .connections import PRESETS, ConnectionError_
    from .connectors.errors import local_ips

    def _cerr(exc):
        return JSONResponse({"ok": False, "error": str(exc), "field": getattr(exc, "field", None)},
                            status_code=getattr(exc, "status", 400))

    def _conn_call(fn, *a, **kw):
        try:
            return fn(*a, **kw)
        except ConnectionError_ as exc:
            return _cerr(exc)

    @r.get("/connections")
    def connections_list():
        return {"connections": emu.connections.list(), "summary": emu.connections.summary(),
                "netinfo": {"ips": local_ips(), "ui_port": (emu.settings.get("web") or {}).get("port")}}

    @r.get("/connections/kinds")
    def connections_kinds():
        return {"kinds": emu.connections.kinds(), "presets": PRESETS}

    @r.post("/connections")
    def connections_add(body: dict):
        return _conn_call(emu.connections.add, body or {})

    @r.put("/connections/{cid}")
    def connections_update(cid: str, body: dict):
        return _conn_call(emu.connections.update, cid, body or {})

    @r.delete("/connections/{cid}")
    def connections_delete(cid: str):
        res = _conn_call(emu.connections.remove, cid)
        return res if isinstance(res, JSONResponse) else {"ok": True}

    @r.post("/connections/{cid}/enable")
    def connections_enable(cid: str):
        return _conn_call(emu.connections.set_enabled, cid, True)

    @r.post("/connections/{cid}/disable")
    def connections_disable(cid: str):
        return _conn_call(emu.connections.set_enabled, cid, False)

    @r.post("/connections/{cid}/restart")
    def connections_restart(cid: str):
        return _conn_call(emu.connections.restart, cid)

    @r.post("/connections/test")
    def connections_test(body: dict):
        body = body or {}
        cid = body.pop("id", None)
        res = _conn_call(emu.connections.test, body, cid)
        return res if isinstance(res, JSONResponse) else {"checks": res}

    @r.get("/connections/{cid}/log")
    def connections_log(cid: str):
        res = _conn_call(emu.connections.log, cid)
        return res if isinstance(res, JSONResponse) else {"log": res}

    @r.get("/connections/{cid}/other-side")
    def connections_other_side(cid: str):
        return _conn_call(emu.connections.other_side, cid)

    @r.get("/connections/{cid}/nodered-flow")
    def connections_flow(cid: str):
        from fastapi.responses import Response
        from .connectors.nodered import flow_json
        try:
            c = emu.connections.get(cid)
        except ConnectionError_ as exc:
            return _cerr(exc)
        if c["kind"] != "ws_server":
            return JSONResponse({"error": "a Node-RED flow is made for WebSocket server connections"},
                                status_code=409)
        con = emu.connections.connector(cid)
        if con is not None:
            url = con.urls()[0]
        else:
            from .connectors.base import bind_address
            host = bind_address(c["params"]["bind"])
            url = f"ws://{local_ips()[0] if host == '0.0.0.0' else host}:{c['params']['port']}" \
                  f"{'/' + c['params']['path'].strip('/')}"
        tok = (emu.connections._get(cid).cfg["params"].get("token") or "")
        if tok:
            url += f"?token={tok}"
        names = [t["name"] for t in emu.store.definitions()]
        example = next((n for n in names if n.lower().startswith("start")), names[0] if names else "Tag1")
        body = flow_json(url, subscribe=",".join(c["params"].get("read_tags") or ["*"]),
                         example_tag=example, label=f"VirtualControlStudio - {c['name']}")
        return Response(body, media_type="application/json", headers={
            "Content-Disposition": 'attachment; filename="vcs-node-red-flow.json"'})

    @r.get("/connections/{cid}/modbus-map.csv")
    def connections_modbus_csv(cid: str):
        from fastapi.responses import Response
        con = emu.connections.connector(cid) if cid in {c["id"] for c in emu.connections.list()} else None
        if con is None or not hasattr(con, "map_csv"):
            return JSONResponse({"error": "turn the Modbus connection on to build its map"},
                                status_code=409)
        return Response(con.map_csv(), media_type="text/csv", headers={
            "Content-Disposition": 'attachment; filename="vcs-modbus-map.csv"'})

    @r.get("/tags.csv")
    def tags_csv():
        """Controller tag list for HMI tag import (e.g. C-more): name, type, description."""
        import csv
        import io
        from fastapi.responses import Response
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Tag Name", "Data Type", "Array", "Description", "Access"])
        for d in emu.store.definitions():
            if d["name"].startswith("Program:"):
                continue
            dims = d.get("dims") or []
            w.writerow([d["name"], d["type"], ",".join(map(str, dims)), d.get("description", ""),
                        _ACCESS_TEXT.get(d.get("access"), "Read/Write")])
        return Response(buf.getvalue(), media_type="text/csv", headers={
            "Content-Disposition": 'attachment; filename="vcs-tags.csv"'})

    @r.get("/datatypes")
    def datatypes():
        return ops.known_types(emu.engine)

    def _used_names():
        """Lower-case root names used anywhere in the logic (for the Tag Browser's
        Show unused filter)."""
        out = set()
        c = ctrl()
        texts = []
        for prog in c.programs.values():
            for rt in prog.routines.values():
                texts.extend(rt.rungs if rt.rtype == "RLL" else [rt.text or ""])
        for aoi in c.aois.values():
            for rt in aoi.routines.values():
                texts.extend(rt.rungs if rt.rtype == "RLL" else [rt.text or ""])
        for t in texts:
            for m in re.finditer(r"(?:Program:[A-Za-z_]\w*\.)?[A-Za-z_]\w*", t or ""):
                out.add(m.group().lower())
        return out

    @r.get("/tagbrowser")
    def tagbrowser(program: str = "", depth: int = 2):
        """Tags usable in ``program`` (program scope first), with members to ``depth``
        levels, for the operand Tag Browser."""
        db = emu.engine.db
        types = db.types()

        def members(dtype, level):
            if level <= 0 or dtype not in types:
                return []
            out = []
            for m in types[dtype].members:
                if m.name in ("EnableIn", "EnableOut") and dtype in ctrl().aois:
                    continue
                out.append({"name": m.name, "type": m.data_type + (f"[{m.dim}]" if m.dim else ""),
                            "members": [] if m.dim else members(m.data_type, level - 1)})
            return out

        items = []
        seen = set()
        pre = f"Program:{program}." if program else None
        used = _used_names()
        decls = db.declarations()
        order = ([n for n in decls if pre and n.startswith(pre)] +
                 [n for n in decls if not n.startswith("Program:")])
        for full in order:
            d = decls[full]
            name = full[len(pre):] if pre and full.startswith(pre) else full
            if name.lower() in seen:
                continue
            seen.add(name.lower())
            dims = list(getattr(d, "dims", ()) or ())
            items.append({"name": name, "address": full,
                          "scope": program if pre and full.startswith(pre) else "controller",
                          "type": d.data_type + (f"[{','.join(map(str, dims))}]" if dims else ""),
                          "base_type": d.data_type, "dims": dims,
                          "description": decl_description(full),
                          "tag_type": getattr(d, "tag_type", "Base") or "Base",
                          "used": name.lower() in used or full.lower() in used,
                          "members": [] if dims else members(d.data_type, max(0, min(depth, 4)))})
        for alias, target in ctrl().aliases.items():
            in_scope = (pre and alias.startswith(pre)) or not alias.startswith("Program:")
            name = alias[len(pre):] if pre and alias.startswith(pre) else alias
            if not in_scope or name.lower() in seen:
                continue
            try:
                atype = db.data_type(target)
            except Exception:
                atype = "?"
            items.append({"name": name, "address": alias, "alias_for": target, "type": atype,
                          "base_type": atype, "dims": [], "tag_type": "Alias",
                          "used": name.lower() in used,
                          "scope": program if pre and alias.startswith(pre) else "controller",
                          "description": "", "members": members(atype, 1)})
        return {"program": program, "items": items}

    app.include_router(r)
