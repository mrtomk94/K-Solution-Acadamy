"""Pass-through descriptions (1756-PM004, Describing a User-defined Data Type).

When a member or element has no description of its own, the programming
software shows one built from the descriptions it inherits:

* an array tag's description passes through to its elements;
* a UDT member's description passes through to every tag of that type, and is
  appended to the description of the tag (or element) it belongs to.

``pass_through(db, "Tanks[1].Level")`` -> "Tank farm Liquid level".
"""
from __future__ import annotations

import re

_SEG = re.compile(r"\.[^.\[]+|\[[^\]]*\]")


def pass_through(db, address: str) -> str:
    """The inherited (gray) description of a member or element, or ''."""
    root, decl = db.declaration_of(address)
    if decl is None:
        return ""
    address = db.canonical(address)
    text = (getattr(decl, "description", "") or "").strip()
    dtype = decl.data_type
    for seg in _SEG.findall(address[len(root):]):
        if seg.startswith("["):
            continue                                 # an element: the array's description
        name = seg[1:]
        if name.isdigit():
            break                                    # a bit of an integer
        try:
            mem = db._member(dtype, name)
        except Exception:
            break
        if mem.description:
            text = f"{text} {mem.description}".strip()
        dtype = mem.data_type
    return text
