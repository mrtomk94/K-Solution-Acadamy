"""Native protocol v1: REST + WebSocket API on an Emulator.

WebSocket ``/api/v1/ws`` — JSON messages, each may carry an ``id`` that is echoed:

  → {"op":"hello","client":"my-sim","v":1}           ← {"op":"welcome","v":1,"project":..,"running":..}
  → {"op":"subscribe","tags":["WIP","AGV*"],"deadband":0}
                                                     ← {"op":"snapshot","sub":n,"seq":0,"values":{..}}
                                                     ← {"op":"changes","sub":n,"seq":k,"values":{..}}
  → {"op":"unsubscribe","sub":n}
  → {"op":"read","tags":[..]}                        ← {"op":"values","values":{..}}
  → {"op":"write","values":{addr:value}}             ← {"op":"ack","ok":bool,"errors":{addr:msg}}
  → {"op":"force","values":{..}} / {"op":"unforce","tags":[..]}        ← ack
  → {"op":"define","tags":[{name,type,dim,value,..meta}]} / {"op":"delete","tags":[..]} ← ack
  → {"op":"list"}                                    ← {"op":"tags","tags":[..],"types":{..}}
  → {"op":"run"} / {"op":"stop"} / {"op":"step"}     ← ack
                                                     ← {"op":"event","kind":"state"|"tags",...}
  bad input                                          ← {"op":"error","error":msg}

Writes from a client are recorded with source ``api:<client name from hello>``.
"""
from __future__ import annotations

import asyncio
import json
import math
from typing import Any

from fastapi import APIRouter, FastAPI, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse

from .tagstore import META_FIELDS, TagMeta, TagStoreError

PROTOCOL = 1
MAX_WS_MESSAGE = 1024 * 1024          # bytes
MAX_CSV_UPLOAD = 2 * 1024 * 1024


_STATUS = {"unknown": 404, "exists": 409, "limit": 413}
LOOPBACK_HOSTS = {"localhost", "127.0.0.1", "::1", "[::1]"}


def origin_allowed(conn, emu) -> bool:
    """Refuse browser requests from other sites (WebSockets get no CORS
    protection, and text/plain POSTs need no preflight).
    Allowed: no Origin (scripts, simulators), the same origin, and the project's
    ``web.allowed_origins`` ("null" = pages opened from disk, "*" = any).
    When bound to loopback, a same-origin request must also name a loopback
    Host, which blocks DNS-rebinding pages."""
    from urllib.parse import urlparse
    headers = conn.headers
    origin = headers.get("origin")
    if not origin:
        return True
    web = emu.settings.get("web") or {}
    allowed = web.get("allowed_origins") or []
    if "*" in allowed or origin in allowed:
        return True
    host = headers.get("host", "")
    if not (urlparse(origin).netloc and urlparse(origin).netloc == host):
        return False
    bind = web.get("bind_host")
    if bind in LOOPBACK_HOSTS:
        hostname = host.rsplit(":", 1)[0] if not host.startswith("[") else host.split("]")[0] + "]"
        return hostname in LOOPBACK_HOSTS or hostname in (web.get("allowed_hosts") or [])
    return True


def _err(exc: TagStoreError) -> JSONResponse:
    return JSONResponse({"error": str(exc), "code": exc.code}, status_code=_STATUS.get(exc.code, 400))


def _safe(v: Any) -> Any:
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return None
    return v


def _clean(values: dict) -> dict:
    return {k: _safe(v) for k, v in values.items()}


def _meta(d: dict) -> TagMeta:
    return TagMeta(**{k: d[k] for k in META_FIELDS if k in d and d[k] is not None})


def define_from(store, d: dict) -> None:
    if not isinstance(d, dict):
        raise TagStoreError("value", "tag definition must be an object")
    store.define(d.get("name"), d.get("type"), dim=d.get("dim", 0) or 0,
                 value=d.get("value"), meta=_meta(d))


def mount_v1(app: FastAPI, emu) -> None:
    r = APIRouter(prefix="/api/v1")
    st = emu.store

    # ---- REST ------------------------------------------------------------------
    @r.get("/status")
    def status():
        s = emu.state()
        s.update(protocol=PROTOCOL, connectors=emu.connector_status(),
                 subscribers=emu.bus.subscriber_count())
        return s

    @r.get("/tags")
    def tags():
        return {"tags": st.definitions(), "types": st.types()}

    @r.post("/tags", status_code=201)
    def define(body: dict):
        try:
            for d in body.get("tags", [body]):
                define_from(st, d)
        except TagStoreError as exc:
            return _err(exc)
        return {"ok": True}

    @r.post("/tags/import")
    async def import_tags(request: Request):
        import os
        import tempfile
        from .project import ProjectError, import_csv
        raw = await request.body()
        if len(raw) > MAX_CSV_UPLOAD:
            return JSONResponse({"error": f"CSV larger than {MAX_CSV_UPLOAD} bytes"}, status_code=413)
        text = raw.decode("utf-8-sig")
        fd, path = tempfile.mkstemp(suffix=".csv")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(text)
            n = import_csv(st, path)
        except ProjectError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        finally:
            os.unlink(path)
        return {"imported": n}

    @r.patch("/tags/{name:path}")
    def patch(name: str, body: dict):
        try:
            fields = {k: body[k] for k in META_FIELDS if k in body}
            if fields:
                st.set_meta(name, **fields)
            if body.get("rename"):
                st.rename(name, body["rename"])
        except TagStoreError as exc:
            return _err(exc)
        return {"ok": True}

    @r.delete("/tags/{name:path}")
    def delete(name: str):
        try:
            st.delete(name)
        except TagStoreError as exc:
            return _err(exc)
        return {"ok": True}

    @r.post("/types", status_code=201)
    def define_type(body: dict):
        try:
            st.define_type(body.get("name"), body.get("members") or [])
        except TagStoreError as exc:
            return _err(exc)
        return {"ok": True}

    @r.get("/values")
    def values(tags: list[str] = Query(default=["*"])):
        return {"values": _clean(st.read_many(tags))}

    @r.put("/values")
    def write(body: dict):
        errors = st.write_many(body.get("values") or {}, source="api:rest")
        return {"ok": not errors, "errors": errors}

    @r.get("/forces")
    def forces():
        return {"forces": st.forces(), "enabled": getattr(st, "forces_enabled", True),
                "status": st.force_status() if hasattr(st, "force_status") else None}

    @r.put("/forces/enabled")
    def forces_enabled(body: dict):
        """Enable or disable all I/O forces (controller level)."""
        st.set_forces_enabled(bool(body.get("enabled")))
        return {"ok": True, "enabled": st.forces_enabled, "status": st.force_status()}

    @r.put("/forces")
    def force(body: dict):
        errors = {}
        for addr, v in (body.get("values") or {}).items():
            try:
                st.force(addr, v, source="api")
            except TagStoreError as exc:
                errors[addr] = str(exc)
        return {"ok": not errors, "errors": errors}

    @r.delete("/forces")
    def unforce(tags: list[str] = Query(default=[])):
        if tags:
            for t in tags:
                st.unforce(t)
        else:
            st.unforce_all()
        return {"ok": True}

    @r.post("/run")
    def run():
        emu.run()
        return emu.state()

    @r.post("/stop")
    def stop():
        emu.halt()
        return emu.state()

    @r.post("/pause")
    def pause():
        emu.pause()
        return emu.state()

    @r.post("/reset")
    def reset():
        emu.reset()
        return emu.state()

    @r.post("/step")
    def step():
        try:
            emu.step()
        except RuntimeError as exc:
            return JSONResponse({"error": str(exc)}, status_code=409)
        return emu.state()

    @r.get("/project")
    def project():
        import os
        import tempfile
        from .project import save_project
        fd, path = tempfile.mkstemp(suffix=".json")
        os.close(fd)
        try:
            save_project(emu, path)
            with open(path, encoding="utf-8") as fh:
                return json.load(fh)
        finally:
            os.unlink(path)

    @r.post("/project/save")
    def save():
        from .project import save_project
        if not getattr(emu, "project_path", None):
            return JSONResponse({"error": "no project file: start with 'logixsim serve <project.json>'"},
                                status_code=409)
        save_project(emu, emu.project_path)
        return {"ok": True, "path": emu.project_path}

    app.include_router(r)

    # ---- WebSocket ------------------------------------------------------------------
    @app.websocket("/api/v1/ws")
    async def ws_v1(sock: WebSocket):
        if not origin_allowed(sock, emu):
            await sock.close(code=1008)
            return
        await sock.accept()
        loop = asyncio.get_running_loop()
        out: asyncio.Queue = asyncio.Queue()
        conn = {"client": "anon", "subs": {}}

        def push(msg):                       # safe from any thread
            loop.call_soon_threadsafe(out.put_nowait, msg)

        def on_event(kind, data):
            push({"op": "event", "kind": kind, "data": data})

        emu.bus.on_event(on_event)

        async def sender():
            while True:
                await sock.send_json(await out.get())

        task = asyncio.create_task(sender())
        try:
            while True:
                text = await sock.receive_text()
                if len(text) > MAX_WS_MESSAGE:
                    out.put_nowait({"op": "error", "error": f"message too large (> {MAX_WS_MESSAGE} bytes)"})
                    continue
                try:
                    msg = json.loads(text)
                    if not isinstance(msg, dict):
                        raise ValueError("message must be a JSON object")
                except ValueError as exc:
                    out.put_nowait({"op": "error", "error": f"bad message: {exc}"})
                    continue
                for reply in _handle(emu, conn, msg, push):
                    if msg.get("id") is not None and "id" not in reply:
                        reply["id"] = msg["id"]
                    out.put_nowait(reply)
        except WebSocketDisconnect:
            pass
        finally:
            for sub in conn["subs"].values():
                emu.bus.unsubscribe(sub)
            emu.bus.off_event(on_event)
            task.cancel()


def _handle(emu, conn, msg, push) -> list[dict]:
    st = emu.store
    op = msg.get("op")
    # The Studio UI is the programming application: full access regardless of
    # External Access (1756-PM004). Integration connections are always external.
    designer = conn.get("client") == "studio" and not conn.get("external")
    src = "ui" if designer else f"api:{conn['client']}"
    try:
        if op == "hello":
            conn["client"] = str(msg.get("client") or "anon")[:40]
            return [{"op": "welcome", "v": PROTOCOL, "server": "logixsim",
                     "project": emu.name, "running": emu.engine.running}]
        if op == "subscribe":
            holder = {}

            def cb(batch, seq):
                push({"op": "changes", "sub": holder["id"], "seq": seq, "values": _clean(batch)})
            sub = emu.bus.subscribe(list(msg.get("tags") or ["*"]), cb,
                                    deadband=msg.get("deadband", 0) or 0)
            holder["id"] = sub.id
            conn["subs"][sub.id] = sub
            emu.bus.start()
            return [{"op": "snapshot", "sub": sub.id, "seq": 0, "values": _clean(sub.snapshot)}]
        if op == "unsubscribe":
            sub = conn["subs"].pop(msg.get("sub"), None)
            if sub:
                emu.bus.unsubscribe(sub)
            return [{"op": "ack", "ok": sub is not None, "errors": {}}]
        if op == "read":
            return [{"op": "values", "values": _clean(st.read_many(list(msg.get("tags") or ["*"])))}]
        if op == "write":
            errors = st.write_many(msg.get("values") or {}, source=src)
            return [{"op": "ack", "ok": not errors, "errors": errors}]
        if op == "force":
            errors = {}
            for addr, v in (msg.get("values") or {}).items():
                try:
                    st.force(addr, v, source=src)
                except TagStoreError as exc:
                    errors[addr] = str(exc)
            return [{"op": "ack", "ok": not errors, "errors": errors}]
        if op == "unforce":
            for t in msg.get("tags") or []:
                st.unforce(t)
            return [{"op": "ack", "ok": True, "errors": {}}]
        if op == "define":
            errors = {}
            for d in msg.get("tags") or []:
                try:
                    define_from(st, d)
                except TagStoreError as exc:
                    errors[str(d.get("name") if isinstance(d, dict) else d)] = str(exc)
            return [{"op": "ack", "ok": not errors, "errors": errors}]
        if op == "delete":
            errors = {}
            for t in msg.get("tags") or []:
                try:
                    st.delete(t)
                except TagStoreError as exc:
                    errors[t] = str(exc)
            return [{"op": "ack", "ok": not errors, "errors": errors}]
        if op == "list":
            return [{"op": "tags", "tags": st.definitions(), "types": st.types()}]
        if op in ("run", "stop", "step"):
            {"run": emu.run, "stop": emu.halt, "step": emu.step}[op]()
            return [{"op": "ack", "ok": True, "errors": {}}]
        return [{"op": "error", "error": f"unknown op {op!r}"}]
    except TagStoreError as exc:
        return [{"op": "error", "error": str(exc), "code": exc.code}]
    except Exception as exc:                      # never drop the socket on bad input
        return [{"op": "error", "error": f"{type(exc).__name__}: {exc}"}]


# ---- integration endpoints: the same protocol with an access policy ----------------------
_CONTROL_OPS = ("force", "unforce", "define", "delete", "run", "stop", "step")


def handle_with_policy(emu, conn, msg, push, policy: dict | None) -> list[dict]:
    """``_handle`` for a connection with limits (the WebSocket server connector):
    policy = {"access": "rw" | "ro", "read": [patterns], "write": [patterns],
    "control": bool}. Refused writes are reported per tag and counted in
    ``conn["refused"]``; ``conn["on_refused"](text)`` is called for the log."""
    conn["external"] = True                          # never the programming application
    if not policy:
        return _handle(emu, conn, msg, push)
    from .events import compile_pattern
    readable = [compile_pattern(p) for p in (policy.get("read") or ["*"])]
    writable = [compile_pattern(p) for p in (policy.get("write") or ["*"])]
    store = emu.store

    def can_read(a):
        if not any(m(a) for m in readable):
            return False
        try:
            return store.access(a) != "none"            # External Access None: hidden
        except Exception:
            return True
    op = msg.get("op")

    def refuse(text):
        conn["refused"] = conn.get("refused", 0) + 1
        cb = conn.get("on_refused")
        if cb:
            cb(text)

    if op in _CONTROL_OPS and not policy.get("control"):
        refuse(f"'{op}' refused: this connection may not {op}")
        return [{"op": "error", "error": f"'{op}' is not allowed on this connection"}]
    if op == "write":
        values = msg.get("values") or {}
        errors = {}
        if not isinstance(values, dict):
            return [{"op": "error", "error": "values must be an object"}]
        allowed = {}
        for addr, v in values.items():
            if policy.get("access") == "ro":
                errors[addr] = "this connection is read-only"
            elif not any(m(addr) for m in writable):
                errors[addr] = ("this connection may only write "
                                + ", ".join(policy.get("write") or []))
            else:
                allowed[addr] = v
        for addr, why in errors.items():
            refuse(f"write to {addr} refused: {why}")
        replies = _handle(emu, conn, {**msg, "values": allowed}, push) if allowed else \
            [{"op": "ack", "ok": True, "errors": {}}]
        for r in replies:
            if r.get("op") == "ack":
                r["errors"] = {**r.get("errors", {}), **errors}
                r["ok"] = not r["errors"]
        return replies
    if op == "subscribe":
        def filtered(m):
            if m.get("op") == "changes":
                vals = {a: v for a, v in m["values"].items() if can_read(a)}
                if not vals:
                    return
                m = {**m, "values": vals}
            push(m)
        replies = _handle(emu, conn, msg, filtered)
        for r in replies:
            if r.get("op") == "snapshot":
                r["values"] = {a: v for a, v in r["values"].items() if can_read(a)}
        return replies
    replies = _handle(emu, conn, msg, push)
    for r in replies:
        if r.get("op") == "values":
            r["values"] = {a: v for a, v in r["values"].items() if can_read(a)}
        if r.get("op") == "tags":
            r["tags"] = [d for d in r["tags"] if can_read(d["name"])]
    return replies
