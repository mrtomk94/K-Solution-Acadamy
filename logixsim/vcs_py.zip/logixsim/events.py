"""EventBus: pushes tag changes to subscribers (API clients, connectors).

* Subscriptions use address patterns: ``*`` matches anything, and a plain
  address also matches everything below it (``WIP`` -> ``WIP[3]``,
  ``M`` -> ``M.Faults[1]``). Brackets are literal.
* On subscribe the caller gets a snapshot; afterwards only changed leaves are
  delivered, in batches, each with a per-subscription sequence number.
* REAL values can use a deadband (change must exceed it vs. the last value sent).
* A background thread detects changes every ``interval`` seconds; callbacks run
  on that thread, so asyncio users hand off with ``loop.call_soon_threadsafe``.
* Non-value events (run/stop, tag defined/deleted, faults) go to ``on_event``.
"""
from __future__ import annotations

import itertools
import logging
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable

log = logging.getLogger(__name__)


def compile_pattern(pattern: str) -> Callable[[str], bool]:
    body = re.escape(pattern).replace(r"\*", ".*").replace(r"\?", ".")
    rx = re.compile(f"^{body}(?:[.\\[].*)?$")
    return lambda addr: rx.match(addr) is not None


@dataclass
class Subscription:
    id: int
    matchers: list
    callback: Callable[[dict, int], None]
    deadband: float = 0.0
    seq: int = 0
    snapshot: dict = field(default_factory=dict)
    last_sent: dict = field(default_factory=dict)

    def matches(self, addr: str) -> bool:
        return any(m(addr) for m in self.matchers)


class EventBus:
    def __init__(self, store, interval: float = 0.05):
        self.store = store
        self.interval = interval
        self._subs: dict[int, Subscription] = {}
        self._event_listeners: list[Callable[[str, dict], None]] = []
        self._ids = itertools.count(1)
        self._lock = threading.Lock()
        self._publish_lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        store.on_structure(self._structure_changed)

    # ---- subscriptions --------------------------------------------------------
    def subscribe(self, patterns: list[str], callback: Callable[[dict, int], None],
                  deadband: float = 0.0) -> Subscription:
        sub = Subscription(next(self._ids), [compile_pattern(p) for p in patterns],
                           callback, float(deadband or 0.0))
        # hold the publish lock so no change slips between snapshot and registration
        with self._publish_lock:
            sub.snapshot = {a: v for a, v in self.store.flat().items() if sub.matches(a)}
            sub.last_sent = dict(sub.snapshot)
            with self._lock:
                self._subs[sub.id] = sub
        return sub

    def unsubscribe(self, sub: Subscription | int) -> None:
        with self._lock:
            self._subs.pop(sub if isinstance(sub, int) else sub.id, None)

    def subscriber_count(self) -> int:
        return len(self._subs)

    # ---- events -------------------------------------------------------------------
    def on_event(self, fn: Callable[[str, dict], None]) -> None:
        self._event_listeners.append(fn)

    def off_event(self, fn: Callable[[str, dict], None]) -> None:
        try:
            self._event_listeners.remove(fn)
        except ValueError:
            pass

    def emit(self, kind: str, data: dict) -> None:
        for fn in list(self._event_listeners):
            try:
                fn(kind, data)
            except Exception:
                log.exception("event listener failed")

    def _forget(self, root: str) -> None:
        """A deleted/renamed tag: a later tag with that name is new to everyone."""
        from .tagstore import root_of
        with self._lock:
            subs = list(self._subs.values())
        for s in subs:
            for a in [a for a in s.last_sent if root_of(a) == root]:
                del s.last_sent[a]

    def _structure_changed(self, kind: str, name) -> None:
        if kind == "reload":
            with self._lock:
                for s in self._subs.values():
                    s.last_sent.clear()
            self.emit("tags", {"action": "reload", "name": None})
            return
        if kind == "delete":
            self._forget(name)
        elif kind == "rename":
            self._forget(name[0])
        if kind == "rename":
            self.emit("tags", {"action": "rename", "old": name[0], "name": name[1]})
        else:
            self.emit("tags", {"action": kind, "name": name})

    # ---- publishing ---------------------------------------------------------------
    def publish_now(self) -> None:
        with self._publish_lock:
            self._publish()

    def _publish(self) -> None:
        changes = self.store.collect_changes()
        if not changes:
            return
        with self._lock:
            subs = list(self._subs.values())
        for sub in subs:
            batch = {}
            for a, v in changes.items():
                if not sub.matches(a):
                    continue
                if sub.deadband and isinstance(v, float) and a in sub.last_sent:
                    prev = sub.last_sent[a]
                    if isinstance(prev, (int, float)) and abs(v - prev) < sub.deadband:
                        continue
                if a in sub.last_sent and sub.last_sent[a] == v and type(sub.last_sent[a]) is type(v):
                    continue            # already in this subscriber's snapshot
                batch[a] = v
            if not batch:
                continue
            sub.last_sent.update(batch)
            sub.seq += 1
            try:
                sub.callback(batch, sub.seq)
            except Exception:
                log.exception("subscriber %s failed", sub.id)

    def _loop(self) -> None:
        wait = self.interval
        while not self._stop.wait(wait):
            t0 = time.perf_counter()
            try:
                self.publish_now()
            except Exception:
                log.exception("publish failed")
            # Large projects (100k+ values) take tens of ms to compare: wait at least
            # three times as long as the last pass took, so change detection never
            # uses more than about a quarter of the time and the logic keeps running.
            self.last_publish_s = time.perf_counter() - t0
            wait = max(self.interval, min(1.0, 3 * self.last_publish_s))

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="eventbus", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=1.0)
            self._thread = None

    def values(self, patterns: list[str]) -> dict[str, Any]:
        return self.store.read_many(patterns)
