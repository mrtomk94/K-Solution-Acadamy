"""SLC 500 / MicroLogix data-table model and address parser.

SLC addressing is file-based, not UDT-based:
  N7:0            integer file 7, element 0
  F8:2            float
  B3:0/5          bit 5 of word 0 in binary file 3  (also B3/5)
  T4:0.ACC/.PRE   timer sub-elements;  T4:0.DN /.EN /.TT  status bits
  C5:0.ACC/.PRE   counter;  C5:0.DN /.CU /.CD /.OV /.UN
  I1:0/3  O0:0/2  input/output bit
  S2:0            status

:class:`SLCDataTable` exposes the same ``get``/``set``/``data_type``/``names``
interface as :class:`model.TagDB`, so the existing scan engine, ladder
interpreter and instruction library drive SLC logic with no changes.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

_ADDR = re.compile(r"""
    ^(?P<file>[A-Za-z]+)(?P<fnum>\d+)?
    (:(?P<elem>\d+))?
    (\.(?P<sub>[A-Za-z]+))?
    (/(?P<bit>\d+|[A-Za-z]+))?$
""", re.VERBOSE)

# default file types for a fresh processor
BIT_FILES = {"I", "O", "B"}
TIMER_FILES = {"T"}
COUNTER_FILES = {"C"}
CONTROL_FILES = {"R"}
FLOAT_FILES = {"F"}
INT_FILES = {"N", "S"}

_TIMER_MEMBERS = {"PRE": "int", "ACC": "int", "EN": "bit", "TT": "bit", "DN": "bit"}
_COUNTER_MEMBERS = {"PRE": "int", "ACC": "int", "CU": "bit", "CD": "bit",
                    "DN": "bit", "OV": "bit", "UN": "bit"}
_CONTROL_MEMBERS = {"LEN": "int", "POS": "int", "EN": "bit", "DN": "bit",
                    "ER": "bit"}


class SLCAddressError(KeyError):
    pass


@dataclass
class FileDef:
    letter: str          # I, O, B, T, C, R, N, F, S
    number: int          # 3, 4, 7, ...
    size: int            # number of elements
    kind: str            # "int" | "float" | "bit" | "timer" | "counter" | "control"


def _parse(addr: str):
    m = _ADDR.match(addr.strip())
    if not m:
        raise SLCAddressError(addr)
    g = m.groupdict()
    letter = g["file"].upper()
    fnum = int(g["fnum"]) if g["fnum"] else None
    elem = int(g["elem"]) if g["elem"] else 0
    sub = g["sub"].upper() if g["sub"] else None
    bit = None
    if g["bit"]:
        if g["bit"].isdigit():
            bit = int(g["bit"])
        else:                       # /DN /EN /TT /CU ... -> a status sub-element
            sub = g["bit"].upper()
    return letter, fnum, elem, sub, bit


class SLCDataTable:
    def __init__(self, files: list[FileDef] | None = None):
        self._files: dict[str, FileDef] = {}
        self._store: dict[str, list] = {}
        for fd in files or self.default_files():
            self.add_file(fd)

    @staticmethod
    def default_files() -> list[FileDef]:
        return [
            FileDef("O", 0, 8, "bit"), FileDef("I", 1, 8, "bit"),
            FileDef("S", 2, 32, "int"), FileDef("B", 3, 16, "bit"),
            FileDef("T", 4, 16, "timer"), FileDef("C", 5, 16, "counter"),
            FileDef("R", 6, 8, "control"), FileDef("N", 7, 32, "int"),
            FileDef("F", 8, 16, "float"),
        ]

    def add_file(self, fd: FileDef) -> None:
        key = f"{fd.letter}{fd.number}"
        self._files[key] = fd
        self._store[key] = [self._blank(fd.kind) for _ in range(fd.size)]

    @staticmethod
    def _blank(kind: str):
        if kind == "float":
            return 0.0
        if kind == "timer":
            return {k: (False if t == "bit" else 0) for k, t in _TIMER_MEMBERS.items()}
        if kind == "counter":
            return {k: (False if t == "bit" else 0) for k, t in _COUNTER_MEMBERS.items()}
        if kind == "control":
            return {k: (False if t == "bit" else 0) for k, t in _CONTROL_MEMBERS.items()}
        return 0

    # ---- resolution --------------------------------------------------
    def _file_key(self, letter, fnum) -> str:
        if fnum is not None:
            return f"{letter}{fnum}"
        # bare letter (B/5, I/3): pick the lowest-numbered file of that letter
        for key, fd in self._files.items():
            if fd.letter == letter:
                return key
        raise SLCAddressError(f"{letter}")

    def _resolve(self, addr: str):
        letter, fnum, elem, sub, bit = _parse(addr)
        key = self._file_key(letter, fnum)
        if key not in self._store:
            raise SLCAddressError(addr)
        fd = self._files[key]
        words = self._store[key]
        if elem >= len(words):                    # grow on demand
            words.extend(self._blank(fd.kind) for _ in range(elem - len(words) + 1))
        return fd, words, elem, sub, bit

    # ---- public API (mirrors TagDB) ----------------------------------
    def names(self) -> list[str]:
        out = []
        for key, fd in self._files.items():
            for i in range(fd.size):
                out.append(f"{key}:{i}")
        return out

    def data_type(self, addr: str) -> str:
        fd, _, _, sub, bit = self._resolve(addr)
        if bit is not None:
            return "BOOL"
        if fd.kind in ("timer", "counter", "control"):
            members = {"timer": _TIMER_MEMBERS, "counter": _COUNTER_MEMBERS,
                       "control": _CONTROL_MEMBERS}[fd.kind]
            return "BOOL" if sub and members.get(sub) == "bit" else "INT"
        if fd.kind == "float":
            return "REAL"
        return "BOOL" if fd.kind == "bit" and bit is not None else "INT"

    def get(self, addr: str):
        fd, words, elem, sub, bit = self._resolve(addr)
        cell = words[elem]
        if fd.kind in ("timer", "counter", "control"):
            if sub is None:
                raise SLCAddressError(f"{addr} (needs a sub-element)")
            return cell[sub]
        if bit is not None:                       # bit of a word
            return bool((cell >> bit) & 1)
        return cell

    def set(self, addr: str, value) -> None:
        fd, words, elem, sub, bit = self._resolve(addr)
        if fd.kind in ("timer", "counter", "control"):
            cell = words[elem]
            if _member_kind(fd.kind, sub) == "bit":
                cell[sub] = bool(value)
            else:
                cell[sub] = int(value)
            return
        if bit is not None:
            word = words[elem]
            if value:
                word |= (1 << bit)
            else:
                word &= ~(1 << bit)
            words[elem] = word & 0xFFFF
            return
        if fd.kind == "float":
            words[elem] = float(value)
        else:
            words[elem] = int(value) & 0xFFFF if fd.kind != "int" else int(value)


def _member_kind(kind: str, sub: str | None) -> str:
    members = {"timer": _TIMER_MEMBERS, "counter": _COUNTER_MEMBERS,
               "control": _CONTROL_MEMBERS}[kind]
    return members.get((sub or "").upper(), "int")
