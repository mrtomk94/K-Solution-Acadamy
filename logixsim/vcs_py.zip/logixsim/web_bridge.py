"""Web bridge: REST + WebSocket access to a running Engine or virtual Chassis.

Every endpoint takes an optional ``slot`` (query param, JSON body field, or
WebSocket message field); without it the lowest occupied slot is used, so
single-controller clients work unchanged. Nested/array tag addresses work
directly (the web layer talks to TagDB).
"""
from __future__ import annotations

import asyncio
import os
import re

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from pydantic import BaseModel

from .chassis import Chassis

_PANEL = os.path.join(os.path.dirname(__file__), "panel", "index.html")
_EMU_PANEL = os.path.join(os.path.dirname(__file__), "panel", "emulator.html")
# pages are never cached, so a browser / app window always shows the version that runs
_NO_CACHE = {"Cache-Control": "no-store, max-age=0"}
_STUDIO = os.path.join(os.path.dirname(__file__), "panel", "studio.html")


class TagWrite(BaseModel):
    name: str
    value: object
    slot: int | None = None


def create_app(target) -> FastAPI:
    """target: an Emulator, a Chassis or an Engine. The v1 API serves the
    Emulator (or the lowest chassis slot wrapped in one)."""
    from .api import mount_v1
    from .emulator import Emulator
    if isinstance(target, Emulator):
        emu = target
        chassis = Chassis.single(emu.engine)
    else:
        chassis = target if isinstance(target, Chassis) else Chassis.single(target)
        emu = Emulator(name=chassis.name, engine=chassis.get(chassis.default_slot()))
    from . import APP_NAME
    app = FastAPI(title=APP_NAME)
    app.state.emulator = emu

    @app.middleware("http")
    async def same_site_only(request, call_next):
        from .api import origin_allowed
        if request.method not in ("GET", "HEAD", "OPTIONS") and request.url.path.startswith("/api") \
                and not origin_allowed(request, emu):
            return JSONResponse({"error": "cross-site request refused"}, status_code=403)
        return await call_next(request)

    mount_v1(app, emu)
    from .studio_api import mount_studio
    mount_studio(app, emu)

    @app.get("/studio")
    def studio_page():
        return FileResponse(_STUDIO, headers=_NO_CACHE)

    _JS_DIR = os.path.join(os.path.dirname(_STUDIO), "js")

    @app.get("/studio/js/{name}")
    def studio_js(name: str):
        """The Studio page's script modules (panel/js/*.js only)."""
        if not re.fullmatch(r"[a-z0-9_]+\.js", name):
            raise HTTPException(status_code=404, detail="not found")
        path = os.path.join(_JS_DIR, name)
        if not os.path.isfile(path):
            raise HTTPException(status_code=404, detail="not found")
        return FileResponse(path, media_type="text/javascript", headers=_NO_CACHE)

    def engine_for(slot: int | None):
        s = chassis.default_slot() if slot is None else slot
        eng = chassis.get(s) if s is not None else None
        if eng is None:
            raise HTTPException(status_code=404, detail=f"no controller in slot {slot}")
        return eng

    @app.get("/")
    def root():
        return RedirectResponse("/studio", status_code=307)

    @app.get("/panel")
    def panel():
        return FileResponse(_EMU_PANEL, headers=_NO_CACHE)

    @app.get("/classic")
    def classic_panel():
        return FileResponse(_PANEL, headers=_NO_CACHE)

    @app.get("/api/chassis")
    def chassis_info():
        return chassis.describe()

    @app.get("/api/state")
    def state(slot: int | None = None):
        return engine_for(slot).state()

    @app.get("/api/tags")
    def tags(slot: int | None = None):
        return {"tags": engine_for(slot).db.names()}

    @app.get("/api/tag")
    def read_tag(name: str, slot: int | None = None):
        eng = engine_for(slot)
        try:
            return {"name": name, "value": eng.db.get(name)}
        except Exception as exc:
            return JSONResponse({"error": str(exc)}, status_code=404)

    @app.post("/api/tag")
    def write_tag(body: TagWrite):
        engine_for(body.slot).queue_write(body.name, body.value)
        return {"ok": True, "name": body.name}

    @app.post("/api/run")
    def run(slot: int | None = None):
        eng = engine_for(slot)
        eng.start()
        return eng.state()

    @app.post("/api/stop")
    def stop(slot: int | None = None):
        eng = engine_for(slot)
        eng.stop()
        return eng.state()

    @app.post("/api/step")
    def step(slot: int | None = None):
        eng = engine_for(slot)
        eng.step()
        return eng.state()

    @app.websocket("/ws")
    async def ws(sock: WebSocket):
        from .api import origin_allowed
        if not origin_allowed(sock, emu):
            await sock.close(code=1008)
            return
        await sock.accept()
        watch: list[str] = []
        watch_slot: list[int | None] = [None]

        async def pump():
            while True:
                if watch:
                    try:
                        eng = engine_for(watch_slot[0])
                    except HTTPException:
                        await asyncio.sleep(0.1)
                        continue
                    values = {}
                    for n in watch:
                        try:
                            values[n] = eng.db.get(n)
                        except Exception:
                            values[n] = None
                    slot = chassis.default_slot() if watch_slot[0] is None else watch_slot[0]
                    await sock.send_json({"type": "update", "values": values,
                                          "scan": eng.scan_count, "slot": slot})
                await asyncio.sleep(0.1)

        pump_task = asyncio.create_task(pump())
        try:
            while True:
                msg = await sock.receive_json()
                cmd = msg.get("cmd")
                try:
                    eng = engine_for(msg.get("slot"))
                except HTTPException as exc:
                    await sock.send_json({"type": "error", "error": exc.detail})
                    continue
                if cmd == "watch":
                    watch[:] = msg.get("tags", [])
                    watch_slot[0] = msg.get("slot")
                elif cmd == "write":
                    eng.queue_write(msg["name"], msg["value"])
                elif cmd == "run":
                    eng.start()
                elif cmd == "stop":
                    eng.stop()
                elif cmd == "step":
                    eng.step()
        except WebSocketDisconnect:
            pass
        finally:
            pump_task.cancel()

    return app
