"""Validation service for the editors: a ladder rung or a Structured Text routine
is checked against the *live* project (the engine's tag database, data types,
routines, labels and Add-On Instructions) and the shared instruction specs
(logixsim/isa). Nothing here touches the UI or the program; the edit service
(logixsim/editing.py) calls it again before applying a change.

Each finding: {"severity": "error"|"warning", "kind", "message", "instr", "operand",
"pos"/"line"/"col"}. Errors block finalization; warnings do not.

Kinds: syntax, unknown_instruction, unsupported (documented but not executed by
VirtualControlStudio - a warning), language, operand_count, missing_operand, operand_syntax,
constant, unknown_tag, type, index, routine, label, structure, aoi.
"""
from __future__ import annotations

import re

from .isa import SPECS
from .isa.catalog import lookup
from .isa.expr import ExprError, parse as parse_expr, tags_in
from .isa.values import ALL_INT_BITS as INT_BITS, literal
from .model import STRING_TYPES, string_max
from .verify import _ATOMIC_TYPES, _WRITES             # shared "which operands are written"

SYSTEM = {"S:FS", "S:N", "S:Z", "S:V", "S:C", "S:MINOR"}
_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_ROOT = re.compile(r"(Program:[A-Za-z_][A-Za-z0-9_]*\.)?[A-Za-z_][A-Za-z0-9_]*(:[A-Za-z0-9_]+)*")


# ---------------------------------------------------------------------------------
# strict rung syntax
# ---------------------------------------------------------------------------------
class RungSyntaxError(Exception):
    def __init__(self, msg, pos):
        super().__init__(msg)
        self.pos = pos


def parse_rung_strict(text: str):
    """Parse neutral rung text; returns the series (same shape as ld_interp.parse_rung,
    plus a 4th element with the instruction's character position). Raises
    RungSyntaxError with a character position."""
    t = text.rstrip()
    end = len(t)
    if t.endswith(";"):
        end -= 1
    i = 0

    def ws(i):
        while i < end and t[i].isspace():
            i += 1
        return i

    def series(i, depth):
        items = []
        while True:
            i = ws(i)
            if i >= end:
                if depth:
                    raise RungSyntaxError("branch is not closed: missing ']'", i)
                return items, i
            c = t[i]
            if c in ",]":
                if not depth:
                    raise RungSyntaxError(f"unexpected '{c}' outside a branch", i)
                return items, i
            if c == "[":
                b, i = branch(i, depth)
                items.append(b)
            elif c == ";":
                raise RungSyntaxError("';' is only allowed at the end of the rung", i)
            else:
                ins, i = instr(i)
                items.append(ins)

    def branch(i, depth):
        start = i
        i += 1
        legs = []
        while True:
            leg, i = series(i, depth + 1)
            legs.append(leg)
            if i >= end:
                raise RungSyntaxError("branch is not closed: missing ']'", start)
            if t[i] == ",":
                i += 1
                continue
            i += 1                                 # ']'
            break
        if len(legs) < 2:
            raise RungSyntaxError("a branch needs at least two legs", start)
        return ("branch", legs, None, start), i

    def instr(i):
        m = _NAME.match(t, i)
        if not m:
            raise RungSyntaxError(f"expected an instruction name at {t[i:i + 10]!r}", i)
        start = i
        name = m.group()
        i = m.end()
        args = []
        if i < end and t[i] == "(":
            depth, j = 0, i
            while j < end:
                if t[j] == "(":
                    depth += 1
                elif t[j] == ")":
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            if j >= end:
                raise RungSyntaxError(f"{name}: missing ')'", start)
            raw = t[i + 1:j]
            if raw.count("[") != raw.count("]"):
                raise RungSyntaxError(f"{name}: unbalanced [ ] in operands", start)
            from .ld_interp import _split_args
            args = _split_args(raw) if raw.strip() else []
            if raw.strip() and raw.rstrip().endswith(","):
                args.append("")
            if raw.strip() and raw.lstrip().startswith(","):
                args.insert(0, "")
            i = j + 1
        return ("instr", name, args, start), i

    items, i = series(0, 0)
    i = ws(i)
    if i < end:
        raise RungSyntaxError(f"unexpected text {t[i:i + 10]!r}", i)
    return items


def flatten(series, out=None):
    out = [] if out is None else out
    for item in series:
        if item[0] == "branch":
            for leg in item[1]:
                flatten(leg, out)
        else:
            out.append(item)
    return out


# ---------------------------------------------------------------------------------
# tag paths
# ---------------------------------------------------------------------------------
class TagChecker:
    """Resolve and type tag references against the live TagDB (with program scope)."""

    def __init__(self, db, program: str | None):
        self.db = db
        self.program = program

    def _decl(self, name):
        """Declared spelling (names are not case sensitive); a program tag or
        program alias wins over a controller tag."""
        if self.program and not name.startswith("Program:"):
            local = f"Program:{self.program}.{name}"
            hit = self.db.find_root(local) or self.db.alias_key(local)
            if hit:
                return hit
        return self.db.find_root(name) or self.db.alias_key(name) or name

    def is_constant(self, text: str) -> bool:
        m = _ROOT.match(text.strip())
        return bool(m) and self.db.is_constant(self._decl(m.group()) + text.strip()[m.end():])

    def check(self, text: str):
        """(data type string | None, error message | None). Array references come
        back as 'DINT[5]'."""
        op = text.strip()
        if not op:
            return None, "empty operand"
        if op.upper().startswith("S:"):
            return ("BOOL" if op.upper() in SYSTEM else None), \
                (None if op.upper() in SYSTEM else f"unknown system value '{op}'")
        m = _ROOT.match(op)
        if not m:
            return None, f"'{op}' is not a valid tag reference"
        if ".@" in op:                                     # Tag.@Min / Tag.@Max
            base, prop = op.split(".@", 1)
            if prop.strip().lower() not in ("min", "max"):
                return None, f"'{op}': only @Min and @Max can be used in logic"
            if self.db.is_alias(self._decl(_ROOT.match(base).group()) if _ROOT.match(base) else base):
                return None, f"'{op}': extended properties of an alias tag cannot be used in logic"
            t, err = self.check(base)
            if err:
                return None, err
            if t not in ("SINT", "INT", "DINT", "LINT", "REAL"):
                return None, f"'{op}': limit properties need a SINT, INT, DINT, LINT or REAL tag"
            return t, None
        root = self._decl(m.group())
        rest = op[m.end():]
        if self.db.is_alias(root):                       # follow aliases (and chains)
            full = self.db.dealias(root + rest)
            m2 = _ROOT.match(full)
            if not m2 or self.db.is_alias(m2.group()):
                return None, f"alias '{root}' does not lead to a tag (alias loop?)"
            root, rest = self.db.find_root(m2.group()) or m2.group(), full[m2.end():]
        decl = self.db._decl.get(root)
        if decl is None:
            return None, f"tag '{m.group()}' does not exist"
        dtype, dim = decl.data_type, decl.dim or 0
        dims = tuple(getattr(decl, "dims", ()) or ((dim,) if dim else ()))
        i = 0
        shown = m.group()
        while i < len(rest):
            c = rest[i]
            if c == "[":
                j, depth = i + 1, 1
                while j < len(rest) and depth:
                    depth += {"[": 1, "]": -1}.get(rest[j], 0)
                    j += 1
                if depth:
                    return None, f"'{op}': missing ']'"
                inner = rest[i + 1:j - 1]
                if not dim:
                    return None, f"'{shown}' is not an array, so it cannot take [{inner}]"
                subs = _split_subscripts(inner)
                if len(subs) != max(1, len(dims)):
                    want = max(1, len(dims))
                    return None, (f"'{shown}' is declared {dtype}[{','.join(map(str, dims))}]: it "
                                  f"needs {want} subscript{'s' if want > 1 else ''}, not {len(subs)}")
                for k, sub in enumerate(subs):
                    size = dims[k] if dims else dim
                    lit = literal(sub)
                    if isinstance(lit, int):
                        if lit < 0 or lit >= size:
                            where = f" (dimension {k + 1})" if len(subs) > 1 else ""
                            return None, (f"index [{lit}] is out of range{where}: '{shown}' has "
                                          f"{size} elements (0..{size - 1})")
                    else:
                        err = self._index_expr(sub)
                        if err:
                            return None, f"index [{sub}] of '{shown}': {err}"
                shown += rest[i:j]
                dim, dims = 0, ()
                i = j
            elif c == ".":
                if dim:
                    return None, f"'{shown}' is an array: give an element index before '.'"
                if rest[i + 1:i + 2] == "[":                      # Word.[Bit]
                    j, depth = i + 2, 1
                    while j < len(rest) and depth:
                        depth += {"[": 1, "]": -1}.get(rest[j], 0)
                        j += 1
                    if dtype not in INT_BITS:
                        return None, f"'{shown}' is {dtype}; a bit index needs an integer"
                    err = self._index_expr(rest[i + 2:j - 1])
                    if err:
                        return None, err
                    shown += rest[i:j]
                    dtype, i = "BOOL", j
                    continue
                mm = re.match(r"\.([A-Za-z_][A-Za-z0-9_]*|\d+)", rest[i:])
                if not mm:
                    return None, f"'{op}': bad member after '{shown}'"
                name = mm.group(1)
                if name.isdigit():
                    bits = INT_BITS.get(dtype)
                    if bits is None:
                        return None, f"'{shown}' is {dtype}; only integers have numbered bits"
                    if int(name) >= bits:
                        return None, f"bit {name} does not exist: {dtype} has bits 0..{bits - 1}"
                    dtype = "BOOL"
                elif dtype in STRING_TYPES and name.upper() in ("LEN", "DATA"):
                    if name.upper() == "LEN":
                        dtype = "DINT"
                    else:
                        n = string_max(dtype)
                        dtype, dim, dims = "SINT", n, (n,)
                else:
                    t = self.db._types.get(dtype)
                    member = next((x for x in t.members if x.name.lower() == name.lower()), None) if t else None
                    if member is None:
                        return None, f"'{shown}' ({dtype}) has no member '{name}'"
                    dtype, dim = member.data_type, member.dim or 0
                    dims = (dim,) if dim else ()
                shown += mm.group()
                i += len(mm.group())
            else:
                return None, f"'{op}': unexpected '{c}'"
        if dim and len(dims) > 1:
            return f"{dtype}[{','.join(map(str, dims))}]", None
        return (f"{dtype}[{dim}]" if dim else dtype), None

    def _index_expr(self, inner: str) -> str | None:
        try:
            parse_expr(inner)
        except Exception as exc:
            return f"bad index expression: {exc}"
        for tag in tags_in(inner):
            t, err = self.check(tag)
            if err:
                return err
            base = t.split("[")[0]
            if base not in INT_BITS and base != "BOOL":
                return f"index tag '{tag}' is {t}; an index must be an integer"
        return None


def _split_subscripts(inner: str) -> list[str]:
    """'1,2' -> ['1', '2']; commas inside parentheses (function calls) do not split."""
    out, depth, cur = [], 0, ""
    for ch in inner:
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append(cur.strip())
            cur = ""
        else:
            cur += ch
    out.append(cur.strip())
    return out


# ---------------------------------------------------------------------------------
# rung validation
# ---------------------------------------------------------------------------------
def _issue(sev, kind, msg, instr=None, operand=None, pos=None):
    return {"severity": sev, "kind": kind, "message": msg, "instr": instr, "operand": operand,
            "pos": pos}


def _aoi(controller, name):
    for n, a in controller.aois.items():
        if n.upper() == name.upper():
            return a
    return None


def _type_ok(actual: str, allowed: tuple) -> bool:
    if not allowed:
        return True
    return actual in allowed or (actual in STRING_TYPES and "STRING" in allowed)


def _routine_labels(routine, skip_index=None):
    out = {}
    for n, text in enumerate(routine.rungs):
        if n == skip_index:
            continue
        try:
            items = flatten(parse_rung_strict(text))
        except Exception:
            continue
        if items and items[0][1].upper() == "LBL" and items[0][2]:
            out.setdefault(items[0][2][0].strip().upper(), n)
    return out


def validate_rung(engine, program: str, routine: str, text: str, index: int | None = None,
                  inserting: bool = False) -> dict:
    """Validate one rung's neutral text. ``index`` is the rung being replaced (or the
    insert position when ``inserting``), used for label checks."""
    from .ld_interp import rung_tree
    ctrl = engine.controller
    prog = ctrl.programs.get(program)
    rt = prog.routines.get(routine) if prog else None
    issues: list[dict] = []
    norm = text.strip()
    try:
        tree = parse_rung_strict(norm)
    except RungSyntaxError as exc:
        return {"ok": False, "issues": [_issue("error", "syntax", str(exc), pos=exc.pos)],
                "tree": None, "text": norm}
    items = flatten(tree)
    tags = TagChecker(engine.db, program)
    routines = prog.routines if prog else {}

    if not items:
        issues.append(_issue("warning", "structure", "the rung is empty"))
    other_labels = _routine_labels(rt, None if inserting else index) if rt else {}

    for iid, (_, name, args, pos) in enumerate(items):
        up = name.upper()
        spec = SPECS.get(up)
        aoi = _aoi(ctrl, name) if spec is None else None
        if spec is None and aoi is None:
            entry = lookup(name)
            if entry and entry["status"] in ("missing", "unsupported"):
                issues.append(_issue("warning", "unsupported",
                                     f"{name} is a Logix instruction that VirtualControlStudio does not "
                                     f"execute ({entry['reason']}); the rung will be reported "
                                     "as not executed", iid, pos=pos))
            else:
                issues.append(_issue("error", "unknown_instruction",
                                     f"'{name}' is not a known instruction or Add-On "
                                     "Instruction", iid, pos=pos))
            continue
        if aoi is not None:
            _check_aoi(issues, tags, aoi, args, iid)
            continue
        if "LD" not in spec.languages:
            issues.append(_issue("error", "language",
                                 f"{spec.mnemonic} is not available in ladder "
                                 f"(languages: {', '.join(spec.languages)})", iid, pos=pos))
            continue
        if up == "LBL":
            if iid != 0:
                issues.append(_issue("error", "structure",
                                     "LBL must be the first instruction on its rung", iid))
            elif args and args[0].strip().upper() in other_labels:
                issues.append(_issue("error", "label",
                                     f"label {args[0].strip()} already exists on rung "
                                     f"{other_labels[args[0].strip().upper()]}", iid, 0))
        _check_operands(issues, spec, args, iid, tags, routines, other_labels, items)

    has_effect = any(SPECS.get(n.upper()) is None or
                     (SPECS[n.upper()].kind == "action" and n.upper() != "ONS")
                     for _, n, _, _ in items)
    if items and not has_effect:
        issues.append(_issue("warning", "structure",
                             "the rung has no output instruction, so it has no effect"))
    try:
        jtree = rung_tree(norm) if items else []
    except Exception:
        jtree = None
    errors = [x for x in issues if x["severity"] == "error"]
    return {"ok": not errors, "issues": issues, "tree": jtree, "text": norm}


def _check_aoi(issues, tags, aoi, args, iid):
    params = aoi.call_params()
    if len(args) != len(params) + 1:
        issues.append(_issue("error", "operand_count",
                             f"{aoi.name} needs the instance tag and {len(params)} argument(s) "
                             f"({', '.join(p.name for p in params) or 'none'}); it has "
                             f"{max(0, len(args) - 1)}", iid))
    if args:
        t, err = tags.check(args[0])
        if err:
            issues.append(_issue("error", "unknown_tag", err, iid, 0))
        elif t != aoi.name:
            issues.append(_issue("error", "type",
                                 f"instance tag '{args[0]}' is {t}; it must be a {aoi.name}",
                                 iid, 0))
    for k, (p, a) in enumerate(zip(params, args[1:]), start=1):
        if not a.strip() or a.strip() == "?":
            issues.append(_issue("error", "missing_operand", f"{p.name} is required", iid, k))
            continue
        if literal(a) is not None:
            if p.usage != "Input":
                issues.append(_issue("error", "constant",
                                     f"{p.name} ({p.usage}) needs a tag, not a constant", iid, k))
            continue
        t, err = tags.check(a)
        if err:
            issues.append(_issue("error", "unknown_tag", err, iid, k))
        elif p.usage == "InOut" and t != (f"{p.data_type}[{p.dim}]" if p.dim else p.data_type):
            issues.append(_issue("error", "type", f"{p.name} is an InOut {p.data_type}; "
                                                  f"'{a}' is {t}", iid, k))


def _check_operands(issues, spec, args, iid, tags, routines, labels, items):
    n = len(args)
    lo, hi = spec.min_args(), spec.max_args()
    if n < lo:
        for k in range(n, lo):
            issues.append(_issue("error", "missing_operand",
                                 f"{spec.mnemonic}: operand {spec.operands[k].name} is missing",
                                 iid, k))
    if hi is not None and n > hi:
        issues.append(_issue("error", "operand_count",
                             f"{spec.mnemonic} takes at most {hi} operand(s); it has {n}", iid))
    for k, a in enumerate(args):
        if not spec.operands:
            break
        od = spec.operands[min(k, len(spec.operands) - 1)]
        a = a.strip()
        if a in ("", "?"):
            if not (od.optional or od.repeat or od.kind == "imm"):
                issues.append(_issue("error", "missing_operand",
                                     f"{spec.mnemonic}: {od.name} is required", iid, k))
            continue
        if od.kind == "routine":
            if a not in routines:
                issues.append(_issue("error", "routine",
                                     f"routine '{a}' does not exist in this program", iid, k))
            continue
        if od.kind == "label":
            if not _NAME.fullmatch(a):
                issues.append(_issue("error", "operand_syntax", f"'{a}' is not a valid label name",
                                     iid, k))
            elif spec.mnemonic == "JMP":
                here = items and items[0][1].upper() == "LBL" and items[0][2] and \
                    items[0][2][0].strip().upper() == a.upper()
                if a.upper() not in labels and not here:
                    issues.append(_issue("error", "label",
                                         f"no rung in this routine starts with LBL({a})", iid, k))
            continue
        if od.kind in ("expr", "elem"):
            text = ",".join(args[k:]) if od.kind == "expr" and k == len(spec.operands) - 1 else a
            try:
                parse_expr(text)
            except (ExprError, SyntaxError) as exc:
                issues.append(_issue("error", "operand_syntax",
                                     f"{od.name}: {exc}", iid, k))
                continue
            for tag in tags_in(text):
                if tag.upper().startswith("S:"):
                    continue
                _, err = tags.check(tag)
                if err:
                    issues.append(_issue("error", "unknown_tag", f"{od.name}: {err}", iid, k))
            if od.kind == "expr" and k == len(spec.operands) - 1:
                break
            continue
        if od.kind == "imm":
            continue
        if literal(a) is not None:
            if od.kind in ("tag", "dest"):
                issues.append(_issue("error", "constant",
                                     f"{spec.mnemonic}: {od.name} must be a tag, not the constant "
                                     f"{a}", iid, k))
            continue
        t, err = tags.check(a)
        if err:
            kind = "index" if "index" in err or "range" in err else "unknown_tag"
            issues.append(_issue("error", kind, f"{od.name}: {err}", iid, k))
            continue
        written = od.kind == "dest" or k in _WRITES.get(spec.mnemonic, ()) or (
            od.kind == "tag" and od.types and not set(od.types) & _ATOMIC_TYPES)
        if written and ".@" in a:
            issues.append(_issue("error", "constant", f"{spec.mnemonic}: '{a}' is an extended "
                                 "property; logic cannot write it", iid, k))
            continue
        if written and tags.is_constant(a):
            issues.append(_issue("error", "constant", f"{spec.mnemonic}: '{a}' is a constant tag; "
                                 "logic cannot change it", iid, k))
            continue
        if t and od.types and not _type_ok(t, od.types):
            issues.append(_issue("error", "type",
                                 f"{spec.mnemonic}: {od.name} must be {'/'.join(od.types)}; "
                                 f"'{a}' is {t}", iid, k))


# ---------------------------------------------------------------------------------
# Structured Text validation
# ---------------------------------------------------------------------------------
def _line_col(src: str, offset: int):
    line = src.count("\n", 0, offset) + 1
    col = offset - (src.rfind("\n", 0, offset) + 1) + 1
    return line, col


def validate_st(engine, program: str, text: str) -> dict:
    from .st_interp import ST_FUNCTIONS, STSyntaxError, _Parser, tokenize
    issues: list[dict] = []
    positions: list[int] = []

    def at(tok_index, sev, kind, msg):
        off = positions[min(tok_index, len(positions) - 1)] if positions else 0
        line, col = _line_col(text, off)
        issues.append({"severity": sev, "kind": kind, "message": msg, "line": line, "col": col})

    # a Structured Text line holds at most 2048 characters (Logix Designer's limit)
    long_lines = [(n, len(l)) for n, l in enumerate(text.split("\n"), 1) if len(l) > 2048]
    if long_lines:
        return {"ok": False, "issues": [{"severity": "error", "kind": "syntax", "line": n, "col": 2049,
                                         "message": f"line {n} has {k} characters; a line can hold at most 2048"}
                                        for n, k in long_lines]}
    try:
        toks = tokenize(text, positions)
    except STSyntaxError as exc:
        line, col = _line_col(text, exc.offset_)
        return {"ok": False, "issues": [{"severity": "error", "kind": "syntax",
                                         "message": str(exc), "line": line, "col": col}]}
    parser = _Parser(toks)
    try:
        ast = parser.block()
        if parser.peek()[0] != "eof":
            raise SyntaxError(f"unexpected '{parser.peek()[1]}' (missing END_IF / END_FOR ...?)")
    except SyntaxError as exc:
        at(parser.p, "error", "syntax", str(exc))
        return {"ok": False, "issues": issues}

    tags = TagChecker(engine.db, program)
    ctrl = engine.controller

    def path_text(node):
        out = ""
        for i, (kind, val) in enumerate(node[1]):
            if kind == "name":
                out += ("." if i else "") + val
            elif kind == "bit":
                out += ".0"
            else:
                subs = val if kind == "idxn" else [val]
                out += "[" + ",".join("0" if e[0] != "num" else str(e[1]) for e in subs) + "]"
        return out

    def check_expr(node):
        k = node[0]
        if k == "path":
            for kind, val in node[1]:
                if kind in ("idx", "bit"):
                    check_expr(val)
                elif kind == "idxn":
                    for e in val:
                        check_expr(e)
            t, err = tags.check(path_text(node))
            if err:
                at(node[2], "error", "unknown_tag" if "exist" in err or "member" in err
                   else "index", err)
            return t
        if k in ("neg", "not"):
            return check_expr(node[1])
        if k == "bin":
            check_expr(node[2])
            check_expr(node[3])
            return None
        if k == "fn":
            for a in node[2]:
                check_expr(a)
            return "REAL"
        return None

    def walk(body):
        for node in body:
            k = node[0]
            if k == "assign":
                t = check_expr(node[1])
                check_expr(node[2])
                if node[1][0] == "path" and tags.is_constant(path_text(node[1])):
                    at(node[1][2], "error", "constant",
                       f"'{path_text(node[1])}' is a constant tag; logic cannot change it")
                if t and node[2][0] == "str" and t not in STRING_TYPES:
                    at(node[1][2], "error", "type", f"cannot assign a string to {t}")
                if t in STRING_TYPES and node[2][0] == "num":
                    at(node[1][2], "error", "type", "cannot assign a number to a STRING")
                if t and "[" in t:
                    at(node[1][2], "error", "type", f"cannot assign to a whole array ({t})")
            elif k == "call":
                name, args = node[1], node[2]
                spec = SPECS.get(name.upper())
                aoi = _aoi(ctrl, name) if spec is None else None
                if name.upper() in ST_FUNCTIONS:
                    at(node[3], "error", "structure",
                       f"{name} is a function: use it in an expression (x := {name}(...);)")
                elif spec is None and aoi is None:
                    entry = lookup(name)
                    if entry and entry["status"] in ("missing", "unsupported"):
                        at(node[3], "warning", "unsupported",
                           f"{name} is not executed by VirtualControlStudio ({entry['reason']})")
                    else:
                        at(node[3], "error", "unknown_instruction",
                           f"'{name}' is not a known instruction or Add-On Instruction")
                elif spec is not None:
                    if "ST" not in spec.languages:
                        at(node[3], "error", "language",
                           f"{spec.mnemonic} is not available in Structured Text")
                    lo, hi = spec.min_args(), spec.max_args()
                    if len(args) < lo or (hi is not None and len(args) > hi):
                        at(node[3], "error", "operand_count",
                           f"{spec.mnemonic} needs {lo}{'' if hi == lo else '..' + str(hi or 'n')}"
                           f" operand(s); it has {len(args)}")
                elif aoi is not None and len(args) != len(aoi.call_params()) + 1:
                    at(node[3], "error", "operand_count",
                       f"{aoi.name} needs the instance tag and {len(aoi.call_params())} "
                       f"argument(s); it has {max(0, len(args) - 1)}")
                for i, a in enumerate(args):
                    od = spec.operands[min(i, len(spec.operands) - 1)] if spec is not None and spec.operands else None
                    if od is not None and od.kind == "routine":
                        # JSR(RoutineName, ...): a routine of this program, not a tag
                        rname = path_text(a) if a[0] == "path" else None
                        prog_obj = ctrl.programs.get(program) if ctrl else None
                        if rname is None or "." in rname or "[" in rname:
                            at(node[3], "error", "routine", f"{spec.mnemonic}: the first operand must be a routine name")
                        elif prog_obj is not None and rname not in prog_obj.routines and \
                                rname.lower() not in {r.lower() for r in prog_obj.routines}:
                            at(node[3], "error", "routine", f"routine '{rname}' does not exist in program {program}")
                        continue
                    check_expr(a)
            elif k == "if":
                for cond, b in node[1]:
                    check_expr(cond)
                    walk(b)
                if node[2]:
                    walk(node[2])
            elif k == "case":
                check_expr(node[1])
                for _, b in node[2]:
                    walk(b)
                if node[3]:
                    walk(node[3])
            elif k == "for":
                t = check_expr(node[1])
                if t and t not in INT_BITS and t != "REAL":
                    at(node[1][2], "error", "type", f"FOR index must be numeric, not {t}")
                for e in node[2:5]:
                    check_expr(e)
                walk(node[5])
            elif k == "while":
                check_expr(node[1])
                walk(node[2])
            elif k == "repeat":
                walk(node[1])
                check_expr(node[2])

    walk(ast)
    return {"ok": not any(x["severity"] == "error" for x in issues), "issues": issues}
