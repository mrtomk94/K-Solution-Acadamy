"""Browser host for VirtualControlStudio (Pyodide).

No threads in WebAssembly: the scan engine and the event bus are driven by
``tick()``, which the page calls on a timer. HTTP and WebSocket calls from the
Studio page are dispatched in-process to the same FastAPI routes the desktop
build serves."""
import asyncio
import os
import threading
import time


class _NoThread:
    """threading.Thread replacement: start() records the target but never runs it
    (the page's timer drives the loops instead)."""
    def __init__(self, target=None, args=(), kwargs=None, name=None, daemon=None, **kw):
        self._target, self._alive = target, False
        self.name, self.daemon = name, daemon

    def start(self):
        self._alive = True

    def join(self, timeout=None):
        self._alive = False

    def is_alive(self):
        return self._alive


class _NoTimer(_NoThread):
    def __init__(self, interval, function, args=None, kwargs=None):
        super().__init__(function)

    def cancel(self):
        pass


threading.Thread = _NoThread
threading.Timer = _NoTimer

try:
    _loop = asyncio.get_event_loop()
    if not hasattr(_loop, "call_soon_threadsafe") or True:
        _orig = getattr(_loop, "call_soon_threadsafe", None)

        def _cst(cb, *a, **kw):
            return _loop.call_soon(cb, *a)
        _loop.call_soon_threadsafe = _cst
except Exception:  # noqa: BLE001
    pass

from logixsim.emulator import Emulator          # noqa: E402
from logixsim.web_bridge import create_app      # noqa: E402

os.makedirs("/home/pyodide/projects", exist_ok=True)
os.chdir("/home/pyodide/projects")

EMU = Emulator(name="VirtualControlStudio")
EMU.settings.setdefault("web", {})["bind_host"] = "127.0.0.1"
EMU.settings["web"]["allowed_origins"] = ["*"]
APP = create_app(EMU)
EMU.start(run=False)

_state = {"last": None, "pub": 0.0, "win_wall": None, "win_sim": 0.0}


def tick():
    """Advance the controller to wall time (called every ~10 ms by the page)."""
    eng = EMU.engine
    now = time.perf_counter()
    if eng.running and eng.mode == "RUN":
        last = _state["last"] or now
        if eng.timing == "exact":
            # periodic tasks: run every due scan up to wall time, within a time budget
            deadline = now + 0.012
            if _state["win_wall"] is None:
                _state["anchor"] = (now, eng.sim_time)
                eng._cont_due = eng.sim_time
            aw, asim = _state.get("anchor", (now, eng.sim_time))
            wall_sim = asim + (now - aw)
            n = 0
            while time.perf_counter() < deadline:
                nxt = max(eng._next_due(), eng.sim_time)
                if nxt > wall_sim:
                    break
                eng.sim_time = nxt
                eng.scan_once(eng.sim_time)
                n += 1
                if eng.mode == "FAULTED":
                    eng.running = False
                    break
            if wall_sim - eng.sim_time > 0.25:          # behind: do not catch up later
                _state["anchor"] = (now, eng.sim_time)
        else:
            eng.sim_time += min(now - last, 5.0)
            eng.scan_once(eng.sim_time)
            if eng.mode == "FAULTED":
                eng.running = False
        if _state["win_wall"] is None:
            _state["win_wall"], _state["win_sim"] = now, eng.sim_time
        elif now - _state["win_wall"] >= 1.0:
            rate = (eng.sim_time - _state["win_sim"]) / (now - _state["win_wall"])
            eng.speed = round(min(rate, 1.0) if eng.timing == "exact" else rate, 4)
            _state["win_wall"], _state["win_sim"] = now, eng.sim_time
    else:
        _state["win_wall"] = None
        _state.pop("anchor", None)
    _state["last"] = now
    if now - _state["pub"] >= EMU.bus.interval:
        _state["pub"] = now
        try:
            EMU.bus.publish_now()
        except Exception:  # noqa: BLE001
            import traceback
            traceback.print_exc()


def _bytes(x):
    if x is None:
        return b""
    if hasattr(x, "to_py"):
        x = x.to_py()
    if isinstance(x, (memoryview, bytearray)):
        return bytes(x)
    return x if isinstance(x, bytes) else bytes(x)


def _dict(x):
    if hasattr(x, "to_py"):
        x = x.to_py()
    return dict(x or {})


async def http(method, path, qs, headers, body):
    hdrs = _dict(headers)
    b = _bytes(body)
    st, ct, data, extra = await APP.handle(method, path, qs, hdrs, b)
    if isinstance(data, str):
        data = data.encode("utf-8")
    return [st, ct, data, extra]


def ws_open(path, qs, send_js):
    return APP.open_ws(path, qs, send_js)


def load_l5x(data, filename):
    """Load an L5X (bytes) as the open project."""
    from logixsim.l5x_loader import load_string
    raw = _bytes(data)
    ctrl = load_string(raw)
    if EMU.engine.running:
        EMU.halt()
    EMU.load_controller(ctrl, logic_file=filename, source=raw)
    return ctrl.name


def _plain(v):
    import math
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return None
    if isinstance(v, dict):
        return {k: _plain(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_plain(x) for x in v]
    return v


def bridge(write, read):
    """3D Lab / HMI Lab <-> this soft PLC: write field inputs, read outputs.
    Tags this project does not have are skipped."""
    import json
    st = EMU.store
    w = _dict(write)
    r = read.to_py() if hasattr(read, "to_py") else list(read or [])
    for name, v in w.items():
        if not st._has(name.split(".")[0].split("[")[0]):
            continue
        try:
            st.write(name, v, source="api:3dlab")
        except Exception:  # noqa: BLE001
            pass
    vals = {}
    for name in r:
        try:
            if st._has(name):
                vals[name] = _plain(st.read(name))
        except Exception:  # noqa: BLE001
            pass
    eng = EMU.engine
    return json.dumps({"values": vals, "project": EMU.name, "mode": eng.mode})
