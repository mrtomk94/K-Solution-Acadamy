"""Tiny pydantic stand-in for the browser build."""


class BaseModel:
    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)
        for k in getattr(self, "__annotations__", {}):
            if not hasattr(self, k):
                setattr(self, k, None)
