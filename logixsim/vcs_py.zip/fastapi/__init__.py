"""In-process FastAPI stand-in for the browser build of VirtualControlStudio.

Supports exactly what logixsim's web layer uses: APIRouter/FastAPI route
decorators, path/query/body parameter binding by signature, Request,
Query, HTTPException, JSONResponse/Response and WebSocket endpoints. Requests
are dispatched in-process by ``FastAPI.handle`` (called from JavaScript)."""
from __future__ import annotations

import asyncio
import dataclasses
import inspect
import json
import math
import re
from types import SimpleNamespace
from urllib.parse import parse_qs

from .responses import JSONResponse, Response, FileResponse, RedirectResponse  # noqa: F401


class HTTPException(Exception):
    def __init__(self, status_code: int = 500, detail=None, headers=None):
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


class WebSocketDisconnect(Exception):
    def __init__(self, code: int = 1000):
        super().__init__(code)
        self.code = code


class _Query:
    def __init__(self, default=None, **kw):
        self.default = default


def Query(default=None, **kw):
    return _Query(default, **kw)


class _Headers(dict):
    def get(self, k, d=None):
        return super().get(str(k).lower(), d)


class _QP:
    def __init__(self, qs: str):
        self._d = parse_qs(qs or "", keep_blank_values=True)

    def get(self, k, d=None):
        v = self._d.get(k)
        return v[-1] if v else d

    def getlist(self, k):
        return list(self._d.get(k, []))

    def __contains__(self, k):
        return k in self._d


class Request:
    def __init__(self, method, path, qs, headers, body: bytes):
        self.method = method
        self.url = SimpleNamespace(path=path, query=qs)
        self.headers = _Headers({str(k).lower(): v for k, v in (headers or {}).items()})
        self.query_params = _QP(qs)
        self._body = body or b""
        self.state = SimpleNamespace()

    async def body(self):
        return self._body

    async def json(self):
        return json.loads(self._body or b"null")


def _clean(o):
    if isinstance(o, float):
        return None if (math.isnan(o) or math.isinf(o)) else o
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple, set, frozenset)):
        return [_clean(v) for v in o]
    if dataclasses.is_dataclass(o) and not isinstance(o, type):
        return _clean(dataclasses.asdict(o))
    if isinstance(o, bytes):
        return o.decode("utf-8", "replace")
    if hasattr(o, "__dict__") and not isinstance(o, (str, int, bool)) and o is not None:
        return _clean({k: v for k, v in vars(o).items() if not k.startswith("_")})
    return o


def dumps(o) -> str:
    return json.dumps(_clean(o), allow_nan=False, default=str)


def _compile(path: str):
    rx, conv = "", {}
    pos = 0
    for m in re.finditer(r"\{(\w+)(?::(\w+))?\}", path):
        rx += re.escape(path[pos:m.start()])
        rx += "(?P<%s>.+)" % m.group(1) if m.group(2) == "path" else "(?P<%s>[^/]+)" % m.group(1)
        pos = m.end()
    rx += re.escape(path[pos:])
    return re.compile("^" + rx + "$")


class _Route:
    def __init__(self, method, path, fn, status_code=200):
        self.method, self.path, self.fn, self.status_code = method, path, fn, status_code
        self.rx = _compile(path)
        self.sig = inspect.signature(fn)


def _conv(ann: str, v):
    a = (ann or "").replace(" ", "")
    if v is None:
        return None
    if a.startswith("int"):
        return int(v)
    if a.startswith("float"):
        return float(v)
    if a.startswith("bool"):
        return str(v).lower() in ("1", "true", "yes", "on")
    return v


class APIRouter:
    def __init__(self, prefix: str = "", **kw):
        self.prefix = prefix
        self.routes: list[_Route] = []
        self.ws_routes: list[_Route] = []

    def _add(self, method, path, status_code=200, **kw):
        def deco(fn):
            self.routes.append(_Route(method, self.prefix + path, fn, status_code))
            return fn
        return deco

    def get(self, path, **kw):
        return self._add("GET", path, **kw)

    def post(self, path, **kw):
        return self._add("POST", path, **kw)

    def put(self, path, **kw):
        return self._add("PUT", path, **kw)

    def patch(self, path, **kw):
        return self._add("PATCH", path, **kw)

    def delete(self, path, **kw):
        return self._add("DELETE", path, **kw)

    def websocket(self, path, **kw):
        def deco(fn):
            self.ws_routes.append(_Route("WS", self.prefix + path, fn))
            return fn
        return deco

    def include_router(self, r: "APIRouter", **kw):
        self.routes.extend(r.routes)
        self.ws_routes.extend(r.ws_routes)


class FastAPI(APIRouter):
    def __init__(self, **kw):
        super().__init__()
        self.state = SimpleNamespace()

    def middleware(self, kind):
        def deco(fn):
            return fn          # same-site middleware: not needed in-process
        return deco

    def on_event(self, kind):
        return lambda fn: fn

    # ---- dispatch ------------------------------------------------------------
    def _find(self, routes, method, path):
        allowed = False
        for r in routes:
            m = r.rx.match(path)
            if m:
                if r.method == method or (method == "HEAD" and r.method == "GET"):
                    return r, m.groupdict()
                allowed = True
        return None, allowed

    async def handle(self, method: str, path: str, qs: str, headers: dict, body: bytes):
        """-> (status, content_type, body bytes or str, extra headers)"""
        method = method.upper()
        req = Request(method, path, qs, headers, body)
        r, pp = self._find(self.routes, method, path)
        if r is None:
            return (405 if pp else 404, "application/json", dumps({"detail": "Not Found"}), {})
        try:
            kw = {}
            for name, p in r.sig.parameters.items():
                ann = p.annotation if isinstance(p.annotation, str) else getattr(p.annotation, "__name__", "")
                if name in pp:
                    kw[name] = _conv(ann, pp[name])
                elif "Request" in ann or name == "request":
                    kw[name] = req
                elif ann.startswith("dict") or name == "body" or ann in ("TagWrite",) or "BaseModel" in ann:
                    data = json.loads(body) if body else None
                    if ann == "TagWrite":
                        from pydantic import BaseModel
                        o = BaseModel(**(data or {}))
                        kw[name] = o
                    else:
                        if data is None and p.default is inspect.Parameter.empty:
                            return (422, "application/json", dumps({"detail": "body required"}), {})
                        kw[name] = data if data is not None else p.default
                elif isinstance(p.default, _Query) or ann.startswith("list"):
                    vals = req.query_params.getlist(name)
                    d = p.default.default if isinstance(p.default, _Query) else p.default
                    kw[name] = vals if vals else (list(d) if isinstance(d, list) else d)
                else:
                    v = req.query_params.get(name)
                    if v is None:
                        if p.default is inspect.Parameter.empty:
                            return (422, "application/json",
                                    dumps({"detail": f"missing query parameter {name}"}), {})
                        kw[name] = p.default
                    else:
                        kw[name] = _conv(ann, v)
            res = r.fn(**kw)
            if inspect.isawaitable(res):
                res = await res
        except HTTPException as exc:
            return (exc.status_code, "application/json", dumps({"detail": exc.detail}), {})
        except Exception as exc:  # noqa: BLE001
            import traceback
            traceback.print_exc()
            return (500, "application/json", dumps({"error": f"{type(exc).__name__}: {exc}"}), {})
        if isinstance(res, Response):
            return (res.status_code, res.media_type, res.body, dict(res.headers))
        return (r.status_code, "application/json", dumps(res), {})

    def open_ws(self, path: str, qs: str, send_js):
        """Start a WebSocket endpoint. send_js(text) delivers to the page; returns the
        socket so JS can push incoming frames with ``sock.feed(text)``."""
        r, pp = self._find(self.ws_routes, "WS", path)
        if r is None:
            return None
        sock = WebSocket(path, qs, send_js)
        sock._task = asyncio.ensure_future(r.fn(sock))
        return sock


class WebSocket:
    def __init__(self, path, qs, send_js):
        self.headers = _Headers({})
        self.query_params = _QP(qs)
        self.url = SimpleNamespace(path=path, query=qs)
        self._in: asyncio.Queue = asyncio.Queue()
        self._send = send_js
        self.closed = False

    async def accept(self, *a, **kw):
        return None

    def feed(self, text):
        self._in.put_nowait(text)

    def disconnect(self):
        self.closed = True
        self._in.put_nowait(None)

    async def receive_text(self):
        t = await self._in.get()
        if t is None:
            raise WebSocketDisconnect(1000)
        return t

    async def receive_json(self):
        return json.loads(await self.receive_text())

    async def send_text(self, text):
        if self.closed:
            raise WebSocketDisconnect(1000)
        self._send(text)

    async def send_json(self, obj):
        await self.send_text(dumps(obj))

    async def close(self, code=1000):
        self.closed = True
        self._send(None)
