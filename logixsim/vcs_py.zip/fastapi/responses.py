class Response:
    media_type = "text/plain"

    def __init__(self, content=None, status_code: int = 200, headers=None, media_type=None, **kw):
        self.status_code = status_code
        self.headers = dict(headers or {})
        if media_type:
            self.media_type = media_type
        self.body = self.render(content)

    def render(self, content):
        if content is None:
            return b""
        return content if isinstance(content, (bytes, str)) else str(content)


class JSONResponse(Response):
    media_type = "application/json"

    def render(self, content):
        from . import dumps
        return dumps(content)


class FileResponse(Response):
    def __init__(self, path, media_type=None, headers=None, **kw):
        with open(path, "rb") as fh:
            data = fh.read()
        super().__init__(data, media_type=media_type or "text/html", headers=headers)


class RedirectResponse(Response):
    def __init__(self, url, status_code=307, **kw):
        super().__init__(b"", status_code=status_code, headers={"location": url})
