"""Minimal lxml.etree stand-in for the browser build (xml.etree underneath).
Covers what l5x_loader / l5x_writer use: XMLParser, fromstring, Element,
SubElement, CDATA, tostring, _Element."""
import sys as _sys
# pure-Python ElementTree so lxml-only methods can be added to Element
for _m in ("xml.etree.ElementTree", "xml.etree.cElementTree"):
    _sys.modules.pop(_m, None)
_sys.modules["_elementtree"] = None
import xml.etree.ElementTree as _ET
del _sys.modules["_elementtree"]


def _replace(self, old, new):
    self[list(self).index(old)] = new


def _getparent(self):
    return None


_ET.Element.replace = _replace
from xml.sax.saxutils import escape as _esc, quoteattr as _qa

_Element = _ET.Element
Element = _ET.Element
SubElement = _ET.SubElement


class CDATA(str):
    pass


class XMLParser:
    def __init__(self, **kw):
        self.kw = kw


class _TB(_ET.TreeBuilder):
    pass


def fromstring(data, parser=None):
    if isinstance(data, str):
        data = data.encode("utf-8")
    # refuse DOCTYPE/ENTITY (same intent as the hardened lxml parser)
    head = data[:4096].upper()
    if b"<!ENTITY" in head or b"<!DOCTYPE" in head:
        raise ValueError("DOCTYPE/ENTITY not allowed in L5X")
    p = _ET.XMLParser(target=_ET.TreeBuilder(insert_comments=False, insert_pis=False))
    p.feed(data)
    return p.close()


def _ser(el, out):
    if not isinstance(el.tag, str):
        return
    out.append("<" + el.tag)
    for k, v in el.attrib.items():
        out.append(" %s=%s" % (k, _qa(str(v))))
    kids = list(el)
    t = el.text
    if t is None and not kids:
        out.append("/>")
    else:
        out.append(">")
        if t is not None:
            if isinstance(t, CDATA):
                out.append("<![CDATA[" + str(t).replace("]]>", "]]]]><![CDATA[>") + "]]>")
            else:
                out.append(_esc(t))
        for k in kids:
            _ser(k, out)
        out.append("</" + el.tag + ">")
    if el.tail:
        out.append(_esc(el.tail))


def tostring(root, xml_declaration=False, encoding=None, standalone=None, pretty_print=False, **kw):
    out = []
    if xml_declaration:
        sa = ' standalone="yes"' if standalone else ""
        out.append('<?xml version="1.0" encoding="%s"%s?>\n' % (encoding or "UTF-8", sa))
    _ser(root, out)
    s = "".join(out)
    if encoding and str(encoding).lower() == "unicode":
        return s
    return s.encode("utf-8")
